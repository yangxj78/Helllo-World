/*
 * Project Name: webService
 * File Name: DateTimeUtil.java
 * Class Name: DateTimeUtil
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.common.util;

import com.hengtiansoft.common.constant.MagicNumConstant;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Class Name: DateTimeUtil Description: date time
 * 
 * @author qianqianzhu
 *
 */
public final class DateTimeUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger(DateTimeUtil.class);

    public static final int DEFAULT_HOUR = 23;
    public static final int START = 1900;

    public static final int DEFAULT_MINUTE = 59;

    public static final int DEFAULT_SENCEND = 0;

    public static final int START_HOUR = 0;

    public static final int FREE_START_HOUR = 9;

    public static final int START_MINUTE = 0;

    public static final int START_SENCEND = 0;

    public static final String SIMPLE_FMT = "yyyy-MM-dd HH:mm:ss";
    
    public static final String SIMPLE_FMT_NEW = "yyyy/MM/dd HH:mm:ss";

    public static final String SIMPLE_FMT_MINUTE = "yyyy-MM-dd HH:mm";

    public static final String SIMPLE_YMD = "yyyy-MM-dd";

    public static final String SIMPLE_YM = "yyyy-MM";

    public static final String SIMPLE_Y = "yyyy";

    public static final String SIMPLE_M = "MM";

    public static final String SIMPLE_D = "dd";

    public static final String SIMPLE_MD = "MM-dd";

    public static final String SIMPLE_MILLS = "yyyyMMddHHmmssSSS";

    public static final String SIMPLE_SECONDS = "yyyyMMddHHmmss";

    public static final String SIMPLE_FMT_MILLS = "yyyy-MM-dd HH:mm:ss：SSS";

    public static final String EN_FORMAT = "EEE MMM dd HH:mm:ss zzz yyyy";

    public static final String MONTH_DAY_FORMAT = "MMdd";

    public static final String SIMPLE_DATE_YMD = "yyyyMMdd";

    public static final String SIMPLE_DATE_YM = "yyyyMM";

    public static final String SIMPLE_TIME_HMS = "HHmmss";

    public static final String CHINA_YMD = "yyyy年MM月dd日";

    public static final String CHINA_YMDHMS = "yyyy年MM月dd日HH时mm分ss秒";

    private DateTimeUtil() {

    }

    /**
     * 时间转换Date to String
     *
     * @param date
     * @param sFmt
     *            转换的时间模式:yyyy-MM-dd
     * @return
     */
    public static String parseDateToString(Date date, String sFmt) {
        return date == null ? null : new SimpleDateFormat(sFmt).format(date);
    }

    public static SimpleDateFormat getSimpleFormatTimeAll() {
        return new SimpleDateFormat(SIMPLE_FMT);
    }

    /**
     * Description:传入Date类型日期转换为String类型
     * 
     * @param date
     * @return
     */
    public static String dateFormat(Date date) {
        return parseDateToString(date, SIMPLE_FMT);
    }

    

    /**
     * Description:传入Date类型日期转换为String类型
     * 
     * @param date
     * @return
     */
    public static String monthDayFormat(Date date) {
        return parseDateToString(date, MONTH_DAY_FORMAT);
    }

    /**
     * Description:传入Date类型日期转换为String类型
     * 
     * @param date
     * @return
     */
    public static String dateFormatToChinaYMD(Date date) {
        return parseDateToString(date, CHINA_YMD);
    }

    /**
     * Description:传入String类型日期转换为Date类型
     * 
     * @param dateString
     * @return
     */
    public static Date dateParse(String dateString) {
        return parseDate(dateString, SIMPLE_FMT);
    }

    /**
     * 强制类型转换 从串到日期
     *
     * @param sDate
     *            源字符串，采用yyyy-MM-dd格式
     * @param sFormat
     * @return 得到的日期对象
     */
    public static Date parseDate(String sDate, String sFormat) {
        try {
            return new SimpleDateFormat(sFormat).parse(sDate);
        } catch (ParseException e) {
            LOGGER.warn("parseDate error:" + e);
        }
        return null;
    }

    /**
     * Description:传入TimeStamp类型日期转换为String类型
     * 
     * @param timestamp
     * @return
     */
    public static String timeStampFormat(Timestamp timestamp) {
        return new SimpleDateFormat(SIMPLE_YMD).format(timestamp);
    }

    /**
     * Description:传入TimeStamp类型日期转换为String类型
     * 
     * @param timestamp
     * @return
     */
    public static String timeStampFormatYYYYMMDDHHMMSS(Timestamp timestamp) {
        return new SimpleDateFormat(SIMPLE_FMT).format(timestamp);
    }

    /**
     * Description:传入String类型日期转换为TimeStamp类型
     * 
     * @param ts
     * @return
     */
    public static Timestamp timeStampParse(String ts) {
        return Timestamp.valueOf(dateFormat(parseDate(ts, SIMPLE_YMD)));
    }

    public static Timestamp timeStampParse(String ts, String fmt) {
        return Timestamp.valueOf(dateFormat(parseDate(ts, fmt)));
    }

    /**
     * 将一种格式的时间字符串装换为另一种格式
     * 
     * @param dateString
     * @param fromFormat
     * @param toFormat
     * @return
     */
    public static String dateFormatParse(String dateString, String fromFormat, String toFormat) {
        return parseDateToString(parseDate(dateString, fromFormat), toFormat);
    }

    /**
     * Description:得到当前日期
     * 
     * @return
     */
    public static String getNow() {
        return dateFormat(new Date());
    }

    // 获取指定日期的年
    public static String getDateYear(Date date) {
        return parseDateToString(date, SIMPLE_Y);
    }

    // 获取指定日期的月
    public static String getDateMonth(Date date) {
        return parseDateToString(date, SIMPLE_M);
    }

    // 获取指定日期的天
    public static String getDateDay(Date date) {
        return parseDateToString(date, SIMPLE_D);
    }

    public static String getNowForMills() {
        return parseDateToString(new Date(), SIMPLE_MILLS);
    }

    public static String getNowForYmd() {
        return parseDateToString(new Date(), SIMPLE_YMD);
    }

    public static String getNowForSampleYmd() {
        return parseDateToString(new Date(), SIMPLE_DATE_YMD);
    }

    public static String getNowForSampleYm() {
        return parseDateToString(new Date(), SIMPLE_DATE_YM);
    }

    public static String getTodayShort() {
        return parseDateToString(new Date(), "yyyy/MM/dd");
    }

    /**
     * 获取今天之后 <code>num</code> 天的格式化日期
     * 
     * @param format
     *            格式化字符
     * @param num
     *            相差天数
     * @return
     */
    public static String getDayAfterToday(String format, int num) {
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.add(Calendar.DATE, num);
        return parseDateToString(calendar.getTime(), format);
    }

    // 获取指定年的第一天
    public static String getFirstDayOfYear(Date date,Integer year) {
        Date date1 = DateUtil.offsetYear(date, year);
        String d = parseDateToString(date1, SIMPLE_Y);
        d += "-01-01";
        return d;
    }

    public static void main(String[] args) {
        LOGGER.info(getFirstDayOfYear(new Date(),-MagicNumConstant.TEN));
    }

    public static String getTomorrowShort() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.add(Calendar.DAY_OF_MONTH, 1);
        return parseDateToString(new Date(calendar.getTimeInMillis()), "yyyy/MM/dd");
    }

    /**
     * 验证指定时间是否超时
     * 
     * @param createDate
     * @param seconds
     *            超时秒数
     * @return true 表示超期，false表示未超期
     */
    public static boolean validateExpiry(String createDate, int seconds) {
        return (new Date().getTime() - parseDate(createDate, SIMPLE_FMT).getTime()) / MagicNumConstant.ONE_THOUSAND > seconds;
    }

    public static String getNowFormat(Date date, String format) {
        return new SimpleDateFormat(format).format(date);
    }

    public static String getDayBegin(String day) {
        if (day == null || !day.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("传入日期参数不正确");
        }
        String[] dateData = day.split("-");
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, Integer.parseInt(dateData[0]));
        calendar.set(Calendar.MONTH, Integer.parseInt(dateData[1]) - 1);
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateData[2]));
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        return parseDateToString(new Date(calendar.getTimeInMillis()), SIMPLE_FMT);
    }

    public static Date getDayBegin() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date getDayEnd() {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR);
        calendar.set(Calendar.MINUTE, DEFAULT_MINUTE);
        calendar.set(Calendar.SECOND, DEFAULT_MINUTE);
        return calendar.getTime();
    }

    public static Date getDayBegin(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date getDayEnd(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR);
        calendar.set(Calendar.MINUTE, DEFAULT_MINUTE);
        calendar.set(Calendar.SECOND, DEFAULT_MINUTE);
        return calendar.getTime();
    }

    public static Date getDateBegin(String dateStr) {
        Date date = parseDate(dateStr, SIMPLE_YMD);
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date getDateEnd(String dateStr) {
        Date date = parseDate(dateStr, SIMPLE_YMD);
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR);
        calendar.set(Calendar.MINUTE, DEFAULT_MINUTE);
        calendar.set(Calendar.SECOND, DEFAULT_MINUTE);
        return calendar.getTime();
    }

    // 取当前时间后10年
    public static Date getDateEndAddYear(int year) {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, year);
        calendar.set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR);
        calendar.set(Calendar.MINUTE, DEFAULT_MINUTE);
        calendar.set(Calendar.SECOND, DEFAULT_MINUTE);
        return calendar.getTime();
    }

    public static Date getMonthBegin(String dateStr) {
        Date date = parseDate(dateStr, SIMPLE_YM);
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static Date getMonthEnd(String dateStr) {
        Date date = parseDate(dateStr, SIMPLE_YM);
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        return calendar.getTime();
    }

    public static String getDayEnd(String day) {
        if (day == null || !day.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("传入日期参数不正确,格式应为yyyy-MM-dd");
        }
        String[] dateData = day.split("-");
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, Integer.parseInt(dateData[0]));
        calendar.set(Calendar.MONTH, Integer.parseInt(dateData[1]) - 1);
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateData[2]));
        calendar.set(Calendar.HOUR_OF_DAY, DEFAULT_HOUR);
        calendar.set(Calendar.MINUTE, DEFAULT_MINUTE);
        calendar.set(Calendar.SECOND, DEFAULT_MINUTE);

        return parseDateToString(new Date(calendar.getTimeInMillis()), SIMPLE_FMT);
    }

    public static Timestamp getNowTimestamp() {
        return new Timestamp(System.currentTimeMillis());
    }

    /**
     * 描述: 设置当天结束时间
     * 
     * @param date
     * @return
     */
    public static Date setDefaultEndDate(Date date) {
        Date newDate = DateUtils.setHours(date, DEFAULT_HOUR);
        newDate = DateUtils.setMinutes(date, DEFAULT_MINUTE);
        newDate = DateUtils.setSeconds(date, DEFAULT_MINUTE);
        return newDate;
    }

    /**
     * 描述: 设置当天开始时间
     * 
     * @param date
     * @return
     */
    public static Date setDefaultStartDate(Date date) {
        Date newDate = DateUtils.setHours(date, START_HOUR);
        newDate = DateUtils.setMinutes(date, START_MINUTE);
        newDate = DateUtils.setSeconds(date, START_MINUTE);
        return newDate;
    }

    /**
     * 获取1个小时后的格式化日期
     * 
     * @param dateString
     *            日期字符串 格式为： MMddHH
     * @param format
     *            返回格式
     * @return
     */
    public static String getNextHour(String dateString, String format) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, Integer.parseInt(parseDateToString(new Date(), "yyyy")));
        calendar.set(Calendar.MONTH, Integer.parseInt(dateString.substring(0, 2)) - 1);
        calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(dateString.substring(2, MagicNumConstant.FOUR)));
        calendar.set(Calendar.HOUR, Integer.parseInt(dateString.substring(MagicNumConstant.FOUR, MagicNumConstant.SIX)));

        calendar.add(Calendar.HOUR, 1);
        return parseDateToString(calendar.getTime(), format);
    }

    /**
     * 获取1个小时后的格式化日期
     * 
     * @param dateString
     *            日期字符串 格式为： yyyyMMddHH
     * @return
     */
    public static String getNextHour2(String dateString) {
        Calendar calendar = Calendar.getInstance();
        calendar.clear();
        calendar.set(Calendar.YEAR, Integer.parseInt(dateString.substring(0, MagicNumConstant.FOUR)));
        calendar.set(Calendar.MONTH,
                Integer.parseInt(dateString.substring(MagicNumConstant.FOUR, MagicNumConstant.SIX)) - 1);
        calendar.set(Calendar.DAY_OF_MONTH,
                Integer.parseInt(dateString.substring(MagicNumConstant.SIX, MagicNumConstant.EIGHT)));
        calendar.set(Calendar.HOUR,
                Integer.parseInt(dateString.substring(MagicNumConstant.EIGHT, MagicNumConstant.TEN)));

        calendar.add(Calendar.HOUR, 1);
        return parseDateToString(calendar.getTime(), "yyyyMMddHH");
    }

    /**
     * 描述: 取当前年月字符串
     * 
     * @return
     */
    public static String getFormatDateString() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
        return simpleDateFormat.format(new Date());
    }

    /**
     * 描述: 取当前年月字符串
     * 
     * @return
     */
    public static Long getDiffDays(Date begin, Date end) {
        return (end.getTime() - begin.getTime()) / MagicNumConstant.THREE_THOUSAND_SIX_HUNDRED
                / MagicNumConstant.TWENTY_FOUR / MagicNumConstant.ONE_THOUSAND;
    }

    /**
     * 根据时间和格式得到格式化后的字符串
     * 
     * @param date
     * @param formatter
     * @return
     */
    public static String getFormatDate(Date date, String formatter) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(formatter);
        return simpleDateFormat.format(date);
    }

    public static String getWeekOfDate(Date dt) {
        String[] weekDays = { "7", "1", "2", "3", "4", "5", "6" };
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0) {
            w = 0;
        }
        return weekDays[w];
    }

    /**
     * Description: 取订单的时间戳
     *
     * @return
     */
    public static Long getOrderTimeStamp() {
        return new Long(parseDateToString(new Date(), SIMPLE_DATE_YMD));

    }

    /**
     * 在某个时间基础上，往前推或者往后推几分钟，返回[年-月-日]格式的日期
     * 
     * @param date
     *            在某个时间点基础上前移或者后移
     * @param offsetMinute
     *            正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetMinute(Date date, Integer offsetMinute) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + offsetMinute);// 正数往后移，负数向前移
        return calendar.getTime();
    }

    /**
     * 
     * Description: 两个日期相减求天数：date2-date1
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long subtractDate(Date date1, Date date2) {
        return (date2.getTime() - date1.getTime()) / MagicNumConstant.ONE_THOUSAND / MagicNumConstant.SIXTY
                / MagicNumConstant.SIXTY / MagicNumConstant.TWENTY_FOUR;
    }

    /**
     * 
     * Description: 获取本周第一天，周一
     *
     * @return Date String，format : yyyy-MM-dd
     */
    public static String getWeekStartDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        Date date = cal.getTime();
        return parseDateToString(date, SIMPLE_YMD);
    }

    public static String getWeekEndDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.add(Calendar.DATE, MagicNumConstant.SIX);
        Date date = cal.getTime();
        return parseDateToString(date, SIMPLE_YMD);
    }

    /**
     * 
     * Description: 获取上一周周一
     *
     * @return Date String，format : yyyy-MM-dd
     */
    public static String getLastWeekSart() {
        Calendar cal = Calendar.getInstance();
        int n = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (n == 0) {
            n = MagicNumConstant.SEVEN;
        }
        cal.add(Calendar.DATE, -(MagicNumConstant.SEVEN + (n - 1)));// 上周一的日期
        Date monday = cal.getTime();
        return parseDateToString(monday, SIMPLE_YMD);
    }

    /**
     * 
     * Description: 获取上一周周日
     *
     * @return Date String，format : yyyy-MM-dd
     */
    public static String getLastWeekEnd() {
        Calendar cal = Calendar.getInstance();
        int n = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (n == 0) {
            n = MagicNumConstant.SEVEN;
        }
        cal.add(Calendar.DATE, -n);// 上周一的日期
        Date monday = cal.getTime();
        return parseDateToString(monday, SIMPLE_YMD);
    }

    /**
     * 
     * Description: 获取下周周一
     *
     * @return Date String，format : yyyy-MM-dd
     */
    public static String getNextWeekSart() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.add(Calendar.DATE, MagicNumConstant.SEVEN);
        Date date = cal.getTime();
        return parseDateToString(date, SIMPLE_YMD);
    }

    /**
     * 
     * Description: 获取下周周一
     *
     * @return Date String，format : yyyy-MM-dd
     */
    public static String getNextWeekEnd() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.add(Calendar.DATE, MagicNumConstant.THIRTEEN);
        Date date = cal.getTime();
        return parseDateToString(date, SIMPLE_YMD);
    }

    /**
     * 本月第一天
     * 
     * @return
     */
    public static String getThisMonthStart() {
        // 获取当前月第一天：
        Calendar c = Calendar.getInstance();
        c.add(Calendar.MONTH, 0);
        c.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号,当前日期既为本月第一天
        return parseDateToString(c.getTime(), SIMPLE_YMD);
    }

    /**
     * 本月最后一天
     * 
     * @return
     */
    public static String getThisMonthEnd() {
        // 获取当前月第一天：
        Calendar ca = Calendar.getInstance();
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));
        return parseDateToString(ca.getTime(), SIMPLE_YMD);
    }

    /**
     * 下月第一天
     * 
     * @return
     */
    public static String getNextMonthStart() {
        // 获取当前月第一天：
        Calendar ca = Calendar.getInstance();
        ca.set(Calendar.MONTH, ca.get(Calendar.MONTH) + 1);
        ca.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号

        return parseDateToString(ca.getTime(), SIMPLE_YMD);
    }

    /**
     * 下月最后一天
     * 
     * @return
     */
    public static String getNextMonthEnd() {
        // 获取当前月第一天：
        Calendar ca = Calendar.getInstance();
        ca.set(Calendar.MONTH, ca.get(Calendar.MONTH) + 1);
        ca.set(Calendar.DAY_OF_MONTH, ca.getActualMaximum(Calendar.DAY_OF_MONTH));// 设置最后一天

        return parseDateToString(ca.getTime(), SIMPLE_YMD);
    }

    /**
     * 
    * Description: 获取当前年份的生肖
    *
    * @return
     */
    public static int getYear() {
        Integer year = Integer.valueOf(getDateYear(new Date()));
        String[] years = new String[] { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪" };
        return (year - START) % years.length;
    }


}
