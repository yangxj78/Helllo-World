package com.hengtiansoft.common.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;

import java.io.UnsupportedEncodingException;
import java.util.Date;

public final class JWTUtil {

    // 过期时间一周
    private static final long EXPIRE_TIME = 7*24*60*60*1000;

    private static final long HR_EXPIRE_TIME = 5*60*60*1000;

    /**
     * 校验token是否正确
     * @param token 密钥
     * @param secret 用户的密码
     * @return 是否正确
     */
    public static boolean verify(String token, String username, String secret) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withClaim("username", username)
                    .build();
            verifier.verify(token);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    /**
     * 获得token中的信息无需secret解密也能获得
     * @return token中包含的用户名
     */
    public static String getUsername(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getClaim("username").asString();
        } catch (JWTDecodeException e) {
            return null;
        }
    }

    /**
     * 生成签名,1小时后过期
     * @param username 用户名
     * @param secret 用户的密码
     * @return 加密的token
     */
    public static String sign(String username, String secret) {
        try {
            Date date = new Date(System.currentTimeMillis()+EXPIRE_TIME);
            Algorithm algorithm = Algorithm.HMAC256(secret);
            // 附带username信息
            return JWT.create()
                    .withClaim("username", username)//明钥
                    .withExpiresAt(date)//失效时间
                    .sign(algorithm);//私钥
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    /*------------------------------HR----------------------------------*/
    public static boolean hrVerify(String token, String ip, String captcha) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(captcha);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withClaim("ip", ip)
                    .withClaim("captcha", captcha)
                    .build();
            verifier.verify(token);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    /**
     * 生成签名,5小时后过期
     * @param ip ip
     * @param captcha 签到码
     * @return 加密的token
     */
    public static String hrSign(String ip, String captcha) {
        try {
            Date date = new Date(System.currentTimeMillis() + HR_EXPIRE_TIME);
            Algorithm algorithm = Algorithm.HMAC256(captcha);
            // 附带username信息
            return JWT.create()
                    .withClaim("ip", ip)
                    .withClaim("captcha", captcha)
                    .withExpiresAt(date)//失效时间
                    .sign(algorithm);//私钥
        } catch (UnsupportedEncodingException e) {
            return null;
        }
    }

    public static String getIp(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getClaim("ip").asString();
        } catch (JWTDecodeException e) {
            return null;
        }
    }

    public static String getCaptcha(String token) {
        try {
            DecodedJWT jwt = JWT.decode(token);
            return jwt.getClaim("captcha").asString();
        } catch (JWTDecodeException e) {
            return null;
        }
    }


    /*------------------------------applicant_user----------------------------------*/

}
