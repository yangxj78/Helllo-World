package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

public enum UserTypeEnum {

    ADMIN(0, "admin"),
    HR(1, "hr"),
    BIG_SCREEN(2, "bigScreen"),
    APPLICANT_USER(3, "phoneUser"),
    TV(4, "tv"),
    SELF_HELP_MACHINE(5, "selfHelpMachine");

    private static final Map<Integer, UserTypeEnum> map;

    static {
        map = new HashMap<>();
        for (UserTypeEnum userTypeEnum: UserTypeEnum.values()) {
            map.put(userTypeEnum.getCode(), userTypeEnum);
        }
    }

    private Integer code;

    private String desc;

    UserTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Map<Integer, UserTypeEnum> getMap() {
        return map;
    }
}
