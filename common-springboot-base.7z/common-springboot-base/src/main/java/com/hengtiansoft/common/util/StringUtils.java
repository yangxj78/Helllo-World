package com.hengtiansoft.common.util;

import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import io.netty.util.internal.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 字符串处理工具类
 * Created by linwu on 7/30/2018.
 */
public final class StringUtils {

    private StringUtils(){};

    private static final Logger LOGGER = LoggerFactory.getLogger(StringUtils.class);

    public static String nullToEmpty(Object obj) {
        String str = String.valueOf(obj);
        return str.equals("null") ? StringUtil.EMPTY_STRING : str;
    }
}
