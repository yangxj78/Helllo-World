/**
 * 
 */
package com.hengtiansoft.common.util;

import com.hengtiansoft.common.constant.MagicNumConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @author tangqh
 */
public final class DateUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

    private static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

    public static final String FORMAT_00 = "yyyy/MM/dd HH:mm:ss";

    private DateUtil() {
    }

    public static String getDateFormate(Date date) {
        SimpleDateFormat format = new SimpleDateFormat(DateTimeUtil.SIMPLE_FMT);
        return format.format(date);
    }


    public static String getDateFormate2(Date date) {
        SimpleDateFormat format = new SimpleDateFormat(DateTimeUtil.SIMPLE_FMT_MINUTE);
        return format.format(date);
    }

    public static String getDateFormate3(Date date) {
        SimpleDateFormat format = new SimpleDateFormat(DateTimeUtil.SIMPLE_YMD);
        return format.format(date);
    }


    /**
     * 获取当天，[年-月-日]格式的日期
     *
     * @return Current Date String，format : yyyy-MM-dd
     */
    public static String getFullDateString() {
        SimpleDateFormat format = new SimpleDateFormat(DateTimeUtil.SIMPLE_YMD);
        return format.format(new Date());
    }

    /**
     * 获取当天，[年-月-日]格式的日期
     *
     * @return Current Date String，format : yyyyMMddHHmmss
     */
    public static String getFullDateNumber() {
        SimpleDateFormat format = new SimpleDateFormat(YYYYMMDDHHMMSS);
        return format.format(new Date());
    }

    public static String getHHmmss() {
        SimpleDateFormat format = new SimpleDateFormat("HHmmss");
        return format.format(new Date());
    }

    /**
     * 获取当天，[年-月-日]格式的日期
     *
     * @return Current Date String，format : yyyyMMddHHmmss
     */
    public static String getFullDateNumberOffsetMinute(Integer offsetMinute) {
        SimpleDateFormat format = new SimpleDateFormat(YYYYMMDDHHMMSS);
        return format.format(offsetMinute(new Date(), offsetMinute));
    }


    /**
     * 在某个时间基础上，往前推或者往后推几小时，返回[年-月-日]格式的日期
     *
     * @param date         在某个时间点基础上前移或者后移
     * @param offsetMinute 正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetMinute(Date date, Integer offsetMinute) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MINUTE, calendar.get(Calendar.MINUTE) + offsetMinute);// 正数往后移天数，负数向前移天数
        return calendar.getTime();
    }

    /**
     * 在某个时间基础上，往前推或者往后推几小时，返回[年-月-日]格式的日期
     *
     * @param date       在某个时间点基础上前移或者后移
     * @param offsetHour 正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetHour(Date date, Integer offsetHour) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR, calendar.get(Calendar.HOUR) + offsetHour);// 正数往后移天数，负数向前移天数
        return calendar.getTime();
    }

    /**
     * 在某个时间基础上，往前推或者往后推几天，返回[年-月-日]格式的日期
     *
     * @param date       在某个时间点基础上前移或者后移
     * @param offsetDate 正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetDate(Date date, Integer offsetDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + offsetDate);// 正数往后移天数，负数向前移天数
        return calendar.getTime();
    }

    /**
     * 在某个时间基础上，往前推或者往后推几个月，返回[年-月-日]格式的日期
     *
     * @param date        在某个时间点基础上前移或者后移
     * @param offsetMonth 正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetMonth(Date date, Integer offsetMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + offsetMonth);// 正数往后移月份，负数向前移月份
        return calendar.getTime();
    }

    /**
     * 在某个时间基础上，往前推或者往后推几个年，返回[年-月-日]格式的日期
     *
     * @param date        在某个时间点基础上前移或者后移
     * @param offsetYear 正数往后移天数，负数向前移天数
     * @return Date String，format : yyyy-MM-dd
     */
    public static Date offsetYear(Date date, Integer offsetYear) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.YEAR, calendar.get(Calendar.YEAR) + offsetYear);// 正数往后移月份，负数向前移月份
        return calendar.getTime();
    }

    public static Date parse(String date) {
        try {
            SimpleDateFormat format = new SimpleDateFormat(DateTimeUtil.SIMPLE_FMT);
            return format.parse(date);
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }
    }

    public static Date parse(String date, SimpleDateFormat format) {
        try {
            return format.parse(date);
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }
    }

    public static Date parse(String date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(pattern);
        try {
            return format.parse(date);
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }
    }

    public static String parseDate(Date date, SimpleDateFormat format) {
        return format.format(date);
    }

    /**
     * Description: 取订单的时间戳
     *
     * @return
     */
    public static Long getOrderTimeStamp() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        return new Long(parseDate(new Date(), format));
    }

    /**
     * 获取与当前时间的时间差
     *
     * @param lastLongTime
     * @return
     */
    public static Integer getSecond(String lastLongTime) {
        try {
            Long last = Long.valueOf(lastLongTime);
            Long now = System.currentTimeMillis();
            return (int) ((now - last) / MagicNumConstant.ONE_THOUSAND);
        } catch (Exception e) {
            LOGGER.error("", e);
            return null;
        }
    }


    public static String dateToWeek(String datetime) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
        Calendar cal = Calendar.getInstance(); // 获得一个日历
        Date datet = null;
        try {
            datet = f.parse(datetime);
            cal.setTime(datet);
        } catch (ParseException e) {
            LOGGER.error("", e);
        }
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1; // 指示一个星期中的某天。
        if (w < 0)
            w = 0;
        return weekDays[w];
    }


    /**
     * @Description: 将日期转化成字符串
     * @author blp
     * @date Jun 1, 2018 7:01:53 PM
     */
    public static Date strToDateLong(String strDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        ParsePosition pos = new ParsePosition(0);
        return formatter.parse(strDate, pos);
    }

    /**
     * @Description: 将日期转化成字符串
     * @author blp
     * @date Jun 1, 2018 7:03:33 PM
     */

    public static String dateToStrLong(Date dateDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return formatter.format(dateDate);
    }

}
