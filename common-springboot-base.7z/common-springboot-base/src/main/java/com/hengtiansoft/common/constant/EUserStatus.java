/*
 * Project Name: sc-archetype
 * File Name: EGender.java
 * Class Name: EGender
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.hengtiansoft.common.constant;

/**
 * Class Name: EUserStatus
 * 
 * @author SC
 * 
 */
public enum EUserStatus{

    ACTIVE("A", "启用"), INACTIVE("I", "禁用");

    private String code;

    private String text;

    /**
     * EUserStatus Constructor
     */
    EUserStatus(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    /**
     * Description: 根据code获取对应的text
     */
    public static String getStatusText(String code) {
        for (EUserStatus status : EUserStatus.values()) {
            if (status.getCode().equals(code)) {
                return status.getText();
            }
        }
        return "";
    }

}
