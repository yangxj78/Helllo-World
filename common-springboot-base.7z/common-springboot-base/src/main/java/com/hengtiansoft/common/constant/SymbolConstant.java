package com.hengtiansoft.common.constant;

/**
 * Class Name: ApplicationConstant Description: application level constants.
 * 
 * @author SC
 * 
 */
public final class SymbolConstant {

    public static final String SEMICOLON = ";";

    public static final String COMMA = ",";

    private SymbolConstant() {

    }
}
