package com.hengtiansoft.common.util;

import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * Class Name: WebUtil
 * 
 * Description: WebUtil
 * 
 * @author SC
 * 
 */
public final class WebUtil {

    private static ObjectMapper objectMapper;

    private WebUtil() {

    }

    /**
     * Description: get the current request bound to current thread
     *
     * @return
     */
    public static HttpServletRequest getThreadRequest() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
    }

    /**
     * Description: get the current session bound to current thread
     *
     * @return
     */
    public static HttpSession getThreadSession() {
        return getThreadRequest().getSession(true);
    }

    /**
     * Description: 获得设备来源
     *
     * @return
     */
    public static String getSource() {
        return getThreadRequest().getHeader("from");
    }
    
    /**
     * Description: 获得app版本
     *
     * @return
     */
    public static String getVersion() {
        String version = getThreadRequest().getHeader("version");
        
        if (StringUtils.isBlank(version)) {
            return null;
        }
        return version.replace("v", "");
    }
    
    /**
     * Description: 获得设备号
     *
     * @return
     */
    public static String getMobileCode() {
        return getThreadRequest().getHeader("mobileCode");
    }

    /**
     * Description: determine whether current request is sent via AJAX
     *
     * @return
     */
    public static boolean isAjaxRequest() {
        return isAjaxRequest(getThreadRequest());
    }

    /**
     * Description: determine whether given request is sent via AJAX
     *
     * @param request
     * @return
     */
    public static boolean isAjaxRequest(HttpServletRequest request) {
        String requestedWith = request.getHeader("X-Requested-With");
        return requestedWith != null ? "XMLHttpRequest".equals(requestedWith) : false;
    }

    /**
     * Description: get the full URL for a relative path
     *
     * @param path
     * @return
     */
    public static String getFullUrlBasedOn(String path) {
        StringBuilder targetUrl = new StringBuilder();
        if (path.startsWith("/")) {
            // Do not apply context path to relative URLs.
            targetUrl.append(getThreadRequest().getContextPath());
        }
        targetUrl.append(path);
        return targetUrl.toString();
    }

    /**
     * Description: get the {@link ObjectMapper} that will be used in converter.
     *
     * @return
     */
    @SuppressWarnings("deprecation")
    public static ObjectMapper getObjectMapper() { // NOSONAR
        if (objectMapper == null) {
            synchronized (WebUtil.class) {
                if (objectMapper == null) {
                    objectMapper = new ObjectMapper();
                    SimpleModule module = new SimpleModule("Custom Serializer", new Version(1, 0, 0, "FINAL"));
                    module.addSerializer(new PageEnumSerializer());
                    objectMapper.registerModule(module);
                }
            }
        }
        return objectMapper;
    }

}
