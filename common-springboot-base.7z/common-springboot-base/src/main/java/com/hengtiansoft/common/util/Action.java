package com.hengtiansoft.common.util;

import java.util.ArrayList;
import java.util.List;

/**
 * @author kexu
 */
public enum Action {
    INSERT("insert", "增加"), UPDATE("update", "修改"), DELETE("delete", "删除");
    private String eName;
    private String cName;

    /**
     * Action Constructor
     */
    Action(String eName, String cName) {
        this.eName = eName;
        this.cName = cName;
    }

    /**
     * Description: 根据eName获取cname
     */
    public static String getCName(String eName) {
        for (Action action : Action.values()) {
            if (action.geteName().equals(eName)) {
                return action.cName;
            }
        }
        return null;
    }

    /**
     * get/set
     */
    public String geteName() {
        return eName;
    }

    /**
     * get/set
     */
    public void seteName(String eName) {
        this.eName = eName;
    }

    /**
     * get/set
     */
    public String getcName() {
        return cName;
    }

    /**
     * get/set
     */
    public void setcName(String cName) {
        this.cName = cName;
    }

    /**
     * Description: 获取所有的action
     */
    public static List<Action> getAction() {
        List<Action> actionList = new ArrayList<Action>();
        for (Action action : Action.values()) {
            actionList.add(action);
        }
        return actionList;
    }


    /**
     * Description: 获取所有的action
     */
    public static List<EnumDomain> getActionDomains() {
        List<EnumDomain> actionList = new ArrayList<EnumDomain>();
        for (Action action : Action.values()) {
            EnumDomain enumDomain = new EnumDomain();
            enumDomain.setKey(action.geteName());
            enumDomain.setValue(action.getcName());
            actionList.add(enumDomain);
        }
        return actionList;
    }

}
