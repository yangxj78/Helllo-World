package com.hengtiansoft.common.constant;

/**
 * Email常量
 * Created by linwu on 7/25/2018.
 */
public final class EmailConstant {

    public static final String TEMPLATE = "<!DOCTYPE html>\n" +
            "<html lang=\"en\">\n" +
            "\n" +
            "<head>\n" +
            "    <meta charset=\"UTF-8\">\n" +
            "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
            "    <title>杭州高新人才市场</title>\n" +
            "</head>\n" +
            "\n" +
            "<body style=\"margin:0;padding:10px\">\n" +
            "    <h1 style=\"font-size:24px\">companyName</h1>\n" +
            "    <p style=\"font-size:18px\">您好!</p>\n" +
            "    <div style=\"padding:20px 20px\">\n" +
            "        <p style=\"line-height:2\">recruitmentDate参加的“recruitmentName”中所有通过、待定的简历信息及面试评价汇总详情见附件。请查阅</p>\n" +
            "        <p style=\"text-align:right\">杭州高新人才市场</p>\n" +
            "        <p style=\"text-align:right\">currentDate</p>\n" +
            "    </div>\n" +
            "</body>\n" +
            "\n" +
            "</html>";

    private EmailConstant() {

    }
}
