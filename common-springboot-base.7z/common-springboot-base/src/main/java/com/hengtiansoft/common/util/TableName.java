package com.hengtiansoft.common.util;

import java.util.ArrayList;
import java.util.List;

/**
 * @author kexu
 */
public enum TableName {
    ADMIN_USER(1, "admin_user"), ADMIN_USER_ROLE(2, "admin_user_role"), ADMIN_ROLE(3, "admin_role"), ADMIN_ROLE_PERMISSION(
            4, "admin_role_permission"), TODO(5, "todo");
    private int code;
    private String name;

    /**
     * TableName Constructor
     */
    TableName(int code, String name) {
        this.setCode(code);
        this.setName(name);
    }

    /**
     * Description: 根据code获取对应的name
     */
    public static String getName(int code) {
        for (TableName tableName : TableName.values()) {
            if (tableName.getCode() == code) {
                return tableName.name;
            }
        }
        return null;
    }

    /**
     * Description: 获取所有的tablename
     */
    public static List<TableName> getTableName() {
        List<TableName> tableNameList = new ArrayList<TableName>();
        for (TableName tableName : TableName.values()) {
            tableNameList.add(tableName);
        }
        return tableNameList;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    /**
     * Description: 获取所有的action
     */
    public static List<EnumDomain> getTableNameDomains() {
        List<EnumDomain> actionList = new ArrayList<EnumDomain>();
        for (TableName action : TableName.values()) {
            EnumDomain enumDomain = new EnumDomain();
            enumDomain.setKey(String.valueOf(action.getCode()));
            enumDomain.setValue(action.getName());
            actionList.add(enumDomain);
        }
        return actionList;
    }

}
