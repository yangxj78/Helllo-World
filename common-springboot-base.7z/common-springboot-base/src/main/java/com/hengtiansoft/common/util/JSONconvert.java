/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  jSONconvert.java   
 * @Package demo.util   
 * @Description:对象转换工具类
 * @author: 许金涛
 * @date:   Oct 9, 2017 3:21:34 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.common.util;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * @author jintaoxu
 *
 */
public class JSONconvert{

	private static final Logger LOGGER = LoggerFactory.getLogger(JSONconvert.class);


	private ObjectMapper objectMapper;
    private static JSONconvert jSONconvert;  
    public static JSONconvert getjSONconvert(){
    	if(jSONconvert==null){
    		jSONconvert=new JSONconvert();
    	}
    	return jSONconvert;
    }
    /**
     * @param jsonstr
     * @param object
     * @return object
     * json字符串转对象
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     */
    public Object jsonstrToObject(String jsonstr, Object object){
    	Object obj=null;
    	try {
			obj=objectMapper.readValue(jsonstr, object.getClass());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
    	return obj;
    }
    /**
     * @param object
     * @return String
     * 对象转字符串
     * @throws JsonProcessingException
     */
    public String objectToJsonstr(Object object){
    	        
    	String obString=null;
		try {
			obString = objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			LOGGER.error(e.getMessage());
		}
    	return obString;
    }
}
