package com.hengtiansoft.common.constant;

/**
 * FTP常量
 * Created by linwu on 7/25/2018.
 */
public final class FTPConstant {

    public static final String VIDEO_PATH = "/video";

    public static final String IMG_PATH = "/picture";

    public static final String DOCUMENT_PATH = "/document";

    public static final String RESUME_PATH = "/resume";

    private FTPConstant() {

    }
}
