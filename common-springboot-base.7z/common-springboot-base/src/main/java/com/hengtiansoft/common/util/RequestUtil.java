package com.hengtiansoft.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public final class RequestUtil {

    private RequestUtil(){};

    private static final Logger LOGGER = LoggerFactory.getLogger(JSONconvert.class);

    public static void write(Object object, HttpServletResponse response) {
        response.setContentType("application/json;charset=utf-8");
        try {
            response.getWriter().print(new ObjectMapper().writeValueAsString(object));
            response.getWriter().flush();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            LOGGER.error(e.getMessage());
        }
    }

    public static void writestr(String josnstr, HttpServletResponse response) {
        response.setContentType("utf-8");
        try {
            PrintWriter writer = response.getWriter();
            writer.print(josnstr);
            writer.flush();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            LOGGER.error(e.getMessage());
        }

    }
}
