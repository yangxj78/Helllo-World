package com.hengtiansoft.common.constant;
/**
 * 
 * */
public final class PathStrings {
    private PathStrings() {

    }

    public static class Product {
    	public static final String ID = "{" + PathVariable.ID + "}";
        public static final String PRODUCT = "/product";
        public static final String PRODUCT_ADD = "/product_add";
        public static final String PRODUCT_EDIT = "/product_edit"+ "/" + ID;
        public static final String PRODUCTS = "/products";
        
        public static final String PRODUCTID = "productId";

        public static final String PRODUCT_ID = PRODUCT + "/" + ID;
        public static final String GET_PRODUCTS = PRODUCT + "/{" + PRODUCTID + "}";

    }

    public static class AdminUser {
        public static final String ADMINUSER = "/adminuser";
        public static final String ID = "{" + PathVariable.ID + "}";
        public static final String PHONE = "{" + PathVariable.PHONE + "}";
        public static final String IDS = "{" + PathVariable.IDS + "}";

        public static final String SEARCHBYCON = ADMINUSER + "/searchbyCon";
        public static final String TO_CHANGE_PWD = ADMINUSER + "/toChangePassword/" + ID;
        public static final String DO_CHANGE_PWD = ADMINUSER + "/doChangePassword";
        public static final String DO_RESET_PWD = ADMINUSER + "/doResetPassword";
        public static final String DO_RESET_PWD1 = ADMINUSER + "/doResetPassword1";
        public static final String TO_EDIT_USERINFO = ADMINUSER + "/toEditUserInfo/" + ID;
        public static final String DO_EDIT_USERINFO = ADMINUSER + "/doEditUserInfo";
        public static final String TO_ADD = ADMINUSER + "/toAdd";
        public static final String DO_ADD = ADMINUSER + "/doAdd";
        public static final String TO_EDIT = ADMINUSER + "/toEdit/" + ID;
        public static final String DO_EDIT = ADMINUSER + "/doEdit/" + ID;
        public static final String DO_DELETE = ADMINUSER + "/doDelete/" + ID;
        public static final String DO_DELETE_ALL = ADMINUSER + "/doDeleteAll/" + IDS;
        public static final String DO_EXIST_PHONE = ADMINUSER + "/doExistPhone/" + PHONE;
        public static final String DO_UPDATE_ID = ADMINUSER + "/doUpdateId" + PHONE;
    }

    public static class Role {
        public static final String ROLE = "/role";
        public static final String ID = "{" + PathVariable.ID + "}";
        public static final String IDS = "{" + PathVariable.IDS + "}";

        public static final String GET_ALL = ROLE + "/getAll";
        public static final String SEARCHBYCON = ROLE + "/searchbyCon";
        public static final String DO_DELETE = ROLE + "/doDelete/" + ID;
        public static final String DO_DELETE_ALL = ROLE + "/doDeleteAll/" + IDS;
        public static final String TO_EDIT = ROLE + "/toEdit/" + ID;
        public static final String DO_EDIT = ROLE + "/doEdit/" + ID;
        public static final String DO_ADD = ROLE + "/doAdd";

    }

    public static class Permission {
        public static final String PERMISSION = "/permission";
        public static final String GET_ROLE_PERMISSIONS = PERMISSION + "/getRolePermissions";
        public static final String ASSIGN_PERMISSIONS = PERMISSION + "/assignPermissions";
    }

    public static class Auth {
        public static final String AUTH = "/auth";
        public static final String AUTH2 = "/auth2";
        public static final String LOGIN = "/login";
        public static final String DO_LOGIN = LOGIN + "/authc";
        public static final String DO_LOGIN1 = LOGIN + "/authc1";
    }

    public static class Log {
        public static final String LOG = "/log";
        public static final String ID = "{" + PathVariable.ID + "}";
        public static final String SEARCHBYCON = LOG + "/searchbyCon";
        public static final String GET_LOG_DETAIL = LOG + "/getLogDetail/" + ID;
    }

    public static class Error {
        public static final String ERROR404 = "error/404";

    }

    public static class Todo {
        public static final String TODO = "/todo";
        public static final String ID = "{" + PathVariable.ID + "}";
        public static final String IDS = "{" + PathVariable.IDS + "}";

        public static final String GET_TODO_LIST = TODO + "/getTodoList";
        public static final String GET_TODO_COUNT = TODO + "/getTodoCount";
        
        public static final String GET_VUETODO_COUNT = TODO + "/getTodoCount/"+ID;
        public static final String GET_VUETODO_LIST = TODO + "/getTodoList/"+ID;
        
        public static final String DO_MARK = TODO + "/doMark/" + ID;
        public static final String DO_MARK_ALL = TODO + "/doMarkAll/" + IDS;

    }

    public static class PathVariable {
        public static final String ID = "id";
        public static final String PHONE = "phone";
        public static final String IDS = "ids";
    }

    public static class IParameter {
        public static final String ROLEID = "roleId";
    }

}
