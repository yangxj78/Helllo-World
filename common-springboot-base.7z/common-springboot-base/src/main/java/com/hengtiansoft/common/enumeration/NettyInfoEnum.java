package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

public enum NettyInfoEnum {

    RECRUITMENT_START(10, "招聘会开始"),
    RECRUITMENT_END(11, "招聘会结束"),
    HR_SIGN_IN(20, "HR签到"),
    HR_SIGN_OUT(21, "HR签退"),
    HR_INTERVIEW(22, "面试状态变更"),
    HR_DELIVERY(23, "投递状态变更"),
    EXCHANGE(24, "调换展位"),
    RECRUITMENT_UPDATE(25, "招聘会信息更新"),
    TEMPLET_UPDATE(26, "模板更新"),
    COMPANY_UPDATE(27, "公司信息更新"),
    POSITION_UPDATE(28, "岗位信息更新"),
    SUSPEND(29, "面试暂停");

    private static final Map<Integer, NettyInfoEnum> map;

    static {
        map = new HashMap<>();
        for (NettyInfoEnum nettyInfoEnum : NettyInfoEnum.values()) {
            map.put(nettyInfoEnum.getCode(), nettyInfoEnum);
        }
    }

    private Integer code;

    private String desc;

    NettyInfoEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Map<Integer, NettyInfoEnum> getMap() {
        return map;
    }
}
