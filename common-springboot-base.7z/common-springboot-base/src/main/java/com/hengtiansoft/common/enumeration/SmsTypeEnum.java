package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

/***
 * 短信类型枚举
 */
public enum SmsTypeEnum {

    BOOK_BOOTH(0, "订展邀请"),
    INTERVIEWING(1, "面试邀请"),
    QR_CODE(2, "入场邀请"),
    REMIND(3, "面试提醒"),
    MATCHING(4, "智能匹配邀约"),
    RESET(7, "重置密码"),
    REGISTER(8, "注册"),
    LOGIN(9, "登录");

    private Integer code;

    private String desc;

    private static final Map<Integer, SmsTypeEnum> map;


    SmsTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    static{
        map = new HashMap<>();
        for (SmsTypeEnum smsTypeEnum : SmsTypeEnum.values()) {
            map.put(smsTypeEnum.code, smsTypeEnum);
        }
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static SmsTypeEnum getByCode(Integer code){
        return map.get(code);
    }
}
