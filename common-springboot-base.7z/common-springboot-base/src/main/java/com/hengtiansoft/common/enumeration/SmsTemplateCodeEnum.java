package com.hengtiansoft.common.enumeration;

/***
 * 短信类型枚举
 */
public enum SmsTemplateCodeEnum {

    /**
     * 企业定展短信通知
     * 请您准时参加${nane}，时间：${time}，地点：${place}。展位号：${booths}，验证码：${code}。
     */
    BOOK_BOOTH("SMS_146610137"),

    /**
     * 邀请通知
     * ${time}举办${name}（地点：${place}），欢迎您前来洽谈，关注“相约在高新”公众号，注册/登录后获取入场二维码，查阅现场相关信息。 www.hhrc.com.cn
     */
    INVITATIONS("SMS_146808667"),

    /**
     * 交流通知
     * 当前企业还有1人等待，请尽快到${booths}展位，以免错失机会。
     */
    REMIND("SMS_146616151"),

    /**
     * 叫号通知
     * 请前往${booths}展位洽谈！
     */
    REMIND2("SMS_151772984"),

    /**
     * 邀约通知
     * ${name}女士/先生您好，${company}诚邀您到${booths}展位前来洽谈，期待您的光临！
     */
    MATCHING("SMS_147437325");

    private String code;

    SmsTemplateCodeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
