package com.hengtiansoft.common.util;

import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 压缩文件工具类
 * Created by linwu on 7/30/2018.
 */
public final class ZipUtils {

    private ZipUtils(){};

    private static final Logger LOGGER = LoggerFactory.getLogger(ZipUtils.class);

    private static final int BUFFER_SIZE = 2 * 1024;

    private static final String ZIP_FAILS = "压缩失败";
    /**
     * 压缩成ZIP 方法1
     * @param srcDir           压缩文件夹路径
     * @param out              压缩文件输出流
     * @param keepDirStructure 是否保留原来的目录结构，true：保留，false：所有文件跑到压缩目录跟目录下（注意：不保留目录结构可能会出现同名文件，会压缩失败）
     */
    public static void toZip(String srcDir, OutputStream out, boolean keepDirStructure) {
        long start = System.currentTimeMillis();
        ZipOutputStream zos = null;
        try {
            zos = new ZipOutputStream(out);
            File sourceFile = new File(srcDir);
            compress(sourceFile, zos, sourceFile.getName(), keepDirStructure);
            long end = System.currentTimeMillis();
            LOGGER.info("压缩完成,耗时: " + (end - start) + "ms");
        } catch (Exception e) {
            LOGGER.error("zip error from ZipUtils", e);
        } finally {
            if (zos != null) {
                try {
                    zos.close();
                } catch (Exception e) {
                    LOGGER.error(ZIP_FAILS, e);
                }
            }
        }
    }

    /**
     * 压缩成Zip
     * @param srcFiles           需要压缩的文件列表
     * @param out                压缩文件输出流
     */
    public static void toZip(List<File> srcFiles, OutputStream out) {
        long start = System.currentTimeMillis();
        ZipOutputStream zos = null;
        try {
            zos = new ZipOutputStream(out);
            for (File srcFile : srcFiles) {
                byte[] buf = new byte[BUFFER_SIZE];
                zos.putNextEntry(new ZipEntry(srcFile.getName()));
                int len;
                FileInputStream in = new FileInputStream(srcFile);
                while ((len = in.read(buf)) != -1) {
                    zos.write(buf, 0, len);
                }
                zos.closeEntry();
                in.close();
            }
            long end = System.currentTimeMillis();
            LOGGER.info("压缩完成，耗时：" + (end - start) + "ms");
        } catch (Exception e) {
            LOGGER.error(ZIP_FAILS);
        } finally {
            if (zos != null) {
                try {
                    zos.close();
                } catch (IOException e) {
                    LOGGER.error(ZIP_FAILS, e);
                }
            }
        }
    }

    /**
     * 压缩成Zip File
     * @param data <String, Map<String, FileInputStream>>  String: 文件夹的名称
     *        map  Map<String, FileInputStream> String：文件名称  FileInputStream：需要压缩的文件输入流
     * @param attachmentFileName 压缩文件名称
     * @return File
     * @throws IOException
     */
    public static File toZipFile(Map<String, Map<String, FileInputStream>> data, String attachmentFileName) throws IOException {
        long start = System.currentTimeMillis();

        File file = File.createTempFile(attachmentFileName, ApplicationConstant.ZIP);
        try (FileOutputStream os = new FileOutputStream(file);
             ZipOutputStream zos = new ZipOutputStream(os)) {

            for (Map.Entry<String, Map<String, FileInputStream>> map : data.entrySet()) {
                //eg map: <"通过的简历", map<String, FileInputStream>>
                for (Map.Entry<String, FileInputStream> entry : map.getValue().entrySet()) {
                    //eg entry: <"linwu的简历", FileInputStream>
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    BufferedInputStream in = new BufferedInputStream(entry.getValue());
                    int bufSize = MagicNumConstant.ONE_THOUSAND_TWENTY_FOUR;
                    byte[] buffer = new byte[bufSize];
                    int len = 0;
                    while (-1 != (len = in.read(buffer, 0, bufSize))) {
                        bos.write(buffer, 0, len);
                    }
                    if (map.getKey().equals("面试评价")) {
                        zos.putNextEntry(new ZipEntry(entry.getKey()));
                    } else {
                        zos.putNextEntry(new ZipEntry(map.getKey() + "/" + entry.getKey()));
                    }
                    zos.write(bos.toByteArray());
                    zos.closeEntry();
                    if (in != null) {
                        in.close();
                    }
                    if (bos != null) {
                        bos.close();
                    }
                }
            }

            long end = System.currentTimeMillis();
            LOGGER.info("压缩完成，耗时：" + (end - start) + "ms");
            return file;
        } catch (Exception e) {
            LOGGER.error(ZIP_FAILS, e);
            return null;
        }
    }

    /**
     * 递归压缩方法
     * @param sourceFile        源文件
     * @param zos               zip输出流
     * @param name              压缩后的名称
     * @param keepDirStructure  是否保留原来的目录结构，true：保留，false：所有文件跑到压缩目录跟目录下（注意：不保留目录结构可能会出现同名文件，会压缩失败）
     * @throws Exception
     */
    private static void compress(File sourceFile, ZipOutputStream zos, String name, boolean keepDirStructure) throws Exception{
        byte[] buf = new byte[BUFFER_SIZE];
        if (sourceFile.isFile()) {
            //向zip输出流中添加一个zip实体，构造器中name为zip实体的文件的名字
            zos.putNextEntry(new ZipEntry(name));
            //copy文件到zip输出流中
            int len;
            FileInputStream in = new FileInputStream(sourceFile);
            while ((len = in.read(buf)) != -1) {
                zos.write(buf, 0, len);
            }

            //Complete the entry
            zos.closeEntry();
            in.close();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if (listFiles == null || listFiles.length == 0) {
                //需要保留原来的文件结构时，需要对空文件夹进行处理
                if (keepDirStructure) {
                    //空文件夹的处理
                    zos.putNextEntry(new ZipEntry(name + "/"));
                    //没有文件，不需要文件的copy
                    zos.closeEntry();
                }
            } else {
                for (File file : listFiles) {
                    if (keepDirStructure) {
                        //注意：file.getName()前面需要带上父文件夹的名字加一斜杠
                        //不然最后压缩包中就不能保留原来的文件结构，即：所有文件都跑到压缩包根目录下了
                        compress(file, zos, name + "/" + file.getName(), keepDirStructure);
                    } else {
                        compress(file, zos, file.getName(), keepDirStructure);
                    }
                }
            }
        }
    }


    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("D://高新大厅的简历压缩包.zip");
        toZip("D://高新大厅test", new FileOutputStream(file), true);
    }
}
