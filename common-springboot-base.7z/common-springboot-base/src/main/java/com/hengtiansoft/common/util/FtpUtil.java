package com.hengtiansoft.common.util;

import com.hengtiansoft.common.constant.FTPConstant;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.pool2.ObjectPool;
import org.apache.shiro.util.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * Ftp工具类
 * Created by linwu on 7/23/2018.
 */
public final class FtpUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FtpUtil.class);

    private static final String ISO88591 = "iso-8859-1";

    private static final String UTF8 = "UTF-8";

    private static final int CONNECT_COUNT = 3;

    /**
     * ftpClient连接池初始化标志
     */
    private static volatile boolean hasInit;

    /**
     * Ftp连接池
     */
    private static ObjectPool<FTPClient> ftpClientObjectPool;


    private FtpUtil() {
    }

    /**
     * 初始化ftpClientPool
     * @param ftpClientObjectPool ftpclient池
     */
    public static void init(ObjectPool<FTPClient> ftpClientObjectPool) {
        if (!hasInit) {
            synchronized (FtpUtil.class) {
                if (!hasInit) {
                    FtpUtil.ftpClientObjectPool = ftpClientObjectPool;
                    hasInit = true;
                }
            }
        }
    }

    /**
     * 上传视频
     * @param fileName 文件名
     * @param inputStream 输入流
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean uploadVideo(String fileName, InputStream inputStream) throws IOException {
        return uploadExistPathFile(FTPConstant.VIDEO_PATH, fileName, inputStream);
    }

    /**
     * 上传图片
     * @param fileName 文件名
     * @param inputStream 输入流
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean uploadImg(String fileName, InputStream inputStream) throws IOException {
        return uploadExistPathFile(FTPConstant.IMG_PATH, fileName, inputStream);
    }

    /**
     * 上传文档
     *
     * @param fileName    文件名
     * @param inputStream 输入流
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean uploadDocument(String fileName, InputStream inputStream) throws IOException {
        return uploadExistPathFile(FTPConstant.DOCUMENT_PATH, fileName, inputStream);
    }

    /**
     * 上传简历
     * @param fileName 文件名
     * @param inputStream 输入流
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean uploadResume(String fileName, InputStream inputStream) throws IOException {
        return uploadFile(FTPConstant.RESUME_PATH, fileName, inputStream);
    }

    public static boolean uploadExistPathFile(String path, String fileName, InputStream inputStream)
            throws IOException {
        boolean flag = false;
        FTPClient ftpClient = getFtpClient();
        try {
            LOGGER.info("开始上传文件中");
            ftpClient.setFileType(ftpClient.BINARY_FILE_TYPE);
            ftpClient.changeWorkingDirectory(path);
            flag = ftpClient.storeFile(new String(fileName.getBytes(UTF8), ISO88591), inputStream);
        } catch (Exception e) {
            LOGGER.error("上传文件失败", e);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            releaseFtpClient(ftpClient);
            LOGGER.info("上传文件成功");
        }
        return flag;
    }

    /**
     * 上传文件
     *
     * @param path        路径
     * @param fileName    文件名
     * @param inputStream 输入流
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean uploadFile(String path, String fileName, InputStream inputStream) throws IOException {
        boolean flag = false;
        FTPClient ftpClient = getFtpClient();
        try {
            LOGGER.info("开始上传文件中");
            ftpClient.setFileType(ftpClient.BINARY_FILE_TYPE);
            createDirectory(path, ftpClient);
            ftpClient.makeDirectory(path);
            ftpClient.changeWorkingDirectory(path);
            ftpClient.setControlEncoding("UTF-8");
            flag = ftpClient.storeFile(new String(fileName.getBytes(UTF8), ISO88591), inputStream);
        } catch (Exception e) {
            LOGGER.error("上传文件失败", e);
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            releaseFtpClient(ftpClient);
            LOGGER.info("上传文件成功");
        }
        return flag;
    }

    /**
     * 删除远程文件
     *
     * @param path     路径
     * @param fileName 文件名
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static boolean deleteFile(String path, String fileName) throws IOException {
        boolean flag = false;
        FTPClient ftpClient = getFtpClient();
        try {
            LOGGER.info("开始删除文件");
            ftpClient.changeWorkingDirectory(path);
            ftpClient.dele(fileName);
            LOGGER.info("删除文件成功");
            flag = true;
        } catch (Exception e) {
            LOGGER.error("删除文件失败", e);
        } finally {
            releaseFtpClient(ftpClient);
        }
        return flag;
    }

    /**
     * 获取远程文件
     *
     * @param path     路径
     * @param fileName 文件名
     * @return 是否成功
     * @throws IOException IO异常
     */
    public static File retrieveFileStream(String path, String fileName) throws IOException {
        boolean flag = false;
        FTPClient ftpClient = getFtpClient();
        ftpClient.changeWorkingDirectory(path);
        try {
            FTPFile[] fs = ftpClient.listFiles();
            for (FTPFile f : fs) {
                if (f.isDirectory()) {
                    System.out.println(11111);
                }
                if (f.getName().equals(fileName)) {
                    File localFile = new File(f.getName());
                    OutputStream is = new FileOutputStream(localFile);
                    ftpClient.retrieveFile(f.getName(), is);
                    is.close();
                    return localFile;
                }
            }
        } catch (Exception e) {
            LOGGER.error("获取文件失败", e);
        } finally {
            releaseFtpClient(ftpClient);
        }
        return null;
    }


    private static boolean changeWorkingDirectory(String directory, FTPClient ftpClient) {
        boolean flag = true;
        try {
            flag = ftpClient.changeWorkingDirectory(directory);
            if (flag) {
                LOGGER.info("进入目录" + directory + "成功");
            } else {
                LOGGER.info("无" + directory + "目录");
            }
        } catch (Exception e) {
            LOGGER.error("转换目录失败", e);
        }
        return flag;
    }

    private static boolean existFile(String path, FTPClient ftpClient) throws IOException {
        return ftpClient.listFiles(path).length > 0;
    }


    private static boolean makeDirectory(String dir, FTPClient ftpClient) {
        boolean flag = true;
        try {
            flag = ftpClient.makeDirectory(dir);
            LOGGER.info("创建目录" + dir + "成功" + flag);
        } catch (Exception e) {
            LOGGER.error("创建目录" + dir + "失败", e);
        }
        return flag;
    }

    private static boolean createDirectory(String remotePath, FTPClient ftpClient) {
        boolean flag = true;
        String directory = remotePath + "/";
        //如果远程目录不存在，则递归创建远程服务器目录
        try {
            if (!"/".equalsIgnoreCase(directory) && !changeWorkingDirectory(directory, ftpClient)) {
                int start = 0;
                int end = 0;
                if (directory.startsWith("/")) {
                    start = 1;
                } else {
                    start = 0;
                }
                end = directory.indexOf('/', start);
                String path = "";
                String paths = "";
                while (true) {
                    String subDirectory = new String(remotePath.substring(start, end).getBytes(UTF8), ISO88591);
                    path = path + "/" + subDirectory;
                    if (!existFile(path, ftpClient)) {
                        LOGGER.info("开始创建目录");
                        makeDirectory(subDirectory, ftpClient);
                    }
                    changeWorkingDirectory(subDirectory, ftpClient);

                    paths = paths + "/" + subDirectory;
                    start = end + 1;
                    end = directory.indexOf('/', start);
                    //检查所有目录是否创建完毕
                    if (end <= start) {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("创建目录失败", e);
            flag = false;
        }
        return flag;
    }


    /**
     * 获取指定路径下的FTP文件
     *
     * @param remoteFilePath 远程路径
     * @return List<String> 远程文件信息
     * @throws IOException IO异常
     */
    public static List<String> readFileByLine(String remoteFilePath) throws IOException {
        FTPClient ftpClient = getFtpClient();
        try (InputStream in = ftpClient.retrieveFileStream(encodingPath(remoteFilePath));
             BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            return br.lines().map(line -> StringUtils.trimToEmpty(line))
                    .filter(line -> StringUtils.isNotEmpty(line))
                    .collect(Collectors.toList());
        } finally {
            ftpClient.completePendingCommand();
            releaseFtpClient(ftpClient);
        }
    }

    /**
     * 获取指定路径下的FTP文件
     *
     * @param remotePath 远程路径
     * @return FTPFile[] FTP文件数组
     * @throws IOException IO异常
     */
    public static FTPFile[] retrieveFTPFiles(String remotePath) throws IOException {
        FTPClient ftpClient = getFtpClient();
        try {
            return ftpClient.listFiles(encodingPath(remotePath + "/"),
                    file -> file != null && file.getSize() > 0);
        } finally {
            releaseFtpClient(ftpClient);
        }
    }

    /**
     * 获取指定路径下FTP文件名称
     *
     * @param remotePath 远程路径
     * @return List<String> 远程文件名
     * @throws IOException IO异常
     */
    public static List<String> retrieveFileNames(String remotePath) throws IOException {
        FTPFile[] ftpFiles = retrieveFTPFiles(remotePath);
        if (ArrayUtils.isEmpty(ftpFiles)) {
            return new ArrayList<>();
        }
        return Arrays.stream(ftpFiles).filter(Objects::nonNull)
                .map(FTPFile::getName).collect(Collectors.toList());
    }


    /**
     * 编码文件路径
     *
     * @param path 路径
     * @return String 修改过后的路径
     * @throws UnsupportedEncodingException 不支持编码格式的异常
     */
    private static String encodingPath(String path) throws UnsupportedEncodingException {
        return new String(path.replaceAll("//", "/").getBytes(UTF8), ISO88591);
    }


    private static FTPClient getFtpClient() {
        checkFtpClientPoolAvailable();
        FTPClient ftpClient = null;
        Exception ex = null;
        //获取连接最多尝试3次
        for (int i = 0; i < CONNECT_COUNT; i++) {
            try {
                ftpClient = ftpClientObjectPool.borrowObject();
                ftpClient.changeWorkingDirectory("/");
                break;
            } catch (Exception e) {
                ex = e;
            }
        }
        if (ftpClient == null) {
            throw new RuntimeException("Could not get a ftpClient from the pool", ex);
        }
        return ftpClient;
    }

    private static void releaseFtpClient(FTPClient ftpClient) {
        if (ftpClient == null) {
            return;
        }
        try {
            ftpClientObjectPool.returnObject(ftpClient);
        } catch (Exception e) {
            LOGGER.error("Cloud not return the ftpClient to the pool", e);
            //destroyFtpClient
            if (ftpClient.isAvailable()) {
                try {
                    ftpClient.disconnect();
                } catch (IOException io) {
                    LOGGER.error("关闭连接失效", e);
                }
            }
        }
    }

    private static void checkFtpClientPoolAvailable() {
        Assert.state(hasInit, "FTP未启用或连接失败!");
    }

}
