package com.hengtiansoft.common.util;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.hengtiansoft.config.SmsConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 短信处理client工厂类
 * Created by linwu on 8/8/2018.
 */
public final class IAcsClientFactory {

    private IAcsClientFactory(){};

    private static final Logger LOGGER = LoggerFactory.getLogger(IAcsClientFactory.class);

    private static final String REGION_ID = "cn-hangzhou";

    private static final String ENDPOINT_NAME = "cn-hangzhou";

    private static IAcsClient acsClient = null;

    /**
     * 获取一个IAcsClient对象
     * @return
     */
    public static IAcsClient getInstance() {
        try {
            synchronized (IAcsClientFactory.class) {
                if (acsClient == null) {
                    //加载配置文件
                    SmsConfig smsConfig = (SmsConfig) SpringContextUtil.getBean("smsConfig");
                    if (smsConfig != null) {
                        IClientProfile profile = DefaultProfile.getProfile(REGION_ID, smsConfig.getAccessKeyId(), smsConfig.getAccessSecret());
                        DefaultProfile.addEndpoint(ENDPOINT_NAME, REGION_ID, smsConfig.getProduct(), smsConfig.getDomain());
                        acsClient = new DefaultAcsClient(profile);
                    }
                }
            }
        } catch (ClientException e) {
            LOGGER.error("获取短信处理客户端失败", e);
            return null;
        }
        return acsClient;
    }

}
