package com.hengtiansoft.common.constant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * 权限
 * 
 * @author zhendongwu
 * 
 */
public final class Permissions {
    /**
     * 系统权限管理
     */
    public static final String ADMIN_PERMISSION_MANAGE = Module.PERMISSION + ":" + Permission.MANAGE;
    /**
     * 添加用户信息
     */
    public static final String ADMIN_USER_ADD = Module.USER + ":" + Permission.ADD;
    /**
     * 编辑用户信息
     */
    public static final String ADMIN_USER_EDIT = Module.USER + ":" + Permission.EDIT;

    /**
     * 删除用户信息
     */
    public static final String ADMIN_USER_DELETE = Module.USER + ":" + Permission.DELETE;
    /**
     * 重置用户密码
     */
    public static final String ADMIN_USER_CHANGEPASSWORD = Module.USER + ":" + Permission.RESET_PWD;
    /**
     * 查看用户信息
     */
    public static final String ADMIN_USER_VIEW = Module.USER + ":" + Permission.VIEW;

    /**
     * 添加角色信息
     */
    public static final String ADMIN_ROLE_ADD = Module.ROLE + ":" + Permission.ADD;

    /**
     * 编辑角色信息
     */
    public static final String ADMIN_ROLE_EDIT = Module.ROLE + ":" + Permission.EDIT;

    /**
     * 删除角色信息
     */
    public static final String ADMIN_ROLE_DELETE = Module.ROLE + ":" + Permission.DELETE;

    /**
     * 查看角色信息
     */
    public static final String ADMIN_ROLE_VIEW = Module.ROLE + ":" + Permission.VIEW;

    /**
     * 日志查询
     */
    public static final String LOG_VIEW = Module.LOG + ":" + Permission.VIEW;

    /**
     * 查看待办事项
     */
    public static final String TODO_VIEW = Module.TODO + ":" + Permission.VIEW;

    /**
     * 用于存放所有的模块
     */
    public static final Map<String, String> MODULE_MAP = new HashMap<String, String>() {
        private static final long serialVersionUID = 1L;
        {
            putAll(buildModuleMap());
        }
    };
    private static final Logger LOGGER = LoggerFactory.getLogger(Permissions.class);

    private Permissions() {
    }

    private static Map<String, String> buildModuleMap() {
        Field[] module = Module.class.getDeclaredFields();
        Field[] desc = Module.Description.class.getDeclaredFields();
        Map<String, String> moduleMap = new HashMap<String, String>();
        for (int i = 0; i < module.length; i++) {
            for (int j = 0; j < desc.length; j++) {
                if (module[i].getName().equals(desc[j].getName())) {
                    try {
                        moduleMap.put((String) module[i].get(module[i].getName()), module[i].get(module[i].getName())
                                + ":" + desc[j].get(desc[j].getName()));
                    } catch (IllegalArgumentException e) {
                        LOGGER.error("buildModuleMap occur error", e);
                    } catch (IllegalAccessException e) {
                        LOGGER.error("buildModuleMap occur error", e);
                    }
                    break;
                }
            }
        }
        return moduleMap;
    }

    /**
     * Module 和 Description的属性名称必须一一对应, 且数量相等. 位置无所谓
     * 
     * @author zhendongwu
     * 
     */
    public static class Module {
        public static final String PERMISSION = "admin_permission";
        public static final String USER = "admin_user";
        public static final String ROLE = "admin_role";
        public static final String LOG = "operationLog";
        public static final String TODO = "todo";

        public static class Description {
            public static final String PERMISSION = "权限管理";
            public static final String USER = "用户管理";
            public static final String ROLE = "角色管理";
            public static final String LOG = "日志管理";
            public static final String TODO = "待办事项";
            public static final String HOME = "Home";
        }
    }

    public static class Permission {
        public static final String VIEW = "view";
        public static final String ADD = "add";
        public static final String EDIT = "edit";
        public static final String DELETE = "delete";
        public static final String MANAGE = "manage";
        public static final String RESET_PWD = "resetPassword";
        public static final String DETAIL = "detail";
    }

}
