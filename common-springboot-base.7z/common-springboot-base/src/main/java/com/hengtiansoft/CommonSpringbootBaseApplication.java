package com.hengtiansoft;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

@MapperScan(basePackages = {"com.hengtiansoft.servlet.mapper"})
@ServletComponentScan
@SpringBootApplication
public class CommonSpringbootBaseApplication {

	/**
	 * 基础启动类
	 * @param args args参数
	 */
	public static void main(String[] args) {
		SpringApplication.run(CommonSpringbootBaseApplication.class, args);
	}
}
