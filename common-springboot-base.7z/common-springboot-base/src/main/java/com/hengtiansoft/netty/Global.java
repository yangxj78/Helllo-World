package com.hengtiansoft.netty;

import io.netty.channel.Channel;
import io.netty.channel.group.ChannelGroup;
import io.netty.channel.group.DefaultChannelGroup;
import io.netty.util.concurrent.GlobalEventExecutor;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * group: 用来存储访问的channel
 *        channelGroup的原型是Set集合，保证Channel的唯一，如需根据参数标注存储，可以使用currentHashMap存储
 *
*  map:   用来存储客户端id与channel的关联关系
 * Created by linwu on 7/11/2018.
 */
public final class Global {

    private Global() {
    }

    private static ChannelGroup group = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    private static ChannelGroup adminGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    private static ChannelGroup tvGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    private static ChannelGroup bigScreenGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    private static ChannelGroup selfGroup = new DefaultChannelGroup(GlobalEventExecutor.INSTANCE);

    /**
     * hr 公司id与当前电脑对应关系
     */
    private static Map<Integer, Channel> hrMap = new ConcurrentHashMap();

    /**
     * 展位id与电视机对应关系
     */
    private static Map<Integer, Channel> tvMap = new ConcurrentHashMap();

    public static ChannelGroup getGroup() {
        return group;
    }

    public static ChannelGroup getAdminGroup() {
        return adminGroup;
    }

    public static ChannelGroup getTvGroup() {
        return tvGroup;
    }

    public static Map<Integer, Channel> getHrMap() {
        return hrMap;
    }

    public static Map<Integer, Channel> getTvMap() {
        return tvMap;
    }

    public static ChannelGroup getBigScreenGroup() {
        return bigScreenGroup;
    }

    public static ChannelGroup getSelfGroup() {
        return selfGroup;
    }
}
