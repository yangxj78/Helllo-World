package com.hengtiansoft.netty;

import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.codec.http.HttpHeaders;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshaker;
import io.netty.handler.codec.http.websocketx.WebSocketServerHandshakerFactory;
import io.netty.util.CharsetUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;

/**
 * 该类是单例的，每个线程处理会新实例化一个类
 * 每个成功线程的访问顺序：channelActive（开启连接）
 *                      -> handleHttpRequest（http握手处理）
 *                      -> channelRead0（消息接收处理）
 *                      -> handlerWebSocketFrame（实际处理，可以放到其他类里面分业务进行）
 * 在该设计中，设计了路由功能，在handleHttpRequest中对每个channel连接的时候对每个连接的url进行绑定参数，
 * 然后在messageReceived中获取绑定的参数进行分发处理，
 * 同时也获取了uri后置参数，有注释
 *
 * 针对第三点路由分发，还有一种方法就是handshaker的uri()方法
 *
 * 群发的时候遍历集合或者map的时候，必须每个channel都实例化一个TextWebSocketFrame对象，否则会报错或者发不出
 *
 * Created by linwu on 7/11/2018.
 */
public class MyWebSocketServerHandler extends SimpleChannelInboundHandler<Object> {

    private static final Logger LOGGER = LoggerFactory.getLogger(MyWebSocketServerHandler.class);

    private WebSocketServerHandshaker handshaker;

    @Override
    public void channelActive(ChannelHandlerContext ctx) {
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        //移除
        /*try {
            String uri = handshaker.uri();
            if (uri.endsWith(UserTypeEnum.ADMIN.getDesc())) {
                Global.getAdminGroup().remove(ctx.channel());
            } else if (uri.endsWith(UserTypeEnum.BIG_SCREEN.getDesc())) {
                Global.getBigScreenGroup().remove(ctx.channel());
            } else if (uri.endsWith(UserTypeEnum.SELF_HELP_MACHINE.getDesc())) {
                Global.getSelfGroup().remove(ctx.channel());
            } else if (uri.contains(UserTypeEnum.TV.getDesc())) {
                Integer boothId = Integer.parseInt(uri.substring(uri.lastIndexOf('/') + 1));
                Global.getTvMap().remove(boothId);
                Global.getTvGroup().remove(ctx.channel());
            } else {
                Integer boothId = Integer.parseInt(uri.substring(uri.lastIndexOf('/') + 1));
                Global.getHrMap().remove(boothId);
                Global.getGroup().remove(ctx.channel());
            }
            LOGGER.error("客户端与服务器端连接关闭: " + ctx.channel().remoteAddress().toString());
        } catch (Exception e) {
            LOGGER.error("客户端与服务器端连接关闭失败", e);
        }*/
    }


    /**
     * 接收客户端发送的消息channel通道, 从通道中读取数据，也就是服务器端接收客户端发来的数据
     * 但是这个数据在不进行解码时它是ByteBuf类型的
     * @param ctx
     * @param msg
     */
    @Override
    protected void channelRead0(ChannelHandlerContext ctx, Object msg) {
        //传统的HTTP接入
        if (msg instanceof FullHttpRequest) {
            handleHttpRequest(ctx, ((FullHttpRequest) msg));
        }
        //WebSocket接入
        if (msg instanceof TextWebSocketFrame) {
             String request = ((TextWebSocketFrame) msg).text();
             ctx.channel().writeAndFlush(new TextWebSocketFrame(request));
        }
    }

    /**
     * 在通道读取完成后会在这个方法里通知，对应可以做刷新操作 ctx.flush()
     * @param ctx
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }


    private void handleHttpRequest(ChannelHandlerContext ctx, FullHttpRequest req) {
        //如果HTTP解码失败，返回HTTP异常
        if (!req.getDecoderResult().isSuccess()
                || !("websocket".equals(req.headers().get("Upgrade")))) {
            sendHttpResponse(ctx, req,
                    new DefaultFullHttpResponse(HttpVersion.HTTP_1_1, HttpResponseStatus.BAD_REQUEST));
            return;
        }

        //获取url后置参数
        String uri = req.getUri();
        try{
            //存入客户端id与channel关系
            if (uri.endsWith(UserTypeEnum.ADMIN.getDesc())) {
                Global.getAdminGroup().add(ctx.channel());
            } else if (uri.endsWith(UserTypeEnum.BIG_SCREEN.getDesc())) {
                Global.getBigScreenGroup().add(ctx.channel());
            }  else if (uri.endsWith(UserTypeEnum.SELF_HELP_MACHINE.getDesc())) {
                Global.getSelfGroup().add(ctx.channel());
            } else if (uri.contains(UserTypeEnum.TV.getDesc())) {
                Global.getTvGroup().add(ctx.channel());
                Integer boothId = Integer.parseInt(uri.substring(uri.lastIndexOf('/') + 1));
                LOGGER.info("客户端ID: "+ boothId);
                Global.getTvMap().put(boothId, ctx.channel());
                LOGGER.info("客户端ID: " + Global.getTvMap().get(boothId));
            } else {
                Global.getGroup().add(ctx.channel());
                Integer boothId = Integer.parseInt(uri.substring(uri.lastIndexOf('/') + 1));
                LOGGER.info("客户端ID: "+ boothId);
                Global.getHrMap().put(boothId, ctx.channel());
                LOGGER.info("客户端ID: " + Global.getHrMap().get(boothId));
            }
            LOGGER.info("客户端与服务器端连接开启: " + ctx.channel().remoteAddress().toString());
        } catch (Exception e){
            LOGGER.error("客户端连接失败", e);
            return;
        }

        //构造握手响应返回，本机测试
        WebSocketServerHandshakerFactory wsFactory = new WebSocketServerHandshakerFactory(
                "ws://"+req.headers().get(HttpHeaders.Names.HOST) + uri, null, false
        );
        handshaker = wsFactory.newHandshaker(req);
        if (handshaker == null) {
            WebSocketServerHandshakerFactory.sendUnsupportedWebSocketVersionResponse(ctx.channel());
        }else {
            handshaker.handshake(ctx.channel(), req);
        }
    }

    private static void sendHttpResponse(ChannelHandlerContext ctx, FullHttpRequest req, DefaultFullHttpResponse res) {
        //返回应答给客户端
        if (res.getStatus().code() != MagicNumConstant.SUCCESS_CODE) {
            ByteBuf buf = Unpooled.copiedBuffer(res.getStatus().toString(), CharsetUtil.UTF_8);
            res.content().writeBytes(buf);
            buf.release();
        }

        //如果是非Keep-Alive，关闭连接
        ChannelFuture f = ctx.channel().writeAndFlush(res);
        if (!HttpHeaders.isKeepAlive(req) || res.getStatus().code() != MagicNumConstant.SUCCESS_CODE) {
            f.addListener(ChannelFutureListener.CLOSE);
        }
    }

    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        LOGGER.error("error", cause);
        ctx.close();
    }

}
