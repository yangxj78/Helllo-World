package com.hengtiansoft.netty;

import com.hengtiansoft.common.constant.MagicNumConstant;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.stream.ChunkedWriteHandler;

/**
 * Created by linwu on 7/11/2018.
 */
public class ChildChannelHandler extends ChannelInitializer<SocketChannel> {

    private static final int SIXTY_FIVE_FIVE_THREE_SIX = 65536;
    @Override
    protected void initChannel(SocketChannel socketChannel) throws Exception {
        //设置30秒没有读到数据，则触发一个READER_IDLE事件
        //socketChannel.pipeline().addLast(new IdleStateHandler(30, 0 , 0));

        //HttpServerCodec:将请求和应答消息解码为HTTP消息
        socketChannel.pipeline().addLast("http-codec", new HttpServerCodec());

        //HttpObjectAggregator：将Http消息的多个部分合成一个完整的HTTP消息
        socketChannel.pipeline().addLast("aggregator", new HttpObjectAggregator(SIXTY_FIVE_FIVE_THREE_SIX));

        //ChunkedWriteHandler：向客户端发送HTML5文件
        socketChannel.pipeline().addLast("http-chunked", new ChunkedWriteHandler());

        //在管道中添加我们自己的接收数据实现方法
        socketChannel.pipeline().addLast("handler", new MyWebSocketServerHandler());
    }

}
