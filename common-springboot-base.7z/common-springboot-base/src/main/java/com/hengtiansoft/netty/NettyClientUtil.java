package com.hengtiansoft.netty;

import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import io.netty.handler.codec.http.websocketx.TextWebSocketFrame;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 客户端通知工具类
 * Created by linwu on 7/16/2018.
 */
public class NettyClientUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(NettyClientUtil.class);


    /**
     * 根据客户端id通知响应HR客户端
     * @param boothId
     */
    public static void notifyHr(Integer boothId) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(new Date().toString() + " channelId-" +  Global.getHrMap().get(boothId).id() + " : " + "flush");
            //返回（谁发的发给谁）
            Global.getHrMap().get(boothId).writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒Hr客户端出错: " + boothId , e);
        }
    }

    public static void notifyHr(Integer boothId, String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //返回（谁发的发给谁）
            Global.getHrMap().get(boothId).writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒客户端出错", e);
        }
    }

    /**
     * 根据客户端id通知响应Tv客户端
     * @param boothId
     */
    public static void notifyTv(Integer boothId, String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //返回（谁发的发给谁）
            Global.getTvMap().get(boothId).writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒Tv客户端出错: " + boothId, e);
        }
    }

    public static void notifyTvHrSign(Integer boothId, String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //返回（谁发的发给谁）
            Global.getTvMap().get(boothId).writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒Tv客户端HRTv登录出错: " + boothId, e);
        }
    }

    /**
     * 通知响应admin端
     */
    public static void notifyAdmin() {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(new Date().toString() + " admin flush ");
            //群发到admin端
            Global.getAdminGroup().writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒all admin客户端出错", e);
        }
    }

    /**
     * 通知响应大屏端
     */
    public static void notifyBigScreen(String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //群发到admin端
            Global.getBigScreenGroup().writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒all BigScreen客户端出错", e);
        }
    }


    /**
     * 通知响应HR
     */
    public static void notifyAllHR(String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //群发到hr端
            Global.getGroup().writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒all HR客户端出错", e);
        }
    }


    /**
     * 通知响应Tv
     */
    public static void notifyAllTv(String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //群发到Tv端
            Global.getTvGroup().writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒all Tv客户端出错", e);
        }
    }


    /**
     * 通知响应自助机
     */
    public static void notifySelfHelpMachine(String data) {
        try {
            TextWebSocketFrame tws = new TextWebSocketFrame(data);
            //群发到自助机端
            Global.getSelfGroup().writeAndFlush(tws);
        } catch (Exception e) {
            LOGGER.error("提醒all SelfHelpMachine客户端出错", e);
        }
    }

}
