package com.hengtiansoft.netty;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Created by linwu on 7/11/2018.
 */
@Component
public class NettyServer {

    private static final Logger LOGGER = LoggerFactory.getLogger(NettyServer.class);

    private static final int INET_PORT = 7397;
    @PostConstruct
    public void initNetty() {
        new Thread() {
            @Override
            public void run() {
                new NettyServer().start();
            }
        }.start();
    }

    public void start() {
        LOGGER.info("Netty端口启动：");
        //Boss线程：由这个线程池提供的线程是boss种类的，用于创建，连接，绑定socket，（有点像门卫）
        //然后把这些socket传给worker线程池

        //在服务端每个监听的socket都有一个boss线程来处理。
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        //在客户端，只有一个boss线程来处理所有的socket
        //Worker线程：Worker线程执行所有的异步I/O，即处理操作
        EventLoopGroup workGroup = new NioEventLoopGroup();

        try {
            //ServerBootstrap->启动NIO服务的辅助启动类
            //负责初始化Netty服务器，并且开始监听端口的socket请求
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workGroup);
            //设置非阻塞，用它来建立新accept的连接，用于构建serversocketchannel的工厂类
            b.channel(NioServerSocketChannel.class);

            //ChildChannelHandler 对出入的数据进行的业务操作，其继承ChannelInitializer
            b.childHandler(new ChildChannelHandler());
            LOGGER.info("服务端开启等待客户端连接... ...");
            Channel ch = b.bind(INET_PORT).sync().channel();
            ch.closeFuture().sync();
        }catch (Exception e) {
            LOGGER.error("netty服务端启动失败", e);
        }finally {
            bossGroup.shutdownGracefully();
            workGroup.shutdownGracefully();
        }

    }

}
