package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.io.Serializable;

public class DictDef implements Serializable{

    private static final long serialVersionUID = 1L;

    private Integer defId;

    private String defCode;

    private String description;

    public Integer getDefId() {
        return defId;
    }

    public void setDefId(Integer defId) {
        this.defId = defId;
    }

    public String getDefCode() {
        return defCode;
    }

    public void setDefCode(String defCode) {
        this.defCode = defCode == null ? null : defCode.trim();
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }
}