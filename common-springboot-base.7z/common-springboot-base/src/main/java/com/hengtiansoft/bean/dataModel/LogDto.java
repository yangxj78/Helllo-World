package com.hengtiansoft.bean.dataModel;

import com.hengtiansoft.bean.tableModel.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author kexu
 */
public class LogDto implements Serializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(LogDto.class);

    private static final long serialVersionUID = 1L;
    private Integer id;
    private String operator;
    private String action;
    private String tableName;
    private String operationTime;
    private String comment;
    private String moduleName;
    private String oldValue;
    private String newValue;
    private String detail;

    public LogDto() {

    }

    public LogDto(Log log) {
        if (log != null) {
            this.id = log.getId();
            this.operator = log.getOperator();
            this.action = log.getAction();
            this.tableName = log.getTname();
            Date logDate = log.getOperationTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            this.operationTime = sdf.format(logDate);
            this.comment = log.getComment();
            this.moduleName = log.getModuleName();
            this.oldValue = log.getBeforeValue();
            this.newValue = log.getAfterValue();
        }
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getOperationTime() {
        return operationTime;
    }

    public void setOperationTime(String operationTime) {
        this.operationTime = operationTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public String getOldValue() {
        return oldValue;
    }

    public void setOldValue(String oldValue) {
        this.oldValue = oldValue;
    }

    public String getNewValue() {
        return newValue;
    }

    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public static Log convertToLog(LogDto logDto) {
        if (logDto == null) {
            return null;
        }else {
            Log entity = new Log();
            entity.setId(logDto.getId());
            entity.setOperator(logDto.getOperator());
            entity.setAction(logDto.getAction());
            entity.setTname(logDto.getTableName());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            try {
                Date logDate = sdf.parse(logDto.getOperationTime());
                entity.setOperationTime(logDate);
            }catch (ParseException e) {
                LOGGER.error(e.getMessage());
            }
            entity.setComment(logDto.getComment());
            entity.setModuleName(logDto.getModuleName());
            entity.setBeforeValue(logDto.getOldValue());
            entity.setAfterValue(logDto.getNewValue());
            return entity;
        }
    }


}