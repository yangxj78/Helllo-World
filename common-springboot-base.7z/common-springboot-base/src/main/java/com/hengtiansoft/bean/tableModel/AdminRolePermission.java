package com.hengtiansoft.bean.tableModel;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;

@Table(name = "admin_role_permission")
public class AdminRolePermission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "roleId")
    private Integer roleId;

    @Column(name = "permissionId")
    private Integer permissionId;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "created_by")
    private Integer createdBy;

    /**
    * @return return the value of the var id
    */
    public Integer getId() {
        return id;
    }

    /**
    * Description: Set id value
    * @param id
    *             
    */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
    * @return return the value of the var roleId
    */
    public Integer getRoleId() {
        return roleId;
    }

    /**
    * Description: Set roleId value
    * @param roleId
    *             
    */
    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    /**
    * @return return the value of the var permissionId
    */
    public Integer getPermissionId() {
        return permissionId;
    }

    /**
    * Description: Set permissionId value
    * @param permissionId
    *             
    */
    public void setPermissionId(Integer permissionId) {
        this.permissionId = permissionId;
    }

    /**
    * @return return the value of the var createdDate
    */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
    * Description: Set createdDate value
    * @param createdDate
    *             
    */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
    * @return return the value of the var createdBy
    */
    public Integer getCreatedBy() {
        return createdBy;
    }

    /**
    * Description: Set createdBy value
    * @param createdBy
    *             
    */
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

 
}