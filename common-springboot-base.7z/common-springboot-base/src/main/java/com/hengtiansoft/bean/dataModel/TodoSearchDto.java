package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

public class TodoSearchDto extends PageDto  implements Serializable {
    private static final long serialVersionUID = 1L;

    private String workPriority;
    private String status;

    public String getWorkPriority() {
        return workPriority;
    }

    public void setWorkPriority(String workPriority) {
        this.workPriority = workPriority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
