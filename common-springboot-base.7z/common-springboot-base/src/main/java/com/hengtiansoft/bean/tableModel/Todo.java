package com.hengtiansoft.bean.tableModel;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;

@Table(name = "todo")
public class Todo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "create_id")
    private Integer createId;

    @Column(name = "create_time")
    private Date createTime;

    @Column(name = "process_id")
    private Integer processId;

    @Column(name = "process_time")
    private Date processTime;

    @Column(name = "work_name")
    private String workName;

    @Column(name = "work_content")
    private String workContent;

    @Column(name = "from_module")
    private String fromModule;

    private String url;

    private String status;

    @Column(name = "work_priority")
    private Integer workPriority;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return create_id
     */
    public Integer getCreateId() {
        return createId;
    }

    /**
     * @param createId
     */
    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    /**
     * @return create_time
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * @param createTime
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * @return process_id
     */
    public Integer getProcessId() {
        return processId;
    }

    /**
     * @param processId
     */
    public void setProcessId(Integer processId) {
        this.processId = processId;
    }

    /**
     * @return process_time
     */
    public Date getProcessTime() {
        return processTime;
    }

    /**
     * @param processTime
     */
    public void setProcessTime(Date processTime) {
        this.processTime = processTime;
    }

    /**
     * @return work_name
     */
    public String getWorkName() {
        return workName;
    }

    /**
     * @param workName
     */
    public void setWorkName(String workName) {
        this.workName = workName;
    }

    /**
     * @return work_content
     */
    public String getWorkContent() {
        return workContent;
    }

    /**
     * @param workContent
     */
    public void setWorkContent(String workContent) {
        this.workContent = workContent;
    }

    /**
     * @return from_module
     */
    public String getFromModule() {
        return fromModule;
    }

    /**
     * @param fromModule
     */
    public void setFromModule(String fromModule) {
        this.fromModule = fromModule;
    }

    /**
     * @return url
     */
    public String getUrl() {
        return url;
    }

    /**
     * @param url
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return work_priority
     */
    public Integer getWorkPriority() {
        return workPriority;
    }

    /**
     * @param workPriority
     */
    public void setWorkPriority(Integer workPriority) {
        this.workPriority = workPriority;
    }
}