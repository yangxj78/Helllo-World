package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

public class IdDownDto implements Serializable {
    private static final long serialVersionUID = -2816284702602646471L;
    private int virtualId;
    private int realId;

    public int getVirtualId() {
        return virtualId;
    }

    public void setVirtualId(int virtualId) {
        this.virtualId = virtualId;
    }

    public int getRealId() {
        return realId;
    }

    public void setRealId(int realId) {
        this.realId = realId;
    }
}
