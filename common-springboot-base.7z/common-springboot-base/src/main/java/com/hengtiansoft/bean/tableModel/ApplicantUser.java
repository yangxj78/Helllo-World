package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table(name = "applicant_user")
public class ApplicantUser implements Serializable {


    private static final long serialVersionUID = -4498854625237614093L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String username;

    private String password;

    private String mobile;
    private String captcha;

    private String status;

    @Column(name = "login_failure_ct")
    private Integer loginFailureCt;

    @Column(name = "last_login_ts")
    private Date lastLoginTs;

    @Column(name = "last_login_failure_ts")
    private Date lastLoginFailureTs;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "modified_date")
    private Date modifiedDate;

    private String token;


     public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return login_failure_ct
     */
    public Integer getLoginFailureCt() {
        return loginFailureCt;
    }

    /**
     * @param loginFailureCt
     */
    public void setLoginFailureCt(Integer loginFailureCt) {
        this.loginFailureCt = loginFailureCt;
    }

    /**
     * @return last_login_ts
     */
    public Date getLastLoginTs() {
        return lastLoginTs;
    }

    /**
     * @param lastLoginTs
     */
    public void setLastLoginTs(Date lastLoginTs) {
        this.lastLoginTs = lastLoginTs;
    }

    /**
     * @return last_login_failure_ts
     */
    public Date getLastLoginFailureTs() {
        return lastLoginFailureTs;
    }

    /**
     * @param lastLoginFailureTs
     */
    public void setLastLoginFailureTs(Date lastLoginFailureTs) {
        this.lastLoginFailureTs = lastLoginFailureTs;
    }

    /**
     * @return created_date
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * @return modified_date
     */
    public Date getModifiedDate() {
        return modifiedDate;
    }

    /**
     * @param modifiedDate
     */
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }


    /**
     * @return mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public ApplicantUser(String mobile) {
        this.mobile = mobile;
    }

    public ApplicantUser() {
    }
}