package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

/**
 * Class Name: ${CLASS_NAME}
 * Description:
 *
 * @author kexu
 * {DATE}
 */
public class ProductSearchDto extends PageDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 关键字
     */
    private String keyword;

    private String category;

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

}
