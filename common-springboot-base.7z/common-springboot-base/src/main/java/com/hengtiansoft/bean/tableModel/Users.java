/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  Users.java   
 * @Package demo.bean.tableModel   
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 16, 2017 5:20:32 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.bean.tableModel;

import java.io.Serializable;

/**
 * @author jintaoxu
 *
 */
public class Users  implements Serializable{
	/**
    * Variables Name: serialVersionUID
    * Description: TODO
    * Value Description: TODO
    */
    private static final long serialVersionUID = 7875613068163480666L;
    private int id;
	private String username;
	private String password;
	private String name;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the username
	 */
	public String getUsername() {
		return username;
	}
	/**
	 * @param username the username to set
	 */
	public void setUsername(String username) {
		this.username = username;
	}
	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param id
	 * @param username
	 * @param password
	 * @param name
	 */
	public Users(){
		
	}
	public Users(int id, String username, String password, String name) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.name = name;
	}
	

}
