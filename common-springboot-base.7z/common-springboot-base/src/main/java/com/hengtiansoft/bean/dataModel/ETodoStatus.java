package com.hengtiansoft.bean.dataModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Class Name: EUserStatus
 * 
 * @author SC
 * 
 */
public enum ETodoStatus {

    COMPLETE("C", "已处理"), INCOMPLETE("I", "待处理");

    private String code;

    private String text;

    /**
     * ETodoStatus Constructor
     */
    ETodoStatus(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    /**
     * Description: 获取所有的status
     */
    public static List<ETodoStatus> getAllStatus() {
        List<ETodoStatus> list = new ArrayList<ETodoStatus>();
        for (ETodoStatus status : ETodoStatus.values()) {
            list.add(status);
        }
        return list;
    }

    /**
     * Description: 根据status code获取status
     */
    public static ETodoStatus getStatus(String code) {
        for (ETodoStatus status : ETodoStatus.values()) {
            if (status.getCode().equals(code)) {
                return status;
            }
        }
        return ETodoStatus.COMPLETE;
    }

}
