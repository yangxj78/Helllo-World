package com.hengtiansoft.bean.dataModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Class Name: EUserStatus
 * 
 * @author SC
 * 
 */
public enum ETodoPriority  {
    HIGH("1", "高"), NORMAL("2", "普通"), LOW("3", "低"), PAUSE("4", "暂停");

    private String code;

    private String text;

    /**
     * ETodoPriority Constructor
     */
    ETodoPriority(String code, String text) {
        this.code = code;
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    /**
     * Description: 获取priority的text
     */
    public static String getPriorityText(String code) {
        for (ETodoPriority p : ETodoPriority.values()) {
            if (p.getCode().equals(code)) {
                return p.getText();
            }
        }
        return NORMAL.getText();
    }

    /**
     * Description: 获取所有的priority
     */
    public static List<ETodoPriority> getPriority() {
        List<ETodoPriority> list = new ArrayList<ETodoPriority>();
        for (ETodoPriority p : ETodoPriority.values()) {
            list.add(p);
        }
        return list;
    }

}
