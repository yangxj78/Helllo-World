package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;
import java.util.Date;

/**
 * InformationDepartmentSearchDto
 * 
 */
@SuppressWarnings("serial")
public class AdminRoleSearchDto implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;

	private String name;

	private Date startDate;

	private Date endDate;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getStartDate() {
		return startDate == null ? null : (Date) startDate.clone();
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate == null ? null : (Date) startDate.clone();
	}

	public Date getEndDate() {
		return endDate == null ? null : (Date) endDate.clone();
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate == null ? null : (Date) endDate.clone();
	}

}
