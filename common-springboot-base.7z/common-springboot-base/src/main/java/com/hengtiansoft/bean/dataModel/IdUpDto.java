package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;
import java.util.List;

public class IdUpDto implements Serializable {
    private static final long serialVersionUID = 222L;
    private int realId;
    private List<Integer> virtualIds;

    public int getRealId() {
        return realId;
    }

    public void setRealId(int realId) {
        this.realId = realId;
    }

    public List<Integer> getVirtualIds() {
        return virtualIds;
    }

    public void setVirtualIds(List<Integer> virtualIds) {
        this.virtualIds = virtualIds;
    }
}
