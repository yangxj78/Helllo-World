package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;
import java.util.Date;


/**
 * TodoDto
 */
public class TodoDto implements Serializable {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private Integer createId;
    private String createUsername;
    private Date createTime;
    private Integer processId;
    private String processUsername;
    private Date processTime;
    private String workName;
    private String workContent;
    private Integer workPriority;
    private String workPriorityStr;
    private String fromModule;
    private String url;
    private String status;
    private String statusName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCreateId() {
        return createId;
    }

    public void setCreateId(Integer createId) {
        this.createId = createId;
    }

    public String getCreateUsername() {
        return createUsername;
    }

    public void setCreateUsername(String createUsername) {
        this.createUsername = createUsername;
    }


    /**
    * @return return the value of the var createTime
    */
    public Date getCreateTime() {
        return createTime;
    }

    /**
    * Description: Set createTime value
    * @param createTime
    *             
    */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getProcessId() {
        return processId;
    }

    public void setProcessId(Integer processId) {
        this.processId = processId;
    }

    public String getProcessUsername() {
        return processUsername;
    }

    public void setProcessUsername(String processUsername) {
        this.processUsername = processUsername;
    }

 

    /**
    * @return return the value of the var processTime
    */
    public Date getProcessTime() {
        return processTime;
    }

    /**
    * Description: Set processTime value
    * @param processTime
    *             
    */
    public void setProcessTime(Date processTime) {
        this.processTime = processTime;
    }

    public String getWorkName() {
        return workName;
    }

    public void setWorkName(String workName) {
        this.workName = workName;
    }

    public String getWorkContent() {
        return workContent;
    }

    public void setWorkContent(String workContent) {
        this.workContent = workContent;
    }

    public Integer getWorkPriority() {
        return workPriority;
    }

    public void setWorkPriority(Integer workPriority) {
        this.workPriority = workPriority;
    }

    /**
     * Description: 获取priority的text
     */
    public String getWorkPriorityStr() {
        workPriorityStr = ETodoPriority.getPriorityText(workPriority.toString());
        return workPriorityStr;
    }

    public void setWorkPriorityStr(String workPriorityStr) {
        this.workPriorityStr = workPriorityStr;
    }

    public String getFromModule() {
        return fromModule;
    }

    public void setFromModule(String fromModule) {
        this.fromModule = fromModule;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Description: 获取status code对应的text
     */
    public String getStatusName() {
        statusName = ETodoStatus.getStatus(status).getText();
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

}
