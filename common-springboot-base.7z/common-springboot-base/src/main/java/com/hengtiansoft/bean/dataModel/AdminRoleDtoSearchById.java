/*
 * Project Name: springboot
 * File Name: AdminRoleDtoSearchById.java
 * Class Name: AdminRoleDtoSearchById
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.bean.dataModel;

/**
 * Class Name: AdminRoleDtoSearchById Description: TODO
 * 
 * @author jintaoxu
 *
 */
public class AdminRoleDtoSearchById extends PageDto {
    private Integer id;

    /**
     * @return return the value of the var id
     */
    public Integer getId() {
        return id;
    }

    /**
     * Description: Set id value
     * 
     * @param id
     * 
     */
    public void setId(Integer id) {
        this.id = id;
    }

}
