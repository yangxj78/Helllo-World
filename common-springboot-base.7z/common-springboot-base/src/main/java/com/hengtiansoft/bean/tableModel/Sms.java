package com.hengtiansoft.bean.tableModel;

import java.io.Serializable;
import java.util.Date;

/**
 * 短信发送记录表
 */
public class Sms implements Serializable{

    private static final long serialVersionUID = 4643936599034049492L;

    private Integer id;

    private Integer type;

    private Integer recruitmentId;

    private Integer companyId;

    private Integer boothId;

    private Integer userId;

    private Integer isSuccess;

    private String mobile;

    private String code;

    private String templateCode;

    private String smsInfo;

    private Date createTs;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(Integer isSuccess) {
        this.isSuccess = isSuccess;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode == null ? null : templateCode.trim();
    }

    public String getSmsInfo() {
        return smsInfo;
    }

    public void setSmsInfo(String smsInfo) {
        this.smsInfo = smsInfo == null ? null : smsInfo.trim();
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public Sms() {
    }

    public Sms(Integer type, Integer userId, Integer isSuccess, String mobile, String code, String templateCode, String smsInfo, Date createTs) {
        this.type = type;
        this.userId = userId;
        this.isSuccess = isSuccess;
        this.mobile = mobile;
        this.code = code;
        this.templateCode = templateCode;
        this.smsInfo = smsInfo;
        this.createTs = createTs;
    }

    public Sms(Integer type, Integer recruitmentId, Integer companyId, Integer boothId, Integer userId, Integer isSuccess, String mobile, String code, String templateCode, String smsInfo, Date createTs) {
        this.type = type;
        this.recruitmentId = recruitmentId;
        this.companyId = companyId;
        this.boothId = boothId;
        this.userId = userId;
        this.isSuccess = isSuccess;
        this.mobile = mobile;
        this.code = code;
        this.templateCode = templateCode;
        this.smsInfo = smsInfo;
        this.createTs = createTs;
    }
}