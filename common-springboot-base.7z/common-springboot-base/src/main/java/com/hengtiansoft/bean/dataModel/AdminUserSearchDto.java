package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

/**
 * InformationDepartmentSearchDto
 * 
 */
public class AdminUserSearchDto extends PageDto implements Serializable {

    /**
    * Variables Name: serialVersionUID
    * Description: TODO
    * Value Description: TODO
    */
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String username;
    private String realname;
    private String mobile;
    private String roleId;
    public AdminUserSearchDto() {
    }

    public AdminUserSearchDto(String mobile) {
        this.mobile = mobile;
    }

    /**
    * @return return the value of the var id
    */
    public Integer getId() {
        return id;
    }


    /**
    * Description: Set id value
    * @param id
    *             
    */
    public void setId(Integer id) {
        this.id = id;
    }


    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

}
