package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

/**
 * 信息发送类
 * Created by linwu on 8/8/2018.
 */
public class SmsDto implements Serializable {

    private static final long serialVersionUID = -1653384427601530621L;

    private String mobile;

    private String name;

    private String templateCode;

    private String smsInfo;

    private String code;

    private Integer type;

    private Integer userId;

    private Integer recruitmentId;

    private Integer companyId;

    private String companyName;

    private Integer boothId;

    private String time;

    private String place;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSmsInfo() {
        return smsInfo;
    }

    public void setSmsInfo(String smsInfo) {
        this.smsInfo = smsInfo;
    }

    public String getTemplateCode() {
        return templateCode;
    }

    public void setTemplateCode(String templateCode) {
        this.templateCode = templateCode;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public SmsDto() {
    }

    public SmsDto(Integer type, String mobile, String name, String templateCode, String smsInfo, String code) {
        this.type = type;
        this.mobile = mobile;
        this.name = name;
        this.templateCode = templateCode;
        this.smsInfo = smsInfo;
        this.code=code;
    }

    public SmsDto(Integer type, Integer recruitmentId, Integer companyId, Integer boothId, Integer userId, String mobile,
                  String name, String templateCode, String smsInfo, String code) {
        this.type = type;
        this.recruitmentId = recruitmentId;
        this.companyId = companyId;
        this.boothId = boothId;
        this.userId = userId;
        this.mobile = mobile;
        this.name = name;
        this.templateCode = templateCode;
        this.smsInfo = smsInfo;
        this.code=code;
    }
    
}
