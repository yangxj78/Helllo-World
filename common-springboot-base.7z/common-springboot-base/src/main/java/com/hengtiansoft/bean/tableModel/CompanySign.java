package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 签到信息
 */
@Table(name = "company_sign")
public class CompanySign implements Serializable {

    private static final long serialVersionUID = -4764506251125854483L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;


    @Column(name = "recruitment_id")
    private Integer recruitmentId;

    @Column(name = "company_id")
    private Integer companyId;

    @Column(name = "booth_id")
    private Integer boothId;

    @Column(name = "meals_number")
    private Integer mealsNumber;

    @Column(name = "is_parking")
    private Integer isParking;

    @Column(name = "captcha")
    private String captcha;

    @Column(name = "status")
    private Integer status;

    @Column(name = "create_ts")
    private Date createTs;

    @Column(name = "update_ts")
    private Date updateTs;

    @Transient
    private Integer recruitmentType;

    @Transient
    private String phone;

    @Transient
    private String companyName;

    @Transient
    private Boolean isBoothed;

    @Transient
    private String token;

    @Transient
    private String ip;

    @Transient
    private Integer nettyType;
    @Transient
    private String recruitmentName;
    @Transient
    private String recruitmentTime;
    @Transient
    private String place;

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getRecruitmentTime() {
        return recruitmentTime;
    }

    public void setRecruitmentTime(String recruitmentTime) {
        this.recruitmentTime = recruitmentTime;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public Integer getMealsNumber() {
        return mealsNumber;
    }

    public void setMealsNumber(Integer mealsNumber) {
        this.mealsNumber = mealsNumber;
    }

    public Integer getIsParking() {
        return isParking;
    }

    public void setIsParking(Integer isParking) {
        this.isParking = isParking;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha == null ? null : captcha.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Date getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    public Boolean getIsBoothed() {
        return isBoothed;
    }

    public Integer getRecruitmentType() {
        return recruitmentType;
    }

    public void setRecruitmentType(Integer recruitmentType) {
        this.recruitmentType = recruitmentType;
    }

    public void setIsBoothed(Boolean boothed) {
        isBoothed = boothed;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Integer getNettyType() {
        return nettyType;
    }

    public void setNettyType(Integer nettyType) {
        this.nettyType = nettyType;
    }

    public CompanySign() {
    }

    public CompanySign(Integer recruitmentId, Integer companyId, Integer boothId, String captcha, Integer status, Date createTs) {
        this.recruitmentId = recruitmentId;
        this.companyId = companyId;
        this.boothId = boothId;
        this.captcha = captcha;
        this.status = status;
        this.createTs = createTs;
    }
}