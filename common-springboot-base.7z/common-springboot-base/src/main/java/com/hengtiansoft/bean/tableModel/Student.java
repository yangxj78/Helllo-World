/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  Student.java   
 * @Package demo.bean.tableModel   
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 20, 2017 10:18:14 AM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.bean.tableModel;

/**
 * @author jintaoxu
 *
 */
public class Student {
	private int id;
	private String newName;
	private int age;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the newName
	 */
	public String getNewName() {
		return newName;
	}
	/**
	 * @param newName the newName to set
	 */
	public void setNewName(String newName) {
		this.newName = newName;
	}
	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * @param age the age to set
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * @param id
	 * @param newName
	 * @param age
	 */
	private Student(int id, String newName, int age) {//重写构造函数后必须后面加上默认的构造函数
		super();
		this.id = id;
		this.newName = newName;
		this.age = age;
	}
	/**
	 * 
	 */
	private Student() {//必须写默认构造函数
		super();
	}
	
}
