package com.hengtiansoft.bean.dataModel;

import com.hengtiansoft.bean.tableModel.AdminRole;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.common.constant.EUserStatus;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * InformationDepartmentDto
 * 
 */
public class AdminUserDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private Integer id;

    private Integer newId;
    
    private String username;
    
    private String realname;

    private String newUsername;

    private String newRealname;

    private String newRolename;

    private String status;

    private String statusName;

    private String checkedStatus;

    private String email;
    private String mobile;
    private String oldPassword;
    private String newPassword;
    private String newConfirmPassword;
    private String newResetPassword;
    private String newResetConfirmPassword;
    private String modifiedBy;
    private String modifiedDate;



    private Integer roleId;
    private String rolename;

    private List<AdminRole> roleList = new ArrayList<AdminRole>();

    /**
     * 
     * AdminUserDto Constructor
     * 
     */
    public AdminUserDto() {

    }

    public AdminUserDto(String username, String status, String mobile, String newConfirmPassword, Integer roleId) {
        this.username = username;
        this.status = status;
        this.mobile = mobile;
        this.newConfirmPassword = newConfirmPassword;
        this.roleId = roleId;
    }

    public AdminUserDto(AdminUser adminUser) {
        this.setId(adminUser.getId());
        this.setUsername(adminUser.getUsername());
        this.setRealname(adminUser.getRealname());
        this.setStatus(adminUser.getStatus());
        this.setEmail(adminUser.getEmail());
        this.setMobile(adminUser.getMobile());
    }

    public String getNewUsername() {
        return newUsername;
    }

    public void setNewUsername(String newUsername) {
        this.newUsername = newUsername;
    }

    public String getNewRealname() {
        return newRealname;
    }

    public void setNewRealname(String newRealname) {
        this.newRealname = newRealname;
    }

    public String getNewRolename() {
        return newRolename;
    }

    public void setNewRolename(String newRolename) {
        this.newRolename = newRolename;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCheckedStatus() {
        return checkedStatus;
    }

    public void setCheckedStatus(String checkedStatus) {
        this.checkedStatus = checkedStatus;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    /**
     * 
     * Description: 获取status的中文名
     * 
     * @return
     */
    public String getStatusName() {
        statusName = EUserStatus.getStatusText(status);
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getNewResetPassword() {
        return newResetPassword;
    }

    public void setNewResetPassword(String newResetPassword) {
        this.newResetPassword = newResetPassword;
    }

    public String getNewResetConfirmPassword() {
        return newResetConfirmPassword;
    }

    public void setNewResetConfirmPassword(String newResetConfirmPassword) {
        this.newResetConfirmPassword = newResetConfirmPassword;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    public List<AdminRole> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<AdminRole> roleList) {
        this.roleList = roleList;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getNewConfirmPassword() {
        return newConfirmPassword;
    }

    public void setNewConfirmPassword(String newConfirmPassword) {
        this.newConfirmPassword = newConfirmPassword;
    }

    public String getRealname() {
        return StringUtils.trimToEmpty(realname);
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return StringUtils.trimToEmpty(email);
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return StringUtils.trimToEmpty(mobile);
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getRolename() {
        return StringUtils.trimToEmpty(rolename);
    }

    public void setRolename(String rolename) {
        this.rolename = rolename;
    }

    public Integer getNewId() {
        return newId;
    }

    public void setNewId(Integer newId) {
        this.newId = newId;
    }


}
