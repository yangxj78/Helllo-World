package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table(name = "admin_user")
public class AdminUser implements Serializable {

    private static final long serialVersionUID = 2891564263555509471L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String username;

    private String password;

    private String realname;

    private String status;

    @Column(name = "login_failure_ct")
    private Integer loginFailureCt;

    @Column(name = "last_login_ts")
    private Date lastLoginTs;

    @Column(name = "last_login_failure_ts")
    private Date lastLoginFailureTs;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "created_by")
    private Integer createdBy;

    @Column(name = "modified_date")
    private Date modifiedDate;

    @Column(name = "modified_by")
    private Integer modifiedBy;

    private String email;

    private String mobile;
    private String token;


    @Transient
    private Boolean isAdmin;

    public Boolean getAdmin() {
        return isAdmin;
    }

    public void setAdmin(Boolean admin) {
        isAdmin = admin;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return realname
     */
    public String getRealname() {
        return realname;
    }

    /**
     * @param realname
     */
    public void setRealname(String realname) {
        this.realname = realname;
    }

    /**
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return login_failure_ct
     */
    public Integer getLoginFailureCt() {
        return loginFailureCt;
    }

    /**
     * @param loginFailureCt
     */
    public void setLoginFailureCt(Integer loginFailureCt) {
        this.loginFailureCt = loginFailureCt;
    }

    /**
     * @return last_login_ts
     */
    public Date getLastLoginTs() {
        return lastLoginTs;
    }

    /**
     * @param lastLoginTs
     */
    public void setLastLoginTs(Date lastLoginTs) {
        this.lastLoginTs = lastLoginTs;
    }

    /**
     * @return last_login_failure_ts
     */
    public Date getLastLoginFailureTs() {
        return lastLoginFailureTs;
    }

    /**
     * @param lastLoginFailureTs
     */
    public void setLastLoginFailureTs(Date lastLoginFailureTs) {
        this.lastLoginFailureTs = lastLoginFailureTs;
    }

    /**
     * @return created_date
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return created_by
     */
    public Integer getCreatedBy() {
        return createdBy;
    }

    /**
     * @param createdBy
     */
    public void setCreatedBy(Integer createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * @return modified_date
     */
    public Date getModifiedDate() {
        return modifiedDate;
    }

    /**
     * @param modifiedDate
     */
    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    /**
     * @return modified_by
     */
    public Integer getModifiedBy() {
        return modifiedBy;
    }

    /**
     * @param modifiedBy
     */
    public void setModifiedBy(Integer modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    /**
     * @return EmailService
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return mobile
     */
    public String getMobile() {
        return mobile;
    }

    /**
     * @param mobile
     */
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}