package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.TodoDto;
import com.hengtiansoft.bean.tableModel.Todo;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TodoMapper extends MyMapper<Todo> {
    List<TodoDto> getTodoDtoByCondition(@Param("todo") Todo todo);
}