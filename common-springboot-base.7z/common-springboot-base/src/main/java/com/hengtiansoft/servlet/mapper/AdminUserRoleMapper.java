package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.AdminUserRole;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminUserRoleMapper extends MyMapper<AdminUserRole> {
    int deleteAdminUserRoleByIds(String[] ids);
}