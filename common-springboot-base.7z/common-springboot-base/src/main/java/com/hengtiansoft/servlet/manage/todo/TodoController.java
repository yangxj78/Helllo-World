package com.hengtiansoft.servlet.manage.todo;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.TodoDto;
import com.hengtiansoft.bean.dataModel.TodoSearchDto;
import com.hengtiansoft.bean.tableModel.Todo;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.constant.PathStrings;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import java.util.List;


/**
* Class Name: TodoController
* Description: 待办事项模块
* @author jintaoxu
*
*/
@RestController
public class TodoController {
    @Autowired
    private TodoService todoService;

    /**
     *根据条件获取所有符合条件的待办事项
     */
    @PostMapping(PathStrings.Todo.GET_VUETODO_LIST)
    public Object getTodoList(@PathVariable(PathStrings.PathVariable.ID) Integer id,@RequestBody TodoSearchDto request) {
        Todo todo = new Todo();
        todo.setProcessId(id);
        if(StringUtils.isNotEmpty(request.getWorkPriority())){
            todo.setWorkPriority(Integer.parseInt(request.getWorkPriority()));
        }
        if(StringUtils.isNotEmpty(request.getStatus())){
            todo.setStatus(request.getStatus());
        }
        Integer pageNum = (request.getPageNum() == null ? 1 : request.getPageNum());  
        Integer pageSize = (request.getPageSize() == null ? MagicNumConstant.TEN : request.getPageSize());
        PageHelper.startPage(pageNum, pageSize); 
        List<TodoDto> resp = todoService.getTodoListByCondition(todo);
        return ResultDtoFactory.toAck(StringUtils.EMPTY,new PageInfo<TodoDto>(resp));
    }
    /**
     *获取代办事项数量
     */
    @GetMapping(PathStrings.Todo.GET_VUETODO_COUNT)
    public Object getTodoCount(@PathVariable(PathStrings.PathVariable.ID) Integer id) {
        Todo todo = new Todo();
        todo.setProcessId(id);
        todo.setStatus("I");
        List<TodoDto> resp = todoService.getTodoListByCondition(todo);
        return ResultDtoFactory.toAck(StringUtils.EMPTY, resp.size());
    }
    /**
     *标记
     */
    @RequestMapping(value = PathStrings.Todo.DO_MARK, method = RequestMethod.GET)
//    @RequiresPermissions(value = Permissions.TODO_VIEW)
    @ResponseBody
    public Object doMark(@PathVariable(PathStrings.PathVariable.ID) Integer id, @RequestParam String status) {
        Todo todo = new Todo();
        todo.setId(id);
        todo.setStatus(status);
        todoService.updateTodoMaker(todo);
        return ResultDtoFactory.toAck("标记成功");
    }
 
}
