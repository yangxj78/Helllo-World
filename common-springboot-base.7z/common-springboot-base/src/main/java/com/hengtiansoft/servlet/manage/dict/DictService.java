/**
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 *
 * @Title: ExampleService.java
 * @Package demo.demo
 * @Description: TODO(用一句话描述该文件做什么)
 * @author: 网新恒天
 * @date: Oct 16, 2017 4:58:32 PM
 * @version V1.0
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved.
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.manage.dict;

import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.servlet.mapper.AdminUserMapper;
import com.hengtiansoft.servlet.mapper.CompanySignMapper;
import com.hengtiansoft.servlet.mapper.DictDataMapper;
import com.hengtiansoft.servlet.mapper.DictDefMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author linwu
 *
 */
@Service
public class DictService {

    @Autowired
    private DictDataMapper dictDataMapper;

    @Autowired
    private DictDefMapper dictDefMapper;

    @Autowired
    private CompanySignMapper companySignMapper;

    @Autowired
    private AdminUserMapper adminUserMapper;


    @Transactional
    public int addCode(DictDef dictDef) {
        return dictDefMapper.insert(dictDef);
    }

    @Transactional
    public int addData(String code, DictData dictData) {
        DictData d = dictDataMapper.findOneByDefCodeDesc(code);
        if (d == null) {
            dictData.setSeqIndex(0);
        } else {
            dictData.setSeqIndex(d.getSeqIndex() + 1);
        }
        return dictDataMapper.insert(dictData);
    }
    @Cacheable(value = "DICT_DATA_ALL", key = "'DICT_DATA_ALL'")
    public Map all() {
        Map map = new HashMap();
        map.put("WORK_YEARS", findByDefCode("WORK_YEARS"));
        map.put("SALARY_AREA", findByDefCode("SALARY_AREA"));
        map.put("EDUCATION",findByDefCode("EDUCATION"));
        map.put("COMPANY_TYPE", findByDefCode("COMPANY_TYPE"));
        map.put("RESUME_SOURCE", findByDefCode("RESUME_SOURCE"));
        map.put("WORK_TYPE",findByDefCode("WORK_TYPE"));
        map.put("YEARS", findByDefCode("YEARS"));
        map.put("USER_TYPE", findByDefCode("USER_TYPE"));
        map.put("TRADE",findByDefCode("TRADE"));
        map.put("DEGREE", findByDefCode("DEGREE"));
        return map;
    }
    @Cacheable(value = CacheConstants.DICT_DATA, key = "'DICT_DATA_'+ #id")
    public DictData findById(Integer id) {
        return Optional.ofNullable(dictDataMapper.selectByPrimaryKey(id)).orElse(new DictData());
    }

    @Cacheable(value = CacheConstants.DICT_DATA_LIST, key = "'DICT_DATA_LIST_'+ #defCode")
    public List<DictData> findByDefCode(String defCode) {
        return dictDataMapper.findByDefCode(defCode);
    }

    @CacheEvict(value = CacheConstants.DICT_DATA, key = "'DICT_DATA_'+ #id")
    public void flushDictDataCacheById(Integer id){
    }

    @CacheEvict(value = CacheConstants.DICT_DATA_LIST, key = "'DICT_DATA_LIST_'+ #defCode")
    public void flushDictDataListCacheByCode(String defCode){
    }

    @CacheEvict(value = CacheConstants.DICT_DATA, allEntries = true)
    public void flushDictDataCache(){
    }

    @CacheEvict(value = CacheConstants.DICT_DATA_LIST, allEntries = true)
    public void flushDictDataListCache(){
    }


    @Cacheable
    public DictData findByDictValue(String dictValue, String defCode) {
        return dictDataMapper.findByDictValue(dictValue, defCode);
    }

    @Cacheable
    public List<DictData> findByDictDescription(String description, String defCode) {
        return dictDataMapper.findByDictDescription(description, defCode);
    }

    @Cacheable
    public DictData findByDictSexIndex(String seqIndex, String defCode) {
        return dictDataMapper.findByDictSexIndex(seqIndex, defCode);
    }

    @Cacheable
    public DictData findOneByDefCode(String defCode) {
        return dictDataMapper.findOneByDefCode(defCode);
    }




}
