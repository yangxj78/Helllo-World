package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.AdminRole;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminRoleMapper extends MyMapper<AdminRole> {
    
}