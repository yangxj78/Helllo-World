package com.hengtiansoft.servlet.manage.companySign;

import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.servlet.mapper.CompanySignMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * Created by linwu on 7/30/2018.
 */
@Service
public class CompanySignService extends BaseService<CompanySign> {

    @Autowired
    private CompanySignMapper companySignMapper;

    /**
     * 根据ip 和 captcha 获取CompanySign
     *
     * @param ip
     * @param captcha
     * @return
     */

    //@Cacheable(value = CacheConstants.COMPANY_SIGN, key = "'COMPANY_SIGN_' + #ip + '_' + #captcha")
    public CompanySign selectByIpAndCaptcha(String ip, String captcha) {
        return companySignMapper.selectByIpAndCaptcha(ip, captcha);
    }


    //@CacheEvict(value = CacheConstants.COMPANY_SIGN, key = "'COMPANY_SIGN_' + #ip + '_' + #captcha")
    public void flushCompanySignCache(String ip, String captcha) {
    }

    public CompanySign findOneByCon2(Integer boothId, Integer recruitmentId,Integer companyId) {
        return companySignMapper.findOneByCon2(boothId, recruitmentId,companyId);
    }

    public List<Integer> findBooth(Integer id) {
        return companySignMapper.getBooth(id);
    }

    public List<Integer> findBoothByCompany(Integer recruitmentId, Integer companyId) {
        return companySignMapper. findBoothByCompany( recruitmentId,  companyId);
    }
}
