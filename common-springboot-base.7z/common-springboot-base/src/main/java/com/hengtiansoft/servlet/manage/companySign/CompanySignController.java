package com.hengtiansoft.servlet.manage.companySign;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "字典数据管理", description = "字典数据管理相关接口")
@RestController
@RequestMapping(value = "/companySign")
public class CompanySignController {

    @Autowired
    private CompanySignService companySignService;

    @ApiOperation(value = "根据字典code获取其值", httpMethod = "GET")
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public ResultDto test(@ApiParam(value = "ip", name = "ip") @RequestParam String ip,
                          @ApiParam(value = "ip", name = "captcha") @RequestParam String captcha) {
        return ResultDtoFactory.toAck("success", companySignService.selectByIpAndCaptcha(ip, captcha));
    }

}
