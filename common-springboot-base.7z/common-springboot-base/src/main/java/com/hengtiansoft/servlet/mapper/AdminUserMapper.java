package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.AdminUserDto;
import com.hengtiansoft.bean.dataModel.AdminUserSearchDto;
import com.hengtiansoft.bean.dataModel.IdDownDto;
import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AdminUserMapper extends MyMapper<AdminUser> {
    //删除用户
    int deleteAdminUserByIds(String[] ids);
    //多条件搜索
    List<AdminUserDto> searchByCon(@Param("adminUserSearchDto") AdminUserSearchDto adminUserSearchDto);
    List<IdDownDto> searchIdByPhone(String phone);

}