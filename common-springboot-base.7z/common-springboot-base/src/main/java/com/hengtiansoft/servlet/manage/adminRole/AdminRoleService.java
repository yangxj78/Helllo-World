/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  ExampleService.java   
 * @Package demo.demo
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 16, 2017 4:58:32 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.manage.adminRole;

import com.hengtiansoft.bean.dataModel.AdminRoleDto;
import com.hengtiansoft.bean.tableModel.AdminRole;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.AdminUserRole;
import com.hengtiansoft.bean.tableModel.AdminRolePermission;
import com.hengtiansoft.bean.tableModel.Log;
import com.hengtiansoft.common.constant.Permissions;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.mapper.AdminRoleMapper;
import com.hengtiansoft.servlet.mapper.AdminRolePermissionMapper;
import com.hengtiansoft.servlet.mapper.AdminUserRoleMapper;
import com.hengtiansoft.servlet.mapper.LogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @author jintaoxu
 *
 */
@Service
public class AdminRoleService {
    private static final String MODULE_NAME = Permissions.Module.Description.ROLE;

    @Autowired
    private AdminRoleMapper adminRoleMapper;

    @Autowired
    private AdminRolePermissionMapper adminRolePermissionMapper;

    @Autowired
    private AdminUserRoleMapper adminUserRoleMapper;

    @Autowired
    private LogMapper operationLogMapper;

    /**
     * 获取所有角色List
     * @return  List<AdminRole>
     */
    public List<AdminRole> getAll() {
        return adminRoleMapper.selectAll();
    }

    /**
     * 获取所有角色List
     * @return  List<AdminRole>
     */
    public List<AdminRole> searchByCon(Integer id) {
        AdminRole adminRole = new AdminRole();
        adminRole.setId(id);
        return adminRoleMapper.select(adminRole);
    }
   
 
    /**
     * 删除单条角色信息
     * @param id 角色Id
     */
    public void delete(Integer id) {
        adminRoleMapper.deleteByPrimaryKey(id);

        /**删除用户角色关联表*/
        AdminUserRole adminUserRole = new AdminUserRole();
        adminUserRole.setRoleid(id);
        adminUserRoleMapper.delete(adminUserRole);

        /**删除用户权限关联表*/
        AdminRolePermission adminRolePermission = new AdminRolePermission();
        adminRolePermission.setRoleId(id);
        adminRolePermissionMapper.delete(adminRolePermission);
    }

    /**
     * 添加角色信息
     * @param adminRoleDto adminRoleDto
     */
    public void save(AdminRoleDto adminRoleDto) {
        AdminUser currentUser = SecurityContext.getCurrentUser();

        AdminRole adminRole = new AdminRole();
        adminRole.setName(adminRoleDto.getName());
        adminRole.setDescription(adminRoleDto.getDescription());
        adminRole.setCreatedBy(SecurityContext.getCurrentUser().getId());
        adminRole.setCreatedDate(new Date());
        adminRole.setModifiedDate(new Date());
        adminRoleMapper.insertSelective(adminRole);

        Log log = new Log();
        log.setOperator(currentUser.getId().toString());
        log.setAction("增加");
        log.setTname("admin_role");
        log.setOperationTime(new Date());
        log.setComment("添加角色");
        log.setModuleName(MODULE_NAME);
        log.setBeforeValue(null);
        log.setAfterValue("角色名：" + adminRole.getName() + "\n描述："
                + adminRole.getDescription());
        operationLogMapper.insert(log);

    }

    /**
     * 获取用户角色信息
     * @param id 角色Id
     * @return AdminRole
     */
    public AdminRole findById(Integer id) {
        return adminRoleMapper.selectByPrimaryKey(id);
    }


    /**
     * 批量删除角色信息
     * @param ids 删除的数组Ids
     */
    public void deleteRoleAll(Integer[] ids) {
        /**批量删除用户角色关联表*/
        Example example = new Example(AdminRole.class);
        example.createCriteria().andIn("id", Arrays.asList(ids));
        adminRoleMapper.deleteByExample(example);
        /**批量删除用户角色关联表*/
        Example exampleAur = new Example(AdminUserRole.class);
        exampleAur.createCriteria().andIn("roleid", Arrays.asList(ids));
        adminUserRoleMapper.deleteByExample(exampleAur);
        /**批量删除用户角色关联表*/
        Example exampleAup = new Example(AdminRolePermission.class);
        exampleAup.createCriteria().andIn("roleId", Arrays.asList(ids));
        adminRolePermissionMapper.deleteByExample(exampleAup);
    }

    /**
     * 修改用户角色信息
     * @param adminRoleDto adminRoleDto
     */
    public void update(AdminRoleDto adminRoleDto) {
        AdminUser currentUser = SecurityContext.getCurrentUser();
        AdminRole adminRole = new AdminRole();
        adminRole.setId(adminRoleDto.getId());
        adminRole.setName(adminRoleDto.getName());
        adminRole.setDescription(adminRoleDto.getDescription());
        adminRole.setModifiedBy(currentUser.getId());
        adminRole.setModifiedDate(new Date());
        adminRoleMapper.updateByPrimaryKey(adminRole);

        Log log = new Log();
        log.setOperator(currentUser.getId().toString());
        log.setAction("修改");
        log.setTname("admin_role");
        log.setOperationTime(new Date());
        log.setComment("修改角色名称");
        log.setModuleName(MODULE_NAME);
        log.setAfterValue("角色名：" + adminRoleDto.getName() + "\n描述："
                + adminRoleDto.getDescription());
        log.setBeforeValue(adminRoleDto.getDescription());
        operationLogMapper.insert(log);
        
    }
}
