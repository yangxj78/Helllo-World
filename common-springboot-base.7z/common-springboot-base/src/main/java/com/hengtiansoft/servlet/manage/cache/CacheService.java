package com.hengtiansoft.servlet.manage.cache;

import com.hengtiansoft.common.constant.CacheConstants;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

/**
 * 缓存Service
 * Created by linwu on 8/9/2018.
 */
@Service
public class CacheService {

    //@CacheEvict(value = CacheConstants.ADMIN_USER, key = "'ADMIN_USER_' +  #username")
    public void flushUserByName(String username) {
    }


}
