package com.hengtiansoft.servlet.manage.dict;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.tableModel.DictData;
import com.hengtiansoft.bean.tableModel.DictDef;
import com.hengtiansoft.common.constant.ApplicationConstant;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(value = "字典数据管理", description = "字典数据管理相关接口")
@RestController
@RequestMapping(value = "/dict")
public class DictController {

    @Autowired
    DictService dictService;

    @ApiOperation(value = "根据字典code获取其值", httpMethod = "GET")
    @RequestMapping(value = "/list/{code}", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<DictData>> list(@ApiParam(value = "字典类型", name = "code") @PathVariable String code) {
        return ResultDtoFactory.toAck("success", dictService.findByDefCode(code));
    }

    @ApiOperation(value = "根据字典id获取其值", httpMethod = "GET")
    @RequestMapping(value = "/findOne/{id}", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<DictData> list(@ApiParam(value = "字典类型", name = "id") @PathVariable Integer id) {
        return ResultDtoFactory.toAck("success", dictService.findById(id));
    }

    @ApiOperation(value = "添加字典code", httpMethod = "POST")
    @RequestMapping(value = "/code/add", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Integer> addCode(@ApiParam(value = "字典类型信息", name = "dictDef") @RequestBody DictDef dictDef) {
        return ResultDtoFactory.toAck("success", dictService.addCode(dictDef));
    }

    @ApiOperation(value = "根据字典code添加其值", httpMethod = "POST")
    @RequestMapping(value = "/data/add/{code}", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Integer> addData(@ApiParam(value = "字典类型", name = "code") @PathVariable String code,
                                      @ApiParam(value = "字典值", name = "id") @RequestBody DictData dictData) {
        return ResultDtoFactory.toAck("success", dictService.addData(code, dictData));
    }

    @ApiOperation(value = "去除字典某data缓存", httpMethod = "DELETE")
    @RequestMapping(value = "/data/flush/{id}", method = RequestMethod.DELETE)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto flushdictDataCacheById(@ApiParam(value = "字典类型", name = "id") @PathVariable Integer id) {
        dictService.flushDictDataCacheById(id);
        return ResultDtoFactory.toAck("success");
    }

    @ApiOperation(value = "去除字典某data列表缓存", httpMethod = "DELETE")
    @RequestMapping(value = "/dataList/flush/{code}", method = RequestMethod.DELETE)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto flushdictDataListCacheByCode(@ApiParam(value = "字典类型", name = "code") @PathVariable String code) {
        dictService.flushDictDataListCacheByCode(code);
        return ResultDtoFactory.toAck("success");
    }

    @ApiOperation(value = "去除字典所有data缓存", httpMethod = "DELETE")
    @RequestMapping(value = "/data/flush", method = RequestMethod.DELETE)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto flushdictDataCache() {
        dictService.flushDictDataCache();
        return ResultDtoFactory.toAck("success");
    }

    @ApiOperation(value = "去除字典所有data列表缓存", httpMethod = "DELETE")
    @RequestMapping(value = "/dataList/flush", method = RequestMethod.DELETE)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto flushdictDataListCache() {
        dictService.flushDictDataListCache();
        return ResultDtoFactory.toAck("success");
    }

    @ApiOperation(value = "获取字典数据所有", httpMethod = "GET")
    @RequestMapping(value = "/data/list", method = RequestMethod.GET)
    public ResultDto listData() {
        return ResultDtoFactory.toAck("success", dictService.all());
    }

}
