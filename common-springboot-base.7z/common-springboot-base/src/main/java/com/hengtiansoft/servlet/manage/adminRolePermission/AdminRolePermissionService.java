/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  ExampleService.java   
 * @Package demo.demo
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 16, 2017 4:58:32 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.manage.adminRolePermission;

import com.hengtiansoft.bean.dataModel.RolePermissionPostDto;
import com.hengtiansoft.bean.tableModel.AdminRolePermission;
import com.hengtiansoft.servlet.mapper.AdminRolePermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * @author jintaoxu
 *
 */
@Service
public class AdminRolePermissionService {
	@Autowired
	private AdminRolePermissionMapper adminRolePermissionMapper;
    //获取角色权限
	public List<AdminRolePermission> findByRoleId(AdminRolePermission adminRolePermission){
	    return adminRolePermissionMapper.select(adminRolePermission);
	}
	//保存角色权限
	public boolean saveAdminRolePermission(RolePermissionPostDto rolePermissionPostDto){
        Integer loginUserId = 1;//当前登录的用户	    
        Integer roleId = rolePermissionPostDto.getRoleId();//被修改的角色id
        String permissions = rolePermissionPostDto.getPermissions();
        //清除原来的旧权限
        AdminRolePermission adminRolePermission = new AdminRolePermission();
        adminRolePermission.setRoleId(roleId);
        boolean flag1 = adminRolePermissionMapper.delete(adminRolePermission)>0;
        boolean flag2 = true;
        //生成新的权限
        if (permissions != null && !"".equals(permissions.trim())) {
            String[] permissionArr = permissions.split(",");
            List<AdminRolePermission> arrList = new LinkedList<>();
            for (int i = 0; i < permissionArr.length; i++) {
                AdminRolePermission rolePermission = new AdminRolePermission();
                rolePermission.setRoleId(roleId);
                rolePermission.setPermissionId(Integer.parseInt(permissionArr[i].trim()));
                rolePermission.setCreatedDate(new Date());
                rolePermission.setCreatedBy(loginUserId);
                arrList.add(rolePermission);
            }
            flag2 = adminRolePermissionMapper.insertList(arrList)>0;
        }
        return flag1&&flag2;
	}
}
