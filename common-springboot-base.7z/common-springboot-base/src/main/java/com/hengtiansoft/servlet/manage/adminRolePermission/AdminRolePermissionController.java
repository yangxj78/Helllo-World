/*
 * Project Name: springboot
 * File Name: AdminRolePermissionController.java
 * Class Name: AdminRolePermissionController
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.servlet.manage.adminRolePermission;

import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.RolePermissionPostDto;
import com.hengtiansoft.bean.tableModel.AdminRolePermission;
import com.hengtiansoft.common.constant.PathStrings;
import com.hengtiansoft.common.constant.Permissions;
import com.hengtiansoft.servlet.manage.adminUser.AdminUserController;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
* Class Name: AdminRolePermissionController
* Description: 权限管理模块
* @author jintaoxu
*
*/
@RestController
public class AdminRolePermissionController {
    @Autowired
    private AdminRolePermissionService adminRolePermissionService;
    
    private static final Log log = LogFactory.getLog(AdminUserController.class);

    /**
     * 获取角色的权限
     */
    @GetMapping(value = PathStrings.Permission.GET_ROLE_PERMISSIONS)
    @RequiresPermissions(value = Permissions.ADMIN_PERMISSION_MANAGE)
    public Object getRolePermissions(@RequestParam(PathStrings.IParameter.ROLEID) String roleIdString) {
        int roleId = Integer.parseInt(roleIdString);
        AdminRolePermission adminRolePermission = new AdminRolePermission();
        adminRolePermission.setRoleId(roleId);
        List<AdminRolePermission> rolePermissions = adminRolePermissionService.findByRoleId(adminRolePermission);
        return ResultDtoFactory.toAck(StringUtils.EMPTY, rolePermissions);
    }
    /**
     * 保存角色的权限
     */
    @PostMapping(value = PathStrings.Permission.ASSIGN_PERMISSIONS)
    @RequiresPermissions(value = Permissions.ADMIN_PERMISSION_MANAGE)
    public Object assignPermissions(@RequestBody RolePermissionPostDto rolePermissionPostDto) {
        adminRolePermissionService.saveAdminRolePermission(rolePermissionPostDto);
        return ResultDtoFactory.toAck("保存成功");
    }
    
}
