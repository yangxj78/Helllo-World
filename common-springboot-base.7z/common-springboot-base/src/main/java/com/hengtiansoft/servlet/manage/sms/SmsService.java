package com.hengtiansoft.servlet.manage.sms;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.MethodType;
import com.hengtiansoft.bean.dataModel.SmsDto;
import com.hengtiansoft.bean.tableModel.Sms;
import com.hengtiansoft.common.enumeration.StatusEnum;
import com.hengtiansoft.common.util.IAcsClientFactory;
import com.hengtiansoft.servlet.mapper.SmsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * 短信service
 * Created by linwu on 8/8/2018.
 */
@Service
public class SmsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SmsService.class);

    @Autowired
    private SmsMapper smsMapper;

    @Transactional
    public boolean send(SmsDto smsDto) {
        try {
            SendSmsRequest request = new SendSmsRequest();
            request.setMethod(MethodType.POST);
            request.setPhoneNumbers(smsDto.getMobile());
            request.setSignName("杭州高新人才网");
            request.setTemplateCode("SMS_147415746");
            request.setTemplateParam("{\"code\":\"" + smsDto.getCode() + "\"}");
            request.setOutId("yourOutId");
            SendSmsResponse sendSmsResponse = IAcsClientFactory.getInstance().getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //短信记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.YES.getCode(), smsDto.getMobile(),
                        smsDto.getCode(), "SMS_141960049",
                        smsDto.getSmsInfo(), new Date()));
            } else {
                //短信异常记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.NO.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), "SMS_141960049",
                        smsDto.getSmsInfo(), new Date()));
                return false;

            }
            LOGGER.info("发送短信成功");
            return true;
        } catch (Exception e) {
            LOGGER.error("发送短信失败", e);
            return false;
        }
    }

    @Transactional
    public boolean sendRemind(SmsDto smsDto) {
        try {
            SendSmsRequest request = new SendSmsRequest();
            request.setMethod(MethodType.POST);
            request.setPhoneNumbers(smsDto.getMobile());
            request.setSignName("杭州高新人才网");
            request.setTemplateCode(smsDto.getTemplateCode());
            request.setTemplateParam("{\"booths\":\"" + smsDto.getBoothId() + "\"}");
            request.setOutId("yourOutId");
            SendSmsResponse sendSmsResponse = IAcsClientFactory.getInstance().getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //短信记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.YES.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), smsDto.getTemplateCode(),
                        smsDto.getSmsInfo(), new Date()));
            } else {
                //短信异常记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.NO.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), smsDto.getTemplateCode(),
                        smsDto.getSmsInfo(), new Date()));
                return false;

            }
            LOGGER.info("发送短信成功");
            return true;
        } catch (Exception e) {
            LOGGER.error("发送短信失败", e);
            return false;
        }
    }



    @Transactional
    public boolean sendMatching(SmsDto smsDto) {
        try {
            SendSmsRequest request = new SendSmsRequest();
            request.setMethod(MethodType.POST);
            request.setPhoneNumbers(smsDto.getMobile());
            request.setSignName("杭州高新人才网");
            request.setTemplateCode(smsDto.getTemplateCode());
            request.setTemplateParam("{\"name\":\"" + smsDto.getName() + "\", \"company\":\"" + smsDto.getCompanyName() + "\", \"booths\":\"" + smsDto.getBoothId() + "\"}");
            request.setOutId("yourOutId");
            SendSmsResponse sendSmsResponse = IAcsClientFactory.getInstance().getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //短信记录
                smsMapper.insert(new Sms(smsDto.getType(),
                        smsDto.getRecruitmentId(), smsDto.getCompanyId(), smsDto.getBoothId(),
                        smsDto.getUserId(),
                        StatusEnum.YES.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), smsDto.getTemplateCode(),
                        smsDto.getSmsInfo(), new Date()));
            } else {
                //短信异常记录
                smsMapper.insert(new Sms(smsDto.getType(),
                        smsDto.getRecruitmentId(), smsDto.getCompanyId(), smsDto.getBoothId(),
                        smsDto.getUserId(),
                        StatusEnum.NO.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), smsDto.getTemplateCode(),
                        smsDto.getSmsInfo(), new Date()));
                return false;

            }
            LOGGER.info("发送短信成功");
            return true;
        } catch (Exception e) {
            LOGGER.error("发送短信失败", e);
            return false;
        }
    }


    @Transactional
    public boolean sendBookBooth(SmsDto smsDto) {
        try {
            SendSmsRequest request = new SendSmsRequest();
            request.setMethod(MethodType.POST);
            request.setPhoneNumbers(smsDto.getMobile());
            request.setSignName("杭州高新人才网");
            request.setTemplateCode("SMS_146610137");
            request.setTemplateParam("{\"nane\":\"" + smsDto.getName() + "\",\"booths\":\"" + smsDto.getBoothId() + "\", \"time\":\"" + smsDto.getTime() + "\",\"place\":\"" + smsDto.getPlace() + "\",\"code\":\"" + smsDto.getCode() + "\"}");
            request.setOutId("yourOutId");
            SendSmsResponse sendSmsResponse = IAcsClientFactory.getInstance().getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //短信记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.YES.getCode(), smsDto.getMobile(),
                        smsDto.getCode(), "SMS_146610137",
                        smsDto.getSmsInfo(), new Date()));
            } else {
                //短信异常记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.NO.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), "SMS_146610137",
                        smsDto.getSmsInfo(), new Date()));
                return false;

            }
            LOGGER.info("发送短信成功");
            return true;
        } catch (Exception e) {
            LOGGER.error("发送短信失败", e);
            return false;
        }
    }

    @Transactional
    public boolean sendInvitation(SmsDto smsDto) {
        try {
            SendSmsRequest request = new SendSmsRequest();
            request.setMethod(MethodType.POST);
            request.setPhoneNumbers(smsDto.getMobile());
            request.setSignName("杭州高新人才网");
            request.setTemplateCode("SMS_146808667");
            request.setTemplateParam("{\"name\":\"" + smsDto.getName() + "\", \"time\":\"" + smsDto.getTime() + "\",\"place\":\"" + smsDto.getPlace() + "\"}");
            request.setOutId("yourOutId");
            SendSmsResponse sendSmsResponse = IAcsClientFactory.getInstance().getAcsResponse(request);
            if (sendSmsResponse.getCode() != null && sendSmsResponse.getCode().equals("OK")) {
                //短信记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.YES.getCode(), smsDto.getMobile(),
                        smsDto.getCode(), "SMS_146808667",
                        smsDto.getSmsInfo(), new Date()));
            } else {
                //短信异常记录
                smsMapper.insert(new Sms(smsDto.getType(), smsDto.getUserId(),
                        StatusEnum.NO.getCode(), smsDto.getMobile(),
                        sendSmsResponse.getCode(), "SMS_146808667",
                        smsDto.getSmsInfo(), new Date()));
                return false;

            }
            LOGGER.info("发送短信成功");
            return true;
        } catch (Exception e) {
            LOGGER.error("发送短信失败", e);
            return false;
        }
    }

    public Sms findOne(String phone,Integer type){
        return smsMapper.findOne(phone,type);
    }

}
