package com.hengtiansoft.servlet;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.exception.UnauthorizedException;
import org.apache.shiro.ShiroException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ExceptionController {

    // 捕捉shiro的异常
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(ShiroException.class)
    public ResultDto<String> handle401(ShiroException e) {
        return ResultDtoFactory.toNack(e.getMessage());
    }
    
    // 捕捉UnauthorizedException
    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    @ExceptionHandler(UnauthorizedException.class)
    public ResultDto<String> handle401(UnauthorizedException e) {
        return ResultDtoFactory.toNack("token error");
    }
    
//    // 捕捉其他所有异常
//    @ExceptionHandler(exception.class)
//    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    templates ResultDto<String> globalException(HttpServletRequest request, Throwable ex) {
//    	return ResultDtoFactory.toNack(ex.getMessage());
//    }

}

