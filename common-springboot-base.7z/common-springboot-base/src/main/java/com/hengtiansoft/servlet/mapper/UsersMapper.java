/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  ExampleMapper.java   
 * @Package demo.demo
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 16, 2017 4:59:32 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.Users;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

/**
 * @author jintaoxu
 *
 */
@Repository
public interface UsersMapper extends MyMapper<Users>{
 
}
