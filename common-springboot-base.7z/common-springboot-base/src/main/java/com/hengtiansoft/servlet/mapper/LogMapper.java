package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.LogDto;
import com.hengtiansoft.bean.dataModel.LogSearchDto;
import com.hengtiansoft.bean.tableModel.Log;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LogMapper extends MyMapper<Log> {
    List<LogDto> searchByCon(@Param("logSearchDto") LogSearchDto logSearchDto);
}