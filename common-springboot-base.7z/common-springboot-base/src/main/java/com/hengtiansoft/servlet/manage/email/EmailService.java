package com.hengtiansoft.servlet.manage.email;

import java.io.FileInputStream;
import java.util.Map;

/**
 * 邮件发送
 * Created by linwu on 8/1/2018.
 */
public interface EmailService {

    /**
     *
     * 发送压缩后简历
     * @param to                 收件人
     * @param subject            主题
     * @param content            内容
     * @param attachmentFileName 附件文件名称
     * @param resumeData <String, Map<String, FileInputStream>>  String: 文件夹的名称
     *        map        Map<String, FileInputStream> String：文件名称  FileInputStream：需要压缩的文件输入流
     * @return 是否成功
     */
    boolean sendZipResumes(String to, String subject, String content, String attachmentFileName,
                           Map<String, Map<String, FileInputStream>>  resumeData) ;


    boolean sendMail(String to, String subject, String content) ;

}
