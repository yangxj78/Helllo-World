package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.Sms;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface SmsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Sms record);

    int insertSelective(Sms record);

    Sms selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Sms record);

    int updateByPrimaryKey(Sms record);

    @Select("select * from sms where mobile = #{phone} and type = #{type} order by create_ts desc limit 1")
    Sms findOne(@Param("phone") String phone,@Param("type") Integer type);
}