package com.hengtiansoft.servlet.manage.login;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.SignInDto;
import com.hengtiansoft.bean.tableModel.AdminPermission;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.BehaviorEnum;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.common.util.JWTUtil;
import com.hengtiansoft.config.JWTToken;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.exception.UnauthorizedException;
import com.hengtiansoft.servlet.manage.adminPermission.AdminPermissionService;
import com.hengtiansoft.servlet.manage.adminUser.AdminUserService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.Date;


/**
 * Class Name: LoginController
 * Description: TODO
 *
 * @author jintaoxu
 */
@RestController
public class LoginController {

    @Autowired
    private AdminPermissionService userPermissionService;
    @Autowired
    AdminUserService adminUserService;

    @PostMapping("/login")
    public ResultDto<Map<String, Object>> login(@RequestBody SignInDto signInDto) {
        Subject currentUser = SecurityUtils.getSubject();
        try {
            String password2 = EncryptUtil.encryptMd5(signInDto.getUserName(), signInDto.getPassword());
            signInDto.setPassword(password2);
            JWTToken token = new JWTToken(UserTypeEnum.ADMIN.getCode(), BehaviorEnum.LOGIN.getCode(),
                    JWTUtil.sign(signInDto.getUserName(), signInDto.getPassword()));

            currentUser.login(token);


        } catch (AuthenticationException e) {

            return ResultDtoFactory.toNack(e.getMessage());
        }
        AdminUser adminUser = SecurityContext.getCurrentUser();


        Map<String, Object> userAuth = new HashMap<String, Object>();
        List<AdminPermission> userPermissions = userPermissionService.selectById(adminUser.getId());
        Set<String> persSet = new HashSet<String>();
        for (AdminPermission adminPermission : userPermissions) {
            persSet.add(adminPermission.getName());
        }
        List<AdminPermission> list = userPermissionService.getAll();
        for (AdminPermission p : list) {
            userAuth.put(p.getName(), persSet.contains(p.getName()));
        }

        String token = JWTUtil.sign(signInDto.getUserName(), signInDto.getPassword());
        Map<String, Object> rMap = new HashMap<String, Object>();
        if (adminUser.getPassword().equals(signInDto.getPassword())) {
            rMap.put("userId", adminUser.getId());
            rMap.put("userInfo", adminUser);
            rMap.put("userAuth", userAuth);
            rMap.put("token", token);
        } else {
            throw new UnauthorizedException();
        }
        adminUser.setLastLoginTs(new Date());
        adminUser.setToken(token);
        adminUserService.updateLoginTs(adminUser);
        return ResultDtoFactory.toAck("登录成功", rMap);
    }

    @GetMapping("/loginOut")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @CacheEvict(value = CacheConstants.ADMIN_USER, key = "'ADMIN_USER_' +  #username")
    public ResultDto logOut(String username) {
        AdminUser currentUser = SecurityContext.getCurrentUser();
        currentUser.setToken("");
        adminUserService.updateLoginTs(currentUser);
        return ResultDtoFactory.toAck("退出成功");
    }


}
