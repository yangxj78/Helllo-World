/*
 * Project Name: springboot
 * File Name: AdminRoleController.java
 * Class Name: AdminRoleController
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.servlet.manage.adminUser;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.AdminUserDto;
import com.hengtiansoft.bean.dataModel.AdminUserSearchDto;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.constant.PathStrings;
import com.hengtiansoft.common.constant.Permissions;
import com.hengtiansoft.servlet.manage.adminRole.AdminRoleService;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
* Class Name: AdminUserController
* Description: 用户管理模块
* @author jintaoxu
*
*/
@RestController
public class AdminUserController {
    
    @Autowired
    private AdminUserService adminUserService;
    
    @Autowired
    private AdminRoleService adminUserRoleService;
    
    private static final Log LOGGER = LogFactory.getLog(AdminUserController.class);

    //多条件搜索
    @PostMapping(PathStrings.AdminUser.SEARCHBYCON)
    public Object searchByCon(@RequestBody AdminUserSearchDto adminUserSearchDto ) {
        Integer  pageNum = (adminUserSearchDto.getPageNum() == null ? MagicNumConstant.ONE : adminUserSearchDto.getPageNum());
        Integer  pageSize = (adminUserSearchDto.getPageSize() == null ? MagicNumConstant.TEN : adminUserSearchDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        List<AdminUserDto> resp = adminUserService.searchByCon(adminUserSearchDto);
        return ResultDtoFactory.toAck(StringUtils.EMPTY, new PageInfo<AdminUserDto>(resp));
    }
    //新增用户
    @PostMapping(PathStrings.AdminUser.DO_ADD)
    //@RequiresPermissions(value = Permissions.ADMIN_USER_ADD)
    public Object doAdd(@RequestBody AdminUserDto adminUserDto) {
        boolean flag = false;
        try {
            flag =  adminUserService.saveUser(adminUserDto);
        } catch (Exception e) {
            return ResultDtoFactory.toNack("新建失败");
        }
        if(flag){
            return ResultDtoFactory.toAck("新建成功");
        }else{
            return ResultDtoFactory.toNack("新建失败");
        }
    }
    //删除用户
    @DeleteMapping(PathStrings.AdminUser.DO_DELETE)
    public Object doDelete(Integer id){
        if(adminUserService.doDeleteSingle(id)){
            return ResultDtoFactory.toAck("删除成功");
        }else {
            return ResultDtoFactory.toNack("删除失败");
        }
    }
    //批量删除
    @DeleteMapping(PathStrings.AdminUser.DO_DELETE_ALL)
    public Object doDeleteBatch(String ids){
        if(adminUserService.doDeleteBatch(ids)){
            return ResultDtoFactory.toAck("删除成功");
        }else {
            return ResultDtoFactory.toNack("删除失败");
        }
    }
    //根据用户id查找用户信息
    @GetMapping(value = PathStrings.AdminUser.TO_EDIT_USERINFO)
    public Object toEditUserInfo(@PathVariable(PathStrings.PathVariable.ID) int id) {
        AdminUserSearchDto adminUserSearchDto = new AdminUserSearchDto();
        adminUserSearchDto.setId(id);
        List<AdminUserDto> resp = adminUserService.searchByCon(adminUserSearchDto);
        return ResultDtoFactory.toAck("查找成功", resp.get(0));
    }
    //根据用户id查找用户信息
    @GetMapping(value = PathStrings.AdminUser.TO_EDIT)
    public Object toEdit(@PathVariable(PathStrings.PathVariable.ID) int id) {
        AdminUserSearchDto adminUserSearchDto = new AdminUserSearchDto();
        adminUserSearchDto.setId(id);
        List<AdminUserDto> resp = adminUserService.searchByCon(adminUserSearchDto);
        return ResultDtoFactory.toAck("查找成功", resp.get(0));
    }

    //修改密码
    @PostMapping(PathStrings.AdminUser.DO_CHANGE_PWD)
    public Object doChangePassword(@RequestBody AdminUserDto adminUserDto) {
        if(adminUserService.doChangePassword(adminUserDto)){
            return ResultDtoFactory.toAck("密码修改成功");
        }else{
            return ResultDtoFactory.toNack("密码修改失败");
        }
    }
 
    //修改用户信息(admin功能)
    @RequestMapping(value = PathStrings.AdminUser.DO_EDIT, method = RequestMethod.POST)
    @RequiresPermissions(value = Permissions.ADMIN_USER_EDIT)
    public Object doEdit(@PathVariable(PathStrings.PathVariable.ID) int id,@RequestBody AdminUserDto adminUserDto) {
        if(adminUserService.updateAdminUserInfo(adminUserDto,id)){
            return ResultDtoFactory.toAck("修改成功");
        }else{
            return ResultDtoFactory.toNack("修改失败");
        }
    }

     // 修改个人信息(普通用户功能)
    @PostMapping(PathStrings.AdminUser.DO_EDIT_USERINFO)
    public Object doEditUserInfo(@RequestBody AdminUserDto adminUserDto) {
        if(adminUserService.updateAdminUserInfo(adminUserDto,null)){
            return ResultDtoFactory.toAck("修改成功");
        }else{
            return ResultDtoFactory.toNack("修改失败");
        }
    }
    //重置密码
    // 修改个人信息(普通用户功能)
   @PostMapping(PathStrings.AdminUser.DO_RESET_PWD1)
   public Object doResetPassword(@RequestBody AdminUserDto adminUserDto) {
       if(adminUserService.doChangePassword2(adminUserDto).equals("修改成功")){
           return ResultDtoFactory.toAck("密码修改成功");
       }else{
           return ResultDtoFactory.toNack("密码修改失败");
       }
   }


}