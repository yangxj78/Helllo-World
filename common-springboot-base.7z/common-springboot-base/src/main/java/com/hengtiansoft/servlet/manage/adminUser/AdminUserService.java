/**
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 *
 * @Title: ExampleService.java
 * @Package demo.demo
 * @Description: TODO(用一句话描述该文件做什么)
 * @author: 网新恒天
 * @date: Oct 16, 2017 4:58:32 PM
 * @version V1.0
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved.
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.manage.adminUser;

import com.hengtiansoft.bean.dataModel.AdminUserDto;
import com.hengtiansoft.bean.dataModel.AdminUserSearchDto;
import com.hengtiansoft.bean.dataModel.IdDownDto;
import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.AdminUserRole;
import com.hengtiansoft.bean.tableModel.Log;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.constant.Permissions;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.manage.cache.CacheService;
import com.hengtiansoft.servlet.mapper.AdminRoleMapper;
import com.hengtiansoft.servlet.mapper.AdminUserMapper;
import com.hengtiansoft.servlet.mapper.AdminUserRoleMapper;
import com.hengtiansoft.servlet.mapper.LogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @author jintaoxu
 */
@Service
public class AdminUserService {

    private static final String MODULE_NAME = Permissions.Module.Description.USER;

    @Autowired
    private AdminUserMapper adminUserMapper;

    @Autowired
    private AdminUserRoleMapper adminUserRoleMapper;

    @Autowired
    private LogMapper operationLogMapper;

    @Autowired
    private AdminRoleMapper adminRoleMapper;

    @Autowired
    private CacheService cacheService;


    /**
     * 新增用户
     */
    @Transactional
    public boolean saveUser(AdminUserDto adminUserDto) {
        Integer loginUserId = 1;//当前登录的用户
        AdminUser adminUser = new AdminUser();
        adminUser.setPassword(adminUserDto.getNewConfirmPassword());
        adminUser.setCreatedDate(new Date());
        adminUser.setCreatedBy(loginUserId);
        adminUser.setEmail(adminUserDto.getEmail());
        adminUser.setRealname(adminUserDto.getRealname());
        adminUser.setMobile(adminUserDto.getMobile());
        adminUser.setStatus(adminUserDto.getStatus());
        adminUser.setUsername(adminUserDto.getUsername());

        //密码加密
        String password2 = EncryptUtil.encryptMd5(adminUser.getUsername(), adminUser.getPassword());
        adminUser.setPassword(password2);
        boolean flag1 = adminUserMapper.insert(adminUser) > 0;
        //记录日志
        String afterValue = "用户名" + adminUserDto.getUsername() + "姓名" + adminUserDto.getRealname()
                + adminRoleMapper.selectByPrimaryKey(adminUserDto.getRoleId()) + "邮箱" + adminUserDto.getEmail() + "手机号"
                + adminUserDto.getMobile();
        //插入纪录
        Log log = new Log();
        log.setOperator(loginUserId.toString());
        log.setAction("增加");
        log.setTname("admin_user");
        log.setOperationTime(new Date());
        log.setComment("新建用户");
        log.setModuleName(MODULE_NAME);
        log.setBeforeValue(null);
        log.setAfterValue(afterValue);
        boolean flag2 = operationLogMapper.insert(log) > 0;
        //插入adminUserRole
        AdminUserRole adminUserRole = new AdminUserRole();
        adminUserRole.setCreatedBy(loginUserId);
        adminUserRole.setCreatedDate(new Date());
        adminUserRole.setRoleid(adminUserDto.getRoleId());//
        adminUserRole.setUserid(adminUser.getId());
        boolean flag3 = adminUserRoleMapper.insert(adminUserRole) > 0;
        return flag1 && flag2 && flag3;
    }

    /**
     * 多条件搜索
     */
    public List<AdminUserDto> searchByCon(AdminUserSearchDto adminUserSearchDto) {
        return adminUserMapper.searchByCon(adminUserSearchDto);
    }

    /**
     * 删除用户
     */
    public boolean doDeleteSingle(Integer id) {
        //删除用户表
        boolean flag1 = adminUserMapper.deleteByPrimaryKey(id) > 0;
        //删除用户与角色表的关联
        AdminUserRole adminUserRole = new AdminUserRole();
        adminUserRole.setUserid(id);
        boolean flag2 = adminUserRoleMapper.delete(adminUserRole) > 0;
        return flag1 && flag2;
    }

    /**
     * 批量删除用户
     */
    public boolean doDeleteBatch(String ids) {
        //删除用户表
        boolean flag1 = adminUserMapper.deleteAdminUserByIds(ids.split(",")) > 0;
        //删除用户与角色表的关联
        boolean flag2 = adminUserRoleMapper.deleteAdminUserRoleByIds(ids.split(",")) > 0;
        return flag1 && flag2;
    }

    /**
     * 修改密码
     */
    public boolean doChangePassword(AdminUserDto adminUserDto) {
        Integer loginUserId = SecurityContext.getCurrentUser().getId();//当前登录的用户
        AdminUser adminUser = adminUserMapper.selectByPrimaryKey(adminUserDto.getId());

        AdminUser adminUser2 = new AdminUser();
        adminUser2.setId(adminUser.getId());
        adminUser2.setPassword(adminUserDto.getNewPassword());
        adminUser2.setUsername(adminUser.getUsername());
        //密码加密
        String password2 = EncryptUtil.encryptMd5(adminUser2.getUsername(), adminUser2.getPassword());
        adminUser2.setPassword(password2);
        if (adminUserMapper.updateByPrimaryKeySelective(adminUser2) > 0) {
            //清除缓存
            cacheService.flushUserByName(adminUser.getUsername());

            //记录日志
            String afterValue = "用户名" + adminUser.getUsername() + "姓名" + adminUser.getRealname() + "修改密码";
            //插入纪录
            Log log = new Log();
            log.setOperator(loginUserId.toString());
            log.setAction("修改");
            log.setTname("admin_user");
            log.setOperationTime(new Date());
            log.setComment("修改用户");
            log.setModuleName(MODULE_NAME);
            log.setBeforeValue(null);
            log.setAfterValue(afterValue);
            operationLogMapper.insert(log);
            return true;
        } else {
            return false;
        }
    }

    //@Cacheable(value = CacheConstants.ADMIN_USER, key = "'ADMIN_USER_' +  #username")
    public AdminUser selectByName(String username) {
        AdminUser adminUser = new AdminUser();
        adminUser.setUsername(username);
        return adminUserMapper.selectOne(adminUser);
    }
    public AdminUser selectByPhone(String phone) {
        AdminUser adminUser = new AdminUser();
        adminUser.setMobile(phone);
        return adminUserMapper.selectOne(adminUser);
    }


    /**
     * 根据adminUser查询用户信息
     */
    public AdminUser queryAdminUserByDto(AdminUser adminUser) {
        return adminUserMapper.selectOne(adminUser);
    }

    /**
     * 更新用户信息(普通用户功能)
     */
    @Transactional
    public boolean updateAdminUserInfo(AdminUserDto adminUserDto, Integer id) {
        Integer loginUserId = SecurityContext.getCurrentUser().getId();//当前登录的用户
        AdminUser adminUser = new AdminUser();
        adminUser.setId(adminUserDto.getId());
        adminUser.setEmail(adminUserDto.getEmail());
        adminUser.setRealname(adminUserDto.getRealname());
        adminUser.setMobile(adminUserDto.getMobile());
        adminUser.setStatus(adminUserDto.getStatus());
        adminUser.setUsername(adminUserDto.getUsername());
        adminUser.setModifiedDate(new Date());
        adminUser.setModifiedBy(loginUserId);
        boolean flag1 = adminUserMapper.updateByPrimaryKeySelective(adminUser) > 0;
        //修改adminUserRole
        AdminUserRole adminUserRole = new AdminUserRole();
        adminUserRole.setUserid(adminUser.getId());
        AdminUserRole aur = adminUserRoleMapper.selectOne(adminUserRole);
        boolean flag2 = false;
        if (aur == null) {//表中不存在
            adminUserRole.setRoleid(adminUserDto.getRoleId());
            adminUserRole.setUserid(adminUserDto.getId());
            adminUserRole.setCreatedDate(new Date());
            adminUserRole.setCreatedBy(loginUserId);
            flag2 = adminUserRoleMapper.insertSelective(adminUserRole) > 0;
        } else {//表中存在
            adminUserRole.setId(aur.getId());
            adminUserRole.setRoleid(adminUserDto.getRoleId());
            flag2 = adminUserRoleMapper.updateByPrimaryKeySelective(adminUserRole) > 0;
        }
        return flag1 && flag2;
    }

    public String doChangePassword2(AdminUserDto adminUserDto) {
        Integer loginUserId = SecurityContext.getCurrentUser().getId();//当前登录的用户
        AdminUser adminUser = adminUserMapper.selectByPrimaryKey(loginUserId);
        if (!adminUserDto.getNewPassword().equals(adminUserDto.getNewResetConfirmPassword())) {//2次密码输入不一致
            return "2次密码输入不一致";
        }
        String newEcryptPassword = EncryptUtil.encryptMd5(adminUser.getUsername(), adminUserDto.getNewPassword());
        if (newEcryptPassword.equals(adminUser.getPassword())) {//和修改密码不能等于当前密码
            return "修改密码不能等于当前密码";
        }
        String oldEcryptPassword = EncryptUtil.encryptMd5(adminUser.getUsername(), adminUserDto.getOldPassword());
        if (!oldEcryptPassword.equals(adminUser.getPassword())) {//当前密码是否正确
            return "当前密码错误";
        }
        AdminUser adminUser2 = new AdminUser();
        adminUser2.setId(loginUserId);
        adminUser2.setModifiedBy(adminUser.getId());
        adminUser2.setPassword(newEcryptPassword);

        if (adminUserMapper.updateByPrimaryKeySelective(adminUser2) > 0) {
            //清除缓存
            cacheService.flushUserByName(adminUser.getUsername());

            //记录日志
            String afterValue = "用户名" + adminUser.getUsername() + "姓名" + adminUser.getRealname() + "修改密码";
            //插入纪录
            Log log = new Log();
            log.setOperator(loginUserId.toString());
            log.setAction("修改");
            log.setTname("admin_user");
            log.setOperationTime(new Date());
            log.setComment("修改用户");
            log.setModuleName(MODULE_NAME);
            log.setBeforeValue(null);
            log.setAfterValue(afterValue);
            operationLogMapper.insert(log);
            return "修改成功";
        } else {
            return "修改失败";
        }
    }

    public int updateLoginTs(AdminUser adminUser) {
        cacheService.flushUserByName(adminUser.getUsername());
        return adminUserMapper.updateByPrimaryKeySelective(adminUser);
    }



}
