/*
 * Project Name: springboot
 * File Name: TodoService.java
 * Class Name: TodoService
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.servlet.manage.todo;

import com.hengtiansoft.bean.dataModel.TodoDto;
import com.hengtiansoft.bean.tableModel.Todo;
import com.hengtiansoft.servlet.mapper.TodoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Class Name: TodoService Description: 待办事项服务
 * 
 * @author jintaoxu
 *
 */
@Service
public class TodoService {
    @Autowired
    private TodoMapper todoMapper;
    /**
     *根据条件获取符合条件的待办事项
     */
    public List<TodoDto> getTodoListByCondition(Todo todo){
        return todoMapper.getTodoDtoByCondition(todo);
    }
    /**
     * 标记
     * */
    public boolean updateTodoMaker(Todo todo){
        return todoMapper.updateByPrimaryKeySelective(todo)>0;
    }
    
}
