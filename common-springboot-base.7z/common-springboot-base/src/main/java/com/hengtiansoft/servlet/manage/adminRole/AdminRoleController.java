/*
 * Project Name: springboot
 * File Name: AdminRoleController.java
 * Class Name: AdminRoleController
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hengtiansoft.servlet.manage.adminRole;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.AdminRoleDto;
import com.hengtiansoft.bean.dataModel.AdminRoleDtoSearchById;
import com.hengtiansoft.bean.tableModel.AdminRole;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.constant.PathStrings;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
* Class Name: AdminRoleController
* Description: 角色管理模块
* @author jintaoxu
*
*/
@RestController
public class AdminRoleController {
    @Autowired
    private AdminRoleService adminRoleService;

    private static final Log LOGGER = LogFactory.getLog(AdminRoleController.class);

    @GetMapping(PathStrings.Role.GET_ALL)
    public Object getAll() {
        return ResultDtoFactory.toAck("查询成功", adminRoleService.getAll());
    }
    
    /**
     *条件搜索
     */
    @PostMapping(PathStrings.Role.SEARCHBYCON)
    public Object searchByCon(@RequestBody AdminRoleDtoSearchById pageDto) {
      Integer  pageNum = (pageDto.getPageNum() == null ? MagicNumConstant.ONE : pageDto.getPageNum());
      Integer  pageSize = (pageDto.getPageSize() == null ? MagicNumConstant.TEN : pageDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize); 
        List<AdminRole> resp = adminRoleService.searchByCon(pageDto.getId());
        return ResultDtoFactory.toAck(StringUtils.EMPTY, new PageInfo<AdminRole>(resp));
    }
    
    @DeleteMapping(PathStrings.Role.DO_DELETE)
     public Object doDelete(@PathVariable(PathStrings.PathVariable.ID) int id) {
        adminRoleService.delete(id);
        return ResultDtoFactory.toAck("角色删除成功!");
    }
    
    @DeleteMapping(PathStrings.Role.DO_DELETE_ALL)
     public Object deleteAll(@PathVariable(PathStrings.PathVariable.IDS) String ids) {
        String [] strings = ids.split(",");
        int len = strings.length;
        Integer [] newString = new Integer [len];
        for (int i = 0; i < len; i++) {
            newString[i]=Integer.parseInt(strings[i]);
        }
        adminRoleService.deleteRoleAll(newString);
        return ResultDtoFactory.toAck("角色删除成功!");
    }
    
    @GetMapping(PathStrings.Role.TO_EDIT)
    public Object toEdit(@PathVariable(PathStrings.PathVariable.ID) int id) {
        return ResultDtoFactory.toAck("查询成功", adminRoleService.findById(id));
    }
    
    /**
     *新增角色
     */
    @PostMapping(PathStrings.Role.DO_ADD)
    public Object doAdd(@RequestBody AdminRoleDto adminRoleDto) {
        adminRoleService.save(adminRoleDto);
        return ResultDtoFactory.toAck("角色创建成功");
    }
    
    /**
     *编辑角色
     */
    @PostMapping(PathStrings.Role.DO_EDIT)
    public Object doEdit(@PathVariable(PathStrings.PathVariable.ID) int id, @RequestBody AdminRoleDto adminRoleDto) {
        adminRoleDto.setId(id);
        adminRoleService.update(adminRoleDto);
        return ResultDtoFactory.toAck("角色更新成功");
    }
}
