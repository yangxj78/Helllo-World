/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  ExampleService.java   
 * @Package demo.demo
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 16, 2017 4:58:32 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */
package com.hengtiansoft.servlet.manage.adminPermission;

import com.hengtiansoft.bean.tableModel.AdminPermission;
import com.hengtiansoft.servlet.mapper.AdminPermissionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author jintaoxu
 *
 */
@Service
public class AdminPermissionService {

	@Autowired
	private AdminPermissionMapper adminPermissionMapper;

	/**
	 * 更具用户id获取用户权限列表
	 * @param userId
	 * @return
	 */
	public List<AdminPermission> selectById(Integer userId) {
		return adminPermissionMapper.getUserPermissions(userId);
	}

	/**
	 * 获取所有用户权限列表
	 * @return
	 */
	public List<AdminPermission> getAll() {
		return adminPermissionMapper.selectAll();
	}
}
