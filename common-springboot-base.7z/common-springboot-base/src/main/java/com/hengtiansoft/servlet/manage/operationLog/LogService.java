package com.hengtiansoft.servlet.manage.operationLog;

import com.hengtiansoft.bean.dataModel.LogDto;
import com.hengtiansoft.bean.dataModel.LogSearchDto;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.Log;
import com.hengtiansoft.servlet.mapper.AdminUserMapper;
import com.hengtiansoft.servlet.mapper.LogMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author kexu
 */

@Service
public class LogService {

    @Autowired
    private LogMapper logMapper;

    @Autowired
    private AdminUserMapper adminUserMapper;


    public List<LogDto> searchByCon(final LogSearchDto searchDto) {
        return logMapper.searchByCon(searchDto);
    }


    public LogDto getLogDetail(final Integer id) {
        // 获取Log
        Log log = logMapper.selectByPrimaryKey(id);
        // 根据id获取userName
        Integer adminUserId = Integer.parseInt(log.getOperator());
        AdminUser adminUser = adminUserMapper.selectByPrimaryKey(adminUserId);
        LogDto logDto = new LogDto(log);
        logDto.setOperator(adminUser.getUsername());
        return logDto;
    }


}
