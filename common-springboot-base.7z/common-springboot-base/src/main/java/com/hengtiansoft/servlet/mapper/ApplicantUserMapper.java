package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.ApplicantUser;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;


@Repository
public interface ApplicantUserMapper extends MyMapper<ApplicantUser> {

    @Update("update applicant_user set captcha = #{captcha} where mobile = #{phone}")
    int updateCaptcha(@Param("captcha") String captcha,@Param("phone")  String phone);

    @Update("update applicant_user set token = #{newToken},last_login_ts = now() where id = #{id}")
    void updateToken(@Param("newToken") String newToken,@Param("id") Integer id);

    @Update("update applicant_user set password = #{password2} where id = #{id}")
    void updatePassword(@Param("password2") String password2, @Param("id") Integer id);
}