package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.DictData;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DictDataMapper {
    int deleteByPrimaryKey(Integer dictId);

    int insert(DictData record);

    int insertSelective(DictData record);

    DictData selectByPrimaryKey(Integer dictId);

    int updateByPrimaryKeySelective(DictData record);

    int updateByPrimaryKey(DictData record);

    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and de.def_code = #{defCode} order by da.seq_index")
    List<DictData> findByDefCode(@Param("defCode") String defCode);

    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and da.dict_value = #{dictValue} and de.def_code = #{defCode} order by da.seq_index")
    DictData findByDictValue(@Param("dictValue") String dictValue,
                             @Param("defCode") String defCode);


    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and da.description like %#{description}% and de.def_code = #{defCode} order by da.seq_index")
    List<DictData> findByDictDescription(@Param("description") String description,
                                         @Param("defCode") String defCode);

    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and da.seq_index = #{seqIndex} and de.def_code = #{defCode} order by da.seq_index Limit 1")
    DictData findByDictSexIndex(@Param("seqIndex") String seqIndex,
                                @Param("defCode") String defCode);


    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and de.def_code = #{defCode} order by da.seq_index LIMIT 1")
    DictData findOneByDefCode(@Param("defCode") String defCode);

    @Select(value = "select da.* from dict_data da, dict_def de where da.def_id = de.def_id and de.def_code = #{defCode} order by da.seq_index DESC LIMIT 1")
    DictData findOneByDefCodeDesc(@Param("defCode") String defCode);
}