package com.hengtiansoft.servlet.manage.applicationUser;


import com.hengtiansoft.bean.tableModel.ApplicantUser;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.mapper.ApplicantUserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;


/**
 * 微信端（申请者）用户的登录注册相关
 */

 @Service
 public class ApplicantUserService {

    @Autowired
    private ApplicantUserMapper applicantUserMapper;

    /**
     * 用户名获取用户
     * @param userName
     * @return
     */
    @Cacheable(value = CacheConstants.APPLICANT_USER, key = "'APPLICANT_USER_'+ #userName")
    public ApplicantUser findApplicantUserByToken(String userName){
        return findApplicantUser(userName);
    }

    @CachePut(value = CacheConstants.APPLICANT_USER, key = "'APPLICANT_USER_'+ #userName")
    public ApplicantUser findApplicantUser(String userName){
        ApplicantUser applicantUser = new ApplicantUser();
        applicantUser.setUsername(userName);
        return applicantUserMapper.selectOne(applicantUser);
    }

    @Cacheable(value = CacheConstants.APPLICANT_USER, key = "'APPLICANT_USER_'+ #userName")
    public ApplicantUser putApplicantUserCache(String userName){
        ApplicantUser applicantUser = new ApplicantUser();
        applicantUser.setUsername(userName);
        return applicantUserMapper.selectOne(applicantUser);
    }

    @CacheEvict(value = CacheConstants.APPLICANT_USER, key = "'APPLICANT_USER_' + #username")
    public void cleanToken(String username) {
        System.out.println(username);
    }


}
