package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.DictDef;
import org.springframework.stereotype.Repository;

@Repository
public interface DictDefMapper {

    int deleteByPrimaryKey(Integer defId);

    int insert(DictDef record);

    int insertSelective(DictDef record);

    DictDef selectByPrimaryKey(Integer defId);

    int updateByPrimaryKeySelective(DictDef record);

    int updateByPrimaryKey(DictDef record);
}