package com.hengtiansoft.servlet.manage.email.impl;

import com.hengtiansoft.common.util.ZipUtils;
import com.hengtiansoft.servlet.manage.email.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.*;
import javax.mail.internet.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by linwu on 8/1/2018.
 */
@Service
public class EmailServiceImpl implements EmailService{

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailService.class);

    public static final String regex1 = ".*[<][^>]*[>].*";

    public static final String regex2 = "<([^>]*)>";

    @Value("${mail.host}")
    private String host;

    @Value("${mail.transport.protocol}")
    private String protocol;

    @Value("${mail.smtp.auth}")
    private String auth;

    @Value("${mail.username}")
    private String username;

    @Value("${mail.password}")
    private String password;

    @Value("${mail.debug}")
    private boolean debug;

    @Value("${mail.account:hhdh@hhrc.com.cn}")
    private String account;


    @Override
    public boolean sendZipResumes(String to, String subject, String content, String attachmentFileName, Map<String, Map<String, FileInputStream>> resumeData) {
        //获取压缩后的File
        try {
            File file = ZipUtils.toZipFile(resumeData, attachmentFileName);
            if (file == null) {
                LOGGER.error("创建压缩文件夹失败， 文件为null");
                return false;
            }
            return send(account, to, subject, content, attachmentFileName, file);
        } catch (IOException e) {
            LOGGER.error("创建压缩文件夹失败", e);
            return false;
        }
    }

    @Override
    public boolean sendMail(String to, String subject, String content) {
        return send2(account,to,subject,content,null,null,null,null);
    }


    private Session getSession() {
        Properties prop = new Properties();
        prop.setProperty("mail.host", host);
        prop.setProperty("mail.transport.protocol", protocol);
        prop.setProperty("mail.smtp.auth", auth);
        //创建链接，链接到邮箱服务器
        Session session = Session.getDefaultInstance(prop, new Authenticator() {//匿名内部类
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
        session.setDebug(debug);
        LOGGER.info("获取邮箱服务器连接成功");
        return session;
    }

    private boolean send(String from, String to, String subject, String content, String issName, InputStreamSource iss) {
        return send(from, to, subject, content, issName, iss, null, null);
    }

    private boolean send(String from, String to, String subject, String content, String fileName, File file) {
        return send(from, to, subject, content, null, null, fileName, file);
    }

    private boolean send(String from, String to, String subject, String content, String issName,
                         InputStreamSource iss, String fileName, File file) {
        try {
            MimeMessage message = new MimeMessage(getSession());

            MimeMessageHelper helper = new MimeMessageHelper(message, true,"GBK");
            helper.setFrom(getfrominternetaddress(from));
            helper.setTo(to);
            helper.setSubject(subject);
            if (iss != null) {
                helper.addAttachment(issName, iss);
            }
            if (file != null) {
                helper.addAttachment(fileName, file);
            }
            helper.setText(content, true);
            Transport.send(message);
            LOGGER.info("发送: " + to + "成功！");
            return true;
        } catch (Exception e) {
            LOGGER.error("邮件发送失败", e);
            return false;
        }
    }

    private boolean send2(String from, String to, String subject, String content, String issName,
                         InputStreamSource iss, String fileName, File file) {
        try {
            MimeMessage message = new MimeMessage(getSession());
            MimeMessageHelper helper = new MimeMessageHelper(message, true);
            helper.setFrom(javax.mail.internet.MimeUtility.encodeText(from , "utf-8","B"));
            helper.setTo(to);
            helper.setSubject(subject);
//            helper.setText(content);
            if (iss != null) {
                helper.addAttachment(issName, iss);
            }
            if (file != null) {
                helper.addAttachment(fileName, file);
            }

            Multipart mainPart = new MimeMultipart();
            BodyPart   html = new MimeBodyPart();
            html.setContent(content, "text/html; charset=utf-8");
            mainPart.addBodyPart(html);

//            MimeBodyPart pictureBodyPart = new MimeBodyPart();
//            File file2 = ResourceUtils.getFile("classpath:");
//            FileDataSource fileDataSource = new FileDataSource("D://1111.png");
//            pictureBodyPart.setDataHandler(new DataHandler(fileDataSource));
//            pictureBodyPart.setContentID("image");
//            mainPart.addBodyPart(pictureBodyPart);
            message.setContent(mainPart);
            message.saveChanges();
            Transport.send(message);
            LOGGER.info("发送: " + to + "成功！");
            return true;
        } catch (Exception e) {
//            LOGGER.info(e.getCause().toString());
            LOGGER.error("邮件发送失败", e);
            return false;
        }
    }


    /**
     * 获取发件人
     * @param from
     * @return
     */
    private InternetAddress getfrominternetaddress(String from) {
        String personal = null;
        String address = null;

        if(from.matches(regex1)){
            personal = from.replaceAll(regex2, "").trim();
            Matcher m = Pattern.compile(regex2).matcher(from);
            if(m.find()){
                address = m.group(1).trim();
            }
            try {
                return new InternetAddress(address, personal, "gb2312");
            } catch (UnsupportedEncodingException e) {
                LOGGER.error("解析发件人地址出错", e);
            }
        }else{
            try {
                return new InternetAddress(from);
            } catch (AddressException e) {
                LOGGER.error("解析发件人地址出错", e);
            }
        }
        return null;
    }

}
