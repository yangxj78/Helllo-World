package com.hengtiansoft.servlet.manage.operationLog;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.LogDto;
import com.hengtiansoft.bean.dataModel.LogSearchDto;
import com.hengtiansoft.bean.dataModel.SmsDto;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.constant.PathStrings;
import com.hengtiansoft.common.util.Action;
import com.hengtiansoft.common.util.EnumDomain;
import com.hengtiansoft.common.util.FtpUtil;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.common.util.TableName;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.manage.email.EmailService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * @author kexu
 */

@RestController
public class LogController {

    @Autowired
    private LogService logService;


    private String SUCCESS = "success";
    /**
     * Description: 跳转到主页面
     */
    @GetMapping(value = PathStrings.Log.LOG)
    public ResultDto<Map<String, Object>> home() {
        List<EnumDomain> tableNames = TableName.getTableNameDomains();
        List<EnumDomain> actions = Action.getActionDomains();
        Map<String, Object> map = new HashMap();
        map.put("tableNames", tableNames);
        map.put("actions", actions);
        return ResultDtoFactory.toAck(StringUtils.EMPTY, map);
    }

    /**
     * Description: 获取日志详情
     */
    @GetMapping(value = PathStrings.Log.GET_LOG_DETAIL)
    public ResultDto<LogDto> getLogDetail(@PathVariable(PathStrings.PathVariable.ID) Integer logId) {
        NettyClientUtil.notifyHr(logId);
        return ResultDtoFactory.toAck(SUCCESS, logService.getLogDetail(logId));
    }

    /**
     * Description: 多条件搜索
     */
    @PostMapping(value = PathStrings.Log.SEARCHBYCON)
    public Object searchByCon(@RequestBody LogSearchDto logSearchDto) {
        Integer pageNum = (logSearchDto.getPageNum() == null ? MagicNumConstant.ONE : logSearchDto.getPageNum());
        Integer pageSize = (logSearchDto.getPageSize() == null ? MagicNumConstant.TEN : logSearchDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        List<LogDto> resp = logService.searchByCon(logSearchDto);
        return ResultDtoFactory.toAck(StringUtils.EMPTY, new PageInfo<LogDto>(resp));
    }



    @GetMapping(value = "/getPassword/{username}/{password}")
    public ResultDto<String> getPassword(@PathVariable String username, @PathVariable String password) {
        return ResultDtoFactory.toAck(SUCCESS, EncryptUtil.encryptMd5(username, password));
    }

}
