package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CompanySignMapper extends MyMapper<CompanySign> {

    CompanySign findOneByCon(@Param("boothId") Integer boothId,
                             @Param("recruitmentId") Integer recruitmentId,
                             @Param("captcha") String captcha);

    CompanySign selectByIpAndCaptcha(@Param("ip") String ip,
                                     @Param("captcha") String captcha);

    int updateCaptcha(CompanySign companySign1);

    int deleteCaptcha(CompanySign companySign);

    List<CompanySign> listByIpAndCaptcha(CompanySign companySign1);

    String getCaptcha(CompanySign companySign);

    void insertCaptcha(CompanySign companySign2);

    CompanySign findOneByCon2(@Param("boothId") Integer boothId, @Param("recruitmentId") Integer recruitmentId, @Param("companyId") Integer companyId);

    /**
     * 根据当前招聘会和本机ip获取CompanySign
     *
     * @return
     */
    CompanySign findByRecIdAndIp(@Param("recruitmentId") Integer recruitmentId, @Param("ip") String ip);

    /**
     * 根据当前招聘会和电视机ip获取CompanySign
     *
     * @return
     */
    CompanySign findByRecIdAndTvIp(@Param("recruitmentId") Integer recruitmentId, @Param("ip") String ip);

    @Select("select captcha from company_sign where recruitment_id=#{recruitmentID} limit 1")
    String findOneByCon3(Integer recruitmentID);

    @Select("select status from company_sign where recruitment_id=#{recruitmentId} and booth_id=#{boothId} limit 1")
    Integer search(@Param("recruitmentId")Integer recruitmentId,@Param("boothId") Integer boothId);

    @Select("select booth_id from company_sign where recruitment_id=#{id}")
    List<Integer> getBooth(Integer id);

    @Select("select booth_id from company_sign where recruitment_id=#{recruitmentId} and company_id =#{companyId}")
    List<Integer> findBoothByCompany(@Param("recruitmentId")Integer recruitmentId, @Param("companyId") Integer companyId);

    @Select("select * from company_sign where recruitment_id=#{recruitmentId} and company_id =#{companyId} and booth_id =#{boothId}  limit 1")
    CompanySign findByIds(@Param("recruitmentId")Integer recruitmentId, @Param("companyId") Integer companyId, @Param("boothId") Integer boothId);
}