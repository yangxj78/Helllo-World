package com.hengtiansoft.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * 短信配置类
 * Created by linwu on 8/8/2018.
 */
@Configuration
public class SmsConfig {

    @Value("${sms.accessKeyId}")
    private String accessKeyId;
    @Value("${sms.accessSecret}")
    private String accessSecret;
    @Value("${sms.product}")
    private String product;
    @Value("${sms.domain}")
    private String domain;

    public String getAccessKeyId() {
        return accessKeyId;
    }

    public String getAccessSecret() {
        return accessSecret;
    }

    public String getProduct() {
        return product;
    }

    public String getDomain() {
        return domain;
    }

}
