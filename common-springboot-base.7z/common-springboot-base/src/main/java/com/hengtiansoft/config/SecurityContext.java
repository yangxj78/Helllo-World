/*
 * Project Name: sc-archetype
 * File Name: SecurityContext.java
 * Class Name: SecurityContext
 *
 * Copyright 2014 Hengtian Software Inc
 *
 * Licensed under the Hengtiansoft
 *
 * http://www.hengtiansoft.com
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.hengtiansoft.config;

import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.ApplicantUser;
import com.hengtiansoft.bean.tableModel.CompanySign;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.subject.Subject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;


/**
 * Class Name: SecurityContext Description:
 * 
 * @author SC
 * 
 */
public final class SecurityContext {

    private static final String USER_KEY = "shiro.user";

    private static final Logger LOGGER = LoggerFactory.getLogger(SecurityContext.class);

    private static final String CACHE_NAME_AUTHZ = "cache.name.authz";

    private static final String CACHE_NAME_AUTHC = "cache.name.authc";

    /**
     * SecurityContext Constructor
     */
    public SecurityContext() {

    }

    /**
     * Description: 获取当前用户的基本信息。
     * 
     * @return
     */
    public static AdminUser getCurrentUser() {
        Subject subject = getSubject();
        if (subject == null) {
            return null;
        }
        return (AdminUser)subject.getPrincipals().getPrimaryPrincipal();
    }

    /**
     * Description: 是否已登录
     * 
     * @return
     */
    public static boolean isAuthenticated() {
        Subject subject = getSubject();
        if (subject == null) {
            return false;
        }
        return getSubject().isAuthenticated();
    }


    /**
     * 登出当前用户
     */
    public static void logout() {
        getSubject().logout();
    }

    /**
     * Description: 验证当前用户是否拥有该权限。
     */
    public static boolean hasPermission(String permission) {
        Subject subject = getSubject();
        return subject == null ? false : subject.isPermitted(permission);
    }

    /**
     * Description: 验证当前用户是否拥有所有以下权限。
     */
    public static boolean hasAllPermissions(String... permissions) {
        Subject subject = getSubject();
        return subject == null ? false : subject.isPermittedAll(permissions);
    }

    /**
     * Description: 验证当前用户是否拥有以下任意一个权限
     */
    public static boolean hasAnyPermission(String[] permissions) {
        Subject subject = getSubject();
        if (subject != null && permissions != null) {
            for (int i = 0; i < permissions.length; i++) {
                String permission = permissions[i];
                if (permission != null && subject.isPermitted(permission.trim())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 检查是否有权限，若无则抛出异常。
     * 
     * @see Subject#checkPermission(String permission)
     * @throws AuthorizationException
     */
    public static void checkPermission(String permission) throws AuthorizationException {
        Subject subject = getSubject();
        if (subject == null) {
            throw new AuthorizationException("No permission as there is no subject bound.");
        }
        subject.checkPermission(permission);
    }

    /**
     * Description: 验证当前用户是否属于以下所有角色。请通过权限而不是角色做判断，比如hasPermission。
     */
    @Deprecated
    public static boolean hasAllRoles(Collection<String> roles) {
        return getSubject().hasAllRoles(roles);
    }

    /**
     * Description: 验证当前用户是否属于以下任意一个角色。请通过权限而不是角色做判断，比如hasPermission。
     */
    @Deprecated
    public static boolean hasAnyRoles(Collection<String> roleNames) {
        Subject subject = getSubject();
        if (subject != null && roleNames != null) {
            for (String role : roleNames) {
                if (role != null && subject.hasRole(role)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static Subject getSubject() {
        try {
            return SecurityUtils.getSubject();
        } catch (Exception e) {
            LOGGER.warn("Failed to get Subject, maybe user is not login or session is lost:", e);
            return null;
        }
    }

    /**
     * Description: 获取当前用户的id。
     *
     * @return
     */
    public static Integer getCurrentUserId() {
        Subject subject = getSubject();
        if (subject == null) {
            return null;
        }
        return ((AdminUser)subject.getPrincipals().getPrimaryPrincipal()).getId();
    }


    /*-------------------------------HR-----------------------------------*/

    public static CompanySign getCurrentHRUser() {
        Subject subject = getSubject();
        if (subject == null) {
            return null;
        }
        return (CompanySign)subject.getPrincipals().getPrimaryPrincipal();
    }

    public static Integer getCurrentHRUserId() {
        Subject subject = getSubject();
        if (subject == null) {
            return null;
        }
        return ((CompanySign)subject.getPrincipals().getPrimaryPrincipal()).getId();
    }



    /*-------------------------------applicant_user-----------------------------------*/


    /**
     * Description: 获取当前用户的基本信息。
     *
     * @return
     */
    public static ApplicantUser getCurrentApplicantUser() {
        Subject subject = getSubject();
        if (subject == null) {
            return null;
        }
        return (ApplicantUser)subject.getPrincipals().getPrimaryPrincipal();
    }


}
