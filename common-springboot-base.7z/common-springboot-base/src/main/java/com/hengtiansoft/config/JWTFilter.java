package com.hengtiansoft.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.EErrorCode;
import com.hengtiansoft.common.enumeration.BehaviorEnum;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import com.hengtiansoft.common.util.WebUtil;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.web.filter.authc.BasicHttpAuthenticationFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JWTFilter extends BasicHttpAuthenticationFilter {

    private static final Logger LOGGER = LoggerFactory.getLogger(JWTFilter.class);

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        // 获取Authorization字段
        String authorization = httpServletRequest.getHeader(ApplicationConstant.AUTHORIZATION);
        if (httpServletRequest.getMethod().equals(RequestMethod.OPTIONS.name())) {//解决post，get等请求变成options请求的解决办法。
            return true;
        }

        if (authorization!=null) {
            try {
                JWTToken token;
                if (httpServletRequest.getRequestURI().startsWith(ApplicationConstant.HR_INTERFACE)) {
                    token = new JWTToken(UserTypeEnum.HR.getCode(), BehaviorEnum.OTHER.getCode(), authorization);
                } else if (httpServletRequest.getRequestURI().startsWith(ApplicationConstant.APPLICANT_INTERFACE)){
                    token = new JWTToken(UserTypeEnum.APPLICANT_USER.getCode(), BehaviorEnum.OTHER.getCode(), authorization);
                } else {
                    token = new JWTToken(UserTypeEnum.ADMIN.getCode(), BehaviorEnum.OTHER.getCode(), authorization);
                }
                // 提交给realm进行登入，如果错误他会抛出异常并被捕获
                getSubject(request, response).login(token);
                return true;
            } catch (Exception e) {
                if (e instanceof LockedAccountException) {
                    response401(request, response, EErrorCode.LOCKED_ACCOUNT_EXCEPTION);
                } else {
                    response401(request, response, EErrorCode.AUTHENTICATION_EXCEPTION);

//                    try {
//                        //手机密码登录模式
//                        JWTToken token = new JWTToken(UserTypeEnum.APPLICANT_USER.getCode(), BehaviorEnum.OTHER.getCode(), authorization);
//                        getSubject(request, response).login(token);
//                        return true;
//                    } catch (Exception e1) {
//                        if (e1 instanceof LockedAccountException) {
//                            response401(request, response, EErrorCode.LOCKED_ACCOUNT_EXCEPTION);
//                        } else {
//                            response401(request, response, EErrorCode.AUTHENTICATION_EXCEPTION);
//                        }
//                    }
                }
                return false;
            }
        } else {
        	response401(request, response, EErrorCode.AUTHENTICATION_EXCEPTION);
            return false;
        }
    }

    /**
     * 将请求返回到 /401
     */
    private void response401(ServletRequest req, ServletResponse resp, EErrorCode eErrorCode) throws Exception {
        HttpServletResponse httpServletResponse = (HttpServletResponse) resp;
        ObjectMapper mapper = WebUtil.getObjectMapper();
        String json = mapper.writeValueAsString(new ResultDto(eErrorCode.getErrorCode(), eErrorCode.getDisplayMsg(), null));
        LOGGER.info("权限验证失败");
        httpServletResponse.getOutputStream().write(json.getBytes());
    }

}
