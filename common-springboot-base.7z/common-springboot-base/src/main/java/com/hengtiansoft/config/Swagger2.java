package com.hengtiansoft.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**  
 * All rights Reserved, Designed By http://www.hengtiansoft.com
 * @Title:  Swagger2.java   
 * @Package    
 * @Description:    TODO(用一句话描述该文件做什么)   
 * @author: 网新恒天    
 * @date:   Oct 18, 2017 1:33:43 PM   
 * @version V1.0 
 * @Copyright: 2017 http://www.hengtiansoft.com Inc. All rights reserved. 
 * 注意：本内容仅限于网新恒天内部传阅，禁止外泄以及用于其他的商业目
 */

/**
 * @author jintaoxu
 *
 */
@Configuration
@EnableSwagger2
public class Swagger2 {
	@Bean
	public Docket createRestApi(){
		return new Docket(DocumentationType.SWAGGER_2)
		.apiInfo(apiInfo())
        .select()
        .apis(RequestHandlerSelectors.basePackage("com.hengtiansoft"))
        .paths(PathSelectors.any())
        .build();
	}
	
	private ApiInfo apiInfo(){
		return new ApiInfoBuilder()
		.title("Spring Boot中使用Swagger2构建RESTful APIs")
        .description("整合swagger2")
        .termsOfServiceUrl("http://www.baidu.com/")
        .contact("HHDH")
        .version("2.0")
        .build();
 
	}
 
}
