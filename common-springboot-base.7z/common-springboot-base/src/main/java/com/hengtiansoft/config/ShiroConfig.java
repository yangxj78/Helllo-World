package com.hengtiansoft.config;

import org.apache.shiro.mgt.DefaultSessionStorageEvaluator;
import org.apache.shiro.mgt.DefaultSubjectDAO;
import org.apache.shiro.spring.security.interceptor.AuthorizationAttributeSourceAdvisor;
import org.apache.shiro.spring.web.ShiroFilterFactoryBean;
import org.apache.shiro.web.mgt.DefaultWebSecurityManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import javax.servlet.Filter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class ShiroConfig {

    @Bean
    public MyRealm getMyRealm() {
        MyRealm realm = new MyRealm();
        realm.setCachingEnabled(false);
        return realm;
    }

    @Bean("securityManager")
    public DefaultWebSecurityManager getManager() {
        DefaultWebSecurityManager manager = new DefaultWebSecurityManager();
        // 使用自己的realm
        manager.setRealm(getMyRealm());
        /*
         * 关闭shiro自带的session，详情见文档
         */
        DefaultSubjectDAO subjectDAO = new DefaultSubjectDAO();
        DefaultSessionStorageEvaluator defaultSessionStorageEvaluator = new DefaultSessionStorageEvaluator();
        defaultSessionStorageEvaluator.setSessionStorageEnabled(false);
        subjectDAO.setSessionStorageEvaluator(defaultSessionStorageEvaluator);
        manager.setSubjectDAO(subjectDAO);

        return manager;
    }

    @Bean("shiroFilter")
    public ShiroFilterFactoryBean factory(DefaultWebSecurityManager securityManager) {
        ShiroFilterFactoryBean factoryBean = new ShiroFilterFactoryBean();

        // 添加自己的过滤器并且取名为jwt
        Map<String, Filter> filterMap = new HashMap<>();
        filterMap.put("jwt", new JWTFilter());
        factoryBean.setFilters(filterMap);

        factoryBean.setSecurityManager(securityManager);
        factoryBean.setUnauthorizedUrl("/401");

        /*
         * 自定义url规则
         * http://shiro.apache.org/web.html#urls-
         */
        Map<String, String> filterRuleMap = new LinkedHashMap<>();
        filterRuleMap.put("/login", "anon");
        filterRuleMap.put("/loginOut", "anon");
        filterRuleMap.put("/applicant/userManage/getUserInfo", "jwt");
        filterRuleMap.put("/applicant/userManage/loginOut", "jwt");
        filterRuleMap.put("/applicant/userManage/**", "anon");
        filterRuleMap.put("/wechat/**", "anon");
        //hr
        filterRuleMap.put("/getBoothId", "anon");
        filterRuleMap.put("/getBoothIdByTvIp", "anon");
        filterRuleMap.put("/getRecruitmentInfo", "anon");
        filterRuleMap.put("/signIn", "anon");
        filterRuleMap.put("/token/getUserName", "anon");

        filterRuleMap.put("/uploadResume", "anon");
        filterRuleMap.put("/SRegion/**", "anon");
        filterRuleMap.put("/applicant/qrCode/record", "anon");
        filterRuleMap.put("/applicant/qrCode/generateCompanyQrCode", "anon");
        filterRuleMap.put("/dict/data/list", "anon");

        filterRuleMap.put("/excel/**", "anon");

        filterRuleMap.put("/admin/company/", "jwt");
        filterRuleMap.put("/admin/company/deleteFile", "jwt");
        filterRuleMap.put("/admin/company/uploadFile", "jwt");
        filterRuleMap.put("/admin/company/deleteFile", "jwt");


        filterRuleMap.put("/admin/company/**", "anon");
        filterRuleMap.put("/admin/recruitment/list", "anon");
        filterRuleMap.put("/admin/recruitment/", "jwt");
        filterRuleMap.put("/admin/recruitment/**", "anon");
        filterRuleMap.put("/admin/positionRecord/batchAdd", "jwt");
        filterRuleMap.put("/admin/positionRecord/", "jwt");
        filterRuleMap.put("/admin/positionRecord/updateOrder", "jwt");
        filterRuleMap.put("/admin/positionRecord/add", "jwt");
        filterRuleMap.put("/admin/booth/check", "anon");
        filterRuleMap.put("/admin/booth/boothDetails", "anon");


        filterRuleMap.put("/admin/positionRecord/**", "anon");
        filterRuleMap.put("/admin/adminManagement/bannerRecordList", "anon");

        filterRuleMap.put("/admin/screenReport/**", "anon");
        filterRuleMap.put("/tag/**", "anon");
        filterRuleMap.put("/applicant/recruitment/serach", "anon");

        filterRuleMap.put("/applicant/recruitment/recruitmentData", "anon");
        filterRuleMap.put("/applicant/recruitment/listPositionRecord", "anon");
        //swagger接口权限 开放
        filterRuleMap.put("/swagger-ui.html", "anon");
        filterRuleMap.put("/swagger-resources", "anon");
        filterRuleMap.put("/v2/api-docs", "anon");
        filterRuleMap.put("/webjars/springfox-swagger-ui/**", "anon");


        filterRuleMap.put("/applicant/resume/createByScanImg", "anon");
        filterRuleMap.put("/export", "anon");

        filterRuleMap.put("/applicant/userManage/test", "anon");

        filterRuleMap.put("/getHrLoginInfo", "anon");

        filterRuleMap.put("/**", "jwt");

        factoryBean.setFilterChainDefinitionMap(filterRuleMap);
        return factoryBean;
    }

    @Bean
    public AuthorizationAttributeSourceAdvisor authorizationAttributeSourceAdvisor(DefaultWebSecurityManager securityManager) {
        AuthorizationAttributeSourceAdvisor advisor = new AuthorizationAttributeSourceAdvisor();
        advisor.setSecurityManager(securityManager);
        return advisor;
    }
}
