package com.hengtiansoft.config;

import com.hengtiansoft.common.util.FtpUtil;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.pool2.ObjectPool;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PreDestroy;

/**
 * FTP配置类
 * Created by linwu on 7/23/2018.
 */
@Configuration
//该注解的参数对应的类必须存在，否则不解析该注解修饰的配置类
@ConditionalOnClass({GenericObjectPool.class, FTPClient.class})
//这个注解能够控制某个configuration是否生效
@ConditionalOnProperty(value = "ftp.enabled", havingValue = "true")
//@EnableConfigurationProperties注解的作用是@ConfigurationProperties注解生效。
//如果只配置@ConfigurationProperties注解，在IOC容器中是获取不到properties配置文件转化的bean的
@EnableConfigurationProperties(FTPConfig.FtpConfigProperties.class)
public class FTPConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger(FTPConfig.class);

    private static final Integer DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 60000;

    private static final Integer DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 50000;

    private static final Integer DEFAULT_EVICTOR_SHUTDOWN_TIMEOUT_MILLIS = 30000;

    private ObjectPool<FTPClient> pool;

    public FTPConfig(FtpConfigProperties props) {
        GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
        poolConfig.setTestOnBorrow(true);
        poolConfig.setTestOnReturn(true);
        poolConfig.setTestWhileIdle(true);
        poolConfig.setMinEvictableIdleTimeMillis(DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        poolConfig.setSoftMinEvictableIdleTimeMillis(DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS);
        poolConfig.setTimeBetweenEvictionRunsMillis(DEFAULT_EVICTOR_SHUTDOWN_TIMEOUT_MILLIS);
        pool = new GenericObjectPool<>(new FtpClientPooledObjectFactory(props), poolConfig);
        preLoadingFtpClient(props.getInitialSize(), props.getMaxIdle());
        // 初始化ftp工具类中的ftpClientPool
        FtpUtil.init(pool);

    }

    /**
     * 预先加载FTPClient连接到对象池中
     * @param initialSize 初始化连接数
     * @param maxIdle 最大空闲连接数
     */
    private void preLoadingFtpClient(Integer initialSize, int maxIdle) {
        if (initialSize == null || initialSize < 0) {
            return;
        }

        int size = Math.min(initialSize.intValue(), maxIdle);
        for (int i = 0; i < size; i++) {
            try {
                pool.addObject();
            } catch (Exception e) {
                LOGGER.error("preLoadingFtpClient error...", e);
            }
        }
    }

    /**
     * 销毁之前的自定义操作
     */
    @PreDestroy
    public void destroy() {
        if (pool != null) {
            pool.close();
            LOGGER.info("销毁FTPClientPool...");
        }
    }

    //把properties配置文件转化为bean
    @ConfigurationProperties(prefix = "ftp")
    static class FtpConfigProperties {

        private String host;

        private int port = FTPClient.DEFAULT_PORT;

        private String username;

        private String password;

        private int bufferSize;

        private Integer initialSize;

        private Integer maxIdle;

        public String getHost() {
            return host;
        }

        public void setHost(String host) {
            this.host = host;
        }

        public int getPort() {
            return port;
        }

        public void setPort(int port) {
            this.port = port;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public int getBufferSize() {
            return bufferSize;
        }

        public void setBufferSize(int bufferSize) {
            this.bufferSize = bufferSize;
        }

        public Integer getInitialSize() {
            return initialSize;
        }

        public void setInitialSize(Integer initialSize) {
            this.initialSize = initialSize;
        }

        public Integer getMaxIdle() {
            return maxIdle;
        }

        public void setMaxIdle(Integer maxIdle) {
            this.maxIdle = maxIdle;
        }
    }


    static class FtpClientPooledObjectFactory implements PooledObjectFactory<FTPClient> {

        private FtpConfigProperties props;

        FtpClientPooledObjectFactory(FtpConfigProperties props) {
            this.props = props;
        }


        @Override
        public PooledObject<FTPClient> makeObject() {
            FTPClient ftpClient = new FTPClient();
            try {
                ftpClient.connect(props.getHost(), props.getPort());
                ftpClient.login(props.getUsername(), props.getPassword());
                LOGGER.info("连接FTP服务器返回码{}", ftpClient.getReplyCode());
                ftpClient.setBufferSize(props.getBufferSize());
                ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
                ftpClient.enterLocalPassiveMode();
                return new DefaultPooledObject<>(ftpClient);
            } catch (Exception e) {
                LOGGER.error("建立FTP连接失败", e);
                if (ftpClient.isAvailable()) {
                    try {
                        ftpClient.disconnect();
                    } catch (Exception ex) {
                        LOGGER.error("关闭FTP连接失败", ex);
                    }
                }
                ftpClient = null;
                return null;
            }
        }

        @Override
        public void destroyObject(PooledObject<FTPClient> pooledObject) {
            FTPClient ftpClient = getObejct(pooledObject);
            if (ftpClient != null && ftpClient.isConnected()) {
                try {
                    ftpClient.disconnect();
                } catch (Exception e) {
                    LOGGER.error("关闭FTP连接失败", e);
                }
            }
        }

        @Override
        public boolean validateObject(PooledObject<FTPClient> pooledObject) {
            FTPClient ftpClient = getObejct(pooledObject);
            if (ftpClient == null || (ftpClient != null && !ftpClient.isConnected())) {
                return false;
            }
            try {
                ftpClient.changeWorkingDirectory("/");
                return true;
            } catch (Exception e) {
                LOGGER.error("验证FTP连接失败::{}", e);
                return false;
            }
        }

        @Override
        public void activateObject(PooledObject<FTPClient> pooledObject) {

        }

        @Override
        public void passivateObject(PooledObject<FTPClient> pooledObject) {

        }

        public FTPClient getObejct(PooledObject<FTPClient> pooledObject) {
            if (pooledObject == null || pooledObject.getObject() == null) {
                return null;
            }
            return pooledObject.getObject();
        }
    }


}
