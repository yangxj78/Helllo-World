package com.hengtiansoft.config;

import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.BehaviorEnum;
import com.hengtiansoft.common.enumeration.SmsTypeEnum;
import com.hengtiansoft.common.enumeration.UserStatusEnum;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import com.hengtiansoft.common.util.JWTUtil;
import com.hengtiansoft.servlet.manage.adminPermission.AdminPermissionService;
import com.hengtiansoft.servlet.manage.adminUser.AdminUserService;
import com.hengtiansoft.servlet.manage.applicationUser.ApplicantUserService;
import com.hengtiansoft.servlet.manage.companySign.CompanySignService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MyRealm extends AuthorizingRealm {

    private static final Logger LOGGER = LoggerFactory.getLogger(MyRealm.class);

    @Autowired
    @Lazy
    private AdminUserService adminUserService;
    @Autowired
    @Lazy
    private ApplicantUserService applicantUserService;

    @Autowired
    private CompanySignService companySignService;

    @Autowired
    private AdminPermissionService userPermissionService;

    @Autowired
    private SmsService smsService;

	/**
     * 大坑！，必须重写此方法，不然Shiro会报错
     */
    @Override
    public boolean supports(AuthenticationToken token) {
        return token instanceof JWTToken;
    }


    /**
     * 只有当需要检测用户权限的时候才会调用此方法，例如checkRole,checkPermission之类的
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        LOGGER.info("权限比对检查");
    	AdminUser adminUser = (AdminUser) principals.getPrimaryPrincipal();
        //获取所有权限信息
        List<AdminPermission> list = userPermissionService.selectById(adminUser.getId());
        Set<String> permission = new HashSet<String>();
        for (AdminPermission adminPermission : list) {
        	permission.add(adminPermission.getName());
        }
        SimpleAuthorizationInfo simpleAuthorizationInfo = new SimpleAuthorizationInfo();
        simpleAuthorizationInfo.addStringPermissions(permission);
        return simpleAuthorizationInfo;
    }

    /**
     * 默认使用此方法进行用户名正确与否验证，错误抛出异常即可。
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken auth) throws AuthenticationException {
        LOGGER.info("登录密码检查");
        JWTToken jwtAuth = null;
        if (auth instanceof JWTToken) {
            jwtAuth = (JWTToken) auth;
        }
        Integer type = (Integer) auth.getPrincipal();
        String token = (String) auth.getCredentials();
        Integer behavior = jwtAuth.getBehavior();
        // 解密获得username，用于和数据库进行对比
        if (UserTypeEnum.HR.getCode().equals(type)) {
            String ip = JWTUtil.getIp(token);
            String captcha = JWTUtil.getCaptcha(token);
            if (ip == null || captcha == null) {
                throw new AuthenticationException("Token 无效!");
            }
            CompanySign companySign = companySignService.selectByIpAndCaptcha(ip, captcha);
            if (companySign == null) {
                throw new UnknownAccountException("签到码错误!");
            }

            if (!JWTUtil.hrVerify(token, ip, companySign.getCaptcha())) {
                throw new IncorrectCredentialsException("签到码错误!");
            }

            if (BehaviorEnum.OTHER.getCode().equals(behavior) &&
                    !UserStatusEnum.LOGIN.getCode().equals(companySign.getStatus())) {
                throw new AuthenticationException("账号已登出!");
            }

            return new SimpleAuthenticationInfo(companySign, token, getName());

        } else if (UserTypeEnum.ADMIN.getCode().equals(type)) {

            String username = JWTUtil.getUsername(token);
            if (username == null) {
                throw new AuthenticationException("Token 无效!");
            }
            AdminUser adminUser = adminUserService.selectByName(username);
            if (adminUser == null) {
                throw new UnknownAccountException("账号或密码错误");
            }

            if (BehaviorEnum.OTHER.getCode().equals(behavior)) {
                if (StringUtils.isEmpty(adminUser.getToken())) {
                    throw new AuthenticationException("账号已登出!");
                } else if (!adminUser.getToken().equals(token)) {
                    throw new LockedAccountException("账号已在其他地方登陆!");
                }
            }

            if (!JWTUtil.verify(token, username, adminUser.getPassword())) {
                throw new IncorrectCredentialsException("账号或密码错误");
            }

            return new SimpleAuthenticationInfo(adminUser, token, getName());

        } else if (UserTypeEnum.APPLICANT_USER.getCode().equals(type)) {


            String username = JWTUtil.getUsername(token);
            if (username == null) {
                throw new AuthenticationException("Token 无效!");
            }
            ApplicantUser applicantUser = null;
            if (BehaviorEnum.LOGIN.getCode().equals(behavior)) {
                applicantUser = applicantUserService.findApplicantUser(username);
            } else if (BehaviorEnum.OTHER.getCode().equals(behavior)) {
                applicantUser = applicantUserService.findApplicantUserByToken(username);
            }

            if (applicantUser == null) {
                throw new UnknownAccountException("账号或密码错误");
            }

            if (BehaviorEnum.OTHER.getCode().equals(behavior)) {
                if (StringUtils.isEmpty(applicantUser.getToken())) {
                    throw new AuthenticationException("账号已登出!");
                } else if (!applicantUser.getToken().equals(token)) {
                    throw new LockedAccountException("账号已在其他地方登陆!");
                }
            }

            if (!JWTUtil.verify(token, username, applicantUser.getPassword())) {
                throw new IncorrectCredentialsException("账号或密码错误");
            }

            return new SimpleAuthenticationInfo(applicantUser, token, getName());


//            String phone = JWTUtil.getUsername(token);
//            if (phone == null) {
//                throw new AuthenticationException("Token 无效!");
//            }
//            AdminUser adminUser = adminUserService.selectByPhone(phone);
//            if (adminUser == null) {
//                throw new UnknownAccountException("账户或密码错误!");
//            }
//
//            if (BehaviorEnum.OTHER.getCode().equals(behavior)) {
//                if (StringUtils.isEmpty(adminUser.getToken())) {
//                    throw new AuthenticationException("账号已登出!");
//                } else if (!adminUser.getToken().equals(token)) {
//                    throw new LockedAccountException("账号已在其他地方登陆!");
//                }
//            }
//
//            Sms sms = smsService.findOne(phone,SmsTypeEnum.LOGIN.getCode());
//            if (!JWTUtil.verify(token, phone, sms.getCode())) {
//                throw new IncorrectCredentialsException("账户或密码错误!");
//            }
//            return new SimpleAuthenticationInfo(adminUser, token, getName());

        } else {

            throw new AuthenticationException("用户类型不存在!");
        }

    }
}
