package com.hengtiansoft.config;

import com.hengtiansoft.common.constant.MagicNumConstant;
import org.apache.commons.codec.Charsets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.ContentNegotiationConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;

import java.util.ArrayList;
import java.util.List;

@Configuration
@EnableWebMvc
public class WebMvcConfig extends WebMvcConfigurerAdapter {

    public static final String DEFAULT_ENCODING = "UTF-8";

    @Autowired
    private ApplicationContext context;


    @Override
    public void configureContentNegotiation(ContentNegotiationConfigurer configurer) {
        configurer.favorPathExtension(false).favorParameter(true);
    }





    @Override
    public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
        StringHttpMessageConverter shc = new StringHttpMessageConverter();
        List<MediaType> strMediaTypes = new ArrayList<>();
        strMediaTypes.add(new MediaType("text", "html", Charsets.toCharset(DEFAULT_ENCODING)));
        strMediaTypes.add(new MediaType("application", "json", Charsets.toCharset(DEFAULT_ENCODING)));
        shc.setSupportedMediaTypes(strMediaTypes);

        MappingJackson2HttpMessageConverter mhc = new MappingJackson2HttpMessageConverter();
        mhc.setSupportedMediaTypes(strMediaTypes);

        converters.add(shc);
        converters.add(mhc);
    }


    @Bean(name = "multipartResolver")
    public MultipartResolver configMultipartResolver() {
        CommonsMultipartResolver bean = new CommonsMultipartResolver();
        bean.setDefaultEncoding("UTF-8");
        //文件上传大小配置已经在MultipartConfig里配置了，这里注释掉了
        // bean.setMaxUploadSize(8388608);
        // bean.setResolveLazily(true);
        return bean;
    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        // argumentResolvers.add(new CollectionArgumentResolver());
    }

    @Bean
    public ResourceBundleMessageSource buildMessageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        messageSource.setBasename("messages");
        messageSource.setCacheSeconds(MagicNumConstant.THREE_THOUSAND_SIX_HUNDRED);
        messageSource.setUseCodeAsDefaultMessage(true);
        return messageSource;
    }

    @Bean
    public InterceptorRegistry i18nInterceptor() {
        InterceptorRegistry registry = new InterceptorRegistry();
        HandlerInterceptor interceptor = new LocaleChangeInterceptor();
        registry.addInterceptor(interceptor);
        return registry;
    }
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry.addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }



}
