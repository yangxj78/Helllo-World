package com.hengtiansoft.bean.ipeopleModel;

import lombok.Data;

@Data
public class ConentType {

    private String type;
    private String content;
    private byte[] bytes;

    public ConentType(String type, String content) {
        this.type = type;
        this.content = content;
    }

    public ConentType(String type, String content, byte[] bytes) {
        this.type = type;
        this.content = content;
        this.bytes = bytes.clone();
    }

}
