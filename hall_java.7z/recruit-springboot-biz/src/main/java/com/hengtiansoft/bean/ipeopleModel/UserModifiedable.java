package com.hengtiansoft.bean.ipeopleModel;

public interface UserModifiedable<M> {
	M getModifiedBy();
}
