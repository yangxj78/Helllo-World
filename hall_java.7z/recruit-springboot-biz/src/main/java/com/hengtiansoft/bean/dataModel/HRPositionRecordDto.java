package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * 现场招聘岗位列表
 */
public class HRPositionRecordDto {

    @ApiModelProperty(value = "主键")
    private Integer id;

    @ApiModelProperty(value = "岗位名称")
    private String name;

    private Integer workingYearsId;

    @ApiModelProperty(value = "工作年限")
    private String workingYears;

    private Integer salaryId;

    @ApiModelProperty(value = "薪资待遇")
    private String salary;

    private Integer workAddressId;

    @ApiModelProperty(value = "工作地点")
    private String workAddress;

    private Integer property;

    @ApiModelProperty(value = "岗位性质 0全职 1兼职")
    private String workProperty;

    private Integer educationId;

    @ApiModelProperty(value = "学历要求")
    private String education;

    @ApiModelProperty(value = "计划招聘人数")
    private Integer recruitNumber;

    @ApiModelProperty(value = "投递人数")
    private Integer deliveryNumber;

    private Integer auditStatusId;

    @ApiModelProperty(value = "审核状态")
    private String auditStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getWorkingYearsId() {
        return workingYearsId;
    }

    public void setWorkingYearsId(Integer workingYearsId) {
        this.workingYearsId = workingYearsId;
    }

    public String getWorkingYears() {
        return workingYears;
    }

    public void setWorkingYears(String workingYears) {
        this.workingYears = workingYears;
    }

    public Integer getSalaryId() {
        return salaryId;
    }

    public void setSalaryId(Integer salaryId) {
        this.salaryId = salaryId;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public Integer getWorkAddressId() {
        return workAddressId;
    }

    public void setWorkAddressId(Integer workAddressId) {
        this.workAddressId = workAddressId;
    }

    public String getWorkAddress() {
        return workAddress;
    }

    public void setWorkAddress(String workAddress) {
        this.workAddress = workAddress;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public String getWorkProperty() {
        return workProperty;
    }

    public void setWorkProperty(String workProperty) {
        this.workProperty = workProperty;
    }

    public Integer getEducationId() {
        return educationId;
    }

    public void setEducationId(Integer educationId) {
        this.educationId = educationId;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public Integer getDeliveryNumber() {
        return deliveryNumber;
    }

    public void setDeliveryNumber(Integer deliveryNumber) {
        this.deliveryNumber = deliveryNumber;
    }

    public String getAuditStatus() {
        return auditStatus;
    }

    public void setAuditStatus(String auditStatus) {
        this.auditStatus = auditStatus;
    }

    public Integer getAuditStatusId() {
        return auditStatusId;
    }

    public void setAuditStatusId(Integer auditStatusId) {
        this.auditStatusId = auditStatusId;
    }

}
