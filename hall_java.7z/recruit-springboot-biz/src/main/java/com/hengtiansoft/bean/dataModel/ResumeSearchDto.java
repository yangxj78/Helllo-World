package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

public class ResumeSearchDto implements Serializable {
    private static final long serialVersionUID = 3702678632690614698L;

    //userInfo
    private Integer userId;

    private String name;

    private Integer educational;

    private Integer maxAge;
    private Integer minAge;

    private String telephone;


    //resume
    private Integer workYears;

    private String updateBegin;

    private String updateEnd;

    private Integer pageSize;

    private Integer pageNumber;

    private Integer source;

    private Integer status;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getEducational() {
        return educational;
    }

    public void setEducational(Integer educational) {
        this.educational = educational;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public Integer getWorkYears() {
        return workYears;
    }

    public void setWorkYears(Integer workYears) {
        this.workYears = workYears;
    }

    public String getUpdateBegin() {
        return updateBegin;
    }

    public void setUpdateBegin(String updateBegin) {
        this.updateBegin = updateBegin;
    }

    public String getUpdateEnd() {
        return updateEnd;
    }

    public void setUpdateEnd(String updateEnd) {
        this.updateEnd = updateEnd;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
