package com.hengtiansoft.bean.dataModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecruitmentSearchDto {

    private Integer recruitmentId;

    private String date;

    private String recruitmentName;

}
