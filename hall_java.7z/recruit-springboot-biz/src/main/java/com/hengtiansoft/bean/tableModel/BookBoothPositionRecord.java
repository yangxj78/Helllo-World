package com.hengtiansoft.bean.tableModel;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Table(name = "book_booth_position_record")
public class BookBoothPositionRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "book_booth_id")
    private Integer bookBoothId;

    @Column(name = "position_record_id")
    private Integer positionRecordId;
    @Column(name = "order_num")
    private Integer order;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return book_booth_id
     */
    public Integer getBookBoothId() {
        return bookBoothId;
    }

    /**
     * @param bookBoothId
     */
    public void setBookBoothId(Integer bookBoothId) {
        this.bookBoothId = bookBoothId;
    }

    /**
     * @return position_record_id
     */
    public Integer getPositionRecordId() {
        return positionRecordId;
    }

    /**
     * @param positionRecordId
     */
    public void setPositionRecordId(Integer positionRecordId) {
        this.positionRecordId = positionRecordId;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }
}