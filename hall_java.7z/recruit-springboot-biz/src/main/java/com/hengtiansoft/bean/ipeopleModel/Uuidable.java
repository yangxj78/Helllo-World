package com.hengtiansoft.bean.ipeopleModel;

public interface Uuidable<UUID> {

	UUID getUuid();
}
