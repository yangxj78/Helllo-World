package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

/**
 * HR端查看简历信息类
 * Created by linwu on 8/13/2018.
 */
public class ResumeInfoDto {

    @ApiModelProperty(value = "简历详情")
    private ResumeDto resumeDto;

    @ApiModelProperty(value = "面试结果")
    private List<InterViewResultDto> interViewResultDtoList;

    public ResumeDto getResumeDto() {
        return resumeDto;
    }

    public void setResumeDto(ResumeDto resumeDto) {
        this.resumeDto = resumeDto;
    }

    public List<InterViewResultDto> getInterViewResultDtoList() {
        return interViewResultDtoList;
    }

    public void setInterViewResultDtoList(List<InterViewResultDto> interViewResultDtoList) {
        this.interViewResultDtoList = interViewResultDtoList;
    }
}
