package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class Experience {

    @ApiModelProperty(value = "起始时间", notes = "必填")
    private String startTs;

    @ApiModelProperty(value = "结束时间", notes = "必填")
    private String endTs;

    public String getStartTs() {
        return startTs;
    }

    public void setStartTs(String startTs) {
        this.startTs = startTs;
    }

    public String getEndTs() {
        return endTs;
    }

    public void setEndTs(String endTs) {
        this.endTs = endTs;
    }
}
