package com.hengtiansoft.bean.dataModel;

import java.util.List;

public class SendMessageDto {

    private List<Integer> resumes;
    private Integer recruitmentID;

    public List<Integer> getResumes() {
        return resumes;
    }

    public void setResumes(List<Integer> resumes) {
        this.resumes = resumes;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }
}
