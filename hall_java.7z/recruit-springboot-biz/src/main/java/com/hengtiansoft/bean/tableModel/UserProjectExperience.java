package com.hengtiansoft.bean.tableModel;

import com.hengtiansoft.bean.dataModel.Experience;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserProjectExperience;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
public class UserProjectExperience extends Experience {

    @Id
    @GeneratedValue(generator = "JDBC")
    @ApiModelProperty(value = "工作经历id", notes = "编辑必填")
    private Integer id;

    @ApiModelProperty(value = "用户id", notes = "必填")
    private Integer userId;

    @ApiModelProperty(value = "简历id", notes = "仅当简历创建时非必填")
    private Integer resumeId;

    @ApiModelProperty(value = "描述", notes = "")
    private String description;

    @ApiModelProperty(value = "职责描述", notes = "")
    private String duty;

    @ApiModelProperty(value = "公司", notes = "必填")
    private String company;


    @ApiModelProperty(value = "项目名称", notes = "必填")
    private String projectName;

    @ApiModelProperty(value = "起始时间", notes = "必填")
    private String startTs;

    @ApiModelProperty(value = "结束时间", notes = "必填")
    private String endTs;

    @ApiModelProperty(value = "createTs", notes = "")
    private String createTs;

    @ApiModelProperty(value = "updateTs", notes = "")
    private String updateTs;



    public UserProjectExperience(MUserProjectExperience experience) {
        this.userId = experience.getUserId();
        this.company = experience.getCompany();
        this.description = experience.getDescription();
        this.duty = experience.getDuty();
        this.projectName = experience.getProjectName();
        this.startTs = dateFormat(experience.getStartTs());
        this.endTs = dateFormat(experience.getEndTs());
    }

    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id")
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "resume_id")
    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }
    @Basic
    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Basic
    @Column(name = "duty")
    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    @Basic
    @Column(name = "company")
    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @Basic
    @Column(name = "project_name")
    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    @Basic
    @Column(name = "start_ts")
    public String getStartTs() {
        return startTs;
    }

    public void setStartTs(String startTs) {
        this.startTs = startTs;
    }

    @Basic
    @Column(name = "end_ts")
    public String getEndTs() {
        return endTs;
    }

    public void setEndTs(String endTs) {
        this.endTs = endTs;
    }

    @Basic
    @Column(name = "create_ts")
    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    @Basic
    @Column(name = "update_ts")
    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public UserProjectExperience(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public UserProjectExperience() {
        super();
    }

    private String dateFormat(String time) {
        String result = time.trim().replaceAll("[^0-9]", "-");
        return result.endsWith("-") ? result.substring(0, result.length() - 1) : result;
    }
}