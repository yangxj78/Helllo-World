package com.hengtiansoft.bean.ipeopleModel;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@MappedSuperclass
@EqualsAndHashCode(callSuper = false)
public abstract class AbstractBaseEntity<ID extends Serializable, UUID extends Serializable, M> implements
        BaseEntity<Long, String, M> {

    private static final long serialVersionUID = -2250778619478173532L;
    public static final int MAX_LENGTH_EMAIL_ADDRESS = 100;
    public static final int MIN_LENGTH_USERNAME = 0;
    public static final int MIN_LENGTH_PASSWORD = 4;
    public static final String STRING_SPILT = ".";
    public static final String ID = "id";
    public static final String UUID = "uuid";
    public static final String NAME = "name";
    public static final String DATE_CREATED = "dateCreated";
    public static final String DATE_MODIFIED = "dateModified";
    public static final String DESCRIPTION = "description";
    public static final String SOFT_DELETE = "softDelete";
    public static final String CODE = "code";
    public static final String CREATE_BY = "createBy";
    public static final String MODIFIED_BY = "modifiedBy";
    public static final String STATUS = "status";
    public static final String TYPE = "type";

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;
    @Column(name = "uuid")
    @Getter
    @Setter
    private String uuid;
    @Getter
    @Setter
    private String code;
    @NotEmpty
    @Length(min = MIN_LENGTH_USERNAME)
    @Getter
    @Setter
    private String name;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_created")
    @Getter
    @Setter
    private Date dateCreated;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_modified")
    @Getter
    @Setter
    private Date dateModified;
    @Transient
    @Getter
    @Setter
    private M createBy;
    @Transient
    @Getter
    @Setter
    private M modifiedBy;
    @Column(name = "soft_delete")
    @Getter
    @Setter
    private boolean softDelete;
    @Column(name = "description", columnDefinition = "text", nullable = true)
    @Getter
    @Setter
    private String description;

    public boolean isNew() {
        return null == getId();
    }

    @Override
    public void markDeleted() {
        this.softDelete = true;
    }
}
