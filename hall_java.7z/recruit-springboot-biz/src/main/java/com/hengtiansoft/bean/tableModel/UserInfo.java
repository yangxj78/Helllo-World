package com.hengtiansoft.bean.tableModel;

import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserInfo;
import com.hengtiansoft.common.enumeration.EducationalLevelEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
@Table(name = "user_info")
public class UserInfo {

    @Id
    @GeneratedValue(generator = "JDBC")
    @ApiModelProperty(value = "基本信息id",notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id",notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "姓名",notes = "必填")
    private String name;
    @ApiModelProperty(value = "电话",notes = "必填")
    private String phone;
    @ApiModelProperty(value = "邮箱",notes = "必填")
    private String email;
    @ApiModelProperty(value = "身份证",notes = "必填")
    private String identityCard;
    @ApiModelProperty(value = "性别",notes = "必填")
    private Integer sex;
    @ApiModelProperty(value = "民族",notes = "暂时不需要")
    private Integer nation;
    @ApiModelProperty(value = "求职者类型",notes = "0 应届高校毕业生；1 在职； 2 离职")
    private Integer type;
    @ApiModelProperty(value = "出生日期",notes = "必填")
    private String birthDate;
    @ApiModelProperty(value = "文化程度",notes = "必填")
    private Integer educational;
    @ApiModelProperty(value = "居住地",notes = "必填")
    private String address;
    @Column(name = "update_Ts")
    private String updateTs;
    @Column(name = "create_Ts")
    private String createTs;

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    @Id
    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id")
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "phone")
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Basic
    @Column(name = "EmailService")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Basic
    @Column(name = "identity_card")
    public String getIdentityCard() {
        return identityCard;
    }

    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }

    @Basic
    @Column(name = "sex")
    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    @Basic
    @Column(name = "type")
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Basic
    @Column(name = "nation")
    public Integer getNation() {
        return nation;
    }

    public void setNation(Integer nation) {
        this.nation = nation;
    }

    @Basic
    @Column(name = "birth_date")
    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    @Basic
    @Column(name = "educational")
    public Integer getEducational() {
        return educational;
    }

    public void setEducational(Integer educational) {
        this.educational = educational;
    }

    @Basic
    @Column(name = "address")
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public UserInfo(Integer userId) {
        this.userId = userId;
    }

    public UserInfo(MUserInfo mUserInfo) {
        this.userId = mUserInfo.getUserId();
        this.name = mUserInfo.getName();
        this.phone = mUserInfo.getPhone();
        this.email = mUserInfo.getEmail();
        this.identityCard = mUserInfo.getIdentityCard();
        if(mUserInfo.getSex() != null){
            this.sex = mUserInfo.getSex().contains("男")? 0 : 1;
        }
        if(mUserInfo.getType() != null){
            if(mUserInfo.getType().contains("应届")) {
                this.type = 0 ;
            }else if(mUserInfo.getType().contains("在职")){
                this.type = 1 ;
            }else{
                this.type = 2 ;
            }
        }
        this.birthDate = mUserInfo.getBirthDate();
        this.educational = EducationalLevelEnum.verifyEducationLevel(mUserInfo.getEducational());
        this.address = mUserInfo.getAddress();
    }

    public UserInfo() {
        super();
    }
}
