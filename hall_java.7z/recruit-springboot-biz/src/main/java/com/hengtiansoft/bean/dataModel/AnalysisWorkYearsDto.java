package com.hengtiansoft.bean.dataModel;

public class AnalysisWorkYearsDto {
    private Integer workYears;
    private Integer number;

    public Integer getWorkYears() {
        return workYears;
    }

    public void setWorkYears(Integer workYears) {
        this.workYears = workYears;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
