package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class RecruitmentDataDto {
    private Integer recruitmentID;
    private String recruitmentName;
    private String recruitmentDate;
    private String recruitmentType;
    private String companyName;
    @ApiModelProperty(value = "参展联系人")
    private String exhibitor;
    private Integer companyID;
    @ApiModelProperty(value = "参展联系人号码")
    private String exhibitorNumber;
    private Integer positionRecordID;
    private String positionName;
    private Integer boothID;
    private Integer education;
    private Integer workingYears;
    private Integer recruitNumber;
    private String desc;
    private Integer salary;


    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getPositionRecordID() {
        return positionRecordID;
    }

    public void setPositionRecordID(Integer positionRecordID) {
        this.positionRecordID = positionRecordID;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }

    public String getRecruitmentDate() {
        return recruitmentDate;
    }

    public void setRecruitmentDate(String recruitmentDate) {
        this.recruitmentDate = recruitmentDate;
    }

    public String getRecruitmentType() {
        return recruitmentType;
    }

    public void setRecruitmentType(String recruitmentType) {
        this.recruitmentType = recruitmentType;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getExhibitor() {
        return exhibitor;
    }

    public void setExhibitor(String exhibitor) {
        this.exhibitor = exhibitor;
    }

    public String getExhibitorNumber() {
        return exhibitorNumber;
    }

    public void setExhibitorNumber(String exhibitorNumber) {
        this.exhibitorNumber = exhibitorNumber;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getEducation() {
        return education;
    }

    public void setEducation(Integer education) {
        this.education = education;
    }

    public Integer getWorkingYears() {
        return workingYears;
    }

    public void setWorkingYears(Integer workingYears) {
        this.workingYears = workingYears;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
