package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class CompanySearch extends PageDto {

    @ApiModelProperty(value = "招聘会ID")
    private Integer recruitmentID;

    @ApiModelProperty(value = "展位ID")
    private Integer boothID;

    private Integer companyID;
    @ApiModelProperty(value = "企业名字（精准匹配）")
    private String companyName;

    @ApiModelProperty(value = "公司地址")
    private String address;

    @ApiModelProperty(value = "公司名称关键字")
    private String search;

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }


    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }
}