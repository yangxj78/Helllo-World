package com.hengtiansoft.bean.dataModel;

public class AnalysisPositionSalaryDto {

    private Integer poisitonSalary;
    private Integer positionNumber;

    public Integer getPoisitonSalary() {
        return poisitonSalary;
    }

    public void setPoisitonSalary(Integer poisitonSalary) {
        this.poisitonSalary = poisitonSalary;
    }

    public Integer getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Integer positionNumber) {
        this.positionNumber = positionNumber;
    }
}
