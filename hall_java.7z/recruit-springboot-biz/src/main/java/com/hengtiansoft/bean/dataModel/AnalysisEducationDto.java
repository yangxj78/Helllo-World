package com.hengtiansoft.bean.dataModel;

public class AnalysisEducationDto {
    private Integer educaiton;
    private Integer number;

    public Integer getEducaiton() {
        return educaiton;
    }

    public void setEducaiton(Integer educaiton) {
        this.educaiton = educaiton;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
