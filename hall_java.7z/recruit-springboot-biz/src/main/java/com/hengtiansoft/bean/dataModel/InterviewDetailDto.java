package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * 面试详细
 */
public class InterviewDetailDto {

    @ApiModelProperty(value = "投递id")
    private Integer id;

    @ApiModelProperty(value = "面试结果： 0 未通过；1 已通过； 2 待定")
    private Integer interviewResult;

    @ApiModelProperty(value = "岗位匹配度")
    private Integer matching;

    @ApiModelProperty(value = "专业基础")
    private Integer profession;

    @ApiModelProperty(value = "学习能力")
    private Integer learning;

    @ApiModelProperty(value = "沟通协调")
    private Integer communicate;

    @ApiModelProperty(value = "面试评价")
    private String interviewEvaluation;

    @ApiModelProperty(value = "是否结束,0:不结束，1结束")
    private Integer isOver;

    @ApiModelProperty(value = "面试操作,0:结束面试，1:面试返回")
    private Integer type;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(Integer interviewResult) {
        this.interviewResult = interviewResult;
    }

    public Integer getMatching() {
        return matching;
    }

    public void setMatching(Integer matching) {
        this.matching = matching;
    }

    public Integer getProfession() {
        return profession;
    }

    public void setProfession(Integer profession) {
        this.profession = profession;
    }

    public Integer getLearning() {
        return learning;
    }

    public void setLearning(Integer learning) {
        this.learning = learning;
    }

    public Integer getCommunicate() {
        return communicate;
    }

    public void setCommunicate(Integer communicate) {
        this.communicate = communicate;
    }

    public String getInterviewEvaluation() {
        return interviewEvaluation;
    }

    public void setInterviewEvaluation(String interviewEvaluation) {
        this.interviewEvaluation = interviewEvaluation;
    }

    public Integer getIsOver() {
        return isOver;
    }

    public void setIsOver(Integer isOver) {
        this.isOver = isOver;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}