package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.List;

public class RecruitmentAppDataDto implements Serializable {
    private static final long serialVersionUID = -8000015839446396883L;

    @ApiModelProperty(value = "招聘会id")
    private Integer recruitmentID;
    private String companyName;
    private Integer companyId;
    @ApiModelProperty(value = "展位id")
    private Integer boothID;
    @ApiModelProperty(value = "岗位名称List")
    private List positionRecordList;


    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public List getPositionRecordList() {
        return positionRecordList;
    }

    public void setPositionRecordList(List positionRecordList) {
        this.positionRecordList = positionRecordList;
    }
}
