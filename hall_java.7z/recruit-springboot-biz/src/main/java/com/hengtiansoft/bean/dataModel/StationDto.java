package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class StationDto implements Serializable {
    private static final long serialVersionUID = -5638981295174002067L;

    @ApiModelProperty(value = "岗位名称")
    private String name;

    @ApiModelProperty(value = "招聘人数")
    private Integer people;

    @ApiModelProperty(value = "岗位描述")
    private String desc;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPeople() {
        return people;
    }

    public void setPeople(Integer people) {
        this.people = people;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
