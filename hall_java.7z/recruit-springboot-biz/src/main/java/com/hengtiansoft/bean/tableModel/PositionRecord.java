package com.hengtiansoft.bean.tableModel;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Transient;

@Table(name = "position_record")
public class PositionRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;


    /**
     * 企业id
     */
    @Column(name = "company_id")
    private Integer companyId;
    /**
     * 企业id
     */
    @Column(name = "recruitment_id")
    private Integer recruitmentId;

    /**
     * 岗位名称
     */
    private String name;



    /**
     * 学历id
     */
    @Column(name = "education_id")
    private Integer educationId;

    /**
     * 工作年限id
     */
    @Column(name = "working_years_id")
    private Integer workingYearsId;

    /**
     * 薪水id
     */
    @Column(name = "salary_id")
    private Integer salaryId;

    /**
     * 招聘人数
     */
    @Column(name = "recruit_number")
    private Integer recruitNumber;

    /**
     * 岗位描述
     */
    private String description;


    @Column(name = "update_ts")
    private Date updateTs;

    @Column(name = "tag_id")
    private Integer tagID;
    @Transient
    private Integer order;
    @Transient
    private Integer boothID;
    private Integer property;
    @Column(name = "s_region_id")
    private Integer sRegionID;

    public Integer getsRegionID() {
        return sRegionID;
    }

    public void setsRegionID(Integer sRegionID) {
        this.sRegionID = sRegionID;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }


    /**
     * 获取企业id
     *
     * @return company_id - 企业id
     */
    public Integer getCompanyId() {
        return companyId;
    }

    /**
     * 设置企业id
     *
     * @param companyId 企业id
     */
    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    /**
     * 获取岗位名称
     *
     * @return name - 岗位名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置岗位名称
     *
     * @param name 岗位名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }


    /**
     * 获取学历id
     *
     * @return education_id - 学历id
     */
    public Integer getEducationId() {
        return educationId;
    }

    /**
     * 设置学历id
     *
     * @param educationId 学历id
     */
    public void setEducationId(Integer educationId) {
        this.educationId = educationId;
    }

    /**
     * 获取工作年限id
     *
     * @return working_years_id - 工作年限id
     */
    public Integer getWorkingYearsId() {
        return workingYearsId;
    }

    /**
     * 设置工作年限id
     *
     * @param workingYearsId 工作年限id
     */
    public void setWorkingYearsId(Integer workingYearsId) {
        this.workingYearsId = workingYearsId;
    }

    /**
     * 获取薪水id
     *
     * @return salary_id - 薪水id
     */
    public Integer getSalaryId() {
        return salaryId;
    }

    /**
     * 设置薪水id
     *
     * @param salaryId 薪水id
     */
    public void setSalaryId(Integer salaryId) {
        this.salaryId = salaryId;
    }

    /**
     * 获取招聘人数
     *
     * @return recruit_number - 招聘人数
     */
    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    /**
     * 设置招聘人数
     *
     * @param recruitNumber 招聘人数
     */
    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    /**
     * 获取岗位描述
     *
     * @return description - 岗位描述
     */
    public String getDescription() {
        return description;
    }

    /**
     * 设置岗位描述
     *
     * @param description 岗位描述
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * 获取更新时间
     *
     * @return update_ts - 更新时间
     */
    public Date getUpdateTs() {
        return updateTs;
    }

    /**
     * 设置更新时间
     *
     * @param updateTs 更新时间
     */
    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }
}