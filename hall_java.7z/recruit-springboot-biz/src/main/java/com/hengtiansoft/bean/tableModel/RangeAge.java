package com.hengtiansoft.bean.tableModel;

import javax.persistence.Entity;
import javax.persistence.Basic;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Objects;

@Entity
@Table(name = "range_age")
public class RangeAge {
    private Integer id;
    private String name;
    private Integer min;
    private Integer max;

    @Id
    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "name", nullable = false, length = 11)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "min", nullable = true)
    public Integer getMin() {
        return min;
    }

    public void setMin(Integer min) {
        this.min = min;
    }

    @Basic
    @Column(name = "max", nullable = true)
    public Integer getMax() {
        return max;
    }

    public void setMax(Integer max) {
        this.max = max;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RangeAge rangeAge = (RangeAge) o;
        return id == rangeAge.id &&
                Objects.equals(name, rangeAge.name) &&
                Objects.equals(min, rangeAge.min) &&
                Objects.equals(max, rangeAge.max);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, name, min, max);
    }
}
