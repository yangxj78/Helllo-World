package com.hengtiansoft.bean.dataModel;

public class BoothListDto {


    private Integer bookBoothID;
    private Integer boothID;
    private Integer companyID;
    private String companyName;
    private String exhibitor;
    private String exhibitorNumber;

    public Integer getBookBoothID() {
        return bookBoothID;
    }

    public void setBookBoothID(Integer bookBoothID) {
        this.bookBoothID = bookBoothID;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getExhibitor() {
        return exhibitor;
    }

    public void setExhibitor(String exhibitor) {
        this.exhibitor = exhibitor;
    }

    public String getExhibitorNumber() {
        return exhibitorNumber;
    }

    public void setExhibitorNumber(String exhibitorNumber) {
        this.exhibitorNumber = exhibitorNumber;
    }
}
