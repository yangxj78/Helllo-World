package com.hengtiansoft.bean.dataModel;

public class ResumDeliveryPRENum {

private Integer peopleNum;
private Integer posNum;

    public Integer getPeopleNum() {
        return peopleNum;
    }

    public void setPeopleNum(Integer peopleNum) {
        this.peopleNum = peopleNum;
    }

    public Integer getPosNum() {
        return posNum;
    }

    public void setPosNum(Integer posNum) {
        this.posNum = posNum;
    }
}
