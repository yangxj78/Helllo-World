package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;

@Table(name = "recycle")
public class Recycle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 删除的类型
     */
    private String type;
    private String name;
    /**
     * 被删除数据的ID
     */
    @Column(name = "delete_id")
    private Integer deleteId;

    @Column(name = "delete_date")
    private String deleteDate;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取删除的类型
     *
     * @return type - 删除的类型
     */
    public String getType() {
        return type;
    }

    /**
     * 设置删除的类型
     *
     * @param type 删除的类型
     */
    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    /**
     * 获取被删除数据的ID
     *
     * @return delete_id - 被删除数据的ID
     */
    public Integer getDeleteId() {
        return deleteId;
    }

    /**
     * 设置被删除数据的ID
     *
     * @param deleteId 被删除数据的ID
     */
    public void setDeleteId(Integer deleteId) {
        this.deleteId = deleteId;
    }

    public String getDeleteDate() {
        return deleteDate;
    }

    public void setDeleteDate(String deleteDate) {
        this.deleteDate = deleteDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}