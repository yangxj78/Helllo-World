package com.hengtiansoft.bean.dataModel;

import org.hibernate.validator.constraints.NotEmpty;

import java.io.Serializable;

public class MobileSignInDto implements Serializable {


    private static final long serialVersionUID = -4577401861116700427L;

    private String phone;
    private String captcha;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }
}
