package com.hengtiansoft.bean.dataModel;

import lombok.Data;

@Data
public class CollectionPositionDto {
    private Integer positionRecordId;

    private String positionName;

    private String companyName;

    private Integer boothId;

    private String date;

    private Integer property;

    private String address;
}
