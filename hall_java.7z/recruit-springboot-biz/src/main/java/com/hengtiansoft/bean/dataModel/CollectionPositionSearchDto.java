package com.hengtiansoft.bean.dataModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CollectionPositionSearchDto {

    private Integer recruitmentId;

    private Integer userId;

    private String keyword;

    private Integer boothId;

    private Integer positionRecordId;

    public CollectionPositionSearchDto(){}

    public CollectionPositionSearchDto(Integer userId, Integer boothId, Integer positionRecordId) {
        this.userId = userId;
        this.boothId = boothId;
        this.positionRecordId = positionRecordId;
    }
}
