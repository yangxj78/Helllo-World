package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * 应聘者管理投递
 * 分流记录
 * 查询条件
 */
public class InterviewSearchDto {

    @ApiModelProperty(value = "岗位记录id")
    private Integer positionRecordId;

    @ApiModelProperty(value = "面试结果：0 未通过；1 已通过； 2 待定")
    private Integer interviewResult;

    @ApiModelProperty(value = "面试状态：0 未面试；1面试中；2已面试")
    private Integer interviewStatus;

    @ApiModelProperty(value = "当前页数")
    private Integer offset;

    @ApiModelProperty(value = "每页条数")
    private Integer limit;

    public Integer getInterviewStatus() {
        return interviewStatus;
    }

    public void setInterviewStatus(Integer interviewStatus) {
        this.interviewStatus = interviewStatus;
    }

    public Integer getPositionRecordId() {
        return positionRecordId;
    }

    public void setPositionRecordId(Integer positionRecordId) {
        this.positionRecordId = positionRecordId;
    }

    public Integer getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(Integer interviewResult) {
        this.interviewResult = interviewResult;
    }

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }
}