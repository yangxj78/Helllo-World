package com.hengtiansoft.bean.ipeopleModel;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
@EqualsAndHashCode(callSuper=false)
public abstract class AbstractJPAEntity<M> extends AbstractBaseEntity<Long,String,M> implements JPAEntity<Long, String, String, String, M> {

	private static final long serialVersionUID = 5684701199923597183L;
	
	protected final String SPILT = "-";
	
	public static final String TYPE="type";
	public static final String STATUS="status";
	
	
	@Column(name="type")
	@Getter
    @Setter
    private String type;
	@Column(name="status")
	@Getter
    @Setter
    private String status;
}
