package com.hengtiansoft.bean.ipeopleModel;

import com.hengtiansoft.common.enumeration.SexEnum;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.util.Collection;
import java.util.Date;

import static com.hengtiansoft.bean.ipeopleModel.AbstractBaseEntity.MIN_LENGTH_USERNAME;

@Entity
@Table(name = "hr_jobhunter")
public class Jobhunter{

    /**
     * Variables Name: serialVersionUID Description: TODO Value Description: TODO
     */
    private static final long serialVersionUID = -1040568708497897702L;
    public static final String UNIONID = "unionid";


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;
    @Column(name = "uuid")
    @Getter
    @Setter
    private String uuid;
    @Getter
    @Setter
    private String code;
    @NotEmpty
    @Length(min = MIN_LENGTH_USERNAME)
    @Getter
    @Setter
    private String name;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_created")
    @Getter
    @Setter
    private Date dateCreated;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_modified")
    @Getter
    @Setter
    private Date dateModified;



    @Column(unique = true, length = 11)
    @Setter
    @Getter
    private String phone;

    @Column(name = "age")
    @Getter
    @Setter
    private String age;

    @Enumerated(EnumType.STRING)
    @Getter
    @Setter
    private SexEnum sex;

    @Column(name = "email")
    @Getter
    @Setter
    private String email;

    @Column(name = "real_name")
    @Getter
    @Setter
    private String realName;

    @Column(name = "headimgurl")
    @Getter
    @Setter
    private String headimgurl;

    @Column(name = "unionid")
    @Getter
    @Setter
    private String unionid;

    @OneToMany
    @JoinColumn(name = "jobhunter_id")
    @Getter
    @Setter
    private Collection<PersonResume> personResumes;

    public Jobhunter(String name, SexEnum sex, String headimgurl, String unionid) {
        setName(name);
        setSex(sex);
        setHeadimgurl(headimgurl);
        setUnionid(unionid);
    }

    public Jobhunter() {

    }

    public void update(String realName, String phone, String email, String sex) {

        if (!StringUtils.isBlank(realName)) {
            setRealName(realName);
        }
        if (!StringUtils.isBlank(phone)) {
            setPhone(phone);
        }
        if (!StringUtils.isBlank(email)) {
            setEmail(email);
        }

        if ("WOMAN".equals(sex) || "MAN".equals(sex)) {
            setSex(SexEnum.valueOf(sex));
        }
    }
}
