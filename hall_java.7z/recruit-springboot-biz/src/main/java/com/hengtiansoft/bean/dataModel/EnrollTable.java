package com.hengtiansoft.bean.dataModel;

/**
*@Description: 招聘会报名表
**/
public class EnrollTable {
    private Integer boothID;
    private String companyName;
    private String exhibitor;
    private String exhibitorNumber;



    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getExhibitor() {
        return exhibitor;
    }

    public void setExhibitor(String exhibitor) {
        this.exhibitor = exhibitor;
    }

    public String getExhibitorNumber() {
        return exhibitorNumber;
    }

    public void setExhibitorNumber(String exhibitorNumber) {
        this.exhibitorNumber = exhibitorNumber;
    }
}
