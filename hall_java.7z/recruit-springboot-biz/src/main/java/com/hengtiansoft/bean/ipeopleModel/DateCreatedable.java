package com.hengtiansoft.bean.ipeopleModel;

import java.util.Date;

public interface DateCreatedable {

	Date getDateCreated();
}
