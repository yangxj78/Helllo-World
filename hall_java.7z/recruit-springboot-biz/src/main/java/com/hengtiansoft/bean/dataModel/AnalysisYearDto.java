package com.hengtiansoft.bean.dataModel;

public class AnalysisYearDto {
    private Integer age1825;
    private Integer age2635;
    private Integer age3650;
    private Integer age50;
    private Integer total;

    public Integer getAge1825() {
        return age1825;
    }

    public void setAge1825(Integer age1825) {
        this.age1825 = age1825;
    }

    public Integer getAge2635() {
        return age2635;
    }

    public void setAge2635(Integer age2635) {
        this.age2635 = age2635;
    }

    public Integer getAge3650() {
        return age3650;
    }

    public void setAge3650(Integer age3650) {
        this.age3650 = age3650;
    }

    public Integer getAge50() {
        return age50;
    }

    public void setAge50(Integer age50) {
        this.age50 = age50;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }


}
