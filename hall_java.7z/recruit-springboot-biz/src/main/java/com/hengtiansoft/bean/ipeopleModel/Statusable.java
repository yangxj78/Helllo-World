package com.hengtiansoft.bean.ipeopleModel;

public interface Statusable<STATUS> {
	STATUS getStatus();
}
