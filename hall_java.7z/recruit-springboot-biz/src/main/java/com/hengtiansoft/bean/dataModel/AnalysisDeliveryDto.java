package com.hengtiansoft.bean.dataModel;

public class AnalysisDeliveryDto {
    private Integer number;
    private double rate;
    private String dimension;

    public Integer getNumber() {
        return number;
    }

    public String getDimension() {

        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }
}
