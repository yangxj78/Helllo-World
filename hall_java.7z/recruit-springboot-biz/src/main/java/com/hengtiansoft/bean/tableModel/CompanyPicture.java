package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;

@Table(name = "company_picture")
public class CompanyPicture {
    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "company_id")
    private Integer companyId;

    @Column(name = "picture_id")
    private String pictureId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return company_id
     */
    public Integer getCompanyId() {
        return companyId;
    }

    /**
     * @param companyId
     */
    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    /**
     * @return picture_id
     */
    public String getPictureId() {
        return pictureId;
    }

    /**
     * @param pictureId
     */
    public void setPictureId(String pictureId) {
        this.pictureId = pictureId == null ? null : pictureId.trim();
    }
}