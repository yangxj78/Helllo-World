package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * 签到信息类
 */
public class CompanySignDto {

    @ApiModelProperty(value = "ip")
    private String ip;

    @ApiModelProperty(value = "招聘会id")
    private Integer recruitmentId;

    @ApiModelProperty(value = "公司id")
    private Integer companyId;

    @ApiModelProperty(value = "展位id,必填字段")
    private Integer boothId;

    @ApiModelProperty(value = "签到码,必填字段")
    private String captcha;

    @ApiModelProperty(value = "就餐人数")
    private Integer mealsNumber;

    @ApiModelProperty(value = "是否停车, 0不停车，1停车")
    private Integer isPacking;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public Integer getMealsNumber() {
        return mealsNumber;
    }

    public void setMealsNumber(Integer mealsNumber) {
        this.mealsNumber = mealsNumber;
    }

    public Integer getIsPacking() {
        return isPacking;
    }

    public void setIsPacking(Integer isPacking) {
        this.isPacking = isPacking;
    }
}