package com.hengtiansoft.bean.dataModel;

import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import java.util.List;

public class BoothDto {

    private List<Position> positions;
    private List<PositionRecord> positionRecords;

    public List<Position> getPositions() {
        return positions;
    }

    public void setPositions(List<Position> positions) {
        this.positions = positions;
    }

     public List<PositionRecord> getPositionRecords() {
        return positionRecords;
    }

    public void setPositionRecords(List<PositionRecord> positionRecords) {
        this.positionRecords = positionRecords;
    }
}
