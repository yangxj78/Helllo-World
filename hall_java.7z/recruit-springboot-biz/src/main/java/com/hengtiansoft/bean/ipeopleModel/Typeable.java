package com.hengtiansoft.bean.ipeopleModel;

public interface Typeable<STATUS> {
	STATUS getType();
}
