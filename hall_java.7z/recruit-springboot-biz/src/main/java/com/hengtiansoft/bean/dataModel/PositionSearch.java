package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class PositionSearch extends PageDto {

    @ApiModelProperty(value = "岗位名称 模糊匹配")
    private String positionName;
    @ApiModelProperty(value = "公司名称")
    private String companyName;
    @ApiModelProperty(value = "企业ID")
    private Integer companyID;
    private Integer tagID;
    @ApiModelProperty(value = "岗位名称 精准匹配")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public static class CompanyDto {
        private Integer positionNumber;
        private Integer recruitNumber;


        public Integer getPositionNumber() {
            return positionNumber;
        }

        public void setPositionNumber(Integer positionNumber) {
            this.positionNumber = positionNumber;
        }

        public Integer getRecruitNumber() {
            return recruitNumber;
        }

        public void setRecruitNumber(Integer recruitNumber) {
            this.recruitNumber = recruitNumber;
        }
    }


}
