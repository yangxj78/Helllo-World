package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;

public class AnalysisDto {
    @ApiModelProperty(value = "起始日期")
    private String startDate;
    @ApiModelProperty(value = "截止日期")
    private String endDate;
    @ApiModelProperty(value = "0 综合 1专场")
    private Integer style;
    @ApiModelProperty(value = "0 企业分析 1应聘者分析")
    private Integer type;
    @ApiModelProperty(value = "维度 0日 1月 2年")
    private Integer dimension;

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Integer getStyle() {
        return style;
    }

    public void setStyle(Integer style) {
        this.style = style;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getDimension() {
        return dimension;
    }

    public void setDimension(Integer dimension) {
        this.dimension = dimension;
    }
}
