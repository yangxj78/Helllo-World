package com.hengtiansoft.bean.tableModel;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Table(name = "statistical_table")
public class StatisticalTable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "recruitment_id")
    private Integer recruitmentID;

    @Column(name = "booth_number")
    private Integer boothID;

    @Column(name = "position_name")
    private String positionName;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "position_description")
    private String positionDescription;

    private Integer educationID;

    @Column(name = "recruit_number")
    private Integer recruitNumber;

    @Column(name = "recruitment_name")
    private String recruitmentName;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return recruitment_id
     */
    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    /**
     * @param recruitmentID
     */
    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    /**
     * @return booth_number
     */
    public Integer getboothID() {
        return boothID;
    }

    /**
     * @param boothID
     */
    public void setboothID(Integer boothID) {
        this.boothID = boothID;
    }

    /**
     * @return position_name
     */
    public String getPositionName() {
        return positionName;
    }

    /**
     * @param positionName
     */
    public void setPositionName(String positionName) {
        this.positionName = positionName == null ? null : positionName.trim();
    }

    /**
     * @return company_name
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    /**
     * @return position_description
     */
    public String getPositionDescription() {
        return positionDescription;
    }

    /**
     * @param positionDescription
     */
    public void setPositionDescription(String positionDescription) {
        this.positionDescription = positionDescription == null ? null : positionDescription.trim();
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    /**
     * @return recruit_number
     */
    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    /**
     * @param recruitNumber
     */
    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    /**
     * @return recruitment_name
     */
    public String getRecruitmentName() {
        return recruitmentName;
    }

    /**
     * @param recruitmentName
     */
    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName == null ? null : recruitmentName.trim();
    }

    public Integer getEducationID() {
        return educationID;
    }

    public void setEducationID(Integer educationID) {
        this.educationID = educationID;
    }
}