package com.hengtiansoft.bean.dataModel;

import java.util.Date;
import java.util.List;

public class InterviewExcelDataDto {
    private Integer id;

    private String name;

    private String birthDate;

    private String sex;

    private String school;

    private String major;

    private String educational;

    private String workYears;

    private String positionRecordName;

    private List<InterViewResultDto> interviewList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational;
    }

    public String getWorkYears() {
        return workYears;
    }

    public void setWorkYears(String workYears) {
        this.workYears = workYears;
    }

    public String getPositionRecordName() {
        return positionRecordName;
    }

    public void setPositionRecordName(String positionRecordName) {
        this.positionRecordName = positionRecordName;
    }

    public List<InterViewResultDto> getInterviewList() {
        return interviewList;
    }

    public void setInterviewList(List<InterViewResultDto> interviewList) {
        this.interviewList = interviewList;
    }
}
