package com.hengtiansoft.bean.ipeopleModel;

import org.springframework.data.domain.Persistable;

import java.io.Serializable;

public interface BaseEntity<ID extends Serializable, UUID extends Serializable, M>
		extends Identityable<ID>, Uuidable<UUID>, Persistable<ID>,
		LogicDeleteable, DateCreatedable, DateModifiedable, UserCreatedable<M>,
		UserModifiedable<M> {

	String getName();

	String getDescription();
}
