package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.util.Date;

@Table(name = "resume_delivery_pre")
public class ResumeDeliveryPre {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "resume_id")
    private Integer resumeId;

    @Column(name = "recruitment_id")
    private Integer recruitmentId;

    @Column(name = "company_id")
    private Integer companyId;

    @Column(name = "position_record_id")
    private Integer positionRecordId;

    @Column(name = "booth_id")
    private Integer boothId;

    @Column(name = "delivery_flag")
    private Integer deliveryFlag;

    @Column(name = "create_ts")
    private Date createTs;

    @Column(name = "update_ts")
    private Date updateTs;

    public ResumeDeliveryPre(){

    };

    public ResumeDeliveryPre(Integer userId,Integer resumeId,Integer recruitmentId,Integer companyId,Integer positionRecordId,Integer boothId,Date createTs){
        this.userId = userId;
        this.resumeId = resumeId;
        this.companyId = companyId;
        this.recruitmentId = recruitmentId;
        this.boothId = boothId;
        this.positionRecordId = positionRecordId;
        this.deliveryFlag = 0;
        this.createTs = createTs;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getPositionRecordId() {
        return positionRecordId;
    }

    public void setPositionRecordId(Integer positionRecordId) {
        this.positionRecordId = positionRecordId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Date getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    public Integer getDeliveryFlag() {
        return deliveryFlag;
    }

    public void setDeliveryFlag(Integer deliveryFlag) {
        this.deliveryFlag = deliveryFlag;
    }
}
