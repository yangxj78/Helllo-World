package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class ReviewPositionDto extends PageDto{
    private String recruitmentName;
    private String date;
    private String companyName;
    private String positionName;
    @ApiModelProperty(value = "审核状态 0未审核 1审核通过 2 审核未通过")
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }
}
