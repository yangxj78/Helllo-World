package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class ResumeDeliverySearch extends PageDto {
private Integer recruitmentId;
    private Integer boothId;
    private String companyName;
    @ApiModelProperty(value = "排序类型 0展位id 1 当前面试编号 2等待人数")
    private Integer orderType;

    public Integer getOrderType() {
        return orderType;
    }

    public void setOrderType(Integer orderType) {
        this.orderType = orderType;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
}
