package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;
import java.util.List;

public class InvitationDto implements Serializable {

    private static final long serialVersionUID = 8698814823581357420L;

    private String positionName;

    private List<Integer> userIds;

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public List<Integer> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<Integer> userIds) {
        this.userIds = userIds;
    }
}
