package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

public class CompanyReportDto {
    @ApiModelProperty(value = "公司名")
    private String name;
    @ApiModelProperty(value = "公司Id")
    private Integer uid;
    @ApiModelProperty(value = "展位Id")
    private Integer station;
    @ApiModelProperty(value = "岗位加招聘人数组合")
    private String desc;

    public CompanyReportDto(){}

    public CompanyReportDto(RecruitmentBoothDto dto) {
        this.name = dto.getCompanyName();
        this.uid = dto.getCompanyId();
        this.station = dto.getBoothID();
        StringBuilder sb = new StringBuilder();
        for (String companyDesc : dto.getPositionList()) {
            if (sb.length() == 0) {
                sb.append(companyDesc).append("人");
            } else {
                sb.append("/").append(companyDesc).append("人");
            }
        }
        this.desc = sb.toString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getStation() {
        return station;
    }

    public void setStation(Integer station) {
        this.station = station;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public static List<CompanyReportDto> RecruitmentBooth2Company(List<RecruitmentBoothDto> list) {
        List<CompanyReportDto> result = new ArrayList<>();
        for (RecruitmentBoothDto dto : list) {
            result.add(new CompanyReportDto(dto));
        }
        return result;
    }
}
