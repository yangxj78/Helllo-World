package com.hengtiansoft.bean.dataModel;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class StatisticsDto {

    private String title;
    private List<AmountDto> amount;

    public StatisticsDto(){}

    public StatisticsDto(String title, List<AmountDto> amount) {
        this.title = title;
        this.amount = amount;
    }

}
