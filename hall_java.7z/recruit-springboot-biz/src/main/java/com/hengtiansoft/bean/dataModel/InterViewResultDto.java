package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * 面试结果信息类
 */
public class InterViewResultDto {

    @ApiModelProperty(value = "面试轮次")
    private Integer interviewNum;

    @ApiModelProperty(value = "面试结果： 0 未通过；1 已通过； 2 待定")
    private String interviewResult;

    @ApiModelProperty(value = "岗位匹配度")
    private Integer matching;

    @ApiModelProperty(value = "专业基础")
    private Integer profession;

    @ApiModelProperty(value = "学习能力")
    private Integer learning;

    @ApiModelProperty(value = "沟通协调")
    private Integer communicate;

    @ApiModelProperty(value = "面试评价")
    private String interviewEvaluation;

    public Integer getInterviewNum() {
        return interviewNum;
    }

    public void setInterviewNum(Integer interviewNum) {
        this.interviewNum = interviewNum;
    }

    public String getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(String interviewResult) {
        this.interviewResult = interviewResult;
    }

    public Integer getMatching() {
        return matching;
    }

    public void setMatching(Integer matching) {
        this.matching = matching;
    }

    public Integer getProfession() {
        return profession;
    }

    public void setProfession(Integer profession) {
        this.profession = profession;
    }

    public Integer getLearning() {
        return learning;
    }

    public void setLearning(Integer learning) {
        this.learning = learning;
    }

    public Integer getCommunicate() {
        return communicate;
    }

    public void setCommunicate(Integer communicate) {
        this.communicate = communicate;
    }

    public String getInterviewEvaluation() {
        return interviewEvaluation;
    }

    public void setInterviewEvaluation(String interviewEvaluation) {
        this.interviewEvaluation = interviewEvaluation;
    }

    public InterViewResultDto() {
    }

    public InterViewResultDto(Integer interviewNum, String interviewResult, Integer matching, Integer profession, Integer learning, Integer communicate, String interviewEvaluation) {
        this.interviewNum = interviewNum;
        this.interviewResult = interviewResult;
        this.matching = matching;
        this.profession = profession;
        this.learning = learning;
        this.communicate = communicate;
        this.interviewEvaluation = interviewEvaluation;
    }
}