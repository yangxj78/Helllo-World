package com.hengtiansoft.bean.dataModel;


import java.io.Serializable;

/**
 * 用户注册类
 */
public class RegisterDto implements Serializable {

    private static final long serialVersionUID = 7898130618796368687L;
    String Phone;
    String username;
    String password;
    String confirmPassword;

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }
}
