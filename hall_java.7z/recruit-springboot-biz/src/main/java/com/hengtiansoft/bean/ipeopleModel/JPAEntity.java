package com.hengtiansoft.bean.ipeopleModel;

import java.io.Serializable;

public interface JPAEntity<ID extends Serializable, UUID extends Serializable, TYPE extends Serializable, STATUS extends Serializable, M>
		extends Typeable<TYPE>, Statusable<STATUS>, BaseEntity<ID, UUID, M> {

	String getName();

	String getDescription();
}
