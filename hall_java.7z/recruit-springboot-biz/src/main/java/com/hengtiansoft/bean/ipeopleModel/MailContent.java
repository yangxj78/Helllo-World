package com.hengtiansoft.bean.ipeopleModel;

import com.hengtiansoft.servlet.applicant.resume.service.ResumeBuilder;
import lombok.Getter;
import lombok.Setter;
import microsoft.exchange.webservices.data.core.service.item.EmailMessage;
import microsoft.exchange.webservices.data.property.complex.EmailAddress;
import microsoft.exchange.webservices.data.property.complex.MessageBody;

import javax.mail.internet.InternetAddress;
import java.util.Date;

public class MailContent {

    @Getter
    @Setter
    private EmailMessage message;
    @Getter
    @Setter
    private String fromAddress;
    @Getter
    @Setter
    private String fromName;
    @Getter
    @Setter
    private String subject;
    @Getter
    @Setter
    private Object content;
    @Getter
    @Setter
    private String contentType;
    @Getter
    @Setter
    private MessageBody messageBody;
    @Getter
    @Setter
    private Date dateTimeSent;
    @Getter
    @Setter
    private ResumeBuilder resumeBuilder;

    public MailContent(EmailMessage message, String senderAddress, String senderName, String subject,
                       MessageBody messageBody, Date dateTimeSent) {
        this(message, subject, messageBody, dateTimeSent);
        setFromAddress(senderAddress);
        setFromName(senderName);
    }

    public MailContent(EmailMessage message, EmailAddress sender, String subject, MessageBody messageBody,
                       Date dateTimeSent) {
        this(message, subject, messageBody, dateTimeSent);
        setFromAddress(sender.getAddress());
        setFromName(sender.getName());
    }

    public MailContent(EmailMessage message, String subject, MessageBody messageBody, Date dateTimeSent) {
        setMessage(message);
        setSubject(subject);
        setMessageBody(messageBody);
        setDateTimeSent(dateTimeSent);
    }

    public MailContent(InternetAddress address, String subject, String contentType, Object content, Date sentDate) {
        setFromName(address.getPersonal());
        setFromAddress(address.getAddress());
        setContent(content);
        setSubject(subject);
        setContentType(contentType);
        setDateTimeSent(sentDate);
    }
}
