package com.hengtiansoft.bean.dataModel;

import java.util.List;

public class SendMailDto {
    private List<Integer> users;
    private Integer recruitmentID;

    public List<Integer> getUsers() {
        return users;
    }

    public void setUsers(List<Integer> users) {
        this.users = users;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }
}
