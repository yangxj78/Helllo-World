package com.hengtiansoft.bean.dataModel;

import java.io.Serializable;

public class AmountDto implements Serializable ,Comparable<AmountDto>{

    private String name;
    private Integer value;

    public AmountDto() {}

    public AmountDto(String name, Integer value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    @Override
    public int compareTo(AmountDto o) {
        return this.getValue() - o.getValue();
    }
}
