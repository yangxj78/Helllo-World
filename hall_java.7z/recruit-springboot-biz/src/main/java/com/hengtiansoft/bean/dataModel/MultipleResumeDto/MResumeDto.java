package com.hengtiansoft.bean.dataModel.MultipleResumeDto;



import java.io.Serializable;
import java.util.List;

public class MResumeDto implements Serializable {

    private static final long serialVersionUID = 433917657608190731L;

    MUserInfo mUserInfo;

    MResume MResume;

    public MResumeDto(){};

    List<MUserWorkExperience> userWorkExperienceList;

    List<MUserProjectExperience> userProjectExperienceList;

    List<MUserEducationExperience> MUserEducationExperienceList;

    public MUserInfo getmUserInfo() {
        return mUserInfo;
    }

    public void setmUserInfo(MUserInfo mUserInfo) {
        this.mUserInfo = mUserInfo;
    }

    public MResume getMResume() {
        return MResume;
    }

    public void setMResume(MResume MResume) {
        this.MResume = MResume;
    }

    public List<MUserWorkExperience> getUserWorkExperienceList() {
        return userWorkExperienceList;
    }

    public void setUserWorkExperienceList(List<MUserWorkExperience> userWorkExperienceList) {
        this.userWorkExperienceList = userWorkExperienceList;
    }

    public List<MUserEducationExperience> getMUserEducationExperienceList() {
        return MUserEducationExperienceList;
    }

    public void setMUserEducationExperienceList(List<MUserEducationExperience> MUserEducationExperienceList) {
        this.MUserEducationExperienceList = MUserEducationExperienceList;
    }

    public List<MUserProjectExperience> getUserProjectExperienceList() {
        return userProjectExperienceList;
    }

    public void setUserProjectExperienceList(List<MUserProjectExperience> userProjectExperienceList) {
        this.userProjectExperienceList = userProjectExperienceList;
    }
}
