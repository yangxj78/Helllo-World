package com.hengtiansoft.bean.tableModel;

import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MResume;
import com.hengtiansoft.common.converters.RegionMatcher;
import com.hengtiansoft.common.converters.TagMatcher;
import com.hengtiansoft.common.enumeration.ExpectSalaryEnum;
import com.hengtiansoft.common.enumeration.StatusEnum;
import com.hengtiansoft.common.enumeration.WorkTimeTypeEnum;
import com.hengtiansoft.common.enumeration.WorkYearsEnum;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Entity
public class Resume {
    @Id
    @GeneratedValue(generator = "JDBC")
    @ApiModelProperty(value = "简历id", notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id",notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "简历名称",notes = "必填")
    private String name;
    @ApiModelProperty(value = "工种",notes = "必填")
    private Integer workType;
    @ApiModelProperty(value = "工作年限",notes = "必填")
    private Integer workYears;
    @ApiModelProperty(value = "工作类型",notes = "0兼职；1 全职； 2 实习")
    private Integer workTimeType;
    @ApiModelProperty(value = "期望月薪",notes = "必填")
    private Integer expectedSalary;
    @ApiModelProperty(value = "地区id",notes = "必填")
    private Integer region;
    @ApiModelProperty(value = "自我介绍",notes = "")
    private String selfIntroduction;
    @ApiModelProperty(value = "简历来源",notes = "0 本地创建；1 BOSS直聘；2 智联招聘；3 高新人才网")
    private Integer source;
    @ApiModelProperty(value = "是否默认简历",notes = "0 否；1 是； 默认为0，创建编辑都不填")
    private Integer defaultFlag;
    @ApiModelProperty(value = "是否完善简历",notes = "0 否；1 是； 默认为0，创建编辑都不填")
    private Integer perfectFlag;
    @ApiModelProperty(value = "上传简历的存放路径",notes = "")
    private String ftpUrl;
    @Column(name = "create_ts")
    private String createTs;

    @Column(name = "update_ts")
    private String updateTs;

    private Integer status;

    public Resume(MResume mResume) {
        this.userId = mResume.getUserId();
        this.name = mResume.getName();
        this.workType =new TagMatcher().getTagId(mResume.getWorkType());
        this.workYears = WorkYearsEnum.verifyWorkYears(mResume.getWorkYears());
        this.workTimeType = WorkTimeTypeEnum.verifyWorkTimeType(mResume.getWorkTimeType());
        this.expectedSalary = ExpectSalaryEnum.verifyExpectSalary(mResume.getExpectedSalary());
        this.region =new RegionMatcher().getRegionId(mResume.getRegion());
        this.selfIntroduction = mResume.getSelfIntroduction();
        this.source = mResume.getSource();
        this.perfectFlag = StatusEnum.NO.getCode();
    }




    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id")
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Basic
    @Column(name = "work_type")
    public Integer getWorkType() {
        return workType;
    }

    public void setWorkType(Integer workType) {
        this.workType = workType;
    }

    @Basic
    @Column(name = "work_years")
    public Integer getWorkYears() {
        return workYears;
    }

    public void setWorkYears(Integer workYears) {
        this.workYears = workYears;
    }

    @Basic
    @Column(name = "work_time_type")
    public Integer getWorkTimeType() {
        return workTimeType;
    }

    public void setWorkTimeType(Integer workTimeType) {
        this.workTimeType = workTimeType;
    }

    @Basic
    @Column(name = "expected_salary")
    public Integer getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(Integer expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    @Basic
    @Column(name = "region")
    public Integer getRegion() {
        return region;
    }

    public void setRegion(Integer region) {
        this.region = region;
    }


    @Basic
    @Column(name = "self_introduction", length = 200)
    public String getSelfIntroduction() {
        return selfIntroduction;
    }

    public void setSelfIntroduction(String selfIntroduction) {
        this.selfIntroduction = selfIntroduction;
    }

    @Basic
    @Column(name = "source")
    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    @Basic
    @Column(name = "default_flag")
    public Integer getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(Integer defaultFlag) {
        this.defaultFlag = defaultFlag;
    }
    @Basic
    @Column(name = "perfect_flag")
    public Integer getPerfectFlag() {
        return perfectFlag;
    }

    public void setPerfectFlag(Integer perfectFlag) {
        this.perfectFlag = perfectFlag;
    }

    @Basic
    @Column(name = "ftp_url")
    public String getFtpUrl() {
        return ftpUrl;
    }

    public void setFtpUrl(String ftpUrl) {
        this.ftpUrl = ftpUrl;
    }

    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Resume(Integer userId) {
        this.userId = userId;
    }

    public Resume(Integer userId, Integer status) {
        this.userId = userId;
        this.status = status;
    }

    public Resume() {
    }


}