package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ResumeDeliveryPreInfoDto {

    private static final String MORNING = " 9:00-12:00";
    private static final String AFTERNOON = " 13:30-17:00";
    private static final String FULL_DAY = " 9:00-17:00";

    @ApiModelProperty(value = "岗位名称")
    private String positionRecordName;

    @ApiModelProperty(value = "公司名称")
    private String companyName;

    @ApiModelProperty(value = "展位号")
    private Integer boothId;

    @ApiModelProperty(value = "招聘会召开时间")
    private String conveningTime;

    public ResumeDeliveryPreInfoDto(){}

    public ResumeDeliveryPreInfoDto(ResumeDeliveryPreDataDto resumeDeliveryPreDataDto) {
        this.boothId = resumeDeliveryPreDataDto.getBoothId();
        this.companyName = resumeDeliveryPreDataDto.getCompanyName();
        this.positionRecordName = resumeDeliveryPreDataDto.getPositionRecordName();
        if (resumeDeliveryPreDataDto.getAppearances() == null) {
            this.conveningTime = resumeDeliveryPreDataDto.getDate() + FULL_DAY;
        }else if (resumeDeliveryPreDataDto.getAppearances() == 0) {
            this.conveningTime = resumeDeliveryPreDataDto.getDate() + MORNING;
        } else if (resumeDeliveryPreDataDto.getAppearances() == 1) {
            this.conveningTime = resumeDeliveryPreDataDto.getDate() + AFTERNOON;
        } else {
            this.conveningTime = resumeDeliveryPreDataDto.getDate() + FULL_DAY;
        }
    }

}
