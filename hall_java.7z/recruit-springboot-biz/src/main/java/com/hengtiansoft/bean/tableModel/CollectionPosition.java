package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;

@Entity
@Table(name = "collection_position")
public class CollectionPosition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "book_booth_position_record_id")
    private Integer bookBoothPositionRecordId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getBookBoothPositionRecordId() {
        return bookBoothPositionRecordId;
    }

    public void setBookBoothPositionRecordId(Integer bookBoothPositionRecordId) {
        this.bookBoothPositionRecordId = bookBoothPositionRecordId;
    }
}
