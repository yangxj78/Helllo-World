package com.hengtiansoft.bean.dataModel;

public class ZJRecordDto {
    String cardNumber;
    String openTime;
    boolean openResult;
    Integer enterOrExist; //1 进；2 出

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getOpenTime() {
        return openTime;
    }

    public void setOpenTime(String openTime) {
        this.openTime = openTime;
    }

    public boolean isOpenResult() {
        return openResult;
    }

    public void setOpenResult(boolean openResult) {
        this.openResult = openResult;
    }

    public Integer getEnterOrExist() {
        return enterOrExist;
    }

    public void setEnterOrExist(Integer enterOrExist) {
        this.enterOrExist = enterOrExist;
    }
}
