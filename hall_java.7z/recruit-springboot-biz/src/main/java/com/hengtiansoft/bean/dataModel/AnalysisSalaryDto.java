package com.hengtiansoft.bean.dataModel;

public class AnalysisSalaryDto {
    private Integer salary;
    private Integer number;

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }
}
