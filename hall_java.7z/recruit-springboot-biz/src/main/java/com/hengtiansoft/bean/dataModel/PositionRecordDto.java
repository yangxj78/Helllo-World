package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.*;

@Table(name = "position_record")
public class PositionRecordDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "岗位记录主键")
    private Integer id;

    @ApiModelProperty(value = "企业ID")
    private Integer companyID;
    @ApiModelProperty(value = "岗位记录的名称")
    private String name;

    @ApiModelProperty(value = "学历ID")
    private Integer educationID;
    @ApiModelProperty(value = "工作年限ID")
    private Integer workingYearsID;
    @ApiModelProperty(value = "薪资ID")
    private Integer salaryID;
    @ApiModelProperty(value = "岗位招聘人数")
    private Integer recruitNumber;
    @ApiModelProperty(value = "岗位描述")
    private String description;
    @ApiModelProperty(value = "招聘会ID")
    private Integer recruitmentID;
    @ApiModelProperty(value = "展位ID")
    private Integer boothID;
    @ApiModelProperty(value = "岗位排序序号")
    private Integer order;
    @ApiModelProperty(value = "创建人")
    private String createBy;
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    @ApiModelProperty(value = "岗位ID")
    private Integer positionID;


    @ApiModelProperty(value = "岗位性质 0全职 1兼职")
    private Integer property;

    @ApiModelProperty(value = "订展记录ID")
    private Integer bookBoothID;
    @ApiModelProperty(value = "岗位记录ID 用于申请审核岗位时使用 无表示新增岗位，有则是更新岗位")
    private Integer positionRecordID;
    private Integer tagID;
    private Integer sRegionID;

    private String oldName;

    private Integer selectOrder;





    public Integer getSelectOrder() {
        return selectOrder;
    }

    public void setSelectOrder(Integer selectOrder) {
        this.selectOrder = selectOrder;
    }

    public Integer getsRegionID() {
        return sRegionID;
    }

    public void setsRegionID(Integer sRegionID) {
        this.sRegionID = sRegionID;
    }

    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder(Integer order) {
        this.order = order;
    }

    public Integer getPositionRecordID() {
        return positionRecordID;
    }

    public void setPositionRecordID(Integer positionRecordID) {
        this.positionRecordID = positionRecordID;
    }


    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public Integer getBookBoothID() {
        return bookBoothID;
    }

    public void setBookBoothID(Integer bookBoothID) {
        this.bookBoothID = bookBoothID;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public Integer getPositionID() {
        return positionID;
    }

    public void setPositionID(Integer positionID) {
        this.positionID = positionID;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Integer getEducationID() {
        return educationID;
    }

    public void setEducationID(Integer educationID) {
        this.educationID = educationID;
    }

    public Integer getWorkingYearsID() {
        return workingYearsID;
    }

    public void setWorkingYearsID(Integer workingYearsID) {
        this.workingYearsID = workingYearsID;
    }

    public Integer getSalaryID() {
        return salaryID;
    }

    public void setSalaryID(Integer salaryID) {
        this.salaryID = salaryID;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }
}
