package com.hengtiansoft.bean.ipeopleModel;

public interface LogicDeleteable {
	
	boolean isSoftDelete();

	void markDeleted();
}
