package com.hengtiansoft.bean.dataModel.MultipleResumeDto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class MUserProjectExperience implements Serializable{

    private static final long serialVersionUID = -1607373787278433376L;

    @ApiModelProperty(value = "工作经历id", notes = "编辑必填")
    private Integer id;

    @ApiModelProperty(value = "用户id", notes = "必填")
    private Integer userId;

    @ApiModelProperty(value = "简历id", notes = "仅当简历创建时非必填")
    private Integer resumeId;

    @ApiModelProperty(value = "描述", notes = "")
    private String description;

    @ApiModelProperty(value = "公司", notes = "必填")
    private String company;

    @ApiModelProperty(value = "项目名称", notes = "必填")
    private String projectName;;

    @ApiModelProperty(value = "职责", notes = "必填")
    private String duty;

    @ApiModelProperty(value = "起始时间", notes = "必填")
    private String startTs;

    @ApiModelProperty(value = "结束时间", notes = "必填")
    private String endTs;

    @ApiModelProperty(value = "createTs", notes = "")
    private String createTs;

    @ApiModelProperty(value = "updateTs", notes = "")
    private String updateTs;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getDuty() {
        return duty;
    }

    public void setDuty(String duty) {
        this.duty = duty;
    }

    public String getStartTs() {
        return startTs;
    }

    public void setStartTs(String startTs) {
        this.startTs = startTs;
    }

    public String getEndTs() {
        return endTs;
    }

    public void setEndTs(String endTs) {
        this.endTs = endTs;
    }

    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public MUserProjectExperience(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public MUserProjectExperience() {
        super();
    }
}