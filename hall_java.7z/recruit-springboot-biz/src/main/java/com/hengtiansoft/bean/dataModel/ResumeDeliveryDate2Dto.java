package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ResumeDeliveryDate2Dto {
    private Integer recruitmentId;
    private Integer boothId;
    private String companyName;
    private String positionRecordName;
    @ApiModelProperty("面试结果")
    private Integer interviewResult;
    @ApiModelProperty("面试编号")
    private Integer orderNum;
    @ApiModelProperty("当前面试编号")
    private Integer currentOrderNum;
    @ApiModelProperty("招聘会状态")
    private Integer recruitmentStatus;
}
