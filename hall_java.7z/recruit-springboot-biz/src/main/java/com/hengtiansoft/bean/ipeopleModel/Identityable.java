package com.hengtiansoft.bean.ipeopleModel;

import java.io.Serializable;

public interface Identityable<ID extends Serializable> {
	ID getId();
}
