package com.hengtiansoft.bean.tableModel;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.persistence.Transient;
import java.io.Serializable;

@Table(name = "recruitment")
public class Recruitment implements Serializable {
    private static final long serialVersionUID = -3024165293053123134L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;

    @Column(name = "date")
    private String date;

    @ApiModelProperty("招聘会类型ID")
    private Integer typeId;


    @ApiModelProperty("招聘会地址")
    private String address;

    @Column(name = "is_appointment")
    @NotNull
    @ApiModelProperty("是否提供预约功能标志默认0")
    private Boolean isAppointment;

    @NotNull
    @ApiModelProperty("场次ID 0上午场 1下午场 2全天场")
    private Integer appearances;

    private String introduction;

    @Column(name = "recruit_number")
    @ApiModelProperty("招聘人数")
    private Integer recruitNumber;
    @ApiModelProperty("接待人数")
    private Integer receptionNumber;
    @ApiModelProperty("通过人数")
    private Integer passNumber;
    @ApiModelProperty("未通过人数")
    private Integer notPassNumber;

    @Column(name = "position_number")
    @ApiModelProperty("岗位数")
    private Integer positionNumber;

    @ApiModelProperty("0综合 1专场")
    private Integer style;
    @ApiModelProperty("招聘会状态 0正常 1失效")
    private Integer status;
    private String createBy;
    private String updateBy;
    private String updateTs;
    @ApiModelProperty("是否提供多面标志位默认0 不提供")
    @NotNull
    private Integer moreInterview;
    @Transient
    @ApiModelProperty("招聘会类型名称")
    private String typeName;

    @ApiModelProperty("设备标记为 0不使用 1使用")
    private Boolean device;
    private Integer companyNumber;
    @ApiModelProperty("待定人数")
    private Integer undeterminedNumber;
    @Column(name = "meals_number")
    @ApiModelProperty("每个展位的可选就餐人数")
    private Integer mealsNumber;
    @ApiModelProperty("是否开始标志位 0未开始 1进行中 2已结束")
    @Column(name = "start_type")
    private Integer startType;
    @Transient
    private boolean bookBooth;

    @Column(name = "age_18_25")
    private Integer age1825;
    @Column(name = "age_26_35")
    private Integer age2635;
    @Column(name = "age_36_50")
    private Integer age3650;
    @Column(name = "age_50")
    private Integer age50;
    @Column(name = "from_gx")
    private Integer fromGx;

    @Column(name = "position_num")
    private Integer positionNum;

    @Column(name = "people_num")
    private Integer peopleNum;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Boolean getAppointment() {
        return isAppointment;
    }

    public void setAppointment(Boolean appointment) {
        isAppointment = appointment;
    }

    public Integer getPositionNum() {
        return positionNum;
    }

    public void setPositionNum(Integer positionNum) {
        this.positionNum = positionNum;
    }

    public Integer getPeopleNum() {
        return peopleNum;
    }

    public void setPeopleNum(Integer peopleNum) {
        this.peopleNum = peopleNum;
    }

    public Integer getFromGx() {
        return fromGx;
    }

    public void setFromGx(Integer fromGx) {
        this.fromGx = fromGx;
    }

    public Integer getAge1825() {
        return age1825;
    }

    public void setAge1825(Integer age1825) {
        this.age1825 = age1825;
    }

    public Integer getAge2635() {
        return age2635;
    }

    public void setAge2635(Integer age2635) {
        this.age2635 = age2635;
    }

    public Integer getAge3650() {
        return age3650;
    }

    public void setAge3650(Integer age3650) {
        this.age3650 = age3650;
    }

    public Integer getAge50() {
        return age50;
    }

    public void setAge50(Integer age50) {
        this.age50 = age50;
    }

    public Integer getStartType() {
        return startType;
    }

    public void setStartType(Integer startType) {
        this.startType = startType;
    }

    public boolean isBookBooth() {
        return bookBooth;
    }

    public void setBookBooth(boolean bookBooth) {
        this.bookBooth = bookBooth;
    }

    public Integer getMealsNumber() {
        return mealsNumber;
    }

    public void setMealsNumber(Integer mealsNumber) {
        this.mealsNumber = mealsNumber;
    }


    public Integer getUndeterminedNumber() {
        return undeterminedNumber;
    }

    public void setUndeterminedNumber(Integer undeterminedNumber) {
        this.undeterminedNumber = undeterminedNumber;
    }

    public String getTypeName() {
        return typeName;
    }

    public Integer getCompanyNumber() {
        return companyNumber;
    }

    public void setCompanyNumber(Integer companyNumber) {
        this.companyNumber = companyNumber;
    }

    public Integer getStyle() {
        return style;
    }

    public void setStyle(Integer style) {
        this.style = style;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Boolean getIsAppointment() {
        return isAppointment;
    }

    public void setIsAppointment(Boolean isAppointment) {
        this.isAppointment = isAppointment;
    }

    public Integer getAppearances() {
        return appearances;
    }

    public void setAppearances(Integer appearances) {
        this.appearances = appearances;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public Integer getReceptionNumber() {
        return receptionNumber;
    }

    public void setReceptionNumber(Integer receptionNumber) {
        this.receptionNumber = receptionNumber;
    }

    public Integer getPassNumber() {
        return passNumber;
    }

    public void setPassNumber(Integer passNumber) {
        this.passNumber = passNumber;
    }

    public Integer getNotPassNumber() {
        return notPassNumber;
    }

    public void setNotPassNumber(Integer notPassNumber) {
        this.notPassNumber = notPassNumber;
    }

    public Integer getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Integer positionNumber) {
        this.positionNumber = positionNumber;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public Integer getMoreInterview() {
        return moreInterview;
    }

    public void setMoreInterview(Integer moreInterview) {
        this.moreInterview = moreInterview;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Boolean getDevice() {
        return device;
    }

    public void setDevice(Boolean device) {
        this.device = device;
    }

    @Override
    public String toString() {
        return "Recruitment{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", typeId=" + typeId +
                ", address='" + address + '\'' +
                ", isAppointment=" + isAppointment +
                ", appearances=" + appearances +
                ", introduction='" + introduction + '\'' +
                ", recruitNumber=" + recruitNumber +
                ", receptionNumber=" + receptionNumber +
                ", passNumber=" + passNumber +
                ", notPassNumber=" + notPassNumber +
                ", positionNumber=" + positionNumber +
                ", style=" + style +
                ", status=" + status +
                ", createBy='" + createBy + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", updateTs='" + updateTs + '\'' +
                ", moreInterview=" + moreInterview +
                ", typeName='" + typeName + '\'' +
                ", device=" + device +
                ", companyNumber=" + companyNumber +
                ", undeterminedNumber=" + undeterminedNumber +
                ", mealsNumber=" + mealsNumber +
                ", startType=" + startType +
                ", bookBooth=" + bookBooth +
                ", age1825=" + age1825 +
                ", age2635=" + age2635 +
                ", age3650=" + age3650 +
                ", age50=" + age50 +
                '}';
    }
}