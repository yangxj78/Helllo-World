package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class PositionRecordSearch extends PageDto {


    @ApiModelProperty(value = "招聘会ID")
    private Integer recruitmentID;

    @ApiModelProperty(value = "企业ID")
    private Integer companyID;
    @ApiModelProperty(value = "岗位关键字")
    private String nameSearch;
    @ApiModelProperty(value = "展位ID")
    private Integer boothID;
    @ApiModelProperty(value = "学历ID")
    private Integer educationID;

    @ApiModelProperty(value = "工作年限ID")
    private Integer workingYears;

    @ApiModelProperty(value = "0全职 1兼职")
    private String property;
    private Integer tagID;
    private Integer salary;

    private String name;

    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String search;

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }


    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getEducationID() {
        return educationID;
    }

    public void setEducationID(Integer educationID) {
        this.educationID = educationID;
    }

    public Integer getWorkingYears() {
        return workingYears;
    }

    public void setWorkingYears(Integer workingYears) {
        this.workingYears = workingYears;
    }

    public String getNameSearch() {
        return nameSearch;
    }

    public void setNameSearch(String nameSearch) {
        this.nameSearch = nameSearch;
    }
}
