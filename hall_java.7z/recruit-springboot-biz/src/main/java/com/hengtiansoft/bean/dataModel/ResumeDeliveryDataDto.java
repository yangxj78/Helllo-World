package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class ResumeDeliveryDataDto {
    private Integer id;
    private String userName;
    private String phone;
    private String idNumber;
    private Integer education;
    private String positionName;
    private String companyName;
    @ApiModelProperty("简历名字")
    private String resumeName;
    @ApiModelProperty("简历来源")
    private String resumeSource;
    @ApiModelProperty("简历评价")
    private String resumeSuggestion;
    @ApiModelProperty("面试结果")
    private Integer interviewResult;
    private String recruitmentName;
    private String recruitmentDate;
private int boothId;
private int positionRecordId;
private int resumeId;
private int userId;


    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getBoothId() {
        return boothId;
    }

    public void setBoothId(int boothId) {
        this.boothId = boothId;
    }

    public int getPositionRecordId() {
        return positionRecordId;
    }

    public void setPositionRecordId(int positionRecordId) {
        this.positionRecordId = positionRecordId;
    }

    public int getResumeId() {
        return resumeId;
    }

    public void setResumeId(int resumeId) {
        this.resumeId = resumeId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Integer getEducation() {
        return education;
    }

    public void setEducation(Integer education) {
        this.education = education;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getResumeName() {
        return resumeName;
    }

    public void setResumeName(String resumeName) {
        this.resumeName = resumeName;
    }

    public String getResumeSource() {
        return resumeSource;
    }

    public void setResumeSource(String resumeSource) {
        this.resumeSource = resumeSource;
    }

    public String getResumeSuggestion() {
        return resumeSuggestion;
    }

    public void setResumeSuggestion(String resumeSuggestion) {
        this.resumeSuggestion = resumeSuggestion;
    }

    public Integer getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(Integer interviewResult) {
        this.interviewResult = interviewResult;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }

    public String getRecruitmentDate() {
        return recruitmentDate;
    }

    public void setRecruitmentDate(String recruitmentDate) {
        this.recruitmentDate = recruitmentDate;
    }
}
