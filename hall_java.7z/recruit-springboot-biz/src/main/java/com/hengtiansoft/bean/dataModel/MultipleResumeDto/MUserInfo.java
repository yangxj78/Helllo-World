package com.hengtiansoft.bean.dataModel.MultipleResumeDto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class MUserInfo implements Serializable{

    private static final long serialVersionUID = -3393730261629327661L;

    @ApiModelProperty(value = "基本信息id",notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id",notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "姓名",notes = "必填")
    private String name;
    @ApiModelProperty(value = "电话",notes = "必填")
    private String phone;
    @ApiModelProperty(value = "邮箱",notes = "必填")
    private String email;
    @ApiModelProperty(value = "身份证",notes = "必填")
    private String identityCard;
    @ApiModelProperty(value = "性别",notes = "必填")
    private String sex;
    @ApiModelProperty(value = "民族",notes = "暂时不需要")
    private String nation;
    @ApiModelProperty(value = "求职者类型",notes = "0 应届高校毕业生；1 在职； 2 离职")
    private String type;
    @ApiModelProperty(value = "出生日期",notes = "必填")
    private String birthDate;
    @ApiModelProperty(value = "文化程度",notes = "必填")
    private String educational;
    @ApiModelProperty(value = "居住地",notes = "必填")
    private String address;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentityCard() {
        return identityCard;
    }

    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public MUserInfo(Integer userId) {
        this.userId = userId;
    }

    public MUserInfo() {
        super();
    }
}
