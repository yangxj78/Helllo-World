package com.hengtiansoft.bean.tableModel;

import java.util.List;

import com.hengtiansoft.bean.dataModel.PositionRecordIDAndName;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Transient;

import java.util.Date;

@Table(name = "company")
public class Company {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "公司主键ID")
    private Integer id;

    @ApiModelProperty(value = "企业名字")
    private String name;

    @ApiModelProperty(value = "企业类型ID")
    @Column(name = "type_id")
    private Integer typeID;

    @ApiModelProperty(value = "企业地址")
    private String address;

    @ApiModelProperty(value = "公司联系人号码")
    @Column(name = "contact_number")
    private String contactNumber;

    @ApiModelProperty(value = "公司客户经理ID")
    @Column(name = "customer_manager_id")
    private Integer customerManagerID;


    @Column(name = "contact_name")
    private String contactName;

    @ApiModelProperty(value = "企业状态（默认0） 0正常 1失效 默认0")
    private Integer status;

    @Column(name = "trade_id")
    private Integer tradeID;
    @Column(name = "video_id")
    @ApiModelProperty(value = "公司宣传视频ID")
    private String videoID;
    @Column(name = "logo_id")
    @ApiModelProperty(value = "公司logoID")
    private String logoID;
    @ApiModelProperty(value = "参展联系人")
    private String exhibitor;

    @ApiModelProperty(value = "参展联系人号码")
    private String exhibitorNumber;

    @ApiModelProperty(value = "公司描述")
    private String description;

    @ApiModelProperty(value = "公司客户经理姓名")
    @Transient
    private String customerManagerName;
    private String email;
    @Transient
    @ApiModelProperty(value = "非数据库字段，某场招聘会职位数")
    private Integer positionNumber;

    @Transient
    @ApiModelProperty(value = "非数据库字段，某场招聘会招聘数")
    private Integer recruitNumber;



    @Transient
    @ApiModelProperty(value = "签到标志位 0未签到 1已签到")
    private Integer sign;

    @Transient
    @ApiModelProperty(value = "签到时间")
    private String signTime;


    @Transient
    @ApiModelProperty(value = "验证码")
    private String captcha;
    @Transient
    private Integer boothID;

    @Transient
    private List<PositionRecordIDAndName> positionRecordIDAndNames;

    @ApiModelProperty(value = "公司创建人")
    private String createBy;

    @ApiModelProperty(value = "公司更新人")
    private String updateBy;

    @ApiModelProperty(value = "创建时间")
    private Date createTs;

    @ApiModelProperty(value = "更新时间")
    private Date updateTs;


    @Transient
    private List<String> pictures;


    @Transient
    private String typeName;

    public Integer getSign() {
        return sign;
    }

    public void setSign(Integer sign) {
        this.sign = sign;
    }

    public String getSignTime() {
        return signTime;
    }

    public void setSignTime(String signTime) {
        this.signTime = signTime;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public String getLogoID() {
        return logoID;
    }

    public void setLogoID(String logoID) {
        this.logoID = logoID;
    }

    public Integer getTradeID() {
        return tradeID;
    }

    public void setTradeID(Integer tradeID) {
        this.tradeID = tradeID;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public List<PositionRecordIDAndName> getPositionRecordIDAndNames() {
        return positionRecordIDAndNames;
    }

    public void setPositionRecordIDAndNames(List<PositionRecordIDAndName> positionRecordIDAndNames) {
        this.positionRecordIDAndNames = positionRecordIDAndNames;
    }

    public List<String> getPictures() {
        return pictures;
    }

    public void setPictures(List<String> pictures) {
        this.pictures = pictures;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Integer positionNumber) {
        this.positionNumber = positionNumber;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Date getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getCustomerManagerName() {
        return customerManagerName;
    }

    public void setCustomerManagerName(String customerManagerName) {
        this.customerManagerName = customerManagerName;
    }


    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }


    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getTypeID() {
        return typeID;
    }

    public void setTypeID(Integer typeID) {
        this.typeID = typeID;
    }

    /**
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address
     */
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    /**
     * @return contact_number
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     * @param contactNumber
     */
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber == null ? null : contactNumber.trim();
    }

    public Integer getCustomerManagerID() {
        return customerManagerID;
    }

    public void setCustomerManagerID(Integer customerManagerID) {
        this.customerManagerID = customerManagerID;
    }

    /**
     * @return contact_name
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * @param contactName
     */
    public void setContactName(String contactName) {
        this.contactName = contactName == null ? null : contactName.trim();
    }

    public String getVideoID() {
        return videoID;
    }

    public void setVideoID(String videoID) {
        this.videoID = videoID;
    }

    public String getExhibitor() {
        return exhibitor;
    }

    public void setExhibitor(String exhibitor) {
        this.exhibitor = exhibitor;
    }

    public String getExhibitorNumber() {
        return exhibitorNumber;
    }

    public void setExhibitorNumber(String exhibitorNumber) {
        this.exhibitorNumber = exhibitorNumber;
    }
}