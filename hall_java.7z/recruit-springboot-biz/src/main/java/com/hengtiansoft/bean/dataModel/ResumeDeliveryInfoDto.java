package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ResumeDeliveryInfoDto {
    private String companyName;
    private Integer boothId;
    private String positionRecordName;
    @ApiModelProperty("面试结果")
    private Integer interviewResult;
    @ApiModelProperty("面试编号")
    private Integer orderNum;
    @ApiModelProperty("当前面试编号")
    private Integer currentOrderNum;
    @ApiModelProperty("招聘会状态")
    private Integer recruitmentStatus;

    public ResumeDeliveryInfoDto(ResumeDeliveryDate2Dto dto) {
        this.boothId = dto.getBoothId();
        this.companyName = dto.getCompanyName();
        this.positionRecordName = dto.getPositionRecordName();
        this.interviewResult = dto.getInterviewResult();
        this.orderNum = dto.getOrderNum();
        this.recruitmentStatus = dto.getRecruitmentStatus();
    }
}
