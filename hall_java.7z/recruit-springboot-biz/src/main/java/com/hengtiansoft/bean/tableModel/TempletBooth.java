package com.hengtiansoft.bean.tableModel;

import java.util.List;

import io.swagger.models.auth.In;

import javax.persistence.*;

@Table(name = "templet_booth")
public class TempletBooth {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "booth_id")
    private Integer boothId;

    @Column(name = "templet_id")
    private Integer templetId;

    @Column(name = "recruitment_id")
    private Integer recruitmentId;
    @Transient
    private List<Integer> booths;
    private String comments;
    @Column(name = "operation")
    private Integer operation;

    public Integer getOperation() {
        return operation;
    }

    public void setOperation(Integer operation) {
        this.operation = operation;
    }

    public String getComments() {

        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<Integer> getBooths() {
        return booths;
    }

    public void setBooths(List<Integer> booths) {
        this.booths = booths;
    }

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return booth_id
     */
    public Integer getBoothId() {
        return boothId;
    }

    /**
     * @param boothId
     */
    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    /**
     * @return templet_id
     */
    public Integer getTempletId() {
        return templetId;
    }

    /**
     * @param templetId
     */
    public void setTempletId(Integer templetId) {
        this.templetId = templetId;
    }

    /**
     * @return recruitment_id
     */
    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    /**
     * @param recruitmentId
     */
    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }
}