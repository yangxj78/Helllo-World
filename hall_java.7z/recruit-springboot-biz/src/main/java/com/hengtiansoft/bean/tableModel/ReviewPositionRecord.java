package com.hengtiansoft.bean.tableModel;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Transient;

@Table(name = "review_position_record")
public class ReviewPositionRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "position_record_id")
    private Integer positionRecordID;

    @Column(name = "recruitment_id")
    private Integer recruitmentID;

    @Column(name = "company_id")
    private Integer companyID;

    @Column(name = "booth_id")
    private Integer boothID;

    @Column(name = "book_booth_id")
    private Integer bookBoothID;

    private String name;

    @Column(name = "working_years_id")
    private Integer workingYearsID;

    @Column(name = "education_id")
    private Integer educationID;

    @Column(name = "s_region_id")
    private Integer sRegionID;

    @Column(name = "salary_id")
    private Integer salaryID;

    @Column(name = "recruit_number")
    private Integer recruitNumber;

    private String description;

    @Column(name = "create_ts")
    private Date createTs;

    @Column(name = "status")
    private Integer status;
    @Column(name = "tag_id")
    private Integer tagID;

    private String suggestion;

    @Transient
    private String recruitmentDate;


    private Integer property;
    @Column(name = "old_name")
    private String oldName;

    public String getRecruitmentDate() {
        return recruitmentDate;
    }

    public void setRecruitmentDate(String recruitmentDate) {
        this.recruitmentDate = recruitmentDate;
    }

    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }


    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }

    @Transient
    private String recruitmnetName;
    @Transient
    private Integer appearances;

    @Transient
    private String companyName;

    public String getRecruitmnetName() {
        return recruitmnetName;
    }

    public void setRecruitmnetName(String recruitmnetName) {
        this.recruitmnetName = recruitmnetName;
    }

    public Integer getAppearances() {
        return appearances;
    }

    public void setAppearances(Integer appearances) {
        this.appearances = appearances;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getId() {

        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPositionRecordID() {
        return positionRecordID;
    }

    public void setPositionRecordID(Integer positionRecordID) {
        this.positionRecordID = positionRecordID;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getBookBoothID() {
        return bookBoothID;
    }

    public void setBookBoothID(Integer bookBoothID) {
        this.bookBoothID = bookBoothID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getWorkingYearsID() {
        return workingYearsID;
    }

    public void setWorkingYearsID(Integer workingYearsID) {
        this.workingYearsID = workingYearsID;
    }

    public Integer getEducationID() {
        return educationID;
    }

    public void setEducationID(Integer educationID) {
        this.educationID = educationID;
    }

    public Integer getsRegionID() {
        return sRegionID;
    }

    public void setsRegionID(Integer sRegionID) {
        this.sRegionID = sRegionID;
    }

    public Integer getSalaryID() {
        return salaryID;
    }

    public void setSalaryID(Integer salaryID) {
        this.salaryID = salaryID;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}