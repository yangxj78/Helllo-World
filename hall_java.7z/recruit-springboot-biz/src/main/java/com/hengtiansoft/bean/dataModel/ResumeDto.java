package com.hengtiansoft.bean.dataModel;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.converters.RegionMatcher;
import com.hengtiansoft.common.converters.TagMatcher;
import com.hengtiansoft.common.enumeration.*;

import java.io.Serializable;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hengtiansoft.common.constant.MagicNumConstant;
import org.apache.commons.lang3.StringUtils;

public class ResumeDto implements Serializable {

    private static final long serialVersionUID = 433917657608190731L;
    UserInfo userInfo;

    Resume resume;

    public ResumeDto(){};

    public ResumeDto(HrResume hrResume) {
        analyzeHrResume(hrResume);
    }

    List<UserWorkExperience> userWorkExperienceList;

    List<UserProjectExperience> userProjectExperienceList;

    List<UserEducationExperience> userEducationExperienceList;

    public UserInfo getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserInfo userInfo) {
        this.userInfo = userInfo;
    }

    public Resume getResume() {
        return resume;
    }

    public void setResume(Resume resume) {
        this.resume = resume;
    }

    public List<UserWorkExperience> getUserWorkExperienceList() {
        return userWorkExperienceList;
    }

    public void setUserWorkExperienceList(List<UserWorkExperience> userWorkExperienceList) {
        this.userWorkExperienceList = userWorkExperienceList;
    }

    public List<UserEducationExperience> getUserEducationExperienceList() {
        return userEducationExperienceList;
    }

    public void setUserEducationExperienceList(List<UserEducationExperience> userEducationExperienceList) {
        this.userEducationExperienceList = userEducationExperienceList;
    }

    public List<UserProjectExperience> getUserProjectExperienceList() {
        return userProjectExperienceList;
    }

    public void setUserProjectExperienceList(List<UserProjectExperience> userProjectExperienceList) {
        this.userProjectExperienceList = userProjectExperienceList;
    }

    public String reserveNumber(String str) {
        String regex = "^[0-9]*";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            return matcher.group();
        }
        return "";
    }

    public String analyzeBirthDate(String str) {
        String pattern = "(\\d{18})|a(\\d{17}(\\d|X|x))";

        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(str);
        if (m.find()) {
            return m.group().substring(MagicNumConstant.SIX, MagicNumConstant.TEN) + "-" + m.group().substring(MagicNumConstant.TEN, MagicNumConstant.TWELVE)
                    + "-" + m.group().substring(MagicNumConstant.TWELVE, MagicNumConstant.FOURTEEN);
        }
        return null;
    }

    public void analyzeHrResume(HrResume hrResume){
        Resume newResume = new Resume();
        UserInfo newUserInfo = new UserInfo();
        this.userWorkExperienceList = hrResume.getUserWorkExperienceList();
        this.userEducationExperienceList = hrResume.getUserEducationExperienceList();
        this.userProjectExperienceList = hrResume.getProjectExperienceList();

        newResume.setWorkTimeType(StringUtils.isNotEmpty(hrResume.getStaffType()) ? WorkTimeTypeEnum.verifyWorkTimeType(hrResume.getStaffType()) : WorkTimeTypeEnum.FULL_TIME_EMPLOYEE.getCode());
        newResume.setWorkYears(StringUtils.isNotEmpty(hrResume.getYears()) ? WorkYearsEnum.verifyWorkYears(this.reserveNumber(hrResume.getYears())) : WorkYearsEnum.LESS_THAN_TWO_YEAR.getCode());
        if (StringUtils.isNotEmpty(hrResume.getPost())) {
            newResume.setWorkType(new TagMatcher().getTagId(hrResume.getPost()));
        } else {
            newResume.setWorkType(new TagMatcher().getTagId(hrResume.getContent()));

        }
        Integer expectedSalary = ExpectSalaryEnum.verifyExpectSalary(hrResume.getExpectSalary());
        newResume.setExpectedSalary(expectedSalary);
        newResume.setRegion(new RegionMatcher().getRegionId(hrResume.getExpectCity()));
        newResume.setFtpUrl(hrResume.getWordUrl());
        newResume.setSource(SourceEnum.LOCALIMPORT.getCode());
        newResume.setSelfIntroduction(hrResume.getSelfIntroduction());

        newUserInfo.setAddress(hrResume.getCity());
        newUserInfo.setName(hrResume.getName());
        newUserInfo.setPhone(hrResume.getPhone());
        newUserInfo.setEmail(hrResume.getEmail());
        newUserInfo.setIdentityCard(StringUtils.isNotEmpty(hrResume.getIdentity()) ? hrResume.getIdentity() : "");
        if (hrResume.getSex() != null) {
            if (hrResume.getSex().getDesc().equals("男")) {
                newUserInfo.setSex(0);
            } else {
                newUserInfo.setSex(1);
            }
        }
        newUserInfo.setEducational(EducationalLevelEnum.verifyEducationLevel(hrResume.getEducation()));
        String birthDate = StringUtils.isNotEmpty(hrResume.getIdentity()) ? this.analyzeBirthDate(hrResume.getIdentity()) : hrResume.getBirthDate();

        if (birthDate != null){
            newUserInfo.setBirthDate(birthDate);
        } else {
            Calendar a= Calendar.getInstance();
            birthDate = (a.get(Calendar.YEAR) - hrResume.getAge()) + "-01-01";
            newUserInfo.setBirthDate(birthDate);
        }

        this.resume = newResume;
        this.userInfo = newUserInfo;
    }
}
