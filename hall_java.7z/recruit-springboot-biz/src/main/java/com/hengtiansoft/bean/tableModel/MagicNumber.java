package com.hengtiansoft.bean.tableModel;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "magic_number")
public class MagicNumber {
    @Id
    private int type;
    private int value;
    private int version;
    private String note;

    @Basic
    @Column(name = "type")
    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Basic
    @Column(name = "value")
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Basic
    @Column(name = "version")
    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    @Basic
    @Column(name = "note")
    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MagicNumber that = (MagicNumber) o;
        return type == that.type &&
                value == that.value &&
                version == that.version &&
                Objects.equals(note, that.note);
    }

    @Override
    public int hashCode() {

        return Objects.hash(type, value, version, note);
    }
}
