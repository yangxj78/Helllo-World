package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class RecruitmentSearch extends PageDto implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "企业名称")
    private String companyName;
    @ApiModelProperty(value = "招聘会名称（精准匹配）")
    private String recruitmentName;
    @ApiModelProperty(value = "岗位名称")
    private String positionName;
    @ApiModelProperty(value = "企业ID")
    private Integer companyID;
    @ApiModelProperty(value = "招聘会关键字（模糊匹配）")
    private String search;
    @ApiModelProperty(value = "起始日期")
    private String startDate;
    @ApiModelProperty(value = "截止日期")
    private String endDate;
    @ApiModelProperty(value = "招聘会类型ID")
    private Integer type;//招聘会类型
    @ApiModelProperty(value = "过期标记位 0不区分 1未过期")
    private Integer overDue;
    @ApiModelProperty(value = "招聘会状态 0正常 1已失效")
    private Integer status;

    @ApiModelProperty(value = "分页标记为 0分页 1不分页")
    private Integer isPage;
    private Boolean device;
    private Integer salary;
    private Integer boothID;
    private Integer recruitmentID;
    private Integer tagID;
    private Integer startType;


    public Integer getSalary() {
        return salary;
    }

    public void setSalary(Integer salary) {
        this.salary = salary;
    }

    public Integer getStartType() {
        return startType;
    }

    public void setStartType(Integer startType) {
        this.startType = startType;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public Boolean getDevice() {
        return device;
    }

    public void setDevice(Boolean device) {
        this.device = device;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    private Integer appearances;

    public Integer getAppearances() {
        return appearances;
    }

    public void setAppearances(Integer appearances) {
        this.appearances = appearances;
    }

    public Integer getIsPage() {
        return isPage;
    }

    public void setIsPage(Integer isPage) {
        this.isPage = isPage;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getOverDue() {
        return overDue;
    }

    public void setOverDue(Integer overDue) {
        this.overDue = overDue;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }


}
