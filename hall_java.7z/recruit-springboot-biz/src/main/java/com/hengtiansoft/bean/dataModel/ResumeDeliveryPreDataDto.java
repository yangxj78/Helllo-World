package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ResumeDeliveryPreDataDto {

    @ApiModelProperty(value = "招聘会名称")
    private String recruitmentName;

    @ApiModelProperty(value = "企业名称")
    private String companyName;

    @ApiModelProperty(value = "职位名称")
    private String positionRecordName;

    @ApiModelProperty(value = "展位id")
    private Integer boothId;

    @ApiModelProperty(value = "招聘会日期")
    private String date;

    @ApiModelProperty(value = "招聘会场次")
    private Integer appearances;

}
