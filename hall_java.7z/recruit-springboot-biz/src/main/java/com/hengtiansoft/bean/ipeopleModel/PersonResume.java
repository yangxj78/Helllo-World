package com.hengtiansoft.bean.ipeopleModel;

import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.util.Date;

import static com.hengtiansoft.bean.ipeopleModel.AbstractBaseEntity.MIN_LENGTH_USERNAME;

@Entity
@Table(name = "hr_person_resume")
@Data
@EqualsAndHashCode(callSuper = false)
public class PersonResume {

    /**
     * Variables Name: serialVersionUID Description: TODO Value Description: TODO
     */
    private static final long serialVersionUID = 4690511007378276787L;


    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;
    @Column(name = "uuid")
    @Getter
    @Setter
    private String uuid;
    @Getter
    @Setter
    private String code;
    @NotEmpty
    @Length(min = MIN_LENGTH_USERNAME)
    @Getter
    @Setter
    private String name;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_created")
    @Getter
    @Setter
    private Date dateCreated;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_modified")
    @Getter
    @Setter
    private Date dateModified;


    @Enumerated(EnumType.STRING)
    private SexEnum sex;
    @Column(name = "age")
    private int age;
    @Column(name = "phone")
    private String phone;
    @Column(name = "email")
    private String email;
    @Column(name = "city")
    private String city;
    @Column(name = "degree")
    private String degree;

    @Enumerated(EnumType.STRING)
    @Column(name = "source")
    private ResumeSourceEnum source;

    @Column(name = "post")
    private String post;

    @Column(name = "years")
    private String years;

    @Column(name = "work_expirence", columnDefinition = "text", nullable = true)
    private String workExpirence;

    @Column(name = "project_experience", columnDefinition = "text", nullable = true)
    private String projectExperience;

    @Column(name = "expectCity")
    private String expectCity;

    @Column(name = "identity")
    private String identity;

    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "content", columnDefinition = "text", nullable = true)
    private String content;

    @Column(name = "school")
    private String school;

    @Column(name = "graduate_date")
    private String graduateDate;

    @Column(name = "major")
    private String major;

    @Column(name = "education", columnDefinition = "text", nullable = true)
    private String education;

    @Column(name = "expect_salary")
    private String expectSalary;

    @Column(name = "annual_income")
    private String annualIncome;

    @Column(name = "english_level")
    private String engLevel;

    @Column(name = "staff_type")
    private String staffType;

    @ManyToOne
    @JoinColumn(name = "jobhunter_id")
    private Jobhunter jobhunter;

    public PersonResume() {

    }

    public PersonResume(HrResume r) {
        setName(r.getName());
        setSex(r.getSex());
        setAge(r.getAge());
        setPhone(r.getPhone());
        setEmail(r.getEmail());
        setCity(r.getCity());
        setDegree(r.getDegree());
        setSource(r.getSource());
        setPost(r.getPost());
        setYears(r.getYears());
        setWorkExpirence(r.getWorkExpirence());
        setProjectExperience(r.getProjectExperience());
        setExpectCity(r.getExpectCity());
        setIdentity(r.getIdentity());
        setContent(r.getContent());
        setSchool(r.getSchool());
        setGraduateDate(r.getGraduateDate());
        setMajor(r.getMajor());
        setEducation(r.getEducation());
        setExpectSalary(r.getExpectSalary());
        setAnnualIncome(r.getAnnualIncome());
        setEngLevel(r.getEngLevel());
        setStaffType(r.getStaffType());

    }

    public void update(PersonResume r) {
        setName(r.getName());
        setSex(r.getSex());
        setAge(r.getAge());
        setPhone(r.getPhone());
        setEmail(r.getEmail());
        setCity(r.getCity());
        setDegree(r.getDegree());
        setSource(r.getSource());
        setPost(r.getPost());
        setYears(r.getYears());
        setWorkExpirence(r.getWorkExpirence());
        setProjectExperience(r.getProjectExperience());
        setExpectCity(r.getExpectCity());
        setIdentity(r.getIdentity());
        setContent(r.getContent());
        setSchool(r.getSchool());
        setGraduateDate(r.getGraduateDate());
        setMajor(r.getMajor());
        setEducation(r.getEducation());
        setExpectSalary(r.getExpectSalary());
        setAnnualIncome(r.getAnnualIncome());
        setEngLevel(r.getEngLevel());
        setStaffType(r.getStaffType());

    }

}
