package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class JobSeekerDto {

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "出生年月")
    private String birthday;

    @ApiModelProperty(value = "学历Id")
    private Integer educationId;

    @ApiModelProperty(value = "学历名称")
    private String educationName;

    @ApiModelProperty(value = "性别")
    private Integer sex;

    @ApiModelProperty(value = "工作地点ID")
    private Integer workingRegionId;

    @ApiModelProperty(value = "工作地点名称")
    private String workingRegionName;

    @ApiModelProperty(value = "期望行业")
    private String workTypeName;

    private Integer workYearsId;

    @ApiModelProperty(value = "工作年限")
    private String workYears;

    @ApiModelProperty(value = "简历Id")
    private Integer resumeId;

    @ApiModelProperty(value = "是否已邀约")
    private String inviteStatus;

    //判断是否邀约使用
    private Integer isInvited;

    private Integer userId;

    private Date createTs;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public Integer getEducationId() {
        return educationId;
    }

    public void setEducationId(Integer educationId) {
        this.educationId = educationId;
    }

    public String getEducationName() {
        return educationName;
    }

    public void setEducationName(String educationName) {
        this.educationName = educationName;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getWorkingRegionId() {
        return workingRegionId;
    }

    public void setWorkingRegionId(Integer workingRegionId) {
        this.workingRegionId = workingRegionId;
    }

    public String getWorkingRegionName() {
        return workingRegionName;
    }

    public void setWorkingRegionName(String workingRegionName) {
        this.workingRegionName = workingRegionName;
    }

    public String getWorkTypeName() {
        return workTypeName;
    }

    public void setWorkTypeName(String workTypeName) {
        this.workTypeName = workTypeName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Integer getWorkYearsId() {
        return workYearsId;
    }

    public void setWorkYearsId(Integer workYearsId) {
        this.workYearsId = workYearsId;
    }

    public String getWorkYears() {
        return workYears;
    }

    public void setWorkYears(String workYears) {
        this.workYears = workYears;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public String getInviteStatus() {
        return inviteStatus;
    }

    public void setInviteStatus(String inviteStatus) {
        this.inviteStatus = inviteStatus;
    }

    public Integer getIsInvited() {
        return isInvited;
    }

    public void setIsInvited(Integer isInvited) {
        this.isInvited = isInvited;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof JobSeekerDto)) return false;
        JobSeekerDto j = (JobSeekerDto) obj;
        if (this.userId.longValue() == j.userId.longValue())
            return true;
        return false;
    }


}
