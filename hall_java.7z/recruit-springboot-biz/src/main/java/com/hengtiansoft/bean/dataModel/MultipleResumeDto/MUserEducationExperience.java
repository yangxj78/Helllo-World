package com.hengtiansoft.bean.dataModel.MultipleResumeDto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class MUserEducationExperience implements Serializable{

    private static final long serialVersionUID = -170811785110125936L;

    @ApiModelProperty(value = "教育经历id", notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id", notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "简历id", notes = "仅当简历创建时非必填")
    private Integer resumeId;
    @ApiModelProperty(value = "学历", notes = "必填")
    private String educational;
    @ApiModelProperty(value = "是否浙江户籍学生", notes = "0 不是；1 是 必填")
    private String localZj;
    @ApiModelProperty(value = "学校", notes = "必填")
    private String school;
    @ApiModelProperty(value = "专业", notes = "必填")
    private String major;
    @ApiModelProperty(value = "入学时间", notes = "必填")
    private String startTs;
    @ApiModelProperty(value = "毕业时间", notes = "必填")
    private String endTs;
    private String createTs;
    private String updateTs;

    public MUserEducationExperience(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public MUserEducationExperience() {
        super();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational;
    }

    public String getStartTs() {
        return startTs;
    }

    public void setStartTs(String startTs) {
        this.startTs = startTs;
    }

    public String getLocalZj() {
        return localZj;
    }

    public void setLocalZj(String localZj) {
        this.localZj = localZj;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getEndTs() {
        return endTs;
    }

    public void setEndTs(String endTs) {
        this.endTs = endTs;
    }

    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }


}