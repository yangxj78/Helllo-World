package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class PositionRecordSaveDto {

    @ApiModelProperty(value = "岗位记录主键")
    private Integer id;

    @ApiModelProperty(value = "岗位记录的名称")
    private String name;

    @ApiModelProperty(value = "更新前的名字")
    private String oldName;

    @ApiModelProperty(value = "工作年限ID")
    private Integer workingYearsId;

    @ApiModelProperty(value = "薪资ID")
    private Integer salaryId;

    @ApiModelProperty(value = "学历ID")
    private Integer educationId;

    @ApiModelProperty(value = "岗位招聘人数")
    private Integer recruitNumber;

    @ApiModelProperty(value = "工作地点")
    private Integer sRegionId;

    @ApiModelProperty(value = "岗位性质 0全职 1兼职")
    private Integer property;

    @ApiModelProperty(value = "岗位描述")
    private String description;

    @ApiModelProperty(value = "岗位记录ID 用于申请审核岗位时使用 无表示新增岗位，有则是更新岗位")
    private Integer positionRecordID;

    @ApiModelProperty(value = "工种id")
    private Integer tagId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getWorkingYearsId() {
        return workingYearsId;
    }

    public void setWorkingYearsId(Integer workingYearsId) {
        this.workingYearsId = workingYearsId;
    }

    public Integer getSalaryId() {
        return salaryId;
    }

    public void setSalaryId(Integer salaryId) {
        this.salaryId = salaryId;
    }

    public Integer getEducationId() {
        return educationId;
    }

    public void setEducationId(Integer educationId) {
        this.educationId = educationId;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public Integer getsRegionId() {
        return sRegionId;
    }

    public void setsRegionId(Integer sRegionId) {
        this.sRegionId = sRegionId;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPositionRecordID() {
        return positionRecordID;
    }

    public void setPositionRecordID(Integer positionRecordID) {
        this.positionRecordID = positionRecordID;
    }

    public Integer getTagId() {
        return tagId;
    }

    public void setTagId(Integer tagId) {
        this.tagId = tagId;
    }


    public String getOldName() {
        return oldName;
    }

    public void setOldName(String oldName) {
        this.oldName = oldName;
    }
}
