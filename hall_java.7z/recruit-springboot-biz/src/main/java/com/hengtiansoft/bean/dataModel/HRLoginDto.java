package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * HR登录签到信息类
 */
public class HRLoginDto {

    @ApiModelProperty(value = "ip")
    private String ip;

    @ApiModelProperty(value = "签到码")
    private String captcha;

    @ApiModelProperty(value = "就餐人数")
    private Integer mealsNumber;

    @ApiModelProperty(value = "是否停车, 0不停车，1停车")
    private Integer isPacking;

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public Integer getMealsNumber() {
        return mealsNumber;
    }

    public void setMealsNumber(Integer mealsNumber) {
        this.mealsNumber = mealsNumber;
    }

    public Integer getIsPacking() {
        return isPacking;
    }

    public void setIsPacking(Integer isPacking) {
        this.isPacking = isPacking;
    }
}