package com.hengtiansoft.bean.dataModel;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

public class Thumbnail {

    private String type;

    private String url;

    public Thumbnail() {}

    public Thumbnail(String type, String url) {
        this.type = type;
        this.url = url;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
