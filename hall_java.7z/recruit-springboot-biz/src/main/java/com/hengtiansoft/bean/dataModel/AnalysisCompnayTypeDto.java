package com.hengtiansoft.bean.dataModel;

public class AnalysisCompnayTypeDto {
    private Integer companyType;
    private Integer companyNumber;

    public Integer getCompanyType() {
        return companyType;
    }

    public void setCompanyType(Integer companyType) {
        this.companyType = companyType;
    }

    public Integer getCompanyNumber() {
        return companyNumber;
    }

    public void setCompanyNumber(Integer companyNumber) {
        this.companyNumber = companyNumber;
    }
}
