package com.hengtiansoft.bean.dataModel;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResumeDeliverySuccessDto {

    private Integer orderNum;

    private Integer boothId;

    private Integer currentOrderNum;

    public ResumeDeliverySuccessDto(){}

    public ResumeDeliverySuccessDto(ResumeDeliveryDate2Dto dto) {
        this.orderNum = dto.getOrderNum();
        this.boothId = dto.getBoothId();
    }
}
