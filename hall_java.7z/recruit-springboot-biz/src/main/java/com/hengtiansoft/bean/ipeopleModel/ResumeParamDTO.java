package com.hengtiansoft.bean.ipeopleModel;

import lombok.Data;

/**
 * Class Name: ResumeParamDTO Description: TODO
 * 
 * @author jingjingzhou
 *
 */
@Data
public class ResumeParamDTO {

    private String username;
    private String source;
    private String name;
    private String content;
    private String phone;
    private String email;
    private String age;
    private String sex;
    private String years;
    private String city;
    private String expect_city;
    private String post;
    private String graduate_date;
    private String school;
    private String degree;
    private String major;
    private String jobId;
    private String html;
    private String resubmit;
}
