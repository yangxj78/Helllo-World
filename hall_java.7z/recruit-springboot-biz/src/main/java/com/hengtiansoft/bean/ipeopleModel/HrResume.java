package com.hengtiansoft.bean.ipeopleModel;

import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.File;
import java.util.Date;
import java.util.List;


@Entity
@Table(name = "hr_resume")
@Data
@EqualsAndHashCode(callSuper = false)
public class HrResume{

    public static final String SOURCE = "source";
    public static final String AGE = "age";
    public static final String EMAIL = "email";
    public static final String CITY = "city";
    public static final String DEGREE = "degree";
    public static final String SOURCE_ID = "sourceId";
    public static final String POST = "post";
    public static final String YEARS = "years";
    public static final String IDENTITY = "identity";
    public static final String CONTENT = "content";
    public static final String PDF_URL = "prfUrl";
    public static final String WORD_URL = "wordUrl";
    public static final String SEND_TIME = "sendTime";
    public static final String IS_READ = "isRead";
    public static final String PNHOE = "phone";
    public static final String EXPECT_CITY = "expectCity";
    public static final String MAIL_TYPE = "mail";
    public static final String MAIL_UPLOAD = "upload";
    public static final String WECHAT = "wechat";

    public static final String CORPORATE = "corporate";
    public static final String VALIDATE_FILE = "resume";
    public static final String FILE_UPLOAD_RESUME = "resume" + File.separator;
    public static final String RESUME_PDF_UPLOAD = "pdf" + File.separator;
    public static final String RESUME_WORD_UPLOAD = "word" + File.separator;
    public static final String RESUME_HTML_UPLOAD = "html" + File.separator;
    public static final String RESUME_ERROT_UPLOAD = "error" + File.separator;

    private static final long serialVersionUID = -3318562257564795802L;



    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    @Getter
    @Setter
    private Long id;
    @Column(name = "uuid")
    @Getter
    @Setter
    private String uuid;
    @Getter
    @Setter
    private String code;
    @NotEmpty
    @Length(min = 0)
    @Getter
    @Setter
    private String name;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_created")
    @Getter
    @Setter
    private Date dateCreated;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "date_modified")
    @Getter
    @Setter
    private Date dateModified;


    @Enumerated(EnumType.STRING)
    private SexEnum sex;
    @Column(name = "age")
    private int age;
    @Column(name = "phone")
    private String phone;
    @Column(name = "email")
    private String email;
    @Column(name = "city")
    private String city;
    @Column(name = "degree")
    private String degree;
    @Column(name = "number")
    private String number;
    @Enumerated(EnumType.STRING)
    @Column(name = "source")
    private ResumeSourceEnum source;
    @Column(name = "source_id")
    private String sourceId;
    @Column(name = "post")
    private String post;
    @Column(name = "years")
    private String years;
    @Column(name = "work_expirence", columnDefinition = "text", nullable = true)
    private String workExpirence;
    @Column(name = "project_experience", columnDefinition = "text", nullable = true)
    private String projectExperience;
    @Column(name = "expectCity")
    private String expectCity;
    @Column(name = "identity")
    private String identity;
    @Lob
    @Basic(fetch = FetchType.LAZY)
    @Column(name = "content", columnDefinition = "text", nullable = true)
    private String content;
    @Column(name = "pdf_url")
    private String pdfUrl;
    @Column(name = "word_url")
    private String wordUrl;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "send_time")
    private Date sendTime;
    @Column(name = "is_read")
    private boolean isRead;
    @Column(name = "post_time")
    @Temporal(TemporalType.TIMESTAMP)
    private Date postTime;
    @Column(name = "school")
    private String school;
    @Column(name = "graduate_date")
    private String graduateDate;
    @Column(name = "match_degree")
    private String matchDegree;
    @Column(name = "major")
    private String major;
    @Column(name = "education", columnDefinition = "text", nullable = true)
    private String education;
    @Column(name = "staffType")
    private String staffType;
    @Column(name = "referrer")
    private String referrer;
    @Column(name = "expect_salary")
    private String expectSalary;
    @Column(name = "annual_income")
    private String annualIncome;
    @Column(name = "english_level")
    private String engLevel;
    @Column(name = "update_date")
    private String updateDate;

    private String birthDate;
    private String selfIntroduction;
    private List<UserEducationExperience> userEducationExperienceList;
    private List<UserWorkExperience> userWorkExperienceList;
    private List<UserProjectExperience> projectExperienceList;


    /**
     * Description：constructor default
     */
    public HrResume() {
        // do nothing
    }

    /**
     *
     * Description：constructor with params
     *
     * @param name
     *            name
     * @param age
     *            age
     * @param degree
     *            degree
     * @param email
     *            email
     * @param phone
     *            phone
     */
    public HrResume(String name, int age, String degree, String email, String phone) {
        setName(name);
        setAge(age);
        setDegree(degree);
        setEmail(email);
        setPhone(phone);
    }

    /**
     *
     * Description：constructor with params
     *
     * @param name
     *            name
     * @param age
     *            age
     * @param man
     *            man
     */

    public HrResume(String name, SexEnum man, int age) {
        setName(name);
        setSex(man);
        setAge(age);
    }

    public HrResume(ResumeParamDTO r) {
        setName(r.getName());
        setSex(SexEnum.valueOf(r.getSex()));
        setAge(Integer.parseInt(r.getAge()));
        setContent(r.getContent());
        setEmail(r.getEmail() == null ? "" : r.getEmail().trim());
        setPhone(r.getPhone());
        setYears(r.getYears());
        setCity(r.getCity());
        setExpectCity(r.getExpect_city());
        setPost(r.getPost());
        setGraduateDate(r.getGraduate_date());
        setSchool(r.getSchool());
        setDegree(r.getDegree());
        setMajor(r.getMajor());
        setSource(ResumeSourceEnum.valueOf(r.getSource()));

    }

    public HrResume(PersonResume r) {
        setName(r.getName());
        setSex(r.getSex());
        setAge(r.getAge());
        setContent(r.getContent());
        setEmail(r.getEmail());
        setPhone(r.getPhone());
        setYears(r.getYears());
        setCity(r.getCity());
        setExpectCity(r.getExpectCity());
        setPost(r.getPost());
        setGraduateDate(r.getGraduateDate());
        setSchool(r.getSchool());
        setDegree(r.getDegree());
        setMajor(r.getMajor());
        setSource(ResumeSourceEnum.OTHER);
        setWorkExpirence(r.getWorkExpirence());
        setExpectSalary(r.getExpectSalary());
        setStaffType(r.getStaffType());
        setEngLevel(r.getEngLevel());

    }

}
