package com.hengtiansoft.bean.tableModel;

import com.hengtiansoft.bean.dataModel.Experience;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserEducationExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.StatusEnum;
import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Basic;

@Entity
@Table(name = "user_education_experience")
public class UserEducationExperience extends Experience {

    @Id
    @GeneratedValue(generator = "JDBC")
    @ApiModelProperty(value = "教育经历id", notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id", notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "简历id", notes = "仅当简历创建时非必填")
    private Integer resumeId;
    @ApiModelProperty(value = "学历", notes = "必填")
    private Integer educational;
    @ApiModelProperty(value = "是否浙江户籍学生", notes = "0 不是；1 是 必填")
    private Integer localZj;
    @ApiModelProperty(value = "学校", notes = "必填")
    private String school;
    @ApiModelProperty(value = "专业", notes = "必填")
    private String major;
    @ApiModelProperty(value = "入学时间", notes = "必填")
    private String startTs;
    @ApiModelProperty(value = "毕业时间", notes = "必填")
    private String endTs;
    private String createTs;
    private String updateTs;


    public UserEducationExperience(MUserEducationExperience experience) {
        this.userId = experience.getUserId();
        this.educational = EducationalEnum.verifyEducation(experience.getEducational());
        this.localZj = StatusEnum.NO.getCode();
        this.school = experience.getSchool();
        this.major = experience.getMajor();
        this.startTs = dateFormat(experience.getStartTs());
        this.endTs = dateFormat(experience.getEndTs());
    }

    public UserEducationExperience(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public UserEducationExperience() {
        super();
    }

    @Column(name = "id")
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id")
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "resume_id")
    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    @Basic
    @Column(name = "educational")
    public Integer getEducational() {
        return educational;
    }

    public void setEducational(Integer educational) {
        this.educational = educational;
    }

    @Basic
    @Column(name = "start_ts")
    public String getStartTs() {
        return startTs;
    }

    public void setStartTs(String startTs) {
        this.startTs = startTs;
    }

    @Basic
    @Column(name = "local_zj")
    public Integer getLocalZj() {
        return localZj;
    }

    public void setLocalZj(Integer localZj) {
        this.localZj = localZj;
    }

    @Basic
    @Column(name = "school")
    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    @Basic
    @Column(name = "major")
    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    @Basic
    @Column(name = "end_ts")
    public String getEndTs() {
        return endTs;
    }

    public void setEndTs(String endTs) {
        this.endTs = endTs;
    }

    @Basic
    @Column(name = "create_ts")
    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    @Basic
    @Column(name = "update_ts")
    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    private String dateFormat(String time) {
        String result = time.trim().replaceAll("[^0-9]", "-");
        return result.endsWith("-") ? result.substring(0, result.length() - 1) : result;
    }
}