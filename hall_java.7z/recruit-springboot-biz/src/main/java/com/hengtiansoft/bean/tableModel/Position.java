package com.hengtiansoft.bean.tableModel;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

@Table(name = "position")
public class Position {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "岗位ID主键")
    private Integer id;

    /**
     * 岗位名称
     */
    @ApiModelProperty(value = "岗位名称")
    @NotNull
    private String name;




    /**
     * 企业ID
     */
    @NotNull
    @ApiModelProperty(value = "关联公司ID")
    @Column(name = "company_id")
    private Integer companyID;
    /**
     * 学历id
     */
    @NotNull
    @ApiModelProperty(value = "学历ID")
    @Column(name = "education_id")
    private Integer educationId;

    /**
     * 工作年限id
     */
    @NotNull
    @ApiModelProperty(value = "工作年限ID")
    @Column(name = "working_years_id")
    private Integer workingYearsId;

    /**
     * 薪水id
     */
    @ApiModelProperty(value = "薪资ID")
    @Column(name = "salary_id")
    private Integer salaryId;

    /**
     * 招聘人数
     */
    @NotNull
    @ApiModelProperty(value = "岗位招聘人数")
    @Column(name = "recruit_number")
    private Integer recruitNumber;

    /**
     * 岗位描述
     */
    @ApiModelProperty(value = "岗位描述")
    private String description;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    @Column(name = "update_ts")
    private Date updateTs;

    @ApiModelProperty(value = "岗位状态 0正常 1已删除")
    private Integer status;

    @Column(name = "update_by")
    @ApiModelProperty(value = "更新人")
    private String updateBy;

    @Column(name = "create_by")
    @ApiModelProperty(value = "创建人")
    private String createBy;
    @ApiModelProperty(value = "岗位性质0 全职 1兼职")
    private Integer property;
    @Column(name = "tag_id")
    private Integer tagID;
    @Transient
    private String companyName;


    @Column(name = "s_region_id")
    private Integer sRegionID;

    public Integer getsRegionID() {
        return sRegionID;
    }

    public void setsRegionID(Integer sRegionID) {
        this.sRegionID = sRegionID;
    }

    public Integer getTagID() {
        return tagID;
    }

    public void setTagID(Integer tagID) {
        this.tagID = tagID;
    }

    public Integer getProperty() {
        return property;
    }

    public void setProperty(Integer property) {
        this.property = property;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取岗位名称
     *
     * @return name - 岗位名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置岗位名称
     *
     * @param name 岗位名称
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }



    /**
     * 获取学历id
     *
     * @return education_id - 学历id
     */
    public Integer getEducationId() {
        return educationId;
    }

    /**
     * 设置学历id
     *
     * @param educationId 学历id
     */
    public void setEducationId(Integer educationId) {
        this.educationId = educationId;
    }

    /**
     * 获取工作年限id
     *
     * @return working_years_id - 工作年限id
     */
    public Integer getWorkingYearsId() {
        return workingYearsId;
    }

    /**
     * 设置工作年限id
     *
     * @param workingYearsId 工作年限id
     */
    public void setWorkingYearsId(Integer workingYearsId) {
        this.workingYearsId = workingYearsId;
    }

    /**
     * 获取薪水id
     *
     * @return salary_id - 薪水id
     */
    public Integer getSalaryId() {
        return salaryId;
    }

    /**
     * 设置薪水id
     *
     * @param salaryId 薪水id
     */
    public void setSalaryId(Integer salaryId) {
        this.salaryId = salaryId;
    }

    /**
     * 获取招聘人数
     *
     * @return recruit_number - 招聘人数
     */
    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    /**
     * 设置招聘人数
     *
     * @param recruitNumber 招聘人数
     */
    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    /**
     * 获取岗位描述
     *
     * @return description - 岗位描述
     */
    public String getDescription() {
        return description;
    }

    /**
     * 设置岗位描述
     *
     * @param description 岗位描述
     */
    public void setDescription(String description) {
        this.description = description == null ? null : description.trim();
    }

    /**
     * 获取更新时间
     *
     * @return update_ts - 更新时间
     */
    public Date getUpdateTs() {
        return updateTs;
    }

    /**
     * 设置更新时间
     *
     * @param updateTs 更新时间
     */
    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }
}