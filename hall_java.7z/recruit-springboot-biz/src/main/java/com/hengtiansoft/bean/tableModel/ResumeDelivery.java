package com.hengtiansoft.bean.tableModel;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.util.Date;

/**
 * 简历投递
 */
@Table(name = "resume_delivery")
public class ResumeDelivery {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "resume_id")
    private Integer resumeId;

    @Column(name = "recruitment_id")
    private Integer recruitmentId;

    @Column(name = "company_id")
    private Integer companyId;

    @Column(name = "position_record_id")
    private Integer positionRecordId;

    @Column(name = "booth_id")
    private Integer boothId;

    @Column(name = "parent_booth_id")
    private Integer parentBoothId;

    @Column(name = "interview_num")
    private Integer interviewNum;

    @Column(name = "interview_status")
    private Integer interviewStatus;

    @Column(name = "pass_status")
    private Integer passStatus;

    @Column(name = "interview_result")
    private Integer interviewResult;

    @Column(name = "matching")
    private Integer matching;

    @Column(name = "profession")
    private Integer profession;

    @Column(name = "learning")
    private Integer learning;

    @Column(name = "communicate")
    private Integer communicate;

    @Column(name = "order_num")
    private Integer orderNum;

    @Column(name = "is_over")
    private Integer isOver;

    @Column(name = "interview_evaluation")
    private String interviewEvaluation;

    @Column(name = "create_ts")
    private Date createTs;

    @Column(name = "update_ts")
    private Date updateTs;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getPositionRecordId() {
        return positionRecordId;
    }

    public void setPositionRecordId(Integer positionRecordId) {
        this.positionRecordId = positionRecordId;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public Integer getInterviewNum() {
        return interviewNum;
    }

    public void setInterviewNum(Integer interviewNum) {
        this.interviewNum = interviewNum;
    }

    public Integer getInterviewStatus() {
        return interviewStatus;
    }

    public void setInterviewStatus(Integer interviewStatus) {
        this.interviewStatus = interviewStatus;
    }

    public Integer getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(Integer interviewResult) {
        this.interviewResult = interviewResult;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public String getInterviewEvaluation() {
        return interviewEvaluation;
    }

    public void setInterviewEvaluation(String interviewEvaluation) {
        this.interviewEvaluation = interviewEvaluation == null ? null : interviewEvaluation.trim();
    }

    public Date getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Date createTs) {
        this.createTs = createTs;
    }

    public Date getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(Date updateTs) {
        this.updateTs = updateTs;
    }

    public Integer getParentBoothId() {
        return parentBoothId;
    }

    public void setParentBoothId(Integer parentBoothId) {
        this.parentBoothId = parentBoothId;
    }

    public Integer getMatching() {
        return matching;
    }

    public void setMatching(Integer matching) {
        this.matching = matching;
    }

    public Integer getProfession() {
        return profession;
    }

    public void setProfession(Integer profession) {
        this.profession = profession;
    }

    public Integer getLearning() {
        return learning;
    }

    public void setLearning(Integer learning) {
        this.learning = learning;
    }

    public Integer getCommunicate() {
        return communicate;
    }

    public void setCommunicate(Integer communicate) {
        this.communicate = communicate;
    }

    public Integer getPassStatus() {
        return passStatus;
    }

    public void setPassStatus(Integer passStatus) {
        this.passStatus = passStatus;
    }

    public Integer getIsOver() {
        return isOver;
    }

    public void setIsOver(Integer isOver) {
        this.isOver = isOver;
    }

    public ResumeDelivery() {
    }

    public ResumeDelivery(Integer userId, Integer resumeId, Integer recruitmentId, Integer companyId, Integer positionRecordId, Integer boothId, Integer interviewStatus, Integer interviewResult, Integer passStatus, Date createTs, Date updateTs) {
        this.userId = userId;
        this.resumeId = resumeId;
        this.recruitmentId = recruitmentId;
        this.companyId = companyId;
        this.positionRecordId = positionRecordId;
        this.boothId = boothId;
        this.interviewStatus = interviewStatus;
        this.interviewResult = interviewResult;
        this.passStatus = passStatus;
        this.createTs = createTs;
        this.updateTs = updateTs;
    }
}