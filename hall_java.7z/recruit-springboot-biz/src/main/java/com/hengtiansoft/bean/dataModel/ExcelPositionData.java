package com.hengtiansoft.bean.dataModel;

public class ExcelPositionData {
    private Integer boothID;
    private String companyName;
    private String positionName;
    private String positionDesprition;
    private String education;
    private Integer recruitNumber;
    private Integer applyNumber;
    private Integer passNumber;
    private Integer undeterminedNumber;
    private String recruitmentName;

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public String getPositionDesprition() {
        return positionDesprition;
    }

    public void setPositionDesprition(String positionDesprition) {
        this.positionDesprition = positionDesprition;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }

    public Integer getApplyNumber() {
        return applyNumber;
    }

    public void setApplyNumber(Integer applyNumber) {
        this.applyNumber = applyNumber;
    }

    public Integer getPassNumber() {
        return passNumber;
    }

    public void setPassNumber(Integer passNumber) {
        this.passNumber = passNumber;
    }

    public Integer getUndeterminedNumber() {
        return undeterminedNumber;
    }

    public void setUndeterminedNumber(Integer undeterminedNumber) {
        this.undeterminedNumber = undeterminedNumber;
    }

    public String getRecruitmentName() {
        return recruitmentName;
    }

    public void setRecruitmentName(String recruitmentName) {
        this.recruitmentName = recruitmentName;
    }
}
