package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

/**
 * 应聘者管理投递信息
 */
public class InterviewDeliveryDto {

    @ApiModelProperty(value = "投递id")
    private Integer id;

    @ApiModelProperty(value = "面试序号")
    private Integer orderNum;

    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "用户id")
    private Integer userId;

    @ApiModelProperty(value = "联系方式")
    private String contact;

    @ApiModelProperty(value = "投递岗位名称")
    private String positionName;

    @ApiModelProperty(value = "简历id")
    private Integer resumeId;

    @ApiModelProperty(value = "面试结果：0 未通过；1 已通过； 2 待定")
    private Integer interviewResult;

    @ApiModelProperty(value = "面试轮次")
    private Integer interviewNum;

    @ApiModelProperty(value = "面试状态：0 未面试；1面试中；2已面试 , 查看分流记录时使用")
    private Integer interviewStatus;

    @ApiModelProperty(value = "面试展位,查看分流记录时使用")
    private Integer boothId;

    @ApiModelProperty(value = "岗位匹配度")
    private Integer matching;

    @ApiModelProperty(value = "专业基础")
    private Integer profession;

    @ApiModelProperty(value = "学习能力")
    private Integer learning;

    @ApiModelProperty(value = "沟通协调")
    private Integer communicate;

    @ApiModelProperty(value = "面试评价")
    private String interviewEvaluation;

    @ApiModelProperty(value = "工作年限")
    private String workYears;

    @ApiModelProperty(value = "文化程度")
    private String educational;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(Integer orderNum) {
        this.orderNum = orderNum;
    }

    public Integer getInterviewResult() {
        return interviewResult;
    }

    public void setInterviewResult(Integer interviewResult) {
        this.interviewResult = interviewResult;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public Integer getResumeId() {
        return resumeId;
    }

    public void setResumeId(Integer resumeId) {
        this.resumeId = resumeId;
    }

    public Integer getInterviewNum() {
        return interviewNum;
    }

    public void setInterviewNum(Integer interviewNum) {
        this.interviewNum = interviewNum;
    }

    public Integer getBoothId() {
        return boothId;
    }

    public void setBoothId(Integer boothId) {
        this.boothId = boothId;
    }

    public Integer getInterviewStatus() {
        return interviewStatus;
    }

    public void setInterviewStatus(Integer interviewStatus) {
        this.interviewStatus = interviewStatus;
    }

    public Integer getMatching() {
        return matching;
    }

    public void setMatching(Integer matching) {
        this.matching = matching;
    }

    public Integer getProfession() {
        return profession;
    }

    public void setProfession(Integer profession) {
        this.profession = profession;
    }

    public Integer getLearning() {
        return learning;
    }

    public void setLearning(Integer learning) {
        this.learning = learning;
    }

    public Integer getCommunicate() {
        return communicate;
    }

    public void setCommunicate(Integer communicate) {
        this.communicate = communicate;
    }

    public String getInterviewEvaluation() {
        return interviewEvaluation;
    }

    public void setInterviewEvaluation(String interviewEvaluation) {
        this.interviewEvaluation = interviewEvaluation;
    }

    public String getWorkYears() {
        return workYears;
    }

    public void setWorkYears(String workYears) {
        this.workYears = workYears;
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational;
    }
}