package com.hengtiansoft.bean.dataModel.MultipleResumeDto;

import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

public class MResume implements Serializable{

    private static final long serialVersionUID = 2305795691627137702L;

    @ApiModelProperty(value = "简历id", notes = "编辑必填")
    private Integer id;
    @ApiModelProperty(value = "用户id",notes = "必填")
    private Integer userId;
    @ApiModelProperty(value = "简历名称",notes = "必填")
    private String name;
    @ApiModelProperty(value = "工种",notes = "必填")
    private String workType;
    @ApiModelProperty(value = "工作年限",notes = "必填")
    private String workYears;
    @ApiModelProperty(value = "工作类型",notes = "0兼职；1 全职； 2 实习")
    private String workTimeType;
    @ApiModelProperty(value = "期望月薪",notes = "必填")
    private String expectedSalary;
    @ApiModelProperty(value = "地区id",notes = "必填")
    private String region;
    @ApiModelProperty(value = "自我介绍",notes = "")
    private String selfIntroduction;
    @ApiModelProperty(value = "简历来源",notes = "0 本地创建；1 BOSS直聘；2 智联招聘；3 高新人才网")
    private Integer source;
    @ApiModelProperty(value = "是否默认简历",notes = "0 否；1 是； 默认为0，创建编辑都不填")
    private Integer defaultFlag;
    @ApiModelProperty(value = "上传简历的存放路径",notes = "")

    private String ftpUrl;

    private String createTs;

    private String updateTs;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkType() {
        return workType;
    }

    public void setWorkType(String workType) {
        this.workType = workType;
    }

    public String getWorkYears() {
        return workYears;
    }

    public void setWorkYears(String workYears) {
        this.workYears = workYears;
    }

    public String getWorkTimeType() {
        return workTimeType;
    }

    public void setWorkTimeType(String workTimeType) {
        this.workTimeType = workTimeType;
    }

    public String getExpectedSalary() {
        return expectedSalary;
    }

    public void setExpectedSalary(String expectedSalary) {
        this.expectedSalary = expectedSalary;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getSelfIntroduction() {
        return selfIntroduction;
    }

    public void setSelfIntroduction(String selfIntroduction) {
        this.selfIntroduction = selfIntroduction;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public Integer getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(Integer defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

    public String getFtpUrl() {
        return ftpUrl;
    }

    public void setFtpUrl(String ftpUrl) {
        this.ftpUrl = ftpUrl;
    }

    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }
}