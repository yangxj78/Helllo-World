package com.hengtiansoft.bean.ipeopleModel;

public interface UserCreatedable<M> {
	M getCreateBy();
}
