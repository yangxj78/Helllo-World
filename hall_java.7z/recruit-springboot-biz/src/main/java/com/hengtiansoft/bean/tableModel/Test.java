package com.hengtiansoft.bean.tableModel;

public class Test {
    private int id;
    private int boothID;
    private String name;
    private String name2;
    private String number;

    public int getBoothID() {
        return boothID;
    }

    public void setBoothID(int boothID) {
        this.boothID = boothID;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName2() {
        return name2;
    }

    public void setName2(String name2) {
        this.name2 = name2;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
