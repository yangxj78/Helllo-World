package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class BoothSearch {
    private Integer id;
    @ApiModelProperty(value = "招聘会ID")
    private Integer recruitmentID;
    @ApiModelProperty(value = "展位ID")
    private Integer boothID;
    @ApiModelProperty(value = "企业ID")
    private Integer companyID;
    @ApiModelProperty(value = "展位状态0未预定 1 已预订")
    private Integer status;
    @ApiModelProperty(value = "岗位记录ID")
    private Integer positionID;

    private Integer type;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPositionID() {
        return positionID;
    }

    public void setPositionID(Integer positionID) {
        this.positionID = positionID;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getboothID() {
        return boothID;
    }

    public void setboothID(Integer boothID) {
        this.boothID = boothID;
    }

    public Integer getcompanyID() {
        return companyID;
    }

    public void setcompanyID(Integer companyID) {
        this.companyID = companyID;
    }
}
