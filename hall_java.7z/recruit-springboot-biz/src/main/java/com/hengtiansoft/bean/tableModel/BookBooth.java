package com.hengtiansoft.bean.tableModel;

import io.swagger.annotations.ApiModelProperty;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Transient;

/**
*@Description: 订展表

**/
@Table(name = "book_booth")
public class BookBooth {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "展位预订记录主键")
    private Integer id;

    @Column(name = "recruitment_id")
    @ApiModelProperty(value = "招聘会ID")
    private Integer recruitmentID;

    @Column(name = "company_id")
    @ApiModelProperty(value = "企业ID")
    private Integer companyID;

    @Column(name = "booth_id")
    @ApiModelProperty(value = "展位ID")
    private Integer boothID;


    @ApiModelProperty(value = "签到验证码")
    @Transient
    private Integer captcha;


    @Column(name = "recruit_number")
    @ApiModelProperty(value = "展位招聘人数")
    @Transient
    private Integer recruitNumber;

    @ApiModelProperty(value = "预定展位操作人")
    private String createBy;

    @Transient
    @ApiModelProperty(value = "旧的展位ID")
    private Integer oldboothID;

    @Transient
    @ApiModelProperty(value = "参展联系人")
    private String exhibitor;
    @Transient
    @ApiModelProperty(value = "参展联系人号码")
    private String exhibitorNumber;
    @Transient
    @ApiModelProperty(value = "企业名称")
    private String companyName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRecruitmentID() {
        return recruitmentID;
    }

    public void setRecruitmentID(Integer recruitmentID) {
        this.recruitmentID = recruitmentID;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }


    public Integer getCaptcha() {
        return captcha;
    }

    public void setCaptcha(Integer captcha) {
        this.captcha = captcha;
    }


    public Integer getRecruitNumber() {
        return recruitNumber;
    }

    public void setRecruitNumber(Integer recruitNumber) {
        this.recruitNumber = recruitNumber;
    }


    public Integer getOldboothID() {
        return oldboothID;
    }

    public void setOldboothID(Integer oldboothID) {
        this.oldboothID = oldboothID;
    }


    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getExhibitor() {
        return exhibitor;
    }

    public void setExhibitor(String exhibitor) {
        this.exhibitor = exhibitor;
    }

    public String getExhibitorNumber() {
        return exhibitorNumber;
    }

    public void setExhibitorNumber(String exhibitorNumber) {
        this.exhibitorNumber = exhibitorNumber;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }
}