package com.hengtiansoft.bean.dataModel;

public class AnalysisPositionEducationDto {
    private Integer poisitonEducation;
    private Integer positionNumber;

    public Integer getPoisitonEducation() {
        return poisitonEducation;
    }

    public void setPoisitonEducation(Integer poisitonEducation) {
        this.poisitonEducation = poisitonEducation;
    }

    public Integer getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Integer positionNumber) {
        this.positionNumber = positionNumber;
    }
}
