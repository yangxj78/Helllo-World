package com.hengtiansoft.bean.tableModel;


import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Basic;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "qr_code_record")
public class QrCodeRecord {
    private Integer id;
    private Integer qrCodeId;
    private Integer recruitmentId;
    private Integer type;
    private String createTs;


    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "qr_code_id", nullable = false)
    public Integer getQrCodeId() {
        return qrCodeId;
    }

    public void setQrCodeId(Integer qrCodeId) {
        this.qrCodeId = qrCodeId;
    }

    public Integer getRecruitmentId() {
        return recruitmentId;
    }

    public void setRecruitmentId(Integer recruitmentId) {
        this.recruitmentId = recruitmentId;
    }

    @Basic
    @Column(name = "type", nullable = false)
    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Basic
    @Column(name = "create_ts", nullable = true)
    public String getCreateTs() {
        return createTs;
    }

    public void setCreateTs(String createTs) {
        this.createTs = createTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QrCodeRecord that = (QrCodeRecord) o;
        return id == that.id &&
                qrCodeId == that.qrCodeId &&
                type == that.type &&
                Objects.equals(createTs, that.createTs);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, qrCodeId, type, createTs);
    }
}
