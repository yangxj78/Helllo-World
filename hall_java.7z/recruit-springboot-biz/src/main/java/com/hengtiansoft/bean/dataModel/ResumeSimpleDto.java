package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;

@ApiModel
public class ResumeSimpleDto implements Serializable {
    private static final long serialVersionUID = -2917181150080199689L;

    @ApiModelProperty(value = "简历id")
    private Integer id;
    private Integer userId;
    private String userName;
    private String resumeName;
    @ApiModelProperty(value = "学历id")
    private Integer educational;
    @ApiModelProperty(value = "身份证号")
    private String identityCard;
    private String phone;
    private Integer workYears;
    @ApiModelProperty(value = "简历来源：0 本地创建；1 BOSS直聘；2 智联招聘；3 高新人才网")
    private Integer source;
    private Integer defaultFlag;
    private Integer perfectFlag;
    private String updateTs;
    private Integer status;

    public Integer getPerfectFlag() {
        return perfectFlag;
    }

    public void setPerfectFlag(Integer perfectFlag) {
        this.perfectFlag = perfectFlag;
    }

    public Integer getDefaultFlag() {
        return defaultFlag;
    }

    public void setDefaultFlag(Integer defaultFlag) {
        this.defaultFlag = defaultFlag;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getResumeName() {
        return resumeName;
    }

    public void setResumeName(String resumeName) {
        this.resumeName = resumeName;
    }

    public Integer getEducational() {
        return educational;
    }

    public void setEducational(Integer educational) {
        this.educational = educational;
    }

    public String getIdentityCard() {
        return identityCard;
    }

    public void setIdentityCard(String identityCard) {
        this.identityCard = identityCard;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getWorkYears() {
        return workYears;
    }

    public void setWorkYears(Integer workYears) {
        this.workYears = workYears;
    }

    public Integer getSource() {
        return source;
    }

    public void setSource(Integer source) {
        this.source = source;
    }

    public String getUpdateTs() {
        return updateTs;
    }

    public void setUpdateTs(String updateTs) {
        this.updateTs = updateTs;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
