package com.hengtiansoft.bean.tableModel;

import javax.persistence.Entity;
import javax.persistence.Basic;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;
import java.sql.Timestamp;
import java.util.Objects;

@Entity
@Table(name = "qr_code")
public class QrCode {
    @Id
    private Integer id;
    private Integer userId;
    private String code;
    private Integer jumpType;
    private Timestamp createTs;


    @Column(name = "id", nullable = false)
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Basic
    @Column(name = "user_id", nullable = false)
    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Basic
    @Column(name = "qr_code", nullable = false, length = 50)
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    @Basic
    @Column(name = "jump_type")
    public Integer getJumpType() {
        return jumpType;
    }

    public void setJumpType(Integer jumpType) {
        this.jumpType = jumpType;
    }

    @Basic
    @Column(name = "create_ts", nullable = true)
    public Timestamp getCreateTs() {
        return createTs;
    }

    public void setCreateTs(Timestamp createTs) {
        this.createTs = createTs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        QrCode qrCode1 = (QrCode) o;
        return id.equals(qrCode1.id)  &&
                userId.equals(qrCode1.userId)&&
                Objects.equals(code, qrCode1.code);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id, userId, code, createTs);
    }
}
