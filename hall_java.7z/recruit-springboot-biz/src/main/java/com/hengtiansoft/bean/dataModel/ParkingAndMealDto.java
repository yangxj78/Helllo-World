package com.hengtiansoft.bean.dataModel;

import io.swagger.annotations.ApiModelProperty;

public class ParkingAndMealDto {
    private Integer boothID;
    private String companyName;

    @ApiModelProperty("是否停车 0不停 1停")
    private Integer isParking;
    @ApiModelProperty("就餐人数")
    private Integer mealsNumber;

    public Integer getBoothID() {
        return boothID;
    }

    public void setBoothID(Integer boothID) {
        this.boothID = boothID;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getIsParking() {
        return isParking;
    }

    public void setIsParking(Integer isParking) {
        this.isParking = isParking;
    }

    public Integer getMealsNumber() {
        return mealsNumber;
    }

    public void setMealsNumber(Integer mealsNumber) {
        this.mealsNumber = mealsNumber;
    }
}
