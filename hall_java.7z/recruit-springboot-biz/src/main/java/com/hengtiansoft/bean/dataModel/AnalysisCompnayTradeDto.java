package com.hengtiansoft.bean.dataModel;

public class AnalysisCompnayTradeDto {
    private Integer companyTrade;
    private Integer companyNumber;

    public Integer getCompanyTrade() {
        return companyTrade;
    }

    public void setCompanyTrade(Integer companyTrade) {
        this.companyTrade = companyTrade;
    }

    public Integer getCompanyNumber() {
        return companyNumber;
    }

    public void setCompanyNumber(Integer companyNumber) {
        this.companyNumber = companyNumber;
    }
}
