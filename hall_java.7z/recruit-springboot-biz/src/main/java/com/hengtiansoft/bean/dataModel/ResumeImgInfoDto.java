package com.hengtiansoft.bean.dataModel;

import java.util.List;

/**
 * 简历图片信息类
 * Created by linwu on 9/17/2018.
 */
public class ResumeImgInfoDto {

    private Integer userId;

    private List<String> base64List;

    private boolean upload;

    private boolean isSchoolResume;

    private String contentType;

    private String fileName;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public List<String> getBase64List() {
        return base64List;
    }

    public void setBase64List(List<String> base64List) {
        this.base64List = base64List;
    }

    public boolean isUpload() {
        return upload;
    }

    public void setUpload(boolean upload) {
        this.upload = upload;
    }

    public boolean isSchoolResume() {
        return isSchoolResume;
    }

    public void setSchoolResume(boolean schoolResume) {
        isSchoolResume = schoolResume;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
