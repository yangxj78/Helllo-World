package com.hengtiansoft.servlet.admin.recycle.service.impl;

import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.servlet.admin.recycle.service.RecycleService;
import com.hengtiansoft.servlet.mapper.RecycleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class RecycleServiceImpl extends BaseService<Recycle> implements RecycleService {

    @Autowired
    RecycleMapper recycleMapper;

    @Override
    public void deleteAll() {
        recycleMapper.deleteAll();
    }

    @Override
    public int deleteByID(Integer id) {
        return recycleMapper.deleteByPrimaryKey(id);
    }

    @Override
    public List<Recycle> list() {
        return recycleMapper.list();
    }
}
