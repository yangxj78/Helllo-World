package com.hengtiansoft.servlet.admin.adminManagement;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.AdminUserDto;
import com.hengtiansoft.bean.dataModel.AdminUserSearchDto;
import com.hengtiansoft.bean.dataModel.PageDto;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.Banner;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.constant.PathStrings;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.common.util.FtpUtil;
import com.hengtiansoft.common.util.WebUtil;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.admin.reportCenter.service.impl.BannerService;
import com.hengtiansoft.servlet.hr.login.service.HrLoginService;
import com.hengtiansoft.servlet.manage.adminUser.AdminUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@RestController
@RequestMapping(value = "/admin/adminManagement")
@Api(value = "工作人员管理")

public class AdminManagement {

    private static final Logger LOGGER = LoggerFactory.getLogger(AdminManagement.class);

    @Autowired
    AdminUserService adminUserService;
    @Autowired
    BannerService bannerService;
    @Autowired
    HrLoginService hrLoginService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ApiOperation(value = "获取管理人员列表")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto list(@RequestParam(required = false) String name, @RequestParam(required = false) Integer pageSize, @RequestParam(required = false) Integer pageNum, @RequestParam(required = false) Integer isPage) {
        AdminUserSearchDto adminUserSearchDto = new AdminUserSearchDto();
        adminUserSearchDto.setRoleId("2");
        if (null != name) {
            adminUserSearchDto.setRealname(name);
        }
        if (null != isPage && isPage == 1) {
            Integer pageNum2 = (pageNum == null ? 1 : pageNum);
            Integer pageSize2 = (pageSize == null ? MagicNumConstant.TEN : pageSize);
            PageHelper.startPage(pageNum2, pageSize2);
            return ResultDtoFactory.toAck("success", new PageInfo<>(adminUserService.searchByCon(adminUserSearchDto)));
        }
        return ResultDtoFactory.toAck("success", adminUserService.searchByCon(adminUserSearchDto));

    }


    //新增用户
    @PostMapping(PathStrings.AdminUser.DO_ADD)
    @ApiOperation(value = "新增管理人员", notes = "必填字段账号（username）和工作人员名称（realname）")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object doAdd(@RequestBody AdminUserDto adminUserDto) {
        boolean flag = false;
        adminUserDto.setStatus("A");
        adminUserDto.setRoleId(2);
        AdminUserSearchDto adminUserSearchDto = new AdminUserSearchDto();
        adminUserSearchDto.setUsername(adminUserDto.getUsername());
        if (adminUserService.searchByCon(adminUserSearchDto).size() > 0) {
            return ResultDtoFactory.toNack("账号已存在");

        }
        try {
            flag = adminUserService.saveUser(adminUserDto);
        } catch (Exception e) {
            return ResultDtoFactory.toNack("新建失败");
        }
        if (flag) {
            return ResultDtoFactory.toAck("新建成功");
        } else {
            return ResultDtoFactory.toNack("新建失败");
        }
    }

    //删除用户
    @DeleteMapping(PathStrings.AdminUser.DO_DELETE)
    @ApiOperation(value = "删除管理人员")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object doDelete(@PathVariable Integer id) {
        if (adminUserService.doDeleteSingle(id)) {
            return ResultDtoFactory.toAck("删除成功");
        } else {
            return ResultDtoFactory.toNack("删除失败");
        }
    }

    //修改管理员信息(admin功能)
    @RequestMapping(value = PathStrings.AdminUser.DO_EDIT, method = RequestMethod.POST)
    @ApiOperation(value = "编辑管理人员", notes = "必填字段账号（username）和工作人员名称（realname）")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object doEdit(@PathVariable(PathStrings.PathVariable.ID) int id, @RequestBody AdminUserDto adminUserDto) {

        AdminUser adminUser = adminUserService.selectByName(adminUserDto.getUsername());
        if (null != adminUser&&adminUser.getId()!=id) {
            return ResultDtoFactory.toNack("账号已存在");
        }
         adminUserService.updateAdminUserInfo(adminUserDto, id);
        return ResultDtoFactory.toAck("修改成功");
    }

    //充值密码
    @RequestMapping(value = "/reset/{id}", method = RequestMethod.POST)
    @ApiOperation(value = "重置密码", notes = "id")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object reset(@PathVariable Integer id) {
        AdminUserDto adminUserDto = new AdminUserDto();
        adminUserDto.setId(id);
        adminUserDto.setNewPassword("a123456");

        if (adminUserService.doChangePassword(adminUserDto)) {
            return ResultDtoFactory.toAck("修改成功");
        }
        return ResultDtoFactory.toNack("修改失败,已是当前密码");
    }

    @RequestMapping(value = "/admin/getUserInfo", method = RequestMethod.POST)
    @ApiOperation(value = "获取当前登陆用户信息")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object getUserInfo() {
        AdminUserSearchDto adminUserSearchDto = new AdminUserSearchDto();
        adminUserSearchDto.setId(SecurityContext.getCurrentUserId());
        return ResultDtoFactory.toAck("success", adminUserService.searchByCon(adminUserSearchDto));
    }


    //修改密码
    @PostMapping(PathStrings.AdminUser.DO_CHANGE_PWD)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object doChangePassword(@RequestBody AdminUserDto adminUserDto) {
        String s = adminUserService.doChangePassword2(adminUserDto);
        if ("修改成功".equals(s)) {
            return ResultDtoFactory.toAck("修改成功");
        } else {
            return ResultDtoFactory.toNack(s);
        }
    }


    @RequestMapping(value = "/uploadBanner", method = RequestMethod.POST)
    @ApiOperation(value = "上传Banner")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto uploadFile(HttpServletRequest request) {
        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");
        List arr = new ArrayList();
        for (MultipartFile file : files) {

            try {
                InputStream inputStream = file.getInputStream();
                String fileName = String.valueOf(System.currentTimeMillis());
                String remoteName = file.getOriginalFilename();
                fileName = remoteName.indexOf(".") == -1 ? null : fileName + remoteName.substring(remoteName.lastIndexOf("."), remoteName.length());
                if (null == fileName) {
                    return ResultDtoFactory.toNack("文件格式有误");
                }
                if (FtpUtil.uploadFile("/picture", fileName, inputStream)) {
                    arr.add(fileName);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        return ResultDtoFactory.toAck("上传成功", arr);

    }


    @RequestMapping(value = "/bannerRecord", method = RequestMethod.POST)
    @ApiOperation(value = "插入banner记录")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto bannerRecord(@RequestBody Banner banner) {
        AdminUser user = SecurityContext.getCurrentUser();
        banner.setUpdateBy(user.getUsername());
        if (bannerService.insert(banner) > 0) {
            return ResultDtoFactory.toAck("success");
        }
        return ResultDtoFactory.toNack("插入失败");
    }

    @RequestMapping(value = "/bannerRecordList", method = RequestMethod.POST)
    @ApiOperation(value = "获取所有banner记录")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto bannerRecordList(@RequestBody PageDto pageDto) {
        Integer pageNum = (pageDto.getPageNum() == null ? 1 : pageDto.getPageNum());
        Integer pageSize = (pageDto.getPageSize() == null ? MagicNumConstant.TEN : pageDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<Banner>(bannerService.select()));
    }

    @RequestMapping(value = "/bannerRecord", method = RequestMethod.PUT)
    @ApiOperation(value = "更新banner记录")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto updateBannerRecord(@RequestBody Banner banner) {
        AdminUser user = SecurityContext.getCurrentUser();
        banner.setUpdateBy(user.getUsername());
        banner.setUpdateTs(DateUtil.getDateFormate(new Date()));
        bannerService.update(banner);
        return ResultDtoFactory.toAck("success");
    }


    @RequestMapping(value = "/bannerRecord", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除banner记录")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto deleteBannerRecord(@RequestParam Integer id) {
        if (bannerService.delete(id) > 0) {
            return ResultDtoFactory.toAck("success");
        }
        return ResultDtoFactory.toNack("删除失败");
    }

    @RequestMapping(value = "/getBannerById", method = RequestMethod.GET)
    @ApiOperation(value = "根据Id获取banner")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getBannerRecord(@RequestParam Integer id) {
        return ResultDtoFactory.toAck("success", bannerService.getById(id));
    }

    @RequestMapping(value = "/resume/export", method = RequestMethod.GET)
    @ApiOperation(value = "下载签退简历")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public void export(@RequestParam Integer companyId,
                       @RequestParam Integer recruitmentId,
                       HttpServletResponse response) throws IOException {
        Map<String, Map<String, FileInputStream>> data = hrLoginService.getSignOutEmail(companyId, recruitmentId);
        response.setContentType("application/zip");
        String downloadFileName = URLEncoder.encode("高新大厅简历.zip","UTF-8");
        response.setHeader("Content-disposition", "attachment;filename=" + downloadFileName);
        try (ZipOutputStream zos = new ZipOutputStream(response.getOutputStream())) {
            for (Map.Entry<String, Map<String, FileInputStream>> map : data.entrySet()) {
                for (Map.Entry<String, FileInputStream> entry : map.getValue().entrySet()) {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    BufferedInputStream in = new BufferedInputStream(entry.getValue());
                    int bufSize = MagicNumConstant.ONE_THOUSAND_TWENTY_FOUR;
                    byte[] buffer = new byte[bufSize];
                    int len = 0;
                    while (-1 != (len = in.read(buffer, 0, bufSize))) {
                        bos.write(buffer, 0, len);
                    }
                    if (map.getKey().equals("面试评价")) {
                        zos.putNextEntry(new ZipEntry(entry.getKey()));
                    } else {
                        zos.putNextEntry(new ZipEntry(map.getKey() + "/" + entry.getKey()));
                    }
                    zos.write(bos.toByteArray());
                    zos.closeEntry();
                    if (in != null) {
                        in.close();
                    }
                    if (bos != null) {
                        bos.close();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("下载简历出错", e);
        }
    }

    @RequestMapping(value = "/resume/isExist", method = RequestMethod.GET)
    @ApiOperation(value = "获取签退简历")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto findResume(@RequestParam Integer companyId,
                                @RequestParam Integer recruitmentId) throws IOException {
        try {
            Map<String, Map<String, FileInputStream>> data = hrLoginService.getSignOutEmail(companyId, recruitmentId);
            if (data == null) {
                return ResultDtoFactory.toAck("当前没有简历", false);
            } else {
                return ResultDtoFactory.toAck("获取成功", true);
            }
        } catch (Exception e) {
            LOGGER.error("获取简历失败", e);
            return ResultDtoFactory.toNack("获取简历失败", false);
        }
    }
}
