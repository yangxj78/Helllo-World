package com.hengtiansoft.servlet.admin.position.service.impl;

import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.mapper.PositionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PositionServiceImpl extends BaseService<Position> implements PositionService {

    @Autowired
    PositionMapper positionMapper;

    @Override
    public List<Position> search(PositionSearch positionSearch) {
        return positionMapper.search(positionSearch);
    }

    @Override
    public List<Position> getIDAndName(BoothSearch boothSearch) {
        return positionMapper.getIDAndName(boothSearch);
    }

    @Override
    public int add(PositionRecordDto positionRecordDto) {
        String name = SecurityContext.getCurrentUser().getUsername();
        positionRecordDto.setName(positionRecordDto.getName().trim());
        positionRecordDto.setUpdateBy(name);
        return positionMapper.add(positionRecordDto);
    }

    @Override
    public int updateByID(Position position) {
        String name = SecurityContext.getCurrentUser().getUsername();
        position.setUpdateBy(name);
        return positionMapper.updateByID(position);
    }

    @Override
    public Position selectByID(Integer id) {
        return positionMapper.selectByID(id);
    }

    @Override
    public int updateByCompanyID(Integer companyID) {
        return positionMapper.updateByCompanyID(companyID);
    }

}
