package com.hengtiansoft.servlet.applicant.resume.template.zhilian;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.ZhiLianResume;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ZhiLianTemplateOne extends ZhiLianResume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {
        content = filtercontent(content);
        String[] arr = content.split("(&nbsp;)+");
        String updateDate = getUpdateDate(content);
        String number = getNumber(content);
        String name = null;
        for (String str : arr) {
            if (str.contains("姓名")) {
                name = strSubstring(str, "姓名：", "工作年限");
                break;
            }
            if (str.contains("手机")) {
                name = strSubstring(str, number, "手机");
                break;
            }
            if (str.contains("当前状态")) {
                name = strSubstring(str, number, "当前状态");
                break;
            }
        }
        String year = getWorkedYears(content);
        String info = strSubstring(content, name, "工作经历");

        String[] infos = info.split("(&nbsp;)+");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        String birthDate = null;
        for (String str : infos) {
            if (str.contains("年龄")) {
                birthDate = strSubstring(str, "（", "）");
                if (!StringUtils.isEmpty(birthDate)) {
                    birthDate = preProcessBirthDate(birthDate);
                }
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (str.contains("目前居住：")) {
                city = strSubstring(str, "目前居住：", "国籍").replaceAll("现居住地：", "");
            }
        }
        r.setBirthDate(birthDate);
        r.setName(name);
        r.setUpdateDate(updateDate);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.ZHILIANUPLOAD);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        content = content.substring(content.indexOf("求职意向"), content.length());

        if (content.contains("工作经历 ")) {
            int index = content.length();
            if (content.contains("项目经验")) {
                index = content.indexOf("项目经验");
            } else if (content.contains("教育经历")) {
                index = content.indexOf("教育经历");
            }

            workExperience = content.substring(content.indexOf("工作经历 "), index);
        }
        if (content.contains("项目经历")) {
            int index = content.length();
            if (content.contains("教育经历")) {
                index = content.indexOf("教育经历");
            }

            projectExperience = content.substring(content.indexOf("项目经历"), index);
        }
        if (content.contains("教育经历")) {
            int index = content.length();
            education = content.substring(content.indexOf("教育经历"), index);
        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    public String preProcessBirthDate(String str) {
        String regex = "[0-9]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            if (sb.length() == 0) {
                sb.append(matcher.group());
            } else {
                sb.append("-").append(matcher.group());
            }
        }
        return sb.toString();
    }

    @Override
    public String getWorkedYears(String context) {
        Pattern yearsExg = Pattern.compile("工作年限：(\\d*)年");
        Matcher matcher = yearsExg.matcher(context);
        String years = "0";
        while (matcher.find()) {
            return fieldTrim(matcher.group(1));
        }
        return fieldTrim(years);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String post = null;
        String expectCity = null;
        String expectSalary = null;
        if (content.contains("求职意向")) {
            String jobObjective = content.substring(content.indexOf("求职意向"));
            post = strSubstring(jobObjective, "期望从事职业：", "期望从事行业：");
            expectCity = strSubstring(jobObjective, "期望工作地区：", "期望月薪：");
            expectSalary = strSubstring(jobObjective, "期望月薪：", "目前状况：");
        }
        expectSalary = StringUtils.isEmpty(expectSalary) || "不显示职位月薪范围".equals(expectSalary) ? "面议" : expectSalary;

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("教育经历")) {
            String eduExperience = content.substring(content.indexOf("教育经历") + BEGIN_OFF_SET_FOUR);
            eduExperience = StringUtils.substring(eduExperience,BEGIN_OFF_SET_ZERO, eduExperience.indexOf("自我评价"));

            String[] eduInfo = eduExperience.split("(&nbsp;)+", BEGIN_OFF_SET_FIVE);
            int subNum = 0;
            if (eduInfo[BEGIN_OFF_SET_ZERO].contains("-")) {
                subNum = 1;
            }
            graduateDate = eduInfo[NUM_SUB_ONE - subNum].substring(eduInfo[NUM_SUB_ONE - subNum].indexOf("-"))
                    .replace("-", "");
            if (!graduateDate.replace(".", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
            school = eduInfo[NUM_SUB_TWO - subNum];
            major = eduInfo[NUM_SUB_THREE - subNum];
            degree = eduInfo[NUM_SUB_FOUR - subNum].substring(BEGIN_OFF_SET_ZERO, BEGIN_OFF_SET_TWO);
        }
        String staffType = strSubstring(content, "期望工作性质：", "期望从事职业：");
        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setExpectSalary(expectSalary);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setStaffType(staffType);
    }
}
