package com.hengtiansoft.servlet.admin.reviewPosition.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.ReviewPositionDto;
import com.hengtiansoft.bean.tableModel.ReviewPositionRecord;
import com.hengtiansoft.common.service.Service;
import java.util.List;

public interface ReviewPositionService extends Service<ReviewPositionRecord> {

    List<ReviewPositionRecord> ls(ReviewPositionDto reviewPositionDto);
    ResultDto operation(Integer id , String suggestion, Integer type) throws Exception;
}
