package com.hengtiansoft.servlet.admin.bookBooth.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.BoothListDto;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.tableModel.BookBooth;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface BoothService   extends Service<BookBooth> {
    List<Company> check(BoothSearch boothSearch);

    int subscribe(BookBooth bookBooth);

    List<BoothListDto> list(BoothSearch boothSearch);

    int adjustBooth(BookBooth bookBooth);

    int cancelBooth(BookBooth bookBooth);

    int addPositionRecord(List<PositionRecordDto> positionRecordDtos);

    int updateByID(BookBooth bookBooth);

    ResultDto sendCaptcha(Integer recruitmentID);


    boolean isBoothed(Integer recruitmentId, Integer companyId, Integer boothId);

    Boolean checkBooth(Integer recruitmentID, Integer boothId);
    void notify(Integer boothID,Integer oldBoothID);

    BookBooth getById(Integer bookBoothID);
}

