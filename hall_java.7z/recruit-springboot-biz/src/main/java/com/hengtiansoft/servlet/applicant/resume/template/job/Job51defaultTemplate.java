package com.hengtiansoft.servlet.applicant.resume.template.job;

import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;

public class Job51defaultTemplate extends Job51Resume {

}
