package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.BoothListDto;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.tableModel.Booth;
import com.hengtiansoft.bean.tableModel.BookBooth;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface BoothMapper extends MyMapper<Booth> {
    List<BoothListDto> listBooth(BoothSearch boothSearch);
    int updateBooth(BookBooth bookBooth);

    int cancelBooth(BookBooth bookBooth);

    @Select("SELECT b.id FROM booth b WHERE b.ip = #{ip} LIMIT 1")
    Integer getBoothIdByIp(@Param(value = "ip") String ip);

    @Select("SELECT b.id FROM booth b WHERE b.tv_ip = #{ip} LIMIT 1")
    Integer getBoothIdByTvIp(@Param(value = "ip") String ip);

    @Select("SELECT b.ip FROM booth b WHERE b.id = #{boothId} LIMIT 1")
    String getIpByBoothId(Integer boothId);
@Select("select company_id from book_booth where recruitment_id =#{recruitmentID} and booth_id=#{boothId}")
    Integer
checkBooth(@Param("recruitmentID") Integer recruitmentID, @Param("boothId") Integer boothId);
}