package com.hengtiansoft.servlet.admin.common.service.impl;

import com.hengtiansoft.bean.dataModel.NumberDto;
import com.hengtiansoft.servlet.admin.common.service.UpdateNumberService;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UpdateNumberServiceImpl implements UpdateNumberService {


    @Autowired
    RecruitmentMapper recruitmentMapper;

    /**
     * @Description: 更新招聘会的企业数，发布职位数，和招聘人数 type 0增加 1 减少
     **/
    @Override
    public void updateRecruitmentNumber(NumberDto numberDto) {
        recruitmentMapper.updateRecruitmentNumber(numberDto);
    }

}
