package com.hengtiansoft.servlet.admin.common.service;

import com.hengtiansoft.bean.dataModel.NumberDto;

public interface UpdateNumberService {
    void updateRecruitmentNumber(NumberDto numberDto);
}
