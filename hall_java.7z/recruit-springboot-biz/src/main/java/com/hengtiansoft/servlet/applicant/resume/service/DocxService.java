package com.hengtiansoft.servlet.applicant.resume.service;

import org.docx4j.TextUtils;
import org.docx4j.TraversalUtil;
import org.docx4j.TraversalUtil.CallbackImpl;
import org.docx4j.XmlUtils;
import org.docx4j.jaxb.Context;
import org.docx4j.jaxb.NamespacePrefixMapperUtils;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.wml.Body;
import org.docx4j.wml.Document;
import org.docx4j.wml.Tr;
import org.jvnet.jaxb2_commons.ppp.Child;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.Writer;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DocxService {

    public static void extractText(Object o, Writer w) throws Exception {
        extractText(o, w, Context.jc);
    }

    public static void extractText(Object o, Writer w, JAXBContext jc) throws Exception {
        Marshaller marshaller = jc.createMarshaller();
        marshaller.marshal(o, new TextExtractor(w));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static void extractText(Object o, Writer w, JAXBContext jc, String uri, String local, Class declaredType)
            throws Exception {
        Marshaller marshaller = jc.createMarshaller();
        NamespacePrefixMapperUtils.setProperty(marshaller, NamespacePrefixMapperUtils.getPrefixMapper());
        marshaller.marshal(new JAXBElement(new QName(uri, local), declaredType, o), new TextExtractor(w));
    }

    public static byte[] extractByte(final InputStream is) throws Exception {
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(is);
        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
        org.docx4j.wml.Document wmlDocumentEl = (org.docx4j.wml.Document) documentPart.getContents();
        try (ByteArrayOutputStream oos = new ByteArrayOutputStream(); Writer out = new OutputStreamWriter(oos);) {
            extractText(wmlDocumentEl, out);
            return oos.toByteArray();
        }
    }

    public static byte[] extractByte(String path) throws Exception {
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(path));
        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
        org.docx4j.wml.Document wmlDocumentEl = (org.docx4j.wml.Document) documentPart.getContents();
        try (ByteArrayOutputStream oos = new ByteArrayOutputStream(); Writer out = new OutputStreamWriter(oos);) {
            extractText(wmlDocumentEl, out);
            return oos.toByteArray();
        }
    }

    @SuppressWarnings("deprecation")
    public static String extractText(final InputStream is) throws Exception {
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(is);
        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
        org.docx4j.wml.Document wmlDocumentEl = (org.docx4j.wml.Document) documentPart.getContents();
        return XmlUtils.marshaltoString(wmlDocumentEl, true);
    }

    public static String parseDocxTextContent(InputStream is) throws Exception {
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(is);
        MainDocumentPart mdp = wordMLPackage.getMainDocumentPart();
        Document wmlDocumentEl = (Document) mdp.getContents();
        Body body = wmlDocumentEl.getBody();
        TrFinder trFinder = new TrFinder();
        new TraversalUtil(body, trFinder);
        return trFinder.builder.toString();
    }

    @SuppressWarnings("deprecation")
    public static String extractText(String path) throws Exception {
        WordprocessingMLPackage wordMLPackage = WordprocessingMLPackage.load(new java.io.File(path));
        MainDocumentPart documentPart = wordMLPackage.getMainDocumentPart();
        org.docx4j.wml.Document wmlDocumentEl = (org.docx4j.wml.Document) documentPart.getContents();
        return XmlUtils.marshaltoString(wmlDocumentEl, true);
    }

    static class TextExtractor extends DefaultHandler {
        private Writer out;

        public TextExtractor(Writer out) {
            this.out = out;
        }

        public void characters(char[] text, int start, int length) throws SAXException {
            try {
                out.write(text, start, length);
            } catch (IOException e) {
                throw new SAXException(e);
            }
        }
    }
}

class TrFinder extends CallbackImpl {
    List<Child> sdtList = new ArrayList<Child>();
    StringBuilder builder = new StringBuilder("");
    Map<String, org.docx4j.wml.Tr> trMap = new HashMap<String, Tr>();

    public List<Object> apply(Object o) {
        if (o instanceof org.docx4j.wml.P) {
            org.docx4j.wml.P o1 = (org.docx4j.wml.P) o;
            StringWriter writer = new StringWriter();
            try {
                TextUtils.extractText(o1, writer);
                writer.append("\n");
                builder.append(writer);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }

    public void walkJAXBElements(Object parent) {
        List children = getChildren(parent);
        if (children != null) {
            for (Object o : children) {
                o = XmlUtils.unwrap(o);
                this.apply(o);
                if (this.shouldTraverse(o)) {
                    walkJAXBElements(o);
                }
            }
        }
    }
}
