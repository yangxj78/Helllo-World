package com.hengtiansoft.servlet.admin.recruitment.service;

import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.constant.CacheConstants;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;

public interface RecruitmentCacheService {

    @Cacheable(value = CacheConstants.CURRENTRECRUITMENT, unless = "#result == null", key = "'CURRENTRECRUITMENT'")
    Recruitment getCurrentRecruitment();

    @CacheEvict(value = CacheConstants.CURRENTRECRUITMENT, allEntries = true, key = "'CURRENTRECRUITMENT'")
    void flushCurrentRecruitment();

    @Cacheable(value = CacheConstants.CURRENTRECRUITMENT, key = "'CURRENTRECRUITMENT'")
    Recruitment updateCurrentRecruitment(Recruitment recruitment);
}
