package com.hengtiansoft.servlet.admin.company.service;

import com.hengtiansoft.bean.tableModel.CompanyPicture;
import com.hengtiansoft.common.service.Service;
import java.util.List;

public interface CompanyPictureService extends Service<CompanyPicture> {
    List<String> getPictures(Integer id);
}
