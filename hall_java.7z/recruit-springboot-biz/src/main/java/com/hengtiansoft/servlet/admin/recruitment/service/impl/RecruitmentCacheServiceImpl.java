package com.hengtiansoft.servlet.admin.recruitment.service.impl;

import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentCacheService;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class RecruitmentCacheServiceImpl implements RecruitmentCacheService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RecruitmentCacheServiceImpl.class);

    @Autowired
    RecruitmentMapper recruitmentMapper;

    @Override
    public Recruitment getCurrentRecruitment() {
        List<Recruitment> recruitments = recruitmentMapper.getCurrentRecruitment();
        if (CollectionUtils.isEmpty(recruitments)) {
            return null;
        }
        return recruitments.get(0);
    }

    @Override
    public void flushCurrentRecruitment() {
        LOGGER.debug("CurrentRecruitment Cache delete---------------------------------------------------");
    }

    @Override

    public Recruitment updateCurrentRecruitment(Recruitment recruitment) {
        return recruitment;
    }
}
