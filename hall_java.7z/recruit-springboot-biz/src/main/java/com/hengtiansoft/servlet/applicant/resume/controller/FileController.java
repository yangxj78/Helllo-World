package com.hengtiansoft.servlet.applicant.resume.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.ResumeDto;
import com.hengtiansoft.common.exception.*;
import com.hengtiansoft.servlet.applicant.resume.service.ExtendExchangeService2;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.fileupload.FileUploadException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

@Api(value = "简历批量导入", description = "restful风格")
@Controller
public class FileController {

    @Autowired
    private ExtendExchangeService2 ees;

    @Autowired
    private ResumeService resumeService;
    private static final Logger log = LoggerFactory.getLogger(FileController.class);

    @ApiOperation(value = "导入", httpMethod = "POST")
    @RequestMapping(value = "/uploadResume", method = RequestMethod.POST)
    public @ResponseBody
    ResultDto upload(@RequestPart MultipartFile file) {

        log.info("========================================");
        log.info("文件长度: " + file.getSize());
        log.info("文件类型: " + file.getContentType());
        log.info("文件名称: " + file.getName());
        log.info("文件原名: " + file.getOriginalFilename());
        log.info("========================================");
        try {

            ResumeDto resume = ees.uploadTemplate2Resume(Arrays.asList(file));


            return resumeService.createResume(resume,false);
        } catch (FileUploadException e) {
            log.error(e.getLocalizedMessage());
            return ResultDtoFactory.toNack("file upload exception");
        } catch (ParserException e) {
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            return ResultDtoFactory.toNack("templates formate error");
        } catch (CustomException e) {
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            return ResultDtoFactory.toNack(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getLocalizedMessage());
            return ResultDtoFactory.toNack("templates formate error");
        }
    }


}
