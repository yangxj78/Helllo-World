package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.dataModel.JobSeekerDto;
import com.hengtiansoft.bean.dataModel.ResumeSearchDto;
import com.hengtiansoft.bean.dataModel.ResumeSimpleDto;
import com.hengtiansoft.bean.tableModel.Resume;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResumeMapper extends MyMapper<Resume> {

    @SelectProvider(type = ResumeProvider.class, method = "selectSimpleResume")
    List<ResumeSimpleDto> selectSimpleResume(@Param(value = "resumeSearchDto") ResumeSearchDto resumeSearchDto,
                                             @Param(value = "userIds") List<Integer> userIds);


    /**
     * /**
     * 获取匹配的简历
     * @param userIds       用户ID集合
     * @param positionName
     * @param recruitmentId
     * @param companyId
     * @param boothId
     * @return List<JobSeekerDto> 简历的集合
     */
    List<JobSeekerDto> selectByMatch(@Param(value = "userIds") List<Integer> userIds,
                                     @Param(value = "positionName") String positionName,
                                     @Param(value = "recruitmentId") Integer recruitmentId,
                                     @Param(value = "companyId") Integer companyId,
                                     @Param(value = "boothId") Integer boothId,
                                     @Param(value = "positionRecordId") Integer positionRecordId,
                                     @Param(value = "index") Integer index,
                                     @Param(value = "limit") Integer limit);

   Integer check(@Param("recruitmentID") Integer recruitmentID,@Param("boothId")Integer boothId);

    void updateUserInfoId(IdUpDto dto);
    void updateResumeId(IdUpDto dto);
    void updateUserWorkId(IdUpDto dto);
    void updateUserProjectId(IdUpDto dto);
    void updateUserEduExpId(IdUpDto dto);
    void updateResumeDelPreId(IdUpDto dto);

    @Select("select count(id) from resume where user_id = #{userId} and status = 1")
    int countByUser(@Param("userId") int userId);


    @Update("update resume set status = 0 where id = #{id}")
    int deleteForApplicant(Integer id);
}