package com.hengtiansoft.servlet.admin.reviewPosition.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.ReviewPositionDto;
import com.hengtiansoft.bean.tableModel.ReviewPositionRecord;
import com.hengtiansoft.common.constant.ResultCode;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.admin.reviewPosition.service.ReviewPositionService;
import com.hengtiansoft.servlet.mapper.ReviewPositionRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@Transactional
public class ReviewPositionServiceImpl extends BaseService<ReviewPositionRecord> implements ReviewPositionService {

    //审核通过
    private static final int PASS = 0;
    //审核未通过
    private static final int FAIL = 1;
    @Autowired
    ReviewPositionRecordMapper reviewPositionRecordMapper;


    @Autowired
    BoothService boothService;

    @Autowired
    PositionRecordService positionRecordService;

    @Override
    public List<ReviewPositionRecord> ls(ReviewPositionDto reviewPositionDto) {
        if(reviewPositionDto.getStatus()==2){
            return reviewPositionRecordMapper.getRefuse(reviewPositionDto);
        }
        return reviewPositionRecordMapper.ls(reviewPositionDto);
    }

    @Override
    public ResultDto operation(Integer id, String suggestion, Integer type) throws Exception {
        if (type == PASS) {
            //通过审核
            PositionRecordDto positionRecordDto = reviewPositionRecordMapper.selectByID(id);
            String name = SecurityContext.getCurrentUser().getUsername();
            if (reviewPositionRecordMapper.operation(id, suggestion, 1) == 0) {
                return ResultDtoFactory.toNack("操作失败，该条记录状态已被变更！");
            }

            if (null == positionRecordDto.getId()) {
                positionRecordDto.setCreateBy(name);
                ResultDto result = positionRecordService.add(positionRecordDto);
                if (result.getCode().equals(ResultCode.NACK)) {
                    return result;
                }
            } else {
                positionRecordDto.setUpdateBy(name);
                if (positionRecordService.updatePositionRecord(positionRecordDto) == 0) {
                    return ResultDtoFactory.toNack("操作失败，该企业存在同名岗位！");
                }
            }

            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
            NettyClientUtil.notifyTv(positionRecordDto.getBoothID(), JSON.toJSONString(map));
            return ResultDtoFactory.toAck("操作成功！");
        } else if (type == FAIL) {
            int operation = reviewPositionRecordMapper.operation(id, suggestion, 2);
            if (operation == 0) {
                return ResultDtoFactory.toNack("操作失败，该条记录状态已被变更！");
            }
            //未通过审核
            return ResultDtoFactory.toAck("操作成功！");
        }
        return ResultDtoFactory.toAck("操作成功！");
    }
}
