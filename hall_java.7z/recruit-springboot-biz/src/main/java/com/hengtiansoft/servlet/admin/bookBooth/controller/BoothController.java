
/**
 * @Description: 展位controller
 **/
package com.hengtiansoft.servlet.admin.bookBooth.controller;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.tableModel.*;

import com.hengtiansoft.bean.dataModel.BoothListDto;
import com.hengtiansoft.bean.dataModel.BoothDto;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordSearch;


import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.company.service.impl.CompanyServiceImpl;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentCacheService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.manage.companySign.CompanySignService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/admin/booth")
@Api(value = "展位controller", description = "展位预订相关接口")
public class BoothController {
    private static final String HTTP_HEADER = "header";
    @Autowired
    BoothService boothService;

    @Autowired
    PositionService positionService;

    @Autowired
    PositionRecordService positionRecordService;

    @Autowired
    CompanyServiceImpl companyServiceImpl;
    @Autowired
    CompanySignService companySignService;
    @Autowired
    ResumeService resumeService;
    @Autowired
    RecruitmentService recruitmentService;
    @Autowired
    RecruitmentCacheService recruitmentCacheService;

    /**
     * @Description: 展位预定
     **/
    @RequestMapping(value = "/subscribe", method = RequestMethod.POST)
    @ApiOperation(value = "预订展位", notes = "必填 公司ID，招聘会ID，展位ID 预定展位操作人")
    @Transactional
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = HTTP_HEADER)})
    public ResultDto subscribeBooth(@RequestBody BookBooth bookBooth) {
        if (null == bookBooth.getRecruitmentID() || null == bookBooth.getCompanyID()) {
            return ResultDtoFactory.toNack("公司ID和招聘会ID不能为空！");
        }
        if (null == bookBooth.getBoothID()) {
            return ResultDtoFactory.toNack("展位Id不能为空！");
        }
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setRecruitmentID(bookBooth.getRecruitmentID());
        boothSearch.setboothID(bookBooth.getBoothID());
        //根据展位ID和招聘会ID查询是否已有企业预定展位
        List ls = boothService.check(boothSearch);
        if (ls.size() != 0) {
            return ResultDtoFactory.toNack("预定失败，展位已被预定！");
        }
        Recruitment recruitment = recruitmentService.getById(bookBooth.getRecruitmentID());
        if (recruitment.getStyle() == 1) {
            boothSearch.setboothID(null);
            List<Company> ls2 = boothService.check(boothSearch);
            if (ls2.size() != 0) {
                if (!ls2.get(0).getId().equals(bookBooth.getCompanyID())) {
                    return ResultDtoFactory.toNack("专场招聘会无法预订多家企业");
                }
            }
        }
        if (boothService.subscribe(bookBooth) > 0) {
            if (recruitment.getStartType() == 1) {
                Map map = new HashMap();
                map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
                NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
                NettyClientUtil.notifyHr(bookBooth.getBoothID(), JSON.toJSONString(map));
            }
            recruitmentCacheService.flushCurrentRecruitment();
            return ResultDtoFactory.toAck("预定成功！");
        }

        return ResultDtoFactory.toNack("预定失败！");
    }


    /**
     * @Description: 获取展位列表和关联的公司信息，status  ：0未被预定的 1已被预定的
     **/
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiOperation(value = "获取展位列表", notes = "必填 招聘会ID，状态： 0 未预订 1已预定")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = HTTP_HEADER)})
    public ResultDto listBooth(@RequestBody BoothSearch boothSearch) {
        if (null == boothSearch.getRecruitmentID()) {
            return ResultDtoFactory.toNack("招聘会ID不能为空！");
        }
        if (null == boothSearch.getStatus()) {
            return ResultDtoFactory.toNack("状态不能为空！");

        }
        return ResultDtoFactory.toAck("success", boothService.list(boothSearch));
    }

    /**
     * @Description: 调整展位
     **/
    @RequestMapping(value = "/adjust", method = RequestMethod.PUT)
    @ApiOperation(value = "调整展位", notes = "必填 招聘会ID，公司ID，展位ID，旧的展位ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = HTTP_HEADER)})
    @Transactional
    public ResultDto adjustBooth(@RequestBody BookBooth bookBooth) {
        BoothSearch search = new BoothSearch();
        search.setcompanyID(bookBooth.getCompanyID());
        search.setRecruitmentID(bookBooth.getRecruitmentID());
        search.setboothID(bookBooth.getOldboothID());
        List<Company> check = boothService.check(search);
        if (check.size() == 0) {
            return ResultDtoFactory.toNack("该公司未预定该展位");
        }
        if (null == bookBooth.getOldboothID()) {
            return ResultDtoFactory.toNack("旧的展位ID不能为空！");

        }
        if (!resumeService.check(bookBooth.getRecruitmentID(), bookBooth.getOldboothID())) {
            return ResultDtoFactory.toNack("展位已有人投递，无法调换");
        }
        if (!resumeService.check(bookBooth.getRecruitmentID(), bookBooth.getBoothID())) {
            return ResultDtoFactory.toNack("被调换展位已有人投递，无法调换");
        }
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setRecruitmentID(bookBooth.getRecruitmentID());
        boothSearch.setboothID(bookBooth.getBoothID());

        BoothSearch search2 = new BoothSearch();
        search2.setStatus(1);
        search2.setRecruitmentID(bookBooth.getRecruitmentID());
        search2.setboothID(bookBooth.getBoothID());
        List<BoothListDto> ls = boothService.list(search2);
        //公司签到信息查询
        CompanySign companySigns = companySignService.findOneByCon2(bookBooth.getBoothID(), bookBooth.getRecruitmentID(), null);
        //预投递简历查询
        List<ResumeDeliveryPre> resumeDeliveryPre = resumeService.findResumeDeliveryPre(bookBooth.getBoothID(), bookBooth.getRecruitmentID());
        if (null != resumeDeliveryPre) {
            for (ResumeDeliveryPre resumeDeliveryPre1 : resumeDeliveryPre) {
                resumeDeliveryPre1.setBoothId(bookBooth.getOldboothID());
                resumeService.updateResumeDeliveryPre1(resumeDeliveryPre1);
            }
        }
        if (companySigns != null) {

            companySigns.setBoothId(bookBooth.getOldboothID());
            companySignService.updateSelective(companySigns);

        }
        if (boothService.adjustBooth(bookBooth) > 0) {
            BookBooth bookBooth1 = new BookBooth();
            if (ls.size() != 0) {
                for (BoothListDto boothListDto : ls) {
                    bookBooth1.setId(boothListDto.getBookBoothID());
                    bookBooth1.setBoothID(bookBooth.getOldboothID());
                    bookBooth1.setRecruitmentID(bookBooth.getRecruitmentID());
                    boothService.updateByID(bookBooth1);
                }

            }
        }
        boothService.notify(bookBooth.getBoothID(), bookBooth.getOldboothID());
        return ResultDtoFactory.toAck("调整成功");

    }


    /**
     * @Description: 取消预订
     **/
    @RequestMapping(value = "/cancel", method = RequestMethod.POST)
    @ApiOperation(value = "取消展位", notes = "必填 招聘会ID，公司ID，展位ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = HTTP_HEADER)})
    public ResultDto cancelBooth(@RequestBody BookBooth bookBooth) {
        if (bookBooth.getRecruitmentID() == null || bookBooth.getCompanyID() == null || bookBooth.getBoothID() == null) {
            return ResultDtoFactory.toNack("公司，招聘会，展位ID不能为空");

        }
        if (!resumeService.check(bookBooth.getRecruitmentID(), bookBooth.getBoothID())) {
            return ResultDtoFactory.toNack("展位已经有人投递，无法取消！");
        }
        int i = boothService.cancelBooth(bookBooth);
        if (i == 1) {
            recruitmentCacheService.flushCurrentRecruitment();
            return ResultDtoFactory.toAck("取消成功！");
        }
        if (i == 2) {
            return ResultDtoFactory.toNack("展位签到中无法取消！");

        }
        return ResultDtoFactory.toNack("取消失败！");
    }


    /**
     * @Description: 根据展位id 公司id，招聘会id获取展位详情
     **/
    @RequestMapping(value = "/boothDetails", method = RequestMethod.POST)
    @ApiOperation(value = "获取展位详情", notes = "必填 招聘会ID，公司ID，展位ID")
    public ResultDto boothDetails(@RequestBody BoothSearch boothSearch) {
        BoothDto boothDto = new BoothDto();
        PositionSearch positionSearch = new PositionSearch();
        positionSearch.setCompanyID(boothSearch.getcompanyID());
        List<Position> ls2 = positionService.getIDAndName(boothSearch);
        boothDto.setPositions(ls2);
        PositionRecordSearch positionRecordSearch = new PositionRecordSearch();
        positionRecordSearch.setBoothID(boothSearch.getboothID());
        positionRecordSearch.setRecruitmentID(boothSearch.getRecruitmentID());
        List<PositionRecord> ls3 = positionRecordService.listPositionRecord(positionRecordSearch);

        boothDto.setPositionRecords(ls3);
        return ResultDtoFactory.toAck("success", boothDto);
    }

    @RequestMapping(value = "/sendCaptcha", method = RequestMethod.GET)
    @ApiOperation(value = "发送验证码", notes = "必填 招聘会ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = HTTP_HEADER)})
    public ResultDto sendCaptcha(@RequestParam Integer recruitmentID) {
        try {
            ResultDto resultDto = boothService.sendCaptcha(recruitmentID);
            return ResultDtoFactory.toAck("短信发送成功", resultDto);

        } catch (Exception e) {
            return ResultDtoFactory.toNack(e.getMessage());
        }
    }

    @RequestMapping(value = "/check", method = RequestMethod.GET)
    public ResultDto check(@RequestParam Integer recruitmentID, @RequestParam Integer boothId) {

        if (boothService.checkBooth(recruitmentID, boothId)) {
            return ResultDtoFactory.toAck("true");
        }
        return ResultDtoFactory.toAck("false");

    }
}