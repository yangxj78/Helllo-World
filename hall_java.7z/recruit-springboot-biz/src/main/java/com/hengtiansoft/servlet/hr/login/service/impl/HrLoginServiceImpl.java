package com.hengtiansoft.servlet.hr.login.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.EmailConstant;
import com.hengtiansoft.common.enumeration.*;
import com.hengtiansoft.common.util.DateTimeUtil;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.common.util.StringUtils;
import com.hengtiansoft.common.util.ZipUtils;
import com.hengtiansoft.common.utils.ExcelUtils;
import com.hengtiansoft.common.utils.WordUtils;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.common.service.SRegionService;
import com.hengtiansoft.servlet.admin.common.service.TagService;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.admin.template.service.TempletService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.hr.login.service.HrLoginService;
import com.hengtiansoft.servlet.manage.companySign.CompanySignService;
import com.hengtiansoft.servlet.manage.dict.DictService;
import com.hengtiansoft.servlet.manage.email.EmailService;
import com.hengtiansoft.servlet.mapper.*;
import io.netty.util.internal.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

/**
 * Created by linwu on 7/25/2018.
 */
@Service
public class HrLoginServiceImpl implements HrLoginService{

    private static final Logger LOGGER = LoggerFactory.getLogger(HrLoginService.class);

    @Autowired
    private CompanySignMapper companySignMapper;

    @Autowired
    private EmailService emailService;

    @Autowired
    private BoothService boothService;

    @Autowired
    private TempletService templetService;

    @Autowired
    private RecruitmentService recruitmentService;

    @Autowired
    private RecruitmentMapper recruitmentMapper;

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private BoothMapper boothMapper;

    @Autowired
    private ResumeService resumeService;

    @Autowired
    private DictService dictService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private SRegionService regionService;


    @Autowired
    private TagService tagService;

    @Override
    @Transactional
    public boolean signIn(CompanySign companySign, HRLoginDto HRLoginDto) {
        try {
            if (companySign == null) {
                return false;
            }
            //保存签到信息状态
            companySign.setStatus(SignInStatusEnum.SIGN_IN.getCode());
            if (HRLoginDto.getMealsNumber() != null) {
                companySign.setMealsNumber(HRLoginDto.getMealsNumber());
            }
            if (HRLoginDto.getIsPacking() != null) {
                companySign.setIsParking(HRLoginDto.getIsPacking());
            }
            if (companySign.getUpdateTs() == null) {
                companySign.setUpdateTs(new Date());
            }
            companySignMapper.updateByPrimaryKey(companySign);

            companySign.setNettyType(NettyInfoEnum.HR_SIGN_IN.getCode());
            NettyClientUtil.notifyTvHrSign(companySign.getBoothId(), JSON.toJSONString(companySign));
        } catch (Exception e) {
            LOGGER.error("签到失败", e);
            return false;
        }
        return true;
    }

    private InterviewExcelDataDto mapRevertTo(ResumeDto resumeDto, Map<String, String> map,
                                              Integer companyId, Integer recruitmentId) {

        UserEducationExperience educationExperience = resumeDto.getUserEducationExperienceList().get(0);

        InterviewExcelDataDto i = new InterviewExcelDataDto();
        i.setName(resumeDto.getUserInfo().getName());
        i.setBirthDate(resumeDto.getUserInfo().getBirthDate());
        i.setPositionRecordName(map.get("positionName"));
        i.setSex(resumeDto.getUserInfo().getSex().equals(0) ? "男" : "女");
        if (educationExperience != null) {
            i.setSchool(educationExperience.getSchool());
            i.setMajor(educationExperience.getMajor());
        }
        i.setWorkYears(dictService.findById(resumeDto.getResume().getWorkYears()).getDictValue());
        i.setEducational(dictService.findById(resumeDto.getUserInfo().getEducational()).getDictValue());
        List<InterViewResultDto> interViewResultDtos = new ArrayList<>();
        //获取面试结果
        List<ResumeDelivery> resumeDeliveries = resumeDeliveryMapper.findInterviewResultByParentId(
                recruitmentId,
                companyId,
                Integer.valueOf(String.valueOf(map.get("userId"))),
                Integer.valueOf(String.valueOf(map.get("positionId"))));

        for (ResumeDelivery rd : resumeDeliveries) {
            interViewResultDtos.add(new InterViewResultDto(
                    rd.getInterviewNum(),
                    InterviewResultEnum.getMap().get(rd.getInterviewResult()).getDesc(),
                    rd.getMatching(),
                    rd.getProfession(),
                    rd.getLearning(),
                    rd.getCommunicate(),
                    rd.getInterviewEvaluation()
            ));
        }
        i.setInterviewList(interViewResultDtos);
        return i;
    }

    @Override
    @Transactional
    public ResultDto signOut(String mail, Boolean sendFlag) {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();

            Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(companySign.getRecruitmentId());
            if (sendFlag) {
                //word简历
                Map<String, Map<String, FileInputStream>> data = new HashMap<>();
                //excel面试评价
                List<InterviewExcelDataDto> interviewExcelDataDtos = new ArrayList<>();

                //通过的简历
                data.put("通过的简历", getResumeInfoFile(companySign.getCompanyId(), companySign.getRecruitmentId(),
                        InterviewResultEnum.PASS.getCode(), interviewExcelDataDtos));

                //不通过的简历
                data.put("不通过的简历", getResumeInfoFile(companySign.getCompanyId(), companySign.getRecruitmentId(),
                        InterviewResultEnum.NOT_PASS.getCode(), interviewExcelDataDtos));

                //待定的简历
                data.put("待定的简历", getResumeInfoFile(companySign.getCompanyId(), companySign.getRecruitmentId(),
                        InterviewResultEnum.NOT_SURE.getCode(), interviewExcelDataDtos));


                //通过待定简历不为空，发送邮件
                if (!CollectionUtils.isEmpty(data.get("通过的简历")) || !CollectionUtils.isEmpty(data.get("待定的简历")) || !CollectionUtils.isEmpty(data.get("不通过的简历"))) {
                    //获取简历内容
                    String companyName = companyService.getById(companySign.getCompanyId()).getName();
                    String content = getContent(companyName, recruitment);

                    //Excel面试评价文件流
                    Map<String, FileInputStream> interviewExcelDataDtoMap = new HashMap<>();
                    //将面试评价信息转化成Excel
                    interviewExcelDataDtoMap.put("面试评价.xlsx", new FileInputStream(ExcelUtils.getInterviewEvaluationSummary(interviewExcelDataDtos)));
                    data.put("面试评价", interviewExcelDataDtoMap);

                    emailService.sendZipResumes(mail, recruitment.getName() + "简历信息及评价汇总", content,
                            "高新大厅简历.zip", data);
                }
            }
            companySign.setStatus(SignInStatusEnum.SIGN_OUT.getCode());
            companySignMapper.updateByPrimaryKey(companySign);

            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.HR_SIGN_OUT.getCode());
            NettyClientUtil.notifyTvHrSign(companySign.getBoothId(), JSON.toJSONString(map));
        } catch (Exception e) {
            LOGGER.error("签退失败", e);
            return ResultDtoFactory.toNack("签退失败, 邮箱可能错误");
        }
        return ResultDtoFactory.toAck("签退成功");
    }

    @Override
    public ResultDto suspend() {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            companySign.setStatus(SignInStatusEnum.SIGN_OUT.getCode());
            companySignMapper.updateByPrimaryKey(companySign);

            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.SUSPEND.getCode());
            NettyClientUtil.notifyTvHrSign(companySign.getBoothId(), JSON.toJSONString(map));
        } catch (Exception e) {
            LOGGER.error("暂停失败", e);
            return ResultDtoFactory.toNack("暂停失败");
        }
        return ResultDtoFactory.toAck("暂停成功");
    }

    @Override
    public Map<String, Map<String, FileInputStream>> getSignOutEmail(Integer companyId, Integer recruitmentId) {
        try {
            //word简历
            Map<String, Map<String, FileInputStream>> data = new HashMap<>();
            //excel面试评价
            List<InterviewExcelDataDto> interviewExcelDataDtos = new ArrayList<>();

            //通过的简历
            data.put("通过的简历", getResumeInfoFile(companyId, recruitmentId,
                    InterviewResultEnum.PASS.getCode(), interviewExcelDataDtos));

            //待定的简历
            data.put("待定的简历", getResumeInfoFile(companyId, recruitmentId,
                    InterviewResultEnum.NOT_PASS.getCode(), interviewExcelDataDtos));

            //不通过的简历
            data.put("待定的简历", getResumeInfoFile(companyId, recruitmentId,
                    InterviewResultEnum.NOT_SURE.getCode(), interviewExcelDataDtos));


            //通过待定简历不为空，发送邮件
            if (!CollectionUtils.isEmpty(data.get("通过的简历")) || !CollectionUtils.isEmpty(data.get("待定的简历")) || !CollectionUtils.isEmpty(data.get("不通过的简历"))) {
                //Excel面试评价文件流
                Map<String, FileInputStream> interviewExcelDataDtoMap = new HashMap<>();
                //将面试评价信息转化成Excel
                interviewExcelDataDtoMap.put("面试评价.xlsx", new FileInputStream(ExcelUtils.getInterviewEvaluationSummary(interviewExcelDataDtos)));
                data.put("面试评价", interviewExcelDataDtoMap);
                return data;
            } else {
                return null;
            }
        } catch (Exception e) {
            LOGGER.error("签退失败", e);
            return null;
        }
    }

    private Map<String, FileInputStream> getResumeInfoFile(Integer companyId, Integer recruitmentId, Integer type, List<InterviewExcelDataDto> interviewExcelDataDtos) {
        Map<String, FileInputStream> resumeInfoFileMap = new HashMap<>();
        try {
            List<Map<String, String>> resumeList = resumeDeliveryMapper.findResumeIdsAndUserIds(companyId, recruitmentId, type);

            for (Map<String, String> map : resumeList) {
                ResumeDto resumeDto = resumeService.findResume(Integer.valueOf(String.valueOf(map.get("resumeId"))),
                        Integer.valueOf(String.valueOf(map.get("userId"))));
                //放入待定简历
                if (null != resumeDto) {
                    resumeInfoFileMap.put(resumeDto.getUserInfo().getName() + " " + String.valueOf(map.get("positionName")).replace("/", "")
                            .replace("\\", "") + ApplicationConstant.SPOT_DOC, new FileInputStream(getResumeFile(resumeDto)));
                    //放入excel面试评价
                    interviewExcelDataDtos.add(mapRevertTo(resumeDto, map, companyId, recruitmentId));
                }
            }
        } catch (Exception e) {
            LOGGER.error("转换简历信息失败", e);
        }
        return resumeInfoFileMap;
    }

    private String getContent(String companyName, Recruitment recruitment) {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "\n" +
                "<head>\n" +
                "    <META http-equiv=Content-Type content=\"text/html; charset=GBK\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
                "    <title>杭州高新人才市场</title>\n" +
                "</head>\n" +
                "\n" +
                "<body style=\"margin:0;padding:10px\">\n" +
                "    <h1 style=\"font-size:24px\">" + companyName + "</h1>\n" +
                "    <p style=\"font-size:18px\">您好!</p>\n" +
                "    <div style=\"padding:20px 20px\">\n" +
                "        <p style=\"line-height:2\"> " + DateTimeUtil.dateFormatParse(recruitment.getDate(), DateTimeUtil.SIMPLE_YMD, DateTimeUtil.CHINA_YMD)
                + " 参加的“ " + recruitment.getName() + " ”中所有通过、待定的简历信息及面试评价汇总详情见附件。请查阅！</p>\n" +
                "        <p style=\"text-align:right\">杭州高新人才市场</p>\n" +
                "        <p style=\"text-align:right\"> " + DateTimeUtil.dateFormatToChinaYMD(new Date()) + " </p>\n" +
                "    </div>\n" +
                "</body>\n" +
                "\n" +
                "</html>";
    }

    @Override
    @Transactional
    public ResultDto saveSignCaptcha(List<CompanySignDto> CompanySignDtos) {
        String msg = validate(CompanySignDtos);
        if (msg != null) {
            return ResultDtoFactory.toNack(msg);
        }
        try {
            companySignMapper.insertList(revertEntity(CompanySignDtos));
        } catch (Exception e) {
            LOGGER.error("保存企业签到码失败", e);
            return ResultDtoFactory.toNack("保存企业签到码失败");
        }
        return ResultDtoFactory.toAck("保存企业签到码成功");
    }

    @Override
    public ResultDto getInfo() {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            Map<String,Object> rMap = new HashMap<String,Object>();
            companySign.setIsBoothed(boothService.isBoothed(companySign.getRecruitmentId(),
                    companySign.getCompanyId(), companySign.getBoothId()));
            companySign.setRecruitmentType(recruitmentMapper.selectByPrimaryKey(companySign.getRecruitmentId()).getStyle());
            rMap.put("info", companySign);
            return ResultDtoFactory.toAck("获取成功",rMap);
        } catch (Exception e) {
            LOGGER.error("获取失败", e);
            return ResultDtoFactory.toNack("获取失败");
        }

    }

    @Override
    public ResultDto<String> getHrLoginInfo(Integer recruitmentId, Integer companyId, Integer boothId) {
        try {
            CompanySign companySign = companySignMapper.findByIds(recruitmentId, companyId, boothId);
            if (companySign == null) {
                return ResultDtoFactory.toAck("获取成功", StringUtil.EMPTY_STRING);
            }
            return ResultDtoFactory.toAck("获取成功", StringUtil.isNullOrEmpty(companySign.getToken()) ?
                            StringUtil.EMPTY_STRING
                            :companySign.getToken());
        } catch (Exception e) {
            LOGGER.error("获取失败", e);
            return ResultDtoFactory.toNack("获取失败");
        }
    }

    @Override
    public Map<String, Object> findRecruitmentStatus(Integer type, String ip) {
        Map<String, Object> result = new HashMap<>();
        try {
            Recruitment recruitment = recruitmentService.getCurrentRecruitment();
            if (recruitment == null) {
                result.put("meals_number", -1);
                result.put("isStart", 0);
            } else {
                if (UserTypeEnum.HR.getCode().intValue() == type.intValue()) {
                    CompanySign companySign = companySignMapper.findByRecIdAndIp(recruitment.getId(), ip);
                    if (companySign != null) {
                        result.put("status", companySign.getStatus());
                    }
                } else if (UserTypeEnum.TV.getCode().intValue() == type.intValue()) {
                    CompanySign companySign = companySignMapper.findByRecIdAndTvIp(recruitment.getId(), ip);
                    if (companySign != null) {
                        result.put("company", companyService.getById(companySign.getCompanyId()));
                        result.put("templetBooth", templetService.getBy(recruitment.getId(), companySign.getBoothId()));
                    }
                }
                result.put("meals_number", recruitment.getMealsNumber());
                result.put("isStart", 1);
                result.put("recruitment", recruitment);
                result.put("type", recruitment.getStyle());
            }
        } catch (Exception e) {
            LOGGER.error("获取当前招聘会信息失败", e);
        }
        return result;
    }

    @Override
    public ResultDto<Map<String, Object>> getInterviewResultInfo(Integer companyId, Integer recruitmentId) {
        try {
            List<Integer> countList = resumeDeliveryMapper.findDeliveryInfo(companyId, recruitmentId);
            Map<String, Object> result = new HashMap<>();
            result.put("passNum", countList.get(2));
            result.put("notSureNum", countList.get(3));
            String mail = "hhdh@hengtiansoft.com";
            Company company = companyService.getById(companyId);
            if (null != company) {
                mail = company.getEmail();
            }
            result.put("mail", mail);
            return ResultDtoFactory.toAck("获取成功", result);
        } catch (Exception e) {
            return ResultDtoFactory.toNack("获取失败");
        }
    }

    @Override
    public ResultDto<Integer> getBoothId(String type, String ip) {
        Integer boothId = null;
        if (UserTypeEnum.HR.getDesc().equals(type)) {
            boothId = boothMapper.getBoothIdByIp(ip);
        } else if (UserTypeEnum.TV.getDesc().equals(type)) {
            boothId = boothMapper.getBoothIdByTvIp(ip);
        }
        if (boothId == null) {
            return ResultDtoFactory.toNack("获取失败, ip不存在");
        }
        return ResultDtoFactory.toAck("获取成功", boothId);
    }

    private File getResumeFile(ResumeDto resumeDto) {
        Map<String, Object> map = new HashMap<>();
        map.put("name", resumeDto.getUserInfo().getName());
        map.put("sex", StringUtils.nullToEmpty(resumeDto.getUserInfo().getSex()).equals("0") ? "男" : "女");
        map.put("birthdate", StringUtils.nullToEmpty(resumeDto.getUserInfo().getBirthDate()).replace(" 00:00:00", ""));
        map.put("phone", StringUtils.nullToEmpty(resumeDto.getUserInfo().getPhone()));
        map.put("email", StringUtils.nullToEmpty(resumeDto.getUserInfo().getEmail()));
        if (resumeDto.getResume() != null) {
            if (resumeDto.getResume().getWorkType() == null) {
                map.put("workType", StringUtil.EMPTY_STRING);
            } else {
                Tag tag = tagService.getByID(resumeDto.getResume().getWorkType());
                map.put("workType", tag != null ? tag.getName() : StringUtil.EMPTY_STRING);
            }
            if (resumeDto.getResume().getExpectedSalary() == null) {
                map.put("expectedSalary", StringUtil.EMPTY_STRING);
            } else {
                DictData dictData = dictService.findById(resumeDto.getResume().getExpectedSalary());
                map.put("expectedSalary", dictData != null ? dictData.getDictValue() : StringUtil.EMPTY_STRING);
            }
            if (resumeDto.getResume().getWorkTimeType() == null) {
                map.put("workTimeType", StringUtil.EMPTY_STRING);
            } else {
                DictData dictData = dictService.findById(resumeDto.getResume().getWorkTimeType());
                map.put("workTimeType", dictData != null ? dictData.getDictValue() : StringUtil.EMPTY_STRING);
            }
            if (resumeDto.getResume().getRegion() == null) {
                map.put("region", StringUtil.EMPTY_STRING);
            } else {
                SRegion sRegion = regionService.getByID(resumeDto.getResume().getRegion());
                map.put("region", sRegion != null ? sRegion.getShortName() : StringUtil.EMPTY_STRING);
            }
            map.put("selfIntroduction", StringUtils.nullToEmpty(resumeDto.getResume().getSelfIntroduction()));
        }

        List<Map<String, Object>> userEducationExperienceList = new ArrayList<>();
        List<UserEducationExperience> userEducationExperiences = resumeDto.getUserEducationExperienceList();
        if (!CollectionUtils.isEmpty(userEducationExperiences)) {
            for (UserEducationExperience userEducationExperience : userEducationExperiences) {
                Map<String, Object> userEducationExperienceMap = new HashMap<>();
                userEducationExperienceMap.put("startTs", StringUtils.nullToEmpty(userEducationExperience.getStartTs()).replace("-", ".").replace(" 00:00:00", ""));
                userEducationExperienceMap.put("endTs", StringUtils.nullToEmpty(userEducationExperience.getEndTs()).replace("-", ".").replace(" 00:00:00", ""));
                userEducationExperienceMap.put("school", StringUtils.nullToEmpty(userEducationExperience.getSchool()));
                userEducationExperienceMap.put("major", StringUtils.nullToEmpty(userEducationExperience.getMajor()));

                if (userEducationExperience.getEducational() == null) {
                    userEducationExperienceMap.put("educational", StringUtil.EMPTY_STRING);
                } else {
                    DictData dictData = dictService.findById(userEducationExperience.getEducational());
                    userEducationExperienceMap.put("educational", dictData != null ? dictData.getDictValue() : StringUtil.EMPTY_STRING);
                }

                userEducationExperienceList.add(userEducationExperienceMap);
            }
        }
        map.put("userEducationExperienceList", userEducationExperienceList);

        List<Map<String, Object>> userWorkExperienceList = new ArrayList<>();
        List<UserWorkExperience> userWorkExperiences = resumeDto.getUserWorkExperienceList();
        if (!CollectionUtils.isEmpty(userWorkExperiences)) {
            for (UserWorkExperience userWorkExperience : userWorkExperiences) {
                Map<String, Object> userWorkExperienceMap = new HashMap<>();
                userWorkExperienceMap.put("company", StringUtils.nullToEmpty(userWorkExperience.getCompany()));
                userWorkExperienceMap.put("job", StringUtils.nullToEmpty(userWorkExperience.getJob()));
                userWorkExperienceMap.put("startTs", StringUtils.nullToEmpty(userWorkExperience.getStartTs()).replace("-", ".").replace(" 00:00:00", ""));
                userWorkExperienceMap.put("endTs", StringUtils.nullToEmpty(userWorkExperience.getEndTs()).replace("-", ".").replace(" 00:00:00", ""));
                userWorkExperienceMap.put("description", StringUtils.nullToEmpty(userWorkExperience.getDescription()));
                userWorkExperienceList.add(userWorkExperienceMap);
            }
        }
        map.put("userWorkExperienceList", userWorkExperienceList);

        List<Map<String, Object>> userProjectExperienceList = new ArrayList<>();
        List<UserProjectExperience> userProjectExperiences = resumeDto.getUserProjectExperienceList();
        if (!CollectionUtils.isEmpty(userProjectExperiences)) {
            for (UserProjectExperience userProjectExperience : userProjectExperiences) {
                Map<String, Object> userProjectExperienceMap = new HashMap<>();
                userProjectExperienceMap.put("projectName", StringUtils.nullToEmpty(userProjectExperience.getProjectName()));
                userProjectExperienceMap.put("startTs", StringUtils.nullToEmpty(userProjectExperience.getStartTs()).replace("-", ".").replace(" 00:00:00", ""));
                userProjectExperienceMap.put("endTs", StringUtils.nullToEmpty(userProjectExperience.getEndTs()).replace("-", ".").replace(" 00:00:00", ""));
                userProjectExperienceMap.put("description", StringUtils.nullToEmpty(userProjectExperience.getDescription()));
                userProjectExperienceMap.put("duty", StringUtils.nullToEmpty(userProjectExperience.getDuty()));
                userProjectExperienceList.add(userProjectExperienceMap);
            }
        }
        map.put("userProjectExperienceList", userProjectExperienceList);
        try {
            return WordUtils.exportMillCertificateWord(map);
        } catch (IOException e) {
            LOGGER.error("解析简历出错", e);
            return null;
        }
    }

    private List<CompanySign> revertEntity(List<CompanySignDto> companySignDtos){
        List<CompanySign> CompanySigns = new ArrayList<>();
        for (CompanySignDto companySignDto: companySignDtos) {
            CompanySigns.add(new CompanySign(
                    companySignDto.getRecruitmentId(),
                    companySignDto.getCompanyId(),
                    companySignDto.getBoothId(),
                    companySignDto.getCaptcha(),
                    SignInStatusEnum.NULL.getCode(),
                    new Date()
            ));
        }
        return  CompanySigns;
    }

    private String validate(List<CompanySignDto> CompanySignDtos) {
        if (CollectionUtils.isEmpty(CompanySignDtos)) {
            return "签到信息不存在";
        }
        for (CompanySignDto CompanySignDto: CompanySignDtos) {
            if (CompanySignDto.getIp() == null) {
                return "IP不存在";
            }
            if (CompanySignDto.getRecruitmentId() == null) {
                return "招聘会不存在";
            }
            if (CompanySignDto.getCompanyId() == null) {
                return "企业不存在";
            }
            if (CompanySignDto.getBoothId() == null) {
                return "展位不存在";
            }
            if (CompanySignDto.getCaptcha() == null) {
                return "签到码不存在";
            }
        }
        return null;
    }

}
