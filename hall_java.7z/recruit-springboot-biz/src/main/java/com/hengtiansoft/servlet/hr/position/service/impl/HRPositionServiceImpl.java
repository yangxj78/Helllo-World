package com.hengtiansoft.servlet.hr.position.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.*;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.common.service.SRegionService;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.hr.position.service.HRPositionService;
import com.hengtiansoft.servlet.manage.dict.DictService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import com.hengtiansoft.servlet.mapper.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created by linwu on 7/25/2018.
 */
@Service
public class HRPositionServiceImpl implements HRPositionService {

    private static final Logger LOGGER = LoggerFactory.getLogger(HRPositionService.class);

    private static final int AUDIT_POSITION = 1;

    @Autowired
    private ReviewPositionRecordMapper reviewPositionRecordMapper;

    @Autowired
    private DictService dictService;

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private PositionRecordMapper positionRecordMapper;

    @Autowired
    private BookBoothMapper bookBoothMapper;

    @Autowired
    private ResumeMapper resumeMapper;

    @Autowired
    private SRegionService sRegionService;

    @Autowired
    private QrCodeMapper qrCodeMapper;

    @Autowired
    private SmsService smsService;

    @Autowired
    private UserInfoMapper userInfoMapper;

    @Autowired
    private PositionRecordService positionRecordService;

    @Autowired
    private CompanyService companyService;

    @Override
    public ResultDto<List<HRPositionRecordDto>> findPosition(Integer type, Integer status, Integer index, Integer limit) {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            List<HRPositionRecordDto> hrPositionRecordDtos;
            if (type == AUDIT_POSITION) {
                hrPositionRecordDtos = positionRecordMapper.findAuditPosition(companySign.getBoothId(),
                        companySign.getCompanyId(), companySign.getRecruitmentId(), status, index, limit);
            } else {
                hrPositionRecordDtos = positionRecordMapper.findCurrentPosition(companySign.getBoothId(),
                        companySign.getCompanyId(), companySign.getRecruitmentId(), index, limit);
            }
            if (CollectionUtils.isEmpty(hrPositionRecordDtos)) {
                return ResultDtoFactory.toAck("获取成功", new ArrayList<>());
            }
            return ResultDtoFactory.toAck("获取成功", analysisList(type, hrPositionRecordDtos));
        } catch (Exception e) {
            LOGGER.error("获取失败", e);
            return ResultDtoFactory.toNack("获取失败");
        }
    }

    @Override
    public ResultDto<List<JobSeekerDto>> findDeliveryList(Integer id, Integer index, Integer limit) {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            List<JobSeekerDto> jobSeekerDtos = positionRecordMapper.findDeliveryList(companySign.getCompanyId(), companySign.getRecruitmentId(), id, index, limit);

            revert(jobSeekerDtos);
            return ResultDtoFactory.toAck("获取成功", jobSeekerDtos);
        } catch (Exception e) {
            LOGGER.error("获取失败", e);
            return ResultDtoFactory.toNack("获取失败");
        }
    }

    @Override
    @Transactional
    public ResultDto<String> save(PositionRecordSaveDto positionRecordSaveDto) {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            ReviewPositionRecord reviewPositionRecord = new ReviewPositionRecord();
            reviewPositionRecord.setPositionRecordID(positionRecordSaveDto.getPositionRecordID());
            reviewPositionRecord.setRecruitmentID(companySign.getRecruitmentId());
            reviewPositionRecord.setCompanyID(companySign.getCompanyId());
            reviewPositionRecord.setBoothID(companySign.getBoothId());
            reviewPositionRecord.setName(positionRecordSaveDto.getName());
            reviewPositionRecord.setOldName(positionRecordSaveDto.getOldName());
            reviewPositionRecord.setEducationID(positionRecordSaveDto.getEducationId());
            reviewPositionRecord.setWorkingYearsID(positionRecordSaveDto.getWorkingYearsId());
            reviewPositionRecord.setSalaryID(positionRecordSaveDto.getSalaryId());
            reviewPositionRecord.setsRegionID(positionRecordSaveDto.getsRegionId());
            reviewPositionRecord.setProperty(positionRecordSaveDto.getProperty());
            reviewPositionRecord.setTagID(positionRecordSaveDto.getTagId());
            reviewPositionRecord.setRecruitNumber(positionRecordSaveDto.getRecruitNumber());
            reviewPositionRecord.setDescription(positionRecordSaveDto.getDescription());
            reviewPositionRecord.setStatus(AuditStatusEnum.NULL.getCode());
            reviewPositionRecord.setCreateTs(new Date());

            reviewPositionRecord.setBookBoothID(bookBoothMapper.findIdByCompanySign(
                    companySign.getRecruitmentId(),
                    companySign.getCompanyId(),
                    companySign.getBoothId()
            ));
            reviewPositionRecordMapper.insert(reviewPositionRecord);
            NettyClientUtil.notifyAdmin();
            return ResultDtoFactory.toAck("新增编辑成功");
        } catch (Exception e) {
            LOGGER.error("新增编辑失败", e);
            return ResultDtoFactory.toNack("新增编辑失败");
        }
    }

    @Override
    @Transactional
    public ResultDto<String> delete(Integer id) {
        if (resumeDeliveryMapper.countByPositionId(id) > 0) {
            return ResultDtoFactory.toNack("当前职位已被投递，不能删除");
        }
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();

            Integer bookboothId = bookBoothMapper.findIdByCompanySign(
                    companySign.getRecruitmentId(),
                    companySign.getCompanyId(),
                    companySign.getBoothId()
            );

            if (positionRecordService.deleteByID(bookboothId, id, companySign.getRecruitmentId()) > 0) {
                Map map = new HashMap();
                map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
                NettyClientUtil.notifyTv(companySign.getBoothId(), JSON.toJSONString(map));
            }
            return ResultDtoFactory.toAck("删除成功");
        } catch (Exception e) {
            LOGGER.error("删除失败", e);
            return ResultDtoFactory.toNack("删除失败");
        }
    }

    @Override
    public ResultDto<List<JobSeekerDto>> selectByMatch(Integer id, Integer index, Integer limit) {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        //查询在场用户
        List<Integer> userIds = qrCodeMapper.findCurrentUser(companySign.getRecruitmentId());
        if (CollectionUtils.isEmpty(userIds)) {
            return ResultDtoFactory.toAck("当前没有在场人员", new ArrayList<>());
        }

        //根据职位id，获取合适的简历
        PositionRecord positionRecord = positionRecordMapper.selectByPrimaryKey(id);
        List<JobSeekerDto> jobSeekerDtos = resumeMapper.selectByMatch(userIds, positionRecord.getName(),
                companySign.getRecruitmentId(), companySign.getCompanyId(), companySign.getBoothId(), id, index, limit);
        if (CollectionUtils.isEmpty(jobSeekerDtos)) {
            return ResultDtoFactory.toAck("没有匹配的简历", new ArrayList<>());
        }
        return ResultDtoFactory.toAck("获取成功", jobSeekerDtos);
    }

    @Override
    public ResultDto invite(InvitationDto invitationDto) {
        if (CollectionUtils.isEmpty(invitationDto.getUserIds())) {
            return ResultDtoFactory.toNack("没有人员符合岗位信息");
        }
        List<UserInfo> userInfos = userInfoMapper.selectByUserIds(invitationDto.getUserIds());
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        companySign.setCompanyName(companyService.getById(companySign.getCompanyId()).getName());
        try {
            for (UserInfo userInfo : userInfos) {
                SmsDto smsDto = new SmsDto();
                smsDto.setType(SmsTypeEnum.MATCHING.getCode());
                smsDto.setRecruitmentId(companySign.getRecruitmentId());
                smsDto.setCompanyId(companySign.getCompanyId());
                smsDto.setCompanyName(companySign.getCompanyName());
                smsDto.setTemplateCode(SmsTemplateCodeEnum.MATCHING.getCode());
                smsDto.setBoothId(companySign.getBoothId());
                smsDto.setMobile(userInfo.getPhone());
                smsDto.setUserId(userInfo.getUserId());
                smsDto.setName(userInfo.getName());
                smsDto.setSmsInfo("<" + companySign.getCompanyName() + "> 展位" + companySign.getBoothId() + ": " + "诚邀您来面试");
                smsService.sendMatching(smsDto);
            }
            return ResultDtoFactory.toAck("发送成功");
        } catch (Exception e) {
            LOGGER.error("发送失败", e);
            return ResultDtoFactory.toAck("发送失败");
        }

    }

    /**
     * 将字典id转成value
     *
     * @return List<HRPositionRecordDto>
     */
    private List<HRPositionRecordDto> analysisList(Integer type, List<HRPositionRecordDto> hrPositionRecordDtos) {
        for (HRPositionRecordDto hrPositionRecordDto : hrPositionRecordDtos) {
            hrPositionRecordDto = Optional.ofNullable(hrPositionRecordDto).orElse(new HRPositionRecordDto());
            hrPositionRecordDto.setWorkingYears(dictService.findById(hrPositionRecordDto.getWorkingYearsId()).getDictValue());
            hrPositionRecordDto.setSalary(dictService.findById(hrPositionRecordDto.getSalaryId()).getDictValue());
            hrPositionRecordDto.setWorkAddress(sRegionService.getByID(hrPositionRecordDto.getWorkAddressId()).getMergerName());
            hrPositionRecordDto.setWorkProperty(dictService.findById(hrPositionRecordDto.getProperty()).getDictValue());
            hrPositionRecordDto.setEducation(dictService.findById(hrPositionRecordDto.getEducationId()).getDictValue());
            Integer status = reviewPositionRecordMapper.getStatusByID(hrPositionRecordDto.getId());
            if (status != null) {
                hrPositionRecordDto.setAuditStatus(String.valueOf(status));
            }
            if (AUDIT_POSITION == type) {
                hrPositionRecordDto.setAuditStatus(
                        AuditStatusEnum.getMap()
                                .get(hrPositionRecordDto.getAuditStatusId())
                                .getDesc());
            }
        }
        return hrPositionRecordDtos;
    }

    private void revert(List<JobSeekerDto> jobSeekerDtos) {
        for (JobSeekerDto j : jobSeekerDtos) {
            j = Optional.ofNullable(j).orElse(new JobSeekerDto());
            j.setWorkingRegionName(sRegionService.getByID(j.getWorkingRegionId()).getMergerName());
            j.setEducationName(dictService.findById(j.getEducationId()).getDictValue());
            j.setWorkYears(dictService.findById(j.getWorkYearsId()).getDictValue());
            j.setInviteStatus(j.getIsInvited() == null ? InvitedStatusEnum.UNSOLICITED.getDesc() : InvitedStatusEnum.HAVE_BEEN_INVITED.getDesc());
        }
    }
}
