package com.hengtiansoft.servlet.admin.recruitmentType.service.impl;


import com.hengtiansoft.bean.tableModel.RecruitmentType;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.admin.recruitmentType.service.RecruitmentTypeService;
import com.hengtiansoft.servlet.mapper.RecruitmentTypeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RecruitmentTypeServiceImpl extends BaseService<RecruitmentType> implements RecruitmentTypeService {

    @Autowired
    RecruitmentTypeMapper recruitmentTypeMapper;


    @Override
    public List<RecruitmentType> getAll(String name) {
        return recruitmentTypeMapper.search(name);
    }

    @Override
    public RecruitmentType getRecruitmentTypeById(Integer id) {
        return recruitmentTypeMapper.selectByPrimaryKey(id);
    }

    @Override
    public int deleteRecruitmentTypeById(Integer id) {
        return recruitmentTypeMapper.deleteByPrimaryKey(id);
    }


    @Transactional
    @Override
    public int createRecruitmentType(RecruitmentType recruitmentType) {
        String name = SecurityContext.getCurrentUser().getUsername();
        recruitmentType.setCreateBy(name);
        recruitmentType.setUpdateBy(name);
        return recruitmentTypeMapper.insert(recruitmentType);
    }

    @Override
    public int updateRecruitmentType(RecruitmentType recruitmentType) {
        String name = SecurityContext.getCurrentUser().getUsername();
        recruitmentType.setUpdateBy(name);
        return recruitmentTypeMapper.updateByID(recruitmentType);
    }

}
