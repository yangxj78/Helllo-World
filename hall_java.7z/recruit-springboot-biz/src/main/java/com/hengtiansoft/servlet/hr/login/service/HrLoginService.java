package com.hengtiansoft.servlet.hr.login.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.CompanySignDto;
import com.hengtiansoft.bean.dataModel.HRLoginDto;
import com.hengtiansoft.bean.tableModel.CompanySign;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Map;

/**
 * Created by linwu on 7/25/2018.
 */
public interface HrLoginService {

    /**
     * 企业签到
     * @param companySign 企业签到码记录
     * @param HRLoginDto 企业签到信息
     * @return 是否成功
     */
    boolean signIn(CompanySign companySign, HRLoginDto HRLoginDto);


    /**
     * 企业签退
     * @return 结果类
     */
    ResultDto signOut(String mail, Boolean sendFlag);

    /**
     * 面试暂停
     * @return
     */
    ResultDto suspend();

    /**
     * 保存企业签到码
     * @param companySignDtos 企业签到信息类
     * @return 结果类
     */
    ResultDto saveSignCaptcha(List<CompanySignDto> companySignDtos);


    /**
     * 获取HR登录信息
     * @return
     */
    ResultDto<Map<String,Object>> getInfo();


    /**
     * TV端获取HR登录信息
     * @return
     */
    ResultDto<String> getHrLoginInfo(Integer recruitmentId, Integer companyId, Integer boothId);


    /**
     * 获取招聘会信息
     * @return
     */
    Map<String, Object> findRecruitmentStatus(Integer type, String ip);


    /**
     * 获取面试结果信息
     * @return
     */
    ResultDto<Map<String,Object>> getInterviewResultInfo(Integer companyId, Integer recruitmentId);


    /**
     * 获取当前展位ID
     * @return
     */
    ResultDto<Integer> getBoothId(String type, String ip);


    /**
     * 获取简历文件
     * @param companyId
     * @param recruitmentId
     * @return
     */
    Map<String, Map<String, FileInputStream>> getSignOutEmail(Integer companyId, Integer recruitmentId);

}
