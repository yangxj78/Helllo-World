package com.hengtiansoft.servlet.applicant.resume.template.liepin;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.LiePinResume;
import com.hengtiansoft.servlet.applicant.resume.template.custom.CustomDefaultTemplate;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LiePinTemplateThree extends LiePinResume {
    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);
        String updateDate = getUpdateDate(content);
        String name = strSubstring(content, "姓名：", "性别");
        String year = strSubstring(content, "工作年限：", "年");
        String number = getNumber(content);
        int age = getRealAge((strSubstring(content, "年龄：", "电子邮件")));
        SexEnum sex = SexEnum.MAN;
        if (strSubstring(content, "性别：", "手机号码").contains("女")) {
            sex = SexEnum.WOMAN;
        }
        String city = strSubstring(content, "所在地：", "目前职业概况").replaceAll("&nbsp;","");

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.LIEPINUPLOAD);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String selfIntroduce = null;
        List<UserWorkExperience> userWorkExperiences = new ArrayList<>();
        List<UserEducationExperience>userEducationExperiences = new ArrayList<>();
        List<String> works = new ArrayList<>();
        List<String> projects = new ArrayList<>();
        String[] arr = content.split("<span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;微软雅黑&quot;,&quot;sans-serif&quot;\">\r\n\\s*");
        if (arr.length == 1) {
            String str = "style='font-size:15.0pt;\\s*font-family:宋体;mso-ascii-font-family:STSong-Light;mso-fareast-font-family:\\s*宋体;mso-fareast-theme-font:minor-fareast;mso-hansi-font-family:STSong-Light;\\s*mso-bidi-font-family:STSong-Light;color:#404040;mso-font-kerning:1.0pt'>\r\n\\s*";
            arr = content.split(str);
        }
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                String[] workArray = str.split("<td width=78 valign=top style='width:78.0pt;background:#EAEAEA;padding:0cm 0cm 0cm 0cm'>");

                for (int i = 0; i < workArray.length; i++) {
                    workArray[i] = enterExperience(filterExperience(workArray[i]).replaceAll("&nbsp;"," "));
                }

                works = new ArrayList<>(Arrays.asList(workArray));

            }
            if (str.startsWith("项目经历")) {
                String[] projectArray = str.split("<td width=90 valign=top style='width:90pt;background:#EAEAEA;padding:0cm 0cm 0cm 0cm'>");

                for (int i = 0; i < projectArray.length; i++) {
                    projectArray[i] = enterExperience(filterExperience(projectArray[i]).replaceAll("&nbsp;"," "));
                }

                projects = new ArrayList<>(Arrays.asList(projectArray));

            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
            }
            if (str.startsWith("自我评价")) {
                selfIntroduce = filtercontent(str).replaceAll("自我评价(&nbsp;)*", "");
            }
        }

        education = enterExperience(education);

        r.setProjectExperienceList(StringList2UserProjectExperienceList(projects));
        r.setEducation(education);

        userEducationExperiences = decomposeEducation(education,ifLocalZJ(r.getCity()));

        r.setSelfIntroduction(selfIntroduce);
        r.setUserWorkExperienceList(StringList2UserWorkExperienceList(works));
        r.setUserEducationExperienceList(userEducationExperiences);
    }

    private List<UserProjectExperience> StringList2UserProjectExperienceList(List<String> projectList) {
        List<UserProjectExperience> projectExperiences = new ArrayList<>();

        for (String s : projectList) {
            s = s.replaceAll(" +", " ");
            if (s.startsWith("项目经历 <br/>")) {
                s = s.replaceFirst("项目经历\\s*<br/>", "");
            }

            if (s.startsWith("项目经历")) {
                continue;
            }

            UserProjectExperience temp = new UserProjectExperience();

            List<String> workDates = new ArrayList<>();
            String regex = "\\d{4}.\\d{1,2}[–-](\\d{4}.\\d{1,2}|至今)";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(s);
            while (matcher.find()) {
                workDates.add(matcher.group());
            }

            if (!workDates.isEmpty()) {
                temp.setStartTs(workDates.get(0).split("–")[0].replace(".","-"));
                temp.setEndTs(workDates.get(0).split("–")[1].replace(".","-"));
            }
            String[] strs = s.split(" +");
            temp.setProjectName(strs[2]);
            temp.setCompany(StringUtils.substringBetween(s, "所在公司：","项目简介"));
            temp.setDescription(StringUtils.substringBetween(s, "项目简介：","项目职责"));
            temp.setDuty(StringUtils.substringBetween(s, "项目职责：", "项目业绩"));
            projectExperiences.add(temp);
        }

        return projectExperiences;
    }

    private List<UserWorkExperience> StringList2UserWorkExperienceList(List<String> workList) {
        List<UserWorkExperience> workExperienceList = new ArrayList<>();

        for (String s : workList) {
            s = s.replaceAll(" +", " ");
            if (s.startsWith("工作经历 <br/>")) {
                s = s.replaceFirst("工作经历\\s*<br/>", "");
            }

            if (s.startsWith("工作经历")) {
                continue;
            }

            UserWorkExperience temp = new UserWorkExperience();

//            String[] strings = s.split("<br/>");

            List<String> workDates = new ArrayList<>();
            String regex = "\\d{4}.\\d{1,2}-(\\d{4}.\\d{1,2}|至今)";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(s);
            while (matcher.find()) {
                workDates.add(matcher.group());
            }

            if (!workDates.isEmpty()) {
                temp.setStartTs(workDates.get(0).split("-")[0].replaceAll("/","-"));
                temp.setEndTs(workDates.get(0).split("-")[1].replaceAll("/","-"));
            }
            String[] strs = s.split(" +");
            temp.setJob(strs[8]);
            temp.setCompany(strs[2]);
            temp.setDescription(s.replaceAll(" +"," "));
            workExperienceList.add(temp);
        }

        return workExperienceList;
    }

    private List<UserWorkExperience> decomposeWorkExperences(String workExperience){
        List<UserWorkExperience> userWorkExperienceList= new ArrayList<>();
        List<String> workExperienceLists = new ArrayList<>();
        //分解工作经历
        String regex = "<br/>";
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(workExperience);
        int index = 0;
        while(m.find()){
            String subString = workExperience.substring(index,m.start());
            index = m.end();
            workExperienceLists.add(subString);
        }
        String subString = workExperience.substring(index);
        workExperienceLists.add(subString);
        //解析工作经历具体内容
        for (String oneWorkExperence:workExperienceLists){
            UserWorkExperience userWorkExperience =  analysisWorkExperience(oneWorkExperence);
            userWorkExperienceList.add(userWorkExperience);
        }
        return userWorkExperienceList;
    }

    private UserWorkExperience analysisWorkExperience(String work){
        UserWorkExperience userWorkExperience = new UserWorkExperience();
        String job = "";
        String description;
        String startTs;
        String endTs;
        String company;
        String dateString = getEduDate(work);
        String work1 = work.substring(dateString.length());
        int index = dateString.indexOf("–");
        if(index < 0)
            index = dateString.indexOf("-");
        startTs = dateString.substring(0,index);
        endTs = dateString.substring(++index);
        index = work1.indexOf("公司 ");
        company = work1.substring(0,index+2);
        company = trim(company);
        Pattern pattern = Pattern.compile("\\s+(\\S+)\\s+所在地区");
        Matcher m = pattern.matcher(work1);
        while(m.find()){
            job = m.group(1);
        }
        if(!job.equals("")){
            description = work1.substring(index+2,work1.indexOf(job));
            description = trim(description);
        }else {
            description = work1.substring(index+2);
            description = trim(description);
        }
        userWorkExperience.setCompany(company);
        userWorkExperience.setDescription(description);
        userWorkExperience.setJob(job);
        startTs = changeDateFormat(startTs);
        endTs = changeDateFormat(endTs);
        userWorkExperience.setStartTs(startTs);
        userWorkExperience.setEndTs(endTs);
        return userWorkExperience;
    }

    private List<UserEducationExperience> decomposeEducation(String eductionExperience, int local){
        List<UserEducationExperience> userEducationExperiences = new ArrayList<>();
        List<String> educationList = new ArrayList<>();
        String regex = "是否统招：\\s*[是否]\\s*";
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(eductionExperience);
        int index = 0;
        while(m.find()){
            String subString = eductionExperience.substring(index,m.start());
            index = m.end();
            educationList.add(subString);
        }

        for (String eduExperience:educationList){
            if (StringUtils.isEmpty(eduExperience)) {
                continue;
            }
            UserEducationExperience userEducationExperience = analysisEducationExperience(eduExperience);
            userEducationExperience.setLocalZj(local);
            userEducationExperiences.add(userEducationExperience);
        }
        return userEducationExperiences;
    }

    private UserEducationExperience analysisEducationExperience(String educationExperience){
        UserEducationExperience userEducationExperience = new UserEducationExperience();
        String school;
        String educational = "";
        String major = "";
        String startTs = "";
        String endTs = "";
        String eduDate = getEduDate(educationExperience);
        if (eduDate.contains("至今")) {
            endTs = "至今";
        }
        else if (!"".equals(eduDate)) {
            int index = eduDate.indexOf("–");
            if(index < 0)
                index = eduDate.indexOf("-");
            startTs = eduDate.substring(0,index);
            endTs = eduDate.substring(++index);
        }
        int index = educationExperience.indexOf(eduDate);
        school = educationExperience.replaceAll("[（）()]","").substring(0,index);

        major = CustomDefaultTemplate.findMajorName(educationExperience);
        school = trim(school);
        startTs = changeDateFormat(startTs);
        endTs = changeDateFormat(endTs);
        userEducationExperience.setStartTs(startTs);
        userEducationExperience.setEndTs(endTs);
        userEducationExperience.setSchool(school);
        userEducationExperience.setMajor(major);
        userEducationExperience.setEducational(EducationalEnum.verifyEducation(educationExperience));
        return userEducationExperience;
    }

    private String trim(String str) {
        if (StringUtils.isEmpty(str)){
            return null;
        }
        char[] val = str.toCharArray();
        int st = 0;
        int len=val.length;
        //半角空格
        while ((st < len) && (val[st] <= ' ')) {
            st++;
        }
        while ((st < len) && (val[len - 1] <= ' ')) {
            len--;
        }
        //全角空格
        while ((st < len) && (val[st] <= '　')) {
            st++;
        }
        while ((st < len) && (val[len - 1] <= '　')) {
            len--;
        }
        return ((st > 0) || (len < val.length)) ? str.substring(st, len) : str;
    }
    private String changeDateFormat(String ts){
        if (StringUtils.isEmpty(ts)){
            return null;
        }
        if (ts.contains("/") || ts.contains(".")){
            return ts.replace("/","-").replace(".","-");
        }
        return ts;
    }
}
