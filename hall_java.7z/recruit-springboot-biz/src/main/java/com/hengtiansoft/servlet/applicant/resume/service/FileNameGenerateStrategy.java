package com.hengtiansoft.servlet.applicant.resume.service;

import java.io.File;

@FunctionalInterface
public interface FileNameGenerateStrategy {

	String nop();

	default public String generateFileName(String baseDir, String fileName) {
		return baseDir + File.separator + fileName;
	}
}
