package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;

public abstract class InternalResume extends BaseResume {

    @Override
    public void buildContactInfo(String content, HrResume r) {

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        String[] resumeAttrStr = content.split("_");
        String name = resumeAttrStr[MagicNumConstant.ZERO];
        String degree = resumeAttrStr[MagicNumConstant.ONE];
        String phone = resumeAttrStr[MagicNumConstant.TWO];

        String post = resumeAttrStr[MagicNumConstant.THREE];
        String expectCity = resumeAttrStr[MagicNumConstant.FOUR];
        String years;
        if (resumeAttrStr[MagicNumConstant.FIVE].contains("docx")) {
            years = resumeAttrStr[MagicNumConstant.FIVE].replace(".docx", "").replace("年", "");
        } else {
            years = resumeAttrStr[MagicNumConstant.FIVE].replace(".doc", "").replace(".pdf", "").replace("年", "");
        }
        int age = 0;

        SexEnum sex = SexEnum.MAN;
        ResumeSourceEnum sourceFrom = ResumeSourceEnum.INTERNAL;
        r.setName(name);
        r.setAge(age);
        r.setDegree(degree);
        r.setPhone(phone);
        r.setPhone(phone);
        r.setContent(content);
        r.setYears(years);
        r.setSex(sex);
        r.setSource(sourceFrom);

        r.setExpectCity(expectCity);
        r.setPost(post);

    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {

    }

}
