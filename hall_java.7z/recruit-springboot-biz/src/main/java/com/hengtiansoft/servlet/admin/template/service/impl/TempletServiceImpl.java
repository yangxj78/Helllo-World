package com.hengtiansoft.servlet.admin.template.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.tableModel.TempletBooth;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.template.service.TempletService;
import com.hengtiansoft.servlet.mapper.TempletBoothMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class TempletServiceImpl extends BaseService<TempletBooth> implements TempletService {

    @Autowired
    TempletBoothMapper templetBoothMapper;

    @Override
    @Transactional
    public Boolean configureTemplet(TempletBooth templetBooth) {
        List<Integer> booths = templetBooth.getBooths();
        Map map = new HashMap();
        map.put("nettyType", NettyInfoEnum.TEMPLET_UPDATE.getCode());
        for (Integer booth : booths) {
            templetBooth.setBoothId(booth);
            templetBoothMapper.config(templetBooth);
            NettyClientUtil.notifyTv(booth, JSON.toJSONString(map));
        }
        return true;
    }

    @Override
    public List<Integer> list(Integer recruitmentId, Integer templetId) {
        return templetBoothMapper.list(recruitmentId, templetId);
    }

    @Override
    public TempletBooth getBy(Integer recruitmentId, Integer boothId) {
        return templetBoothMapper.getBy(recruitmentId, boothId);
    }

    @Override
    public List<TempletBooth> listTemplet8(Integer recruitmentId) {
        return templetBoothMapper.listTemplet8(recruitmentId);
    }

    @Override
    public void setTemplet8(List<TempletBooth> templetBooths) {
        Map map = new HashMap();
        map.put("nettyType", NettyInfoEnum.TEMPLET_UPDATE.getCode());
        templetBooths.forEach(n -> {
            templetBoothMapper.config(n);
            NettyClientUtil.notifyTv(n.getBoothId(), JSON.toJSONString(map));
        });
    }
}
