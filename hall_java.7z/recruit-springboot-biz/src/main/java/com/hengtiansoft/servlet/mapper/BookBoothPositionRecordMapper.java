package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.tableModel.BookBoothPositionRecord;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;


@Repository
public interface BookBoothPositionRecordMapper extends MyMapper<BookBoothPositionRecord> {
    int updateOrder(PositionRecordDto positionRecordDto);
}