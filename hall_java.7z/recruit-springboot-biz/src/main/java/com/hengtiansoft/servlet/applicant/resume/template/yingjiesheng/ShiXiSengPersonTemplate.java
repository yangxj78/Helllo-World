package com.hengtiansoft.servlet.applicant.resume.template.yingjiesheng;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.servlet.applicant.resume.resume.ShiXiSengResume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.Date;

public class ShiXiSengPersonTemplate extends ShiXiSengResume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {
        Document document = Jsoup.parse(content);
        Element resumeElement = document.getElementsByClass("content").get(0);
        Element schoolEle = null;
        Elements infEles = resumeElement.getElementsByClass("inf");
        for (Element element : infEles) {
            if (filterHtml(element).contains("教育背景")) {
                schoolEle = element;
                break;
            }
        }
        String graduate = "";
        String school = "";
        String major = "";
        String degree = null;
        String city = "";
        if (schoolEle != null) {
            graduate = getElementTextByClassArray(schoolEle, "time");
            school = getElementTextByClassArray(schoolEle, "sec_p");
            major = getElementTextByClassArray(schoolEle, "thr_p");
            if (StringUtils.isNotBlank(major)) {
                if (major.contains("(") && major.contains(")")) {
                    degree = major.substring(major.indexOf("(") + 1, major.indexOf(")"));
                }
            }
            city = getElementTextByClassArray(schoolEle, "addr");
        }
        String newContent = content.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                .replaceAll("\r", "").replaceAll(" ", "");
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setUpdateDate(DateUtil.getDateFormate3(new Date()));
        r.setCity(city);
        r.setGraduateDate(graduate);
        r.setContent(newContent);
        r.setSource(ResumeSourceEnum.CAMPUS);
    }

    private String getElementTextByClassArray(Element element, String classs) {
        if (element.getElementsByClass(classs) != null && element.getElementsByClass(classs).size() > 0) {
            return element.getElementsByClass(classs).get(0).text();
        }
        return null;
    }

    @Override
    public void buildContactInfo(String content, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        Document document = Jsoup.parse(content);
        Element resumeElement = document.getElementsByClass("content").get(0);
        Elements elements = resumeElement.getElementsByClass("inf");
        String eduStr = "";
        String workExperienceStr = "";
        if (elements != null) {
            for (Element element : elements) {
                String text = filterHtml(element);
                if (text.contains("教育背景")) {
                    eduStr += text;
                } else if (text.contains("实习经历")) {
                    workExperienceStr += text;
                } else if (text.contains("学术经历")) {
                    workExperienceStr += text;
                } else if (text.contains("校园经历")) {
                    eduStr += text;
                } else if (text.contains("技能爱好")) {
                    eduStr += text;
                } else if (text.contains("作品展示")) {
                    eduStr += text;
                } else if (text.contains("个人评价")) {
                    eduStr += text;
                }
            }
        }
        if (StringUtils.isNotBlank(eduStr)) {
            r.setEducation(eduStr);
        }
        if (StringUtils.isNotBlank(workExperienceStr)) {
            r.setWorkExpirence(workExperienceStr);
        }
    }

    private String filterHtml(Element element) {
        return element.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "");
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

}
