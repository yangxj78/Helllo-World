package com.hengtiansoft.servlet.applicant.qrcode.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.ZJRecordDto;

public interface QrCodeService {

    ResultDto generateCompanyQrCode();

    ResultDto generateQrCode(Integer userId);

    boolean record(ZJRecordDto zjRecordDto);

    boolean resumeDelivery(Integer userId,Integer recruitmentId);

    boolean out();

    boolean hasRecord(Integer id);

    boolean hasSignIn(Integer userId, Integer positionRecordId);
}
