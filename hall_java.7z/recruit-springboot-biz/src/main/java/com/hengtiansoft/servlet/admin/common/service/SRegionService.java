package com.hengtiansoft.servlet.admin.common.service;

import com.hengtiansoft.bean.tableModel.SRegion;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface SRegionService extends Service<SRegion> {

    SRegion getByID(Integer id);

    List<SRegion> list(int i);
}
