package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;

public abstract class DaJieWangResume extends BaseResume {

    @Override
    public void buildContactInfo(String content, HrResume r) {

        String info = filtercontent(content);
        String email = getEmailAddress(info);
        String phone = getPhone(info);
        r.setEmail(email);
        r.setPhone(phone);

    }

    @Override
    public void buildOtherInfo(String s, HrResume r) {
        String content = filtercontent(s);
        content = content.substring(content.indexOf("求职意愿"), content.length()).trim();

        String[] infos = content.split("#");

        List<String> list = new ArrayList<String>();

        for (String str : infos) {
            if (!StringUtils.isBlank(str)) {
                list.add(str);
            }

        }

        String staffType = null;
        String expectCity = null;
        String expectSalary = null;
        String post = null;
        String englishLevel = null;
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i);
            if (str != null) {

                if (str.contains("工作类型")) {
                    staffType = list.get(i + 1);
                }
                if (str.contains("工作城市")) {
                    expectCity = list.get(i + 1);
                }
                if (str.contains("薪资范围")) {
                    expectSalary = list.get(i + 1);
                }
                if (r.getPost() == null && str.contains("职位类别")) {
                    post = list.get(i + 1);
                    if (post.contains("关于我")) {
                        post = null;
                    }
                    r.setPost(post);
                }

                if (str.contains("英语四级")) {
                    englishLevel = "英语四级";
                }
                if (str.contains("英语六级")) {
                    englishLevel = "英语六级";
                }
            }
        }

        r.setEngLevel(englishLevel);
        r.setExpectCity(expectCity);
        r.setExpectSalary(expectSalary);
        r.setStaffType(staffType);
    }

    private String[] degrees = { "中专", "大专", "本科", "研究生", "硕士", "博士", "博士后" };

    @Override
    public void buildExperienceInfo(String s, HrResume r) {

        String workExperience = null;
        String education = null;
        String strEdu = "教育经历";

        String content = filtercontent(s);
        content = content.substring(content.indexOf("求职意愿"), content.length()).trim();
        if (content.contains("工作经历")) {
            int endIndex = content.length();
            if (content.contains(strEdu)) {
                endIndex = content.indexOf(strEdu);
            }

            workExperience = content.substring(content.indexOf("工作经历"), endIndex).replaceAll("#", "");
        }
        if (content.contains(strEdu)) {
            education = content.substring(content.indexOf(strEdu), content.length()).replaceAll("#", "");
        }

        String degree = r.getDegree();
        if (StringUtils.isBlank(degree)) {
            for (String str : degrees) {
                if (education.contains(str)) {
                    degree = str;
                    r.setDegree(degree);
                    break;
                }

            }

        }

        if (StringUtils.isBlank(r.getSchool()) && content.contains(strEdu)) {

            String edu = content.substring(content.indexOf(strEdu), content.length()).trim();
            String[] edus = edu.split("#");
            for (String str : edus) {
                if (str.contains("学校") || str.contains("大学") || str.contains("学院")) {
                    if (StringUtils.isBlank(r.getMajor())) {
                        String[] ed = str.split(" ");
                        if (ed.length >= 2) {
                            r.setMajor(ed[0]);
                            if (!StringUtils.isBlank(degree)) {
                                r.setMajor(ed[0].replaceAll(degree, ""));
                            }
                            r.setSchool(ed[1]);
                        }

                    } else {
                        r.setSchool(str.substring(str.indexOf(r.getMajor()), str.length()).replaceAll(r.getMajor(), "")
                                .trim());
                    }
                    break;
                }

            }

        }

        r.setWorkExpirence(workExperience);
        r.setEducation(education);
    }

    @Override
    public void buildBaseInfo(String s, HrResume r) {

        r.setContent(s);
        String content = filtercontent(s);
        content = content.substring(0, content.lastIndexOf("求职意愿")).trim();

        String[] infos = content.split("#");

        List<String> list = new ArrayList<String>();

        for (String str : infos) {
            if (!StringUtils.isBlank(str)) {
                list.add(str);
            }

        }

        String name = list.get(0);
        String major = null;
        SexEnum sex = SexEnum.MAN;
        int age = getRealAge(list.get(MagicNumConstant.THREE));
        String year = "无";
        String city = null;
        String degree = null;
        String school = null;
        String post = null;
        for (int i = 0; i < list.size(); i++) {
            String str = list.get(i);
            if (str != null) {

                if (str.contains("女")) {
                    sex = SexEnum.WOMAN;
                }

                if (str.contains("所在城市")) {
                    city = list.get(i).replaceAll("所在城市", "").replaceAll("：", "");
                }
                if (str.contains("所在学校")) {
                    school = list.get(i).replaceAll("所在学校", "").replaceAll("：", "");
                }

                if (str.contains("学历")) {
                    degree = list.get(i).replaceAll("学历", "").replaceAll("：", "");
                }
                if (str.contains("专业")) {
                    major = list.get(i).replaceAll("专业", "").replaceAll("：", "");
                }

                if (str.contains("职位")) {
                    post = list.get(i).replaceAll("职位", "").replaceAll("：", "");
                }

                if (str.contains("工作经验")) {
                    String value = list.get(i);
                    if (!value.contains("学生")) {
                        year = value;
                    }
                }
            }

        }

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setSchool(school);
        r.setPost(post);
        r.setDegree(degree);
        r.setMajor(major);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.DAJIEUPLOAD);
    }

    public String filtercontent(String s) {
        String content = s.replaceAll("\n", "#").replaceAll("\r", "#").replaceAll("\\s*", "")
                .replaceAll("<style>.*?</style>", "").replaceAll("<.*?>", "").replaceAll("  ", "").replaceAll(" +", "");
        for (int i = 0; i < MagicNumConstant.TWENTY; i++) {
            content = content.replaceAll("###", "#");
        }
        content = content.replaceAll("##", "#");
        content = content.substring(0, content.lastIndexOf("中国职业社交网站缔造者"));
        return content;
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
    }
}
