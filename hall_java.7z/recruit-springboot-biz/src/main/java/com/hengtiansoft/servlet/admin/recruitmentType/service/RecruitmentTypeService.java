package com.hengtiansoft.servlet.admin.recruitmentType.service;

import com.hengtiansoft.bean.tableModel.RecruitmentType;
import com.hengtiansoft.common.service.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface RecruitmentTypeService extends Service<RecruitmentType> {
    List<RecruitmentType> getAll(String name);

    RecruitmentType getRecruitmentTypeById(Integer id);

    int deleteRecruitmentTypeById(Integer id);

    @Transactional
    int createRecruitmentType(RecruitmentType recruitmentType);

    int updateRecruitmentType(RecruitmentType recruitmentType);
}
