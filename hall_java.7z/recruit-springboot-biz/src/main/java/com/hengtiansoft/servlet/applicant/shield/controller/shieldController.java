package com.hengtiansoft.servlet.applicant.shield.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.tableModel.ShieldCompany;
import com.hengtiansoft.servlet.applicant.shield.service.ShieldService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Api(value = "屏蔽公司接口", description = "restful风格")
@RestController
@RequestMapping(value = "/applicant/shield")
public class shieldController {

    @Autowired
    ShieldService shieldService;

    @ApiOperation(value = "屏蔽公司", httpMethod = "POST", notes = "id不传")
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto add(@RequestBody List<ShieldCompany> shieldCompanys) {
        return shieldService.shieldCompany(shieldCompanys);
    }

    @ApiOperation(value = "删除屏蔽公司", httpMethod = "POST", notes = "根据ID删除已屏蔽公司")
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto delete(@RequestParam Integer id) {
        return shieldService.delete(id);
    }

    @ApiOperation(value = "获得屏蔽公司列表", httpMethod = "GET", notes = "传id")
    @RequestMapping(value = "/list/{id}", method = RequestMethod.GET)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto list(@PathVariable @ApiParam(name = "id", value = "简历ID", required = true) Integer id) {
        return shieldService.getShieldCompanyList(id);
    }

}
