package com.hengtiansoft.servlet.applicant.resume.service;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;

public interface ResumeBuilder {

    HrResume buildResume(String content);

    void buildBaseInfo(String content, HrResume r);

    void buildContactInfo(String content, HrResume r);

    void buildOtherInfo(String content, HrResume r);

    void buildExperienceInfo(String content, HrResume r);

    HrResume buildResume(MailContent mailContent);

    void buildBaseInfo(MailContent mailContent, HrResume r);

    void buildContactInfo(MailContent mailContent, HrResume r);

    void buildOtherInfo(MailContent mailContent, HrResume r);

    void buildExperienceInfo(MailContent mailContent, HrResume r);

}
