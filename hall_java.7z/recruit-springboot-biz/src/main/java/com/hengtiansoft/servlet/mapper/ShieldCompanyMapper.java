package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.CompanyDateDto;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.ShieldCompany;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ShieldCompanyMapper extends MyMapper<ShieldCompany> {
    List<ShieldCompany> getShieldCompanyList(int userId);

    int insertAll(@Param("list") List<ShieldCompany> list);

    List<CompanyDateDto> searchCompanyAndShield(@Param("resumeId") Integer userId, @Param("companySearch") String companySearch);
}
