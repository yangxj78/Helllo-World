package com.hengtiansoft.servlet.admin.position.service;

import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface PositionService extends Service<Position> {

    List<Position> search(PositionSearch positionSearch);
    List<Position> getIDAndName(BoothSearch boothSearch);
    int add(PositionRecordDto positionRecordDto);
    int updateByID(Position position);
    Position selectByID(Integer id);

    int  updateByCompanyID(Integer companyID);
}
