package com.hengtiansoft.servlet.applicant.resume.template.internal;

import com.hengtiansoft.servlet.applicant.resume.resume.InternalResume;

public class InternalDefaultTemplate extends InternalResume {

}
