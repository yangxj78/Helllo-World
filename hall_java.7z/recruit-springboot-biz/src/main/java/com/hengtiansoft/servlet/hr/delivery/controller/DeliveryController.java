package com.hengtiansoft.servlet.hr.delivery.controller;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.InterviewDeliveryDto;
import com.hengtiansoft.bean.dataModel.InterviewSearchDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.hr.delivery.service.DeliveryService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Api(value="分配投递管理", description = "分配投递管理相关接口")
@RestController
@RequestMapping("/hr/delivery")
public class DeliveryController {

    @Autowired
    DeliveryService deliveryService;

    @ApiOperation(value = "简历投递", httpMethod = "POST")
    @RequestMapping(value = "/postResume", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto postResume(@ApiParam(value = "简历投递", name = "resumeDeliveryDto") @RequestBody ResumeDeliveryDto resumeDeliveryDto) {
        return deliveryService.postResume(resumeDeliveryDto);
    }

    @ApiOperation(value = "分配展位", httpMethod = "POST")
    @RequestMapping(value = "/allotBooth/{type}/{boothId}/{resumeDeliveryId}", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<InterviewDeliveryDto> allotBooth(@ApiParam(value = "分配类型 0:排队时分配，1面试分配", name = "type") @PathVariable Integer type,
                                                      @ApiParam(value = "展位id", name = "boothId") @PathVariable Integer boothId,
                                                      @ApiParam(value = "投递id", name = "resumeDeliveryId") @PathVariable Integer resumeDeliveryId) {
        return deliveryService.allotBooth(type, boothId, resumeDeliveryId);
    }


    @ApiOperation(value = "获取分流记录", httpMethod = "POST")
    @RequestMapping(value = "/findAllotRecord", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<InterviewDeliveryDto>> findAllotRecord(@ApiParam(value = "查询信息", name = "interviewSearch") @RequestBody InterviewSearchDto searchDto) {
        return deliveryService.findAllotRecord(searchDto);
    }


}
