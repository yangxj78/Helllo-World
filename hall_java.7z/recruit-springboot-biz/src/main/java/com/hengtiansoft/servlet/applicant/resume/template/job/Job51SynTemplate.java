package com.hengtiansoft.servlet.applicant.resume.template.job;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.List;

public class Job51SynTemplate extends Job51Resume {

    public void buildBaseInfo(String content, HrResume r) {

        Document document = Jsoup.parse(content);
        String name = document.select("title").text();
        String updateDate = document.getElementById("lblResumeUpdateTime").text();
        String year = getWorkedYears(content);
        String number = document.getElementsByClass("icard").text().replaceAll("ID:", "");
        String email = document.getElementsByClass("m_com").text();
        content = filtercontent(content);

        int index = content.indexOf("最近工作");
        if (index == -1) {
            index = content.indexOf("更多信息");
        }
        String[] infos = content.substring(content.indexOf(name), index).split("\\|");
        int age = 0;
        String city = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
            }
            if (str.contains("现居住")) {
                city = str.replace("现居住", "");
            }
        }
        String sex = document.getElementsByClass("infr").text();
        if (sex.contains("女")) {
            r.setSex(SexEnum.WOMAN);
        } else {
            r.setSex(SexEnum.MAN);
        }

        r.setName(name);
        r.setEmail(email);
        r.setAge(age);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(document.removeClass("MenuContentCssFolder").html());
        r.setSource(ResumeSourceEnum.JOB51UPLOAD);
    }

    public void buildContactInfo(String content, HrResume r) {

        String phone = getPhone(content);
        r.setPhone(phone);
    }

    public void buildOtherInfo(String content, HrResume r) {
        Document document = Jsoup.parse(content);
        content = (document.getElementsByClass("box2").text() + document.getElementById("divInfo").text()).replaceAll(
                "　", "").replaceAll(" ", "");

        String post = strSubstring(content, "职能：", "工作类型：");
        if (content.contains("到岗时间：")) {
            post = strSubstring(content, "职能：", "到岗时间：");
        }
        if (!StringUtils.isEmpty(post) && post.contains("行业：")) {
            post = post.substring(BEGIN_OFF_SET_ZERO, post.indexOf("行业："));
        }
        if (StringUtils.isEmpty(post)) {
            post = strSubstring(content, "职位：", "专业：");
        }
        String school = strSubstring(content, "学校：", "学历/学位：");
        String major = strSubstring(content, "专业：", "学校：");
        String degree = strSubstring(content, "学历/学位：", BEGIN_OFF_SET_SIX, "学历/学位：", BEGIN_OFF_SET_EIGHT);
        String expectCity = strSubstring(content, "地点：", "职能：");
        String eduDate = strSubstring(content, "教育经历", school);
        String graduateDate = "";
        String englishLevel = getEnglishLevel(content);
        if (!StringUtils.isEmpty(eduDate)) {
            graduateDate = eduDate.substring(eduDate.indexOf("-")).replace("-", "");
            if (!graduateDate.replace("/", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
        }
        String expectSalary = strSubstring(content, "期望薪资：", "地点");
        expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
        String annualIncome = strSubstring(content, "目前年收入：", "(包含基本工资、补贴、奖金、股权收益等)");
        String staffType = strSubstring(content, "工作类型：", BEGIN_OFF_SET_FIVE, "工作类型：", BEGIN_OFF_SET_SEVEN);
        if (!StringUtils.isEmpty(staffType) && staffType.contains("/")) {
            staffType = strSubstring(content, "工作类型：", BEGIN_OFF_SET_FIVE, "工作类型：", BEGIN_OFF_SET_NINE);
        }
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setGraduateDate(graduateDate);
        r.setExpectSalary(expectSalary);
        r.setAnnualIncome(annualIncome);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = "";
        String projectExperience = "";
        String education = "";
        content = content.replaceAll("</td>", "##</td>");
        Document document = Jsoup.parse(content);
        List<Element> list = document.getElementById("divInfo").child(0).children();

        for (Element node : list) {
            String str = node.text();
            if (str.contains("工作经验")) {
                workExperience = str.replaceAll("##", "<w:p></w:p>");
            }
            if (str.contains("项目经验")) {
                projectExperience = str.replaceAll("##", "<w:p></w:p>");
                ;

            }
            if (str.contains("教育经历")) {
                education = str.replaceAll("##", "<w:p></w:p>");
                ;
            }

        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

}
