package com.hengtiansoft.servlet.admin.positionRecord.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.PositionRecordSearch;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface PositionRecordService extends Service<PositionRecord> {
    List<PositionRecord> listPositionRecord(PositionRecordSearch positionRecordSearch);

    ResultDto batchAdd(List<PositionRecordDto> positionRecordDtos);

    ResultDto add(PositionRecordDto positionRecordDto);

    int updatePositionRecord(PositionRecordDto positionRecordDto) throws Exception;

    int deleteByID(int bookBoothID, int positionRecordID, int recruitmentID);

    int updateOrder(PositionRecordDto positionRecordDto);
    PositionRecord getByID(int id);

    Boolean check(Integer positionID);
}
