package com.hengtiansoft.servlet.admin.recruitmentType.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.tableModel.RecruitmentType;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.admin.recruitmentType.service.RecruitmentTypeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/admin/recruitmentType")
@Api(value = "招聘会类型controller", description = "招聘会类型管理相关接口")

public class RecruitmentTypeController {

    @Autowired
    RecruitmentTypeService recruitmentTypeService;

    @Autowired
    RecruitmentService recruitmentService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getRecruitmentTypeList(@RequestParam(required = false) String name, @RequestParam(required = false) Integer pageSize, @RequestParam(required = false) Integer pageNum, @RequestParam(required = false) Integer isPage) {


        if (null!= isPage &&1 == isPage) {
            Integer pageNum2 = (pageNum == null ? 1 : pageNum);
            Integer pageSize2 = (pageSize == null ? MagicNumConstant.TEN : pageSize);
            PageHelper.startPage(pageNum2, pageSize2);
            return ResultDtoFactory.toAck("success", new PageInfo<>(recruitmentTypeService.getAll(name)));
        }

          return ResultDtoFactory.toAck("success", recruitmentTypeService.getAll(name));

    }


    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto deleteRecruitmentTypeById(@PathVariable Integer id) {
        if (recruitmentService.getRecruitmentByTypeId(id).size() != 0) {
            return ResultDtoFactory.toNack("删除失败，已有招聘会关联");
        }

        if (recruitmentTypeService.deleteRecruitmentTypeById(id) > 0) {
            return ResultDtoFactory.toAck("删除成功");
        }
        return ResultDtoFactory.toNack("删除失败");
    }

    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto createRecruitmentType(@RequestBody RecruitmentType recruitmentType) {
        if (null == recruitmentType.getName()) {
            return ResultDtoFactory.toNack("名字不能为空");
        }
        if (recruitmentTypeService.select(recruitmentType).size() != 0) {
            return ResultDtoFactory.toNack("招聘会类型已存在");

        }
        if (recruitmentTypeService.createRecruitmentType(recruitmentType) > 0) {
            return ResultDtoFactory.toAck("创建成功");
        }
        return ResultDtoFactory.toNack("创建失败");
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getRecruitmentTypeById(@PathVariable Integer id) {
        return ResultDtoFactory.toAck("success", recruitmentTypeService.getRecruitmentTypeById(id));
    }

    @RequestMapping(value = "/", method = RequestMethod.PUT)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto updateRecruitmentType(@RequestBody RecruitmentType recruitmentType) {
        if (null == recruitmentType.getId()) {
            return ResultDtoFactory.toNack("类型ID不能为空！");
        }

        if (recruitmentTypeService.updateRecruitmentType(recruitmentType) > 0) {
            return ResultDtoFactory.toAck("更新成功！");
        }
        return ResultDtoFactory.toNack("更新失败");

    }

}
