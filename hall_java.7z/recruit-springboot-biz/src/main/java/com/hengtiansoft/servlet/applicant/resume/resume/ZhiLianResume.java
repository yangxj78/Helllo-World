package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.common.utils.HttpRequest;
import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class ZhiLianResume extends BaseResume {

    public static final int BEGIN_OFF_SET_ZERO = 0;
    public static final int BEGIN_OFF_SET_TWO = 2;
    public static final int BEGIN_OFF_SET_FOUR = 4;
    public static final int BEGIN_OFF_SET_FIVE = 5;
    public static final int NUM_SUB_ONE = 1;
    public static final int NUM_SUB_TWO = 2;
    public static final int NUM_SUB_THREE = 3;
    public static final int NUM_SUB_FOUR = 4;

    @Override
    public void buildContactInfo(String content, HrResume r) {
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String post = null;
        String expectCity = null;
        String expectSalary = null;
        if (content.contains("求职意向")) {
            String jobObjective = content.substring(content.indexOf("求职意向"));
            post = strSubstring(jobObjective, "期望从事职业：", "期望从事行业：");
            expectCity = strSubstring(jobObjective, "期望工作地区：", "期望月薪：");
            expectSalary = strSubstring(jobObjective, "期望月薪：", "目前状况：");
        }
        expectSalary = StringUtils.isEmpty(expectSalary) || "不显示职位月薪范围".equals(expectSalary) ? "面议" : expectSalary;

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("教育经历")) {
            String eduExperience = content.substring(content.indexOf("教育经历"));

            String[] eduInfo = eduExperience.split("(&nbsp;)+", BEGIN_OFF_SET_FIVE);
            int subNum = 0;
            if (eduInfo[BEGIN_OFF_SET_ZERO].contains("-")) {
                subNum = 1;
            }
            graduateDate = eduInfo[NUM_SUB_ONE - subNum].substring(eduInfo[NUM_SUB_ONE - subNum].indexOf("-"))
                    .replace("-", "");
            if (!graduateDate.replace(".", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
            school = eduInfo[NUM_SUB_TWO - subNum];
            major = eduInfo[NUM_SUB_THREE - subNum];
            degree = eduInfo[NUM_SUB_FOUR - subNum].substring(BEGIN_OFF_SET_ZERO, BEGIN_OFF_SET_TWO);
        }
        String staffType = strSubstring(content, "期望工作性质：", "期望从事职业：");
        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setExpectSalary(expectSalary);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = {};
        if (content.contains("charset=utf-8")) {
            arr = content
                    .split("<span style='font-size:15.0pt;font-family:宋体;mso-ascii-font-family:\r\nCalibri;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:宋体;mso-fareast-theme-font:\r\nminor-fareast;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\r\nbackground:#D9D9D9;mso-shading:white;mso-pattern:gray-15 auto'>");

        } else if (content.contains("charset=unicode")) {
            arr = content
                    .split("<span lang=ZH-CN style='font-size:15.0pt;font-family:宋体;mso-ascii-font-family:\r\nCalibri;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:宋体;mso-fareast-theme-font:\r\nminor-fareast;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\r\nbackground:#D9D9D9;mso-shading:white;mso-pattern:gray-15 auto'>");
        }
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                workExperience = filterExperience(str).replaceFirst("工作经历(&nbsp;)*", "");
            }
            if (str.startsWith("项目经历")) {
                projectExperience = filterExperience(str).replaceFirst("项目经历(&nbsp;)*", "");
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    };

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);

        String[] arr = content.split("(&nbsp;)+");
        String updateDate = getUpdateDate(content);
        String number = getNumber(content);
        String name = null;
        for (String str : arr) {
            if (str.contains("手机")) {
                name = str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("手机"));
                break;
            }
            if (str.contains("当前状态")) {
                name = str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("当前状态"));
                break;
            }
        }
        String year = getWorkedYears(content);
        String info = strSubstring(content, name, "求职意向");

        String[] infos = info.split("(&nbsp;)+");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (str.contains("现居住地：")) {
                if (str.contains("|")) {
                    city = strSubstring(str, "现居住地：", "|").replaceAll("现居住地：", "");
                } else {
                    city = str.substring(str.indexOf("现居住地：") + BEGIN_OFF_SET_FIVE);
                }
            }
        }
        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.ZHILIANUPLOAD);
    }

    public String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<style>.*?</style>", "").replaceAll("<xml>.*?</xml>", "")
                .replaceAll("<.*?>", "").replaceAll("　", "").replaceAll(" ", "&nbsp;").replace("&amp;", "");
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

        String content = messageBody2String(mailContent);
        content = filtercontent(content);

        String[] postAndName = mailContent.getSubject().split("-");
        String post = null;
        String name = null;
        String city = null;
        if (postAndName.length == 3) {
            post = fieldTrim(postAndName[0].substring("(Zhaopin.com) 应聘 ".length()));
            city = fieldTrim(postAndName[1]);
            name = fieldTrim(postAndName[2]);
        }
        String year = getWorkedYears(content);
        String number = getNumber(content);

        String info = strSubstring(content, name, name + "要求您给出反馈后才展示联系方式");
        SexEnum sex = SexEnum.MAN;
        int age = getAge(info);
        if (info.contains("女")) {
            sex = SexEnum.WOMAN;
        }

        r.setPost(post);
        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.ZHILIANCOLLECT);

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        String request = "http://rd.zhaopin.com" + strSubstring(content, "http://rd.zhaopin.com", "\"");
        String[] reuqestUrl = request.split("\\?");
        String url = reuqestUrl[0];
        String param = reuqestUrl[1];
        String response = HttpRequest.sendGet(url, param);
        String phone = fieldTrim(this.getPhone(response));
        String email = this.getEmailAddress(response);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);

        String expectCity = null;
        String expectSalary = null;
        if (content.contains("求职意向")) {
            String jobObjective = content.substring(content.indexOf("求职意向"));
            expectCity = strSubstring(jobObjective, "期望工作地区：", "期望工作性质：");
            expectSalary = strSubstring(jobObjective, "期望月薪：", "目前状况：");
        }
        expectSalary = StringUtils.isEmpty(expectSalary) || "不显示职位月薪范围".equals(expectSalary) ? "面议" : expectSalary;

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("教育经历")) {
            String eduExperience = content.substring(content.indexOf("教育经历"));
            String[] eduInfo = eduExperience.split("(&nbsp;)+", BEGIN_OFF_SET_FIVE);
            String dateAndSchool = eduInfo[NUM_SUB_ONE];
            String eduDate = getEduDate(dateAndSchool);
            if (eduDate.contains("至今")) {
                graduateDate = "暂未毕业";
            }
            graduateDate = fieldTrim(eduDate.substring(eduDate.indexOf('-')).replace("-", ""));
            school = fieldTrim(dateAndSchool.replace(eduDate, ""));
            major = eduInfo[NUM_SUB_TWO];
            degree = eduInfo[NUM_SUB_FOUR].substring(BEGIN_OFF_SET_ZERO, BEGIN_OFF_SET_TWO);
        }
        String staffType = strSubstring(content, "期望工作性质：", "期望工作性质：");
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setGraduateDate(graduateDate);
        r.setExpectSalary(expectSalary);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {

        String content = messageBody2String(mailContent);

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = content.split("<span lang=\"ZH-CN\" style=\"font-size:10.5pt;color:white\">");

        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                workExperience = filterExperience(str).replaceFirst("工作经历(&nbsp;)*", "");
            }
            if (str.startsWith("项目经验")) {
                projectExperience = filterExperience(str).replaceFirst("项目经验(&nbsp;)*", "");
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    @Override
    public String getUpdateDate(String context) {
        Pattern updateDateRex = Pattern.compile("\\d{4}\\.\\d{2}.\\d{2}");
        Matcher matcher = updateDateRex.matcher(context);
        while (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    public int getAge(String context) {
        Pattern birthYearRex = Pattern.compile("\\d{4}年");
        Matcher matcher = birthYearRex.matcher(context);
        while (matcher.find()) {
            int birthYear = Integer.parseInt(matcher.group().replace("年", ""));
            return Calendar.getInstance().get(Calendar.YEAR) - birthYear;
        }
        return 0;
    }

}
