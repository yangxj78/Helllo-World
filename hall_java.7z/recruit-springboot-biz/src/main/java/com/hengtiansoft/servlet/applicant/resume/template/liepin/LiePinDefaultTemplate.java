package com.hengtiansoft.servlet.applicant.resume.template.liepin;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.LiePinResume;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LiePinDefaultTemplate extends LiePinResume {

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String selfIntroduce = null;
        List<UserEducationExperience>userEducationExperiences;
        List<String> works = new ArrayList<>();
        List<String> projects = new ArrayList<>();
        String[] arr = content.split("<span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:&quot;微软雅黑&quot;,&quot;sans-serif&quot;\">\r\n\\s*");
        if (arr.length == 1) {
            arr = content.split("<span lang=ZH-CN\r\n\\s*" +
                    "style='font-size:12.0pt;mso-bidi-font-size:11.0pt;font-family:\"微软雅黑\",\"sans-serif\"'>");
        }
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                //对工作经历所在职位的HTML元素做特殊处理
                str = str.replaceAll("</span></b><b\r\n" +
                        "\\s*style='mso-bidi-font-weight:normal'><span lang=ZH-CN style='mso-bidi-font-size:\r\n" +
                        "\\s*10.5pt;line-height:115%;font-family:宋体;mso-ascii-font-family:Tahoma;\r\n" +
                        "\\s*mso-hansi-font-family:Tahoma'>", "");
                String[] workArray = str.split("<td width=\"209\" colspan=\"3\" style=\"width:104.65pt;border:none;border-left:solid #FF9900 2.25pt;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;height:19.85pt\">\r\n" +
                        "\\s*<p class=\"MsoNormal\" style=\"margin-left:5.25pt;mso-para-margin-left:.5gd\">\r\n" +
                        "\\s*<span lang=\"EN-US\" style=\"font-family:&quot;Tahoma&quot;,&quot;sans-serif&quot;;mso-fareast-font-family:宋体\">");
                if (workArray.length <= 1) {
                    workArray = str.split("<p class=MsoNormal style='margin-left:5.25pt;mso-para-margin-left:.5gd'><span\r\n" +
                            "\\s*style='font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:宋体'>");
                }
                for (int i = 0; i < workArray.length; i++) {
                    workArray[i] = enterExperience(filterExperience(workArray[i]).replaceAll("&nbsp;"," ").replace(" 至今","至今"));
                }

                works = new ArrayList<>(Arrays.asList(workArray));

            }
            if (str.startsWith("项目经历")) {
                String[] projectArray = str.split("<td width=\\d* colspan=2 style='width:411.1pt;background:#F2F2F2;mso-background-themecolor:\r\n" +
                        "\\s*background1;mso-background-themeshade:242;padding:0in 5.4pt 0in 5.4pt;\r\n" +
                        "\\s*height:19.85pt'>\r\n" +
                        "\\s*<p class=MsoNormal><b style='mso-bidi-font-weight:normal'><span lang=ZH-CN\r\n" +
                        "\\s*style='font-family:宋体;mso-ascii-font-family:Tahoma;mso-hansi-font-family:\r\n" +
                        "\\s*Tahoma'>");
                if (projectArray.length <= 1) {
                    projectArray = str.split("<p class=MsoNormal style='margin-left:5.25pt;mso-para-margin-left:.5gd'><span\r\n" +
                            "\\s*style='font-family:\"Tahoma\",\"sans-serif\";mso-fareast-font-family:宋体'>");
                }
                if (projectArray.length <= 1) {
                    projectArray = str.split("<td width=\"822\" colspan=\"2\" style=\"width:411.1pt;background:#F2F2F2;mso-background-themecolor:background1;mso-background-themeshade:242;padding:0cm 5.4pt 0cm 5.4pt;height:19.85pt\">\r\n" +
                            "\\s*<p class=\"MsoNormal\">\r\n" +
                            "\\s*<b style=\"mso-bidi-font-weight:normal\">\r\n" +
                            "\\s*<span style=\"font-family:宋体;mso-ascii-font-family:Tahoma;mso-hansi-font-family:Tahoma\">");
                }
                for (int i = 0; i < projectArray.length; i++) {
                    projectArray[i] = enterExperienceForProjectName(filterExperience(projectArray[i]).replaceAll("&nbsp;"," ").replace(" 至今","至今"));
                }

                projects = new ArrayList<>(Arrays.asList(projectArray));
            }
            if (str.startsWith("教育经历")) {
                education = StringUtils.substringBefore(filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "")
                        .replaceAll("&nbsp;", " "), "语言能力");
            }
            if (str.startsWith("自我评价")) {
                selfIntroduce = filtercontent(str).replaceAll("自我评价(&nbsp;)*", "");
            }
        }

        r.setEducation(education);

        userEducationExperiences = decomposeEducation(education,ifLocalZJ(r.getCity()));

        r.setSelfIntroduction(selfIntroduce);
        r.setUserWorkExperienceList(StringList2UserWorkExperienceList(works));
        r.setProjectExperienceList(StringList2ProjectExperience(projects));
        r.setUserEducationExperienceList(userEducationExperiences);
    }

    private List<UserProjectExperience> StringList2ProjectExperience(List<String> projects) {
        List<UserProjectExperience> projectExperienceList = new ArrayList<>();

        for (String s : projects) {
            s = s.replaceAll(" +", " ");
            if (s.startsWith("项目经历 <br/>")) {
                s = s.replaceFirst("项目经历\\s*<br/>", "");
            }

            if (s.startsWith("项目经历")) {
                continue;
            }

            UserProjectExperience temp = new UserProjectExperience();

            String[] strings = s.split("<br/>");

            List<String> workDates = new ArrayList<>();
            String regex = "\\d{4}.\\d{1,2}-(\\d{4}.\\d{1,2}|至今)";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(strings[1]);
            while (matcher.find()) {
                workDates.add(matcher.group());
            }

            if (!workDates.isEmpty()) {
                temp.setStartTs(workDates.get(0).split("-")[0].replaceAll("\\.","-"));
                temp.setEndTs(workDates.get(0).split("-")[1].replaceAll("\\.","-"));
            }

            temp.setProjectName(strings[0].trim());
            temp.setDescription(StringUtils.substringBetween(strings[1], "项目描述：", "项目职责："));
            temp.setDuty(StringUtils.substringBetween(strings[1], "项目职责：", "项目业绩："));
            projectExperienceList.add(temp);
        }

        return projectExperienceList;
    }

    private List<UserWorkExperience> StringList2UserWorkExperienceList(List<String> workList) {
        List<UserWorkExperience> workExperienceList = new ArrayList<>();

        for (String s : workList) {
            s = s.replaceAll(" +", " ");
            if (s.startsWith("工作经历 <br/>")) {
                s = s.replaceFirst("工作经历\\s*<br/>", "");
            }

            if (s.startsWith("工作经历")) {
                 continue;
            }

            UserWorkExperience temp = new UserWorkExperience();

            String[] strings = s.split("<br/>");

            List<String> workDates = new ArrayList<>();
            String regex = "\\d{4}.\\d{1,2}-(\\d{4}.\\d{1,2}|至今)";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(strings[1]);
            while (matcher.find()) {
                workDates.add(matcher.group());
            }

            if (!workDates.isEmpty()) {
                temp.setStartTs(workDates.get(0).split("-")[0].replaceAll("\\.","-"));
                temp.setEndTs(workDates.get(0).split("-")[1].replaceAll("\\.","-"));
            }
            String[] strs = strings[0].replaceAll(" \\( ", "(").replaceAll(" \\) ", ")").split(" +");
            temp.setJob(strs[strs.length - 1]);
            temp.setCompany(strs[1]);
            temp.setDescription(StringUtils.substringAfter(strings[1].replaceAll(" +"," "), "职责业绩："));
            workExperienceList.add(temp);
        }

        return workExperienceList;
    }

    private List<UserEducationExperience> decomposeEducation(String eductionExperience, int local){
        List<UserEducationExperience> userEducationExperiences = new ArrayList<>();
        List<String> educationList = new ArrayList<>();
        String regex = "是否统招： [是否] ";
        Pattern pattern = Pattern.compile(regex);
        Matcher m = pattern.matcher(eductionExperience);
        int index = 0;
        while(m.find()){
            String subString = eductionExperience.substring(index,m.start());
            index = m.end();
            educationList.add(subString);
        }

        for (String eduExperience:educationList){
            if (StringUtils.isEmpty(eduExperience)) {
                continue;
            }
            UserEducationExperience userEducationExperience = analysisEducationExperience(eduExperience);
            userEducationExperience.setLocalZj(local);
            userEducationExperiences.add(userEducationExperience);
        }
        return userEducationExperiences;
    }

    private UserEducationExperience analysisEducationExperience(String educationExperience){
        UserEducationExperience userEducationExperience = new UserEducationExperience();
        educationExperience = educationExperience.replaceAll("&nbsp;", " ")
                .replaceAll(" +", " ");

        String school;
        String educational = "";
        String major = "";
        String startTs = "";
        String endTs = "";
        String eduDate = getEduDate(educationExperience);
        if (eduDate.contains("至今")) {
            endTs = "至今";
        }
        else if (!"".equals(eduDate)) {
            int index = eduDate.indexOf("–");
            if(index < 0)
                index = eduDate.indexOf("-");
            startTs = eduDate.substring(0,index);
            endTs = eduDate.substring(++index);
        }
        int index = educationExperience.indexOf(eduDate);
        school = educationExperience.replaceAll("[（）()]","").substring(0,index);
        String[] strings = educationExperience.replaceAll("[（）()]", "").split(" ");

        educational = strings[6];
        major = strings[4];
        school = trim(school);
        int degree = EducationalEnum.verifyEducation(educational);
        startTs = changeDateFormat(startTs);
        endTs = changeDateFormat(endTs);
        userEducationExperience.setStartTs(startTs);
        userEducationExperience.setEndTs(endTs);
        userEducationExperience.setSchool(school);
        userEducationExperience.setMajor(major);
        userEducationExperience.setEducational(degree);
        return userEducationExperience;
    }

    private String trim(String str) {
        if (StringUtils.isEmpty(str)){
            return null;
        }
        char[] val = str.toCharArray();
        int st = 0;
        int len=val.length;
        //半角空格
        while ((st < len) && (val[st] <= ' ')) {
            st++;
        }
        while ((st < len) && (val[len - 1] <= ' ')) {
            len--;
        }
        //全角空格
        while ((st < len) && (val[st] <= '　')) {
            st++;
        }
        while ((st < len) && (val[len - 1] <= '　')) {
            len--;
        }
        return ((st > 0) || (len < val.length)) ? str.substring(st, len) : str;
    }

    private String changeDateFormat(String ts){
        if (StringUtils.isEmpty(ts)){
            return null;
        }
        if (ts.contains("/") || ts.contains(".")){
            return ts.replace("/","-").replace(".","-");
        }
        return ts;
    }

    //分割项目经历的项目名称和其余字段
    private String enterExperienceForProjectName(String content) {
        String str = content;
        String br = "<br/>";
        Pattern exg = Pattern.compile("\\d{4}[/.]\\d{1,2}[–-](\\d{4}[/.]\\d{1,2}|至今)");
        if (!StringUtils.isEmpty(str)) {
            str = str.replace("&nbsp;至今", "至今");
            Matcher matcher = exg.matcher(str);
            while (matcher.find()) {
                str = str.replace(matcher.group(), br + matcher.group());
            }
            str = str.replaceAll("(<br/>){2,}", br).replace("&nbsp;", " ");
        }
        if (!StringUtils.isEmpty(str) && str.startsWith(br)) {
            str = str.replaceFirst(br, "");
        }
        return str;
    }
}
