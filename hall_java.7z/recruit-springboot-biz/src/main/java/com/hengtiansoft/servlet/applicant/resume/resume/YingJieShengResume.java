package com.hengtiansoft.servlet.applicant.resume.resume;


public abstract class YingJieShengResume extends BaseResume {

}
