package com.hengtiansoft.servlet.applicant.resume.template.zhilian;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.List;

public class ZhiLianPluginTemplate extends Job51Resume {

    public void buildBaseInfo(String content, HrResume r) {

    }

    public void buildContactInfo(String content, HrResume r) {

    }

    public void buildOtherInfo(String content, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = "";
        String projectExperience = "";
        String education = "";
        String staffType = "";

        Document document = Jsoup.parse(content);
        List<Element> list = document.getElementById("resumeContentBody").children();

        String sex = document.getElementsByClass("summary").text();
        if (sex.contains("女")) {
            r.setSex(SexEnum.WOMAN);
        } else {
            r.setSex(SexEnum.MAN);
        }

        for (Element node : list) {
            String str = node.toString();
            if (str.contains("工作经历")) {
                workExperience = str.replaceAll("<.*?>", "").replaceAll("&nbsp;", "").replaceFirst("工作经历", "")
                        .replaceAll("\r", "").replaceAll(" ", "").replaceAll("\n", TEMPLATE_CSS);
                workExperience = removeBr(workExperience);

            }
            if (str.contains("项目经历")) {
                projectExperience = str.replaceAll("<.*?>", "").replaceAll("&nbsp;", "").replaceFirst("项目经历", "")
                        .replaceAll("\r", "").replaceAll(" ", "").replaceAll("\n", TEMPLATE_CSS);

                projectExperience = removeBr(projectExperience);
            }
            if (str.contains("教育经历")) {
                education = str.replaceAll("<.*?>", "").replaceAll("&nbsp;", "").replaceFirst("教育经历", "")
                        .replaceAll("\r", "").replaceAll(" ", "").replaceAll("\n", TEMPLATE_CSS);
                education = removeBr(education);

            }
            if (str.contains("求职意向")) {
                if (str.contains("全职")) {
                    staffType = "全职";
                }
                if (str.contains("兼职")) {
                    staffType = "兼职";
                }

            }

        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
        r.setStaffType(staffType);
    }

}
