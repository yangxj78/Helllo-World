package com.hengtiansoft.servlet.applicant.recruitment.service.impl;

import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.EntranceTimeEnum;
import com.hengtiansoft.servlet.applicant.recruitment.service.CacheService;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class CacheServiceImpl implements CacheService {

    @Override
    //缓存出场记录
    @Cacheable(value = CacheConstants.ENTRANCETIME, key = "'ENTRANCETIME_'+ #recruitmentId")
    public Map<EntranceTimeEnum, Integer> getLastResultMap(Integer recruitmentId){
        return new LinkedHashMap<>();
    }

    @Override
    //更新出场记录
    @CachePut(value = CacheConstants.ENTRANCETIME, key = "'ENTRANCETIME_'+ #recruitmentId")
    public Map<EntranceTimeEnum, Integer> updateEntranceTimeMap(Integer recruitmentId, Map<EntranceTimeEnum, Integer> map) {
        return map;
    }

    @Override
    //获取上一次查询出场记录时的id号，用于增量查询
    @Cacheable(value = CacheConstants.ENTRANCETIME, key = "'QCR_'+ #recruitmentId")
    public Integer getIndexID(Integer recruitmentId) {
        return -1;
    }

    @Override
    //更新出场记录id
    @CachePut(value = CacheConstants.ENTRANCETIME, key = "'QCR_'+ #recruitmentId")
    public Integer updateIndexID(Integer recruitmentId ,Integer index) {
        return index;
    }
}
