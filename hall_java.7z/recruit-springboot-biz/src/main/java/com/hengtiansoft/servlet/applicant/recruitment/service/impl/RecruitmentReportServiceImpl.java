package com.hengtiansoft.servlet.applicant.recruitment.service.impl;

import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.QrCodeRecord;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.RecruitmentType;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.*;
import com.hengtiansoft.servlet.admin.company.service.CompanyPictureService;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.recruitment.service.CacheService;
import com.hengtiansoft.servlet.applicant.recruitment.service.RecruitmentReportService;
import com.hengtiansoft.servlet.mapper.QrCodeRecordMapper;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.util.*;

@Service
public class RecruitmentReportServiceImpl implements RecruitmentReportService {

    private static final int SPECIAL = 1;
    private static final int MULTIPLE = 0;
    private static final int ATTEND_TYPE = 1;
    private static final int LEAVE_TYPE = 2;
    private static final String VIDEO_TYPE = "/video/";
    private static final String PIC_Type = "/picture/";


    @Value("${ftp.host}")
    private String globalContext;

    @Autowired
    private RecruitmentMapper recruitmentMapper;

    @Autowired
    private RecruitmentService recruitmentService;

    @Autowired
    private CompanyService companyService;

    @Autowired
    private CompanyPictureService companyPictureService;

    @Autowired
    private QrCodeRecordMapper qrCodeRecordMapper;

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private CacheService cacheService;

    @Override
    public StatisticsDto getTotalCount(Recruitment recruitment) {
        List<AmountDto> amount = new ArrayList<>();
        amount.add(new AmountDto("入场人数", recruitmentService.getAttendOrLeaveNumber(ATTEND_TYPE, recruitment.getId())));
        if (recruitment.getStyle() == MULTIPLE) {
            amount.add(new AmountDto("出场人数", recruitmentService.getAttendOrLeaveNumber(LEAVE_TYPE, recruitment.getId())));
            amount.add(new AmountDto("招聘企业数", recruitment.getCompanyNumber()));
        }
        amount.add(new AmountDto("招聘岗位数", recruitment.getPositionNumber()));
        amount.add(new AmountDto("用工需求数目", recruitment.getRecruitNumber()));
        amount.add(new AmountDto("简历投递数", resumeDeliveryMapper.getDeliveryCount(recruitment.getId())));

        return new StatisticsDto("综合统计", amount);
    }

    @Override
    public StatisticsDto getEducationCount(Recruitment recruitment) {
        Timestamp today = new Timestamp(System.currentTimeMillis());
        List<AmountDto> amount = recruitmentMapper.getEducationCount(recruitment.getId(), today);

        //根据EducationalEnum对查询出来的记录进行排序
        amount.sort((o1, o2) -> {
            EducationalEnum enum1 = EducationalEnum.getMap().get(Integer.parseInt(o1.getName()));
            EducationalEnum enum2 = EducationalEnum.getMap().get(Integer.parseInt(o2.getName()));
            if (enum1 == null || enum2 == null) {
                return 0;
            }
            return enum1.compareTo(enum2);
        });

        int count = 0;
        for (AmountDto dto : amount) {
            //将数据数值改成相应的学历
            dto.setName(EducationalLevelEnum.getMap().get(Integer.parseInt(dto.getName())).getDesc());
            if (dto.getName().equals(EducationalLevelEnum.UNLIMITED.getDesc())) {
                dto.setName("其他");
            }
            count = count + dto.getValue();
        }

        //计算各类学历的所占百分比
        int temp = 0;
        for (int i = 0; i < amount.size(); i++) {
            AmountDto dto = amount.get(i);
            if (i == amount.size() - 1) {
                dto.setValue(100 - temp);
                break;
            }

            temp = temp + 100 * dto.getValue() / count;
            dto.setValue(100 * dto.getValue() / count);
        }
        return new StatisticsDto("入场人员学历分布", amount);
    }

    @Override
    public StatisticsDto getAgeCount(Recruitment recruitment) {
        List<AmountDto> amount = new ArrayList<>();

        Timestamp today = new Timestamp(System.currentTimeMillis());
        List<Date> birthDateList = recruitmentMapper.getPresentBirthDate(recruitment.getId(), today);
        HashMap<AgeScopeEnum, Integer> tempMap = new HashMap<>();
        for (Date birthDate : birthDateList) {
            AgeScopeEnum ageScope = AgeScopeEnum.DetermineScope(birthDate);
            //对数据对应到AgeScopeEnum
            if (ageScope != AgeScopeEnum.UNLIMITED) {
                tempMap.put(ageScope, (tempMap.get(ageScope) == null ? 1 : tempMap.get(ageScope) + 1));
            }
        }

        //对map内容进行排序
        ArrayList<Map.Entry<AgeScopeEnum, Integer>> list = new ArrayList<>(tempMap.entrySet());
        list.sort(Comparator.comparing(Map.Entry::getKey));

        for (Map.Entry<AgeScopeEnum, Integer> entry : list) {
            amount.add(new AmountDto(entry.getKey().getDesc(), entry.getValue()));
        }
        return new StatisticsDto("入场人员年龄分布", amount);
    }

    @Override
    public StatisticsDto getEntranceTime(Recruitment recruitment) {
        return updateEntranceTime(recruitment.getId(), recruitment.getAppearances());
    }

    /**
     * 获取入场人数时间分布
     *
     * @param recruitmentId
     * @return StatisticsDto
     */
    private StatisticsDto updateEntranceTime(Integer recruitmentId, Integer appearance) {
        // 获取增量id 走缓存
        int index = cacheService.getIndexID(recruitmentId);

        //获取增量数据集
        Timestamp today = new Timestamp(System.currentTimeMillis());
        List<QrCodeRecord> qrCodeRecords = qrCodeRecordMapper.findQCRByIndex(recruitmentId, index, today);

        //数据处理返回最新的map结果集
        Map<EntranceTimeEnum, Integer> tempMap = getLatestResultMap(recruitmentId, qrCodeRecords, appearance);

        //map 结果集排序
        List<Map.Entry<EntranceTimeEnum, Integer>> entryList = new ArrayList<>(tempMap.entrySet());
        entryList.sort(Comparator.comparing(Map.Entry::getKey));

        Map<EntranceTimeEnum, Integer> resultMap = new LinkedHashMap<>();
        for (Map.Entry<EntranceTimeEnum, Integer> entry : entryList) {
            resultMap.put(entry.getKey(), entry.getValue());
        }

        //更新map缓存
        cacheService.updateEntranceTimeMap(recruitmentId, resultMap);

        //更新index缓存
        if (qrCodeRecords.size() > 0) {
            cacheService.updateIndexID(recruitmentId, qrCodeRecords.get(qrCodeRecords.size() - 1).getId());
        }

        List<Map.Entry<EntranceTimeEnum, Integer>> list = new ArrayList<>(tempMap.entrySet());
        list.sort(Comparator.comparing(Map.Entry::getKey));

        //组装dto对象
        List<AmountDto> amount = new ArrayList<>();

        //判断招聘会是是否为全天展
        if (appearance == 2) {
            Map<EntranceTimeForAllDayEnum, Integer> allDayMap = new LinkedHashMap<>();
            for (Map.Entry<EntranceTimeEnum, Integer> entry : resultMap.entrySet()) {
                int code = entry.getKey().getCode() / 2;
                EntranceTimeForAllDayEnum tempEnum = EntranceTimeForAllDayEnum.getMap().get(code);
                allDayMap.put(tempEnum, allDayMap.get(tempEnum) != null ? allDayMap.get(tempEnum) + entry.getValue() : entry.getValue());
            }

            for (Map.Entry<EntranceTimeForAllDayEnum, Integer> entry : allDayMap.entrySet()) {
                amount.add(new AmountDto(entry.getKey().getDesc(), entry.getValue()));
            }
        } else {
            for (Map.Entry<EntranceTimeEnum, Integer> entry : resultMap.entrySet()) {
                amount.add(new AmountDto(entry.getKey().getDesc(), entry.getValue()));
            }
        }

        return new StatisticsDto("入场人员时间段分布", amount);
    }

    /**
     * 生成最新的Map结果集
     *
     * @param recruitmentId ,qrCodeRecords
     * @return
     */
    private Map<EntranceTimeEnum, Integer> getLatestResultMap(Integer recruitmentId, List<QrCodeRecord> qrCodeRecords, Integer appearance) {
        //获取上一次结果集
        Map<EntranceTimeEnum, Integer> lastResultMap = cacheService.getLastResultMap(recruitmentId);
        EntranceTimeEnum morningTag = EntranceTimeEnum.TAG_FOR_AFTERNOON;
        EntranceTimeEnum noonTag = EntranceTimeEnum.TAG_FOR_MORNING;

        if (appearance.equals(RecruitmentAppearancesEnum.MORNING.getCode())) {
            morningTag = EntranceTimeEnum.BEFORE_THIRTEEN_THIRTY;
        }

        if (appearance.equals(RecruitmentAppearancesEnum.AFTERNOON.getCode())) {
            noonTag = EntranceTimeEnum.BEFORE_THIRTEEN_THIRTY;
        }

        for (QrCodeRecord qrCodeRecord : qrCodeRecords) {
            EntranceTimeEnum timeEnum = EntranceTimeEnum.verifyTime(qrCodeRecord);

            //对不属于招聘会时间段的出入场记录进行筛选
            if (timeEnum == null || timeEnum.compareTo(morningTag) >= 0 || timeEnum.compareTo(noonTag) < 0) {
                continue;
            }

            lastResultMap.put(timeEnum, lastResultMap.get(timeEnum) != null ? lastResultMap.get(timeEnum) + 1 : 1);
        }

        return lastResultMap;
    }

    @Override
    public HashMap<String, Object> getSummary(Recruitment recruitment) {
        //判断招聘会类型为专场
        if (recruitment.getStyle() == SPECIAL) {
            return getSpecialSummary(recruitment);
        }

        //招聘会为综合场
        return getMultipleSummary(recruitment);
    }

    @Override
    public StatisticsDto getJobTop5(Recruitment recruitment) {
        List<AmountDto> results = new ArrayList<>();
        if (recruitment.getStyle() == 0) {
            //综合场
            results = resumeDeliveryMapper.findPositionRecordTop5(recruitment.getId());
            Collections.sort(results);
            return new StatisticsDto("招聘岗位Top5", results);
        } else {
            //专场
            List<Map<String, Integer>> userWorkYears = resumeDeliveryMapper.findDeliveryUserWorkYears(recruitment.getId());
            if (!CollectionUtils.isEmpty(userWorkYears)) {
                //转化处理数据 List<Map<userId:value,workyears:value>>  -->  Map<userId,workyears>  （同userID的多个workyears取最大值）
                Map<Integer, Integer> userIdWyMap = new HashMap<>();
                for (Map<String, Integer> userWorkYear : userWorkYears) {
                    Integer userId = userWorkYear.get("userId");
                    Integer workYears = userWorkYear.get("workYears");
                    if (userId == null || workYears == null) {
                        continue;
                    }
                    if (userIdWyMap.containsKey(userId)) {
                        Integer preWorkYears = userIdWyMap.get(userId);
                        userIdWyMap.put(userId, preWorkYears - workYears > 0 ? preWorkYears : workYears);
                    } else {
                        userIdWyMap.put(userId, workYears);
                    }
                }


                //生成结果
                List<Integer> workYearsList = new ArrayList<>(userIdWyMap.values());
                List<WorkYearsEnum> workYearsEnums = Arrays.asList(WorkYearsEnum.values());

                for (WorkYearsEnum anEnum : workYearsEnums) {
                    AmountDto amountDto = new AmountDto();
                    amountDto.setName(anEnum.getDesc());
                    amountDto.setValue(0);
                    for (Integer f : workYearsList) {
                        if (f.equals(anEnum.getCode())) {
                            amountDto.setValue(amountDto.getValue() + 1);
                        }
                    }
                    results.add(amountDto);
                }
            }
            Collections.reverse(results);
            return new StatisticsDto("工作年限分布Top5", results);
        }
    }

    private HashMap<String, Object> getMultipleSummary(Recruitment recruitment) {
        HashMap<String, Object> resultMap = new HashMap<>();

        List<RecruitmentBoothDto> boothDtos = getBoothDesc(recruitment);

        List<CompanyReportDto> companyList = null;
        if (boothDtos != null) {
            companyList = CompanyReportDto.RecruitmentBooth2Company(boothDtos);
            companyList.sort(new Comparator<CompanyReportDto>() {
                @Override
                public int compare(CompanyReportDto o1, CompanyReportDto o2) {
                    return o1.getStation() - o2.getStation();
                }
            });
        }

        resultMap.put("fairName", recruitment.getName());
        resultMap.put("timeTag", RecruitmentAppearancesEnum.getMap().get(recruitment.getAppearances()).getDesc());
        resultMap.put("companyList", companyList);
        resultMap.put("style", 0);
        resultMap.put("date", recruitment.getDate());
        return resultMap;
    }

    private HashMap<String, Object> getSpecialSummary(Recruitment recruitment) {
        HashMap<String, Object> resultMap = new HashMap<>();

        RecruitmentSearch recruitmentSearch = new RecruitmentSearch();
        recruitmentSearch.setRecruitmentID(recruitment.getId());
        List<RecruitmentDataDto> boothDtos = recruitmentService.getRecruitmentData(recruitmentSearch);

        if (CollectionUtils.isEmpty(boothDtos)) {
            return null;
        }

        CompanySpecialReportDto companySpecialReportDto = getCompanyInfo(boothDtos.get(0).getCompanyID());
        List<StationDto> stationList = recruitmentService.getStationsByRecruitmentId(boothDtos.get(0).getRecruitmentID());

        resultMap.put("company", companySpecialReportDto);
        resultMap.put("stations", stationList);
        resultMap.put("style", 1);
        resultMap.put("date", recruitment.getDate());
        return resultMap;
    }

    //获取一个展位的公司信息和招聘岗位列表
    private List<RecruitmentBoothDto> getBoothDesc(Recruitment recruitment) {
        List<RecruitmentBoothDto> dtos = new ArrayList<>();

        RecruitmentSearch recruitmentSearch = new RecruitmentSearch();
        recruitmentSearch.setRecruitmentID(recruitment.getId());
        List<RecruitmentDataDto> dataDtos = recruitmentService.getRecruitmentData(recruitmentSearch);

        if (CollectionUtils.isEmpty(dataDtos)) {
            return null;
        }

        Map<Integer, List<String>> companyDescMap = new HashMap<>();
        for (RecruitmentDataDto dataDto : dataDtos) {
            if (StringUtils.isEmpty(dataDto.getPositionName())) {
                continue;
            }
            if (companyDescMap.containsKey(dataDto.getBoothID())) {
                //重复的公司合并岗位信息
                companyDescMap.get(dataDto.getBoothID()).add(dataDto.getPositionName() + " " + dataDto.getRecruitNumber());
            } else {
                List list = new ArrayList();
                list.add(dataDto.getPositionName() + " " + dataDto.getRecruitNumber());
                companyDescMap.put(dataDto.getBoothID(), list);
                RecruitmentBoothDto recruitmentBoothDto = new RecruitmentBoothDto();
                recruitmentBoothDto.setRecruitmentID(dataDto.getRecruitmentID());
                recruitmentBoothDto.setBoothID(dataDto.getBoothID());
                recruitmentBoothDto.setCompanyName(dataDto.getCompanyName());
                recruitmentBoothDto.setCompanyId(dataDto.getCompanyID());
                recruitmentBoothDto.setPositionList(list);
                dtos.add(recruitmentBoothDto);
            }
        }
        return dtos;
    }

    private CompanySpecialReportDto getCompanyInfo(int companyId) {
        CompanySpecialReportDto result = new CompanySpecialReportDto();
        List<Thumbnail> thumbnails = new ArrayList<>();

        Company company = companyService.getById(companyId);

        if (company == null) {
            return null;
        }

        //优先存入公司的视频资料
        if (StringUtils.isNotEmpty(company.getVideoID())) {
            thumbnails.add(new Thumbnail("video", globalContext + VIDEO_TYPE + company.getVideoID()));
        }

        //存入公司的图片展示资料
        List<String> companyPictures = companyPictureService.getPictures(companyId);
        if (!CollectionUtils.isEmpty(companyPictures)) {
            for (String pictureId : companyPictures) {
                thumbnails.add(new Thumbnail("image", globalContext + PIC_Type + pictureId));
            }
        }

        result.setName(company.getName());
        result.setDesc(company.getDescription());
        result.setThumbnail(thumbnails);
        return result;
    }
}
