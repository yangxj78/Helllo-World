package com.hengtiansoft.servlet.applicant.userManage.controller;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.MobileSignInDto;
import com.hengtiansoft.bean.dataModel.RegisterDto;
import com.hengtiansoft.bean.dataModel.SignInDto;
import com.hengtiansoft.bean.dataModel.SmsDto;
import com.hengtiansoft.bean.tableModel.AdminUser;
import com.hengtiansoft.bean.tableModel.ApplicantUser;
import com.hengtiansoft.bean.tableModel.Sms;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.SmsTypeEnum;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.applicant.userManage.service.ApplicantUserLoginService;
import com.hengtiansoft.servlet.manage.adminPermission.AdminPermissionService;
import com.hengtiansoft.servlet.manage.adminUser.AdminUserService;
import com.hengtiansoft.servlet.manage.applicationUser.ApplicantUserService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import io.swagger.annotations.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 用户相关接口
 */
@Api(value = "wx用户登录注册相关接口")
@RestController
@RequestMapping("/applicant/userManage")
public class UserManageController {


    @Autowired
    private ApplicantUserService applicantUserService;

    @Autowired
    private SmsService smsService;

    @Autowired
    private ApplicantUserLoginService applicantUserLoginService;


    /**
     * 发送验证码
     */
    @PostMapping(value = "/sendSms")
    @ApiOperation(value = "发送验证码", notes = "必填 phone； 验证码类型：7 重置密码 ，8 注册，9 登录 type ")
    public ResultDto sendSms(@RequestParam String phone, @RequestParam @ApiParam(value = "验证码类型：7 重置密码 ，8 注册，9 登录") Integer type) {
        if (!isPhone(phone)) {
            return ResultDtoFactory.toNack("请填入正确的手机号");
        }
        String captcha = generateCode();
        if (smsService.send(new SmsDto(type, phone, SmsTypeEnum.getByCode(type).getDesc(), null, null, captcha))) {
            if (type.equals(SmsTypeEnum.LOGIN.getCode())) {
                applicantUserLoginService.updateCaptcha(captcha, phone);
            }
            return ResultDtoFactory.toAck("发送成功");
        }
        return ResultDtoFactory.toAck("发送失败");
    }


    /**
     * 校验验证码
     */
    @PostMapping(value = "/checkSms")
    @ApiOperation(value = "校验验证码", notes = "必填 phone；code；type 验证码类型：7 重置密码 ，8 注册，9 登录  ")
    public ResultDto checkSms(@RequestParam String phone,
                              @RequestParam String code,
                              @RequestParam @ApiParam(value = "验证码类型：7 重置密码 ，8 注册，9 登录") Integer type) {
        if (StringUtils.isEmpty(code)) {
            return ResultDtoFactory.toNack("验证码为空");
        }
        Sms sms = smsService.findOne(phone, type);
        if (sms == null || !sms.getCode().equals(code)) {
            return ResultDtoFactory.toNack("验证码错误");
        }
        return ResultDtoFactory.toAck("验证成功");
    }

    /**
     * 检查手机号是否已注册
     */
    @PostMapping(value = "/checkRegister")
    @ApiOperation(value = "检查手机号是否已注册", notes = "必填 phone ")
    public ResultDto checkRegister(@RequestParam String phone) {
        ApplicantUser applicantUser = applicantUserLoginService.findApplicantUser(phone);
        if (applicantUser != null) {
            return ResultDtoFactory.toAck("手机号已注册", false);
        }
        return ResultDtoFactory.toAck("手机号未注册", true);
    }


    /**
     * 检查用户名是否已注册
     */
    @PostMapping(value = "/checkRegisterByUsername")
    @ApiOperation(value = "检查用户名是否已注册", notes = "必填 phone ")
    public ResultDto checkUsernameRegister(@RequestParam String username) {
        ApplicantUser applicantUser = applicantUserLoginService.findApplicantUserByUsername(username);
        if (applicantUser != null) {
            return ResultDtoFactory.toAck("用户名已注册", false);
        }
        return ResultDtoFactory.toAck("用户名未注册", true);
    }

    /**
     * 登录(账号密码登录方式)
     */
    @PostMapping("/UPLogin")
    public ResultDto<Map<String, Object>> mobileLogin(@RequestBody SignInDto signInDto) {
        Map<String, Object> rMap = new HashMap<String, Object>();
        String password2 = EncryptUtil.encryptMd5(signInDto.getUserName(), signInDto.getPassword());
        try {
            rMap = applicantUserLoginService.login(signInDto.getUserName(), password2);
            String username = signInDto.getUserName();
            applicantUserService.cleanToken(username);
            applicantUserService.putApplicantUserCache(username);
        } catch (AuthenticationException e) {
            return ResultDtoFactory.toNack(e.getMessage());
        }

        return ResultDtoFactory.toAck("登录成功", rMap);
    }

    @PostMapping("/test")
    public ResultDto<Map<String, Object>> test(@RequestBody SignInDto signInDto) {
        for (int i = 1; i < 500; i++) {
            signInDto.setUserName("test" + i);
            signInDto.setPassword("123456");
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Long startTime = System.currentTimeMillis();
                    Map<String, Object> rMap = new HashMap<String, Object>();
                    String password2 = EncryptUtil.encryptMd5(signInDto.getUserName(), signInDto.getPassword());
                    try {
                        rMap = applicantUserLoginService.login(signInDto.getUserName(), password2);
                        String userName = signInDto.getUserName();
                        applicantUserService.cleanToken(userName);
                    } catch (AuthenticationException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
        return ResultDtoFactory.toAck("登录成功");
    }


    /**
     * 登录(手机号登录方式)
     */
    @PostMapping("/mobileLogin")
    public ResultDto<Map<String, Object>> mobileLogin(@RequestBody MobileSignInDto mobileSignInDto) {
        ApplicantUser applicantUser = applicantUserLoginService.findApplicantUser(mobileSignInDto.getPhone());
        if (applicantUser == null) {
            return ResultDtoFactory.toNack("手机号未注册");
        }
        if (!StringUtils.equalsIgnoreCase(mobileSignInDto.getCaptcha(), applicantUser.getCaptcha())) {
            return ResultDtoFactory.toNack("验证码不正确");
        }
        Map<String, Object> rMap = new HashMap<String, Object>();
        try {
            rMap = applicantUserLoginService.login(applicantUser.getUsername(), applicantUser.getPassword());
            String username = applicantUser.getUsername();
            applicantUserService.cleanToken(username);
            applicantUserService.putApplicantUserCache(username);
        } catch (AuthenticationException e) {
            return ResultDtoFactory.toNack(e.getMessage());
        }

        return ResultDtoFactory.toAck("登录成功", rMap);
    }


    /**
     * 注册
     */
    @PostMapping(value = "/userRegister")
    @ApiOperation(value = "注册", notes = "必填 phone ")
    public ResultDto userRegister(@RequestBody RegisterDto registerDto) {
        if (StringUtils.isEmpty(registerDto.getPhone())) {
            return ResultDtoFactory.toNack("手机号不能为空");
        }
        if (!isPhone(registerDto.getPhone())) {
            return ResultDtoFactory.toNack("手机号格式不正确");
        }
        if (StringUtils.isEmpty(registerDto.getUsername())) {
            return ResultDtoFactory.toNack("用户名不能为空");
        }
        if (StringUtils.isEmpty(registerDto.getPassword())) {
            return ResultDtoFactory.toNack("密码不能为空");
        }
        if (StringUtils.isEmpty(registerDto.getConfirmPassword())) {
            return ResultDtoFactory.toNack("确认密码不能为空");
        }
        if (!registerDto.getConfirmPassword().equals(registerDto.getPassword())) {
            return ResultDtoFactory.toNack("两次密码不一致");
        }

        try {
            return ResultDtoFactory.toAck("新建成功", applicantUserLoginService.saveUser(registerDto));

        } catch (Exception e) {
            e.printStackTrace();
            return ResultDtoFactory.toNack("新建失败");
        }
    }


    /**
     * 重置密码
     */
    @PostMapping(value = "/resetPassword")
    @ApiOperation(value = "重置密码", notes = "必填 phone ")
    public ResultDto resetPassword(@RequestBody RegisterDto registerDto) {
        if (StringUtils.isEmpty(registerDto.getPhone())) {
            return ResultDtoFactory.toNack("手机号不能为空");
        }
        if (!isPhone(registerDto.getPhone())) {
            return ResultDtoFactory.toNack("手机号格式不正确");
        }
        if (StringUtils.isEmpty(registerDto.getPassword())) {
            return ResultDtoFactory.toNack("密码不能为空");
        }
        if (StringUtils.isEmpty(registerDto.getConfirmPassword())) {
            return ResultDtoFactory.toNack("确认密码不能为空");
        }
        if (!registerDto.getConfirmPassword().equals(registerDto.getPassword())) {
            return ResultDtoFactory.toNack("两次密码不一致");
        }

        boolean flag = false;
        try {
            flag = applicantUserLoginService.resetPassword(registerDto);
        } catch (Exception e) {
            return ResultDtoFactory.toNack("重置失败");
        }
        if (flag) {
            return ResultDtoFactory.toAck("重置成功");
        } else {
            return ResultDtoFactory.toNack("重置失败");
        }
    }

    @RequestMapping(value = "/getUserInfo", method = RequestMethod.POST)
    @ApiOperation(value = "获取当前登陆用户信息")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public Object getUserInfo() {
        return ResultDtoFactory.toAck("success", SecurityContext.getCurrentApplicantUser());
    }

    /**
     * 注销
     */

    @GetMapping("/loginOut")
    @ApiOperation(value = "注销")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto logOut() {
        ApplicantUser currentUser = SecurityContext.getCurrentApplicantUser();
        currentUser.setToken("");
        applicantUserLoginService.updateLoginTs(currentUser);
        String username = currentUser.getUsername();
        applicantUserService.cleanToken(username);

        return ResultDtoFactory.toAck("退出成功");
    }


    /**
     * 校验手机号
     *
     * @param phone
     * @return
     */
    public Boolean isPhone(String phone) {
        String regex = "^((13[0-9])|(14[5,7,9])|(15([0-3]|[5-9]))|(166)|(17[0,1,3,5,6,7,8])|(18[0-9])|(19[8|9]))\\d{8}$";
        if (phone.length() != 11) {
            return false;
        } else {
            Pattern p = Pattern.compile(regex);
            Matcher m = p.matcher(phone);
            return m.matches();
        }
    }

    /**
     * 生成验证码
     *
     * @return
     */
    public String generateCode() {
        String str = "0123456789";
        StringBuilder sb = new StringBuilder(4);
        for (int i = 0; i < 6; i++) {
            char ch = str.charAt(new Random().nextInt(str.length()));
            sb.append(ch);
        }
        return sb.toString();

    }

    @PostMapping(value = "/updateIds")
    public Object doUpdateId(String phone) {
        applicantUserLoginService.updateIdByPhone(phone);
        return ResultDtoFactory.toAck("成功更新");
    }
}
