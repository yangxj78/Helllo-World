package com.hengtiansoft.servlet.applicant.recruitment.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.qrcode.service.QrCodeService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.applicant.shield.service.ShieldService;
import io.swagger.annotations.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Api(value = "求职者招聘会相关接口", description = "招聘会-职位搜索")
@RestController
@RequestMapping(value = "/applicant/recruitment")
public class ApplicantRecruitmentController {

    @Autowired
    RecruitmentService recruitmentService;

    @Autowired
    ResumeService resumeService;

    @Autowired
    ShieldService shieldService;

    @Autowired
    QrCodeService qrCodeService;

    @Autowired
    PositionRecordService positionRecordService;

    @RequestMapping(value = "/recruitmentData", method = RequestMethod.POST)
    @ApiOperation(value = "招聘会-职位搜索", notes = "")
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto recruitmentData(@RequestBody RecruitmentSearch recruitmentSearch) {
        return ResultDtoFactory.toAck("success", recruitmentService.getRecruitmentDataForApplicant(recruitmentSearch));

    }

    @RequestMapping(value = "/listPositionRecord", method = RequestMethod.POST)
    @ApiOperation(value = "获取招聘会某个展位的岗位列表", notes = "必填 ：招聘会ID 展位ID 字段可选岗位关键字，学历ID，工作年限ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto listPositionRecord(@RequestBody PositionRecordSearch positionRecordSearch) {
        if (positionRecordSearch.getRecruitmentID() == null || positionRecordSearch.getBoothID() == null) {
            return ResultDtoFactory.toNack("招聘会ID和展位ID不能为空");
        }
        return ResultDtoFactory.toAck("success", positionRecordService.listPositionRecord(positionRecordSearch));
    }

    @RequestMapping(value = "/countResume", method = RequestMethod.GET)
    @ApiOperation(value = "现场申请记录&我的简历数", notes = "必填 ：userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto countResume(@RequestParam Integer userId) {
        return resumeService.getCountByUserId(userId);
    }

    @RequestMapping(value = "/listRecruitmentSearch", method = RequestMethod.GET)
    @ApiOperation(value = "遍历所收藏岗位的招聘会", notes = "必填 ：userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto listRecruitmentSearch(@RequestParam Integer userId) {
        if (userId == null) {
            return ResultDtoFactory.toNack("用户Id不能为空");
        }
        return ResultDtoFactory.toAck("success", recruitmentService.listRecruitmentSearchs(userId));
    }

    @PostMapping("/listCollectionPosition")
    @ApiOperation(value = "遍历收藏的岗位", notes = "必填 ：userId 选填recruitmentId、keyword")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto listCollectionPosition(@ApiParam(name = "searchDto") @RequestBody CollectionPositionSearchDto searchDto) {
        if (searchDto.getUserId() == null) {
            return ResultDtoFactory.toNack("用户Id不能为空");
        }
        return ResultDtoFactory.toAck("success", recruitmentService.listCollectionPosition(searchDto));
    }

    @RequestMapping(value = "/collectionPosition", method = RequestMethod.POST)
    @ApiOperation(value = "收藏岗位", notes = "必填 ：userId positionRecordId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto collectionPosition(@RequestParam("userId") Integer userId
            , @RequestParam("boothId") Integer boothId, @RequestParam("positionRecordId") Integer positionRecordId) {
        CollectionPositionSearchDto searchDto = new CollectionPositionSearchDto(userId, boothId, positionRecordId);
        return recruitmentService.collectionPosition(searchDto);
    }

    @RequestMapping(value = "/deleteCollectionPosition", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除岗位的收藏状态", notes = "必填 boothId positionRecordId userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto deleteCollectionPosition(@RequestParam("userId") Integer userId
            , @RequestParam("boothId") Integer boothId, @RequestParam("positionRecordId") Integer positionRecordId) {
        CollectionPositionSearchDto searchDto = new CollectionPositionSearchDto(userId, boothId, positionRecordId);
        if (!recruitmentService.getCollectionPosition(searchDto)) {
            return ResultDtoFactory.toNack("你还没有收藏该岗位");
        }
        if (recruitmentService.deleteCollectionPosition(searchDto) > 0) {
            return ResultDtoFactory.toAck("取消收藏成功");
        }
        return ResultDtoFactory.toNack("取消收藏失败");
    }

    @RequestMapping(value = "/getCollectionPosition", method = RequestMethod.GET)
    @ApiOperation(value = "查询岗位的收藏状态", notes = "必填 boothId positionRecordId userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto getCollectionPosition(@RequestParam("userId") Integer userId
            , @RequestParam("boothId") Integer boothId, @RequestParam("positionRecordId") Integer positionRecordId) {
        CollectionPositionSearchDto searchDto = new CollectionPositionSearchDto(userId, boothId, positionRecordId);
        Map<String, Boolean> result = new HashMap<>();
        result.put("isCollectionPosition", recruitmentService.getCollectionPosition(searchDto));
        result.put("isPreDevlivery", recruitmentService.isPreDelivery(searchDto));
        result.put("isDevlivery", recruitmentService.isDelivery(searchDto));
        result.put("isSignIn", qrCodeService.hasSignIn(userId, positionRecordId));
        return ResultDtoFactory.toAck("success", result);
    }


    @RequestMapping(value = "/serach", method = RequestMethod.POST)
    @ApiOperation(value = "职位搜索", notes = "")
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto recruitmentData(@RequestBody PositionRecordSearch positionRecordSearch) {
        int pageNum = (positionRecordSearch.getPageNum() == null ? 1 : positionRecordSearch.getPageNum());
        int pageSize = (positionRecordSearch.getPageSize() == null ? MagicNumConstant.TEN : positionRecordSearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<>(recruitmentService.positionRecordSearch2(positionRecordSearch)));

    }


    @RequestMapping(value = "/companySearch", method = RequestMethod.POST)
    @ApiOperation(value = "公司名模糊搜索", notes = "userId search必填")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto companySearch(@RequestParam Integer resumeId, @RequestBody CompanySearch companySearch) {
        if (StringUtils.isEmpty(companySearch.getSearch())) {
            return ResultDtoFactory.toNack("搜索信息不能为空");
        }
        int pageNum = (companySearch.getPageNum() == null ? 1 : companySearch.getPageNum());
        int pageSize = (companySearch.getPageSize() == null ? MagicNumConstant.TEN : companySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<>(shieldService.searchCompanyAndShield(resumeId, companySearch.getSearch())));
    }
}
