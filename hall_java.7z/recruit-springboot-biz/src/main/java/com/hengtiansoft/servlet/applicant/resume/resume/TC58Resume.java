package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class TC58Resume extends BaseResume {

    public static final int BEGIN_OFF_SET_ZERO = 0;
    public static final int NUM_ZERO = 0;
    public static final int NUM_ONE = 1;
    public static final int NUM_FIVE = 5;

    @Override
    public void buildContactInfo(String content, HrResume r) {
        content = filtercontent(content);
        String phone = getPhone(content);
        String email = getEmailAddress(content);
        if (!StringUtils.isEmpty(email) && email.contains(phone)) {
            email = email.replace(phone, "");
        }
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String post = null;
        String expectCity = null;
        if (content.contains("求职意向")) {
            String jobObjective = content.substring(content.indexOf("求职意向："));
            String[] arr = jobObjective.split("\\|");
            if (arr[NUM_ZERO].contains("求职意向：求职")) {
                post = arr[NUM_ZERO].replace("求职意向：求职", "");
            }
            if (arr[NUM_ONE].contains("想在") && arr[NUM_ONE].contains("工作")) {
                expectCity = strSubstring(arr[NUM_ONE], "想在", "工作");
            }
        }

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("学历教育")) {
            String eduExperience = content.substring(content.indexOf("学历教育"));
            if (eduExperience.contains("获得证书")) {
                eduExperience = strSubstring(eduExperience, "学历教育", "获得证书");
            } else {
                eduExperience = strSubstring(eduExperience, "学历教育", "相关推荐");
            }
            if (eduExperience.contains("毕业")) {
                graduateDate = eduExperience.substring(BEGIN_OFF_SET_ZERO, eduExperience.indexOf("毕业"));
            }
            String[] schoolName = { "大学", "学校", "学院" };
            for (String str : schoolName) {
                if (eduExperience.contains(str)) {
                    school = strSubstring(eduExperience, "毕业", str) + str;
                    major = eduExperience.substring(eduExperience.indexOf(school)).replace(school, "");
                    break;
                }
            }
        }

        Pattern degreePattern = Pattern.compile("高中以下|高中|中专/技校|大专|本科|硕士|博士|MBA/EMBA");
        Matcher degreeMatcher = degreePattern.matcher(content);
        while (degreeMatcher.find()) {
            degree = degreeMatcher.group(0);
        }

        String expectSalary = fieldTrim(strSubstring(content, "期望薪资", "元/月"));
        expectSalary = StringUtils.isEmpty(expectSalary) || !expectSalary.startsWith("//d") ? "面议" : expectSalary
                + "元/月";
        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        if (content.contains("相关推荐：")) {
            content = content.substring(NUM_ZERO, content.indexOf("相关推荐："));
        }
        String[] arr = content.split("<h3>");
        for (String str : arr) {
            if (str.startsWith("工作经验")) {
                workExperience = filterExperience(str).replaceFirst("工作经验(&nbsp;)*", "");
            }
            if (str.startsWith("项目经验")) {
                projectExperience = filterExperience(str).replaceFirst("项目经验(&nbsp;)*", "");
            }
            if (str.startsWith("学历教育")) {
                education = filterExperience(str).replaceFirst("学历教育(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);
        String updateDate = getUpdateDate(content);
        String name = content.substring(BEGIN_OFF_SET_ZERO, content.indexOf('-'));

        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String sexAndAge = strSubstring(content, "（", "）");
        if (!StringUtils.isEmpty(sexAndAge)) {
            String[] arr = sexAndAge.split("，");
            if (arr[NUM_ZERO].contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (arr[NUM_ONE].contains("岁")) {
                age = getRealAge(arr[NUM_ONE].substring(BEGIN_OFF_SET_ZERO, arr[NUM_ONE].indexOf("岁")));
            }
        }

        String info = strSubstring(content, "基本情况：", "求职意向：");
        String[] infos = info.split("\\|");
        String year = null;
        String city = null;
        for (String str : infos) {
            if (str.contains("工作经验")) {
                year = str.replace("工作经验", "");
            }
            if (str.contains("现居")) {
                city = str.replace("现居", "");
            }
        }

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.TC58UPLOAD);
    }

    public String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<!--.*?-->", "").replaceAll("<script[^>]*>.*?</script>", "")
                .replaceAll("<style[^>]*>.*?</style>", "").replaceAll("<.*?>", "");
    }

    public String filterExperience(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<!--.*?-->", "").replaceAll("<script[^>]*>.*?</script>", "")
                .replaceAll("<style[^>]*>.*?</style>", "").replaceAll("(<.*?>)+", "&nbsp;").replaceAll("　", "");
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        String[] postAndName = mailContent.getSubject().split("-");
        String post = null;
        String city = null;
        String name = null;
        if (postAndName.length == 3) {
            post = postAndName[0].substring("(58.com)应聘贵公司".length()).trim();
            city = postAndName[1].trim();
            name = postAndName[2].trim();
        }

        String content = messageBody2String(mailContent);
        Document document = Jsoup.parse(content);
        content = document.text();

        String updateDate = content.substring(content.indexOf("更新时间：") + 5,
                content.indexOf(" ", content.indexOf("更新时间：")));
        String years = filtercontent(content.substring(content.indexOf("工作经验") - 5, content.indexOf("工作经验")));
        String degree = null;
        Pattern degreePattern = Pattern.compile("高中以下|高中|中专/技校|大专|本科|硕士|博士|MBA/EMBA");
        Matcher degreeMatcher = degreePattern.matcher(content);
        while (degreeMatcher.find()) {
            degree = degreeMatcher.group(0);
        }
        String phone = this.getPhone(content).trim();
        String email = this.getEmailAddress(content).trim();
        String expectCity = content.substring(content.indexOf("期望地区：") + NUM_FIVE,
                content.indexOf(" ", content.indexOf("期望地区：") + NUM_FIVE));
        String sex = content.substring(content.indexOf(name + "（") + name.length() + NUM_ONE, content.indexOf("，"));
        SexEnum realSex = this.getRealSex(sex);
        int realAge = Integer.parseInt(content.substring(content.indexOf("，") + NUM_ONE, content.indexOf("岁")));
        String expectSalary = content.substring(content.indexOf("期望薪资：") + NUM_FIVE,
                content.indexOf(" ", content.indexOf("期望薪资：") + NUM_FIVE));

        r.setName(name);
        r.setAge(realAge);
        r.setDegree(degree);
        r.setEmail(email);
        r.setPhone(phone);
        r.setContent(content);
        r.setYears(years);
        r.setSex(realSex);
        r.setSource(ResumeSourceEnum.TC58COLLECT);
        r.setCity(city);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setUpdateDate(updateDate);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = content.split("<span lang=\"ZH-CN\" style=\"font-size:12.0pt;color:#404040\">");
        for (String str : arr) {
            if (str.startsWith("工作经验")) {
                workExperience = filterExperience(str).replaceFirst("工作经验(&nbsp;)*", "");
            }
            if (str.startsWith("项目经验")) {
                projectExperience = filterExperience(str).replaceFirst("项目经验(&nbsp;)*", "");
            }
            if (str.startsWith("学历教育")) {
                education = filterExperience(str).replaceFirst("学历教育(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

}
