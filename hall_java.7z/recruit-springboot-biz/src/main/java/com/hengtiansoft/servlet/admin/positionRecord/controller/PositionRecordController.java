package com.hengtiansoft.servlet.admin.positionRecord.controller;


import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.tableModel.BookBooth;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.common.service.UpdateNumberService;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/positionRecord")
@Api(value = "参会岗位controller", description = "新增参会岗位相关接口")
public class PositionRecordController {

    @Autowired
    PositionRecordService positionRecordService;
    @Autowired
    BoothService boothService;
    @Autowired
    UpdateNumberService updateNumberService;

    @Autowired
    RecruitmentMapper recruitmentMapper;

    @Autowired
    PositionService positionService;
    @Autowired
    RecruitmentService recruitmentService;

    /**
     * @Description: 批量导入岗位
     **/
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    @Transactional
    @ApiOperation(value = "新增参会岗位", notes = "必填 招聘会ID，企业ID，展位ID,岗位名称")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto add(@RequestBody PositionRecordDto positionRecordDto) {
        positionRecordDto.setName(positionRecordDto.getName().trim());
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setcompanyID(positionRecordDto.getCompanyID());
        boothSearch.setRecruitmentID(positionRecordDto.getRecruitmentID());
        boothSearch.setboothID(positionRecordDto.getBoothID());
        if (boothService.check(boothSearch).size() == 0) {
            return ResultDtoFactory.toNack("该公司未预定该展位");
        }
        return positionRecordService.add(positionRecordDto);

    }

    @RequestMapping(value = "/batchAdd", method = RequestMethod.POST)
    @ApiOperation(value = "批量新增参会岗位", notes = "必填 订展ID （bookBoothID）招聘会ID，企业ID，展位ID,position_id（岗位ID）,岗位记录名称")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto batchAdd(@RequestBody List<PositionRecordDto> positionRecordDtos) {
        return positionRecordService.batchAdd(positionRecordDtos);
    }


    @RequestMapping(value = "/", method = RequestMethod.PUT)
    @ApiOperation(value = "更新参会岗位", notes = "必填 岗位记录ID,岗位记录名称")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto update(@RequestBody PositionRecordDto positionRecordDto) {
        try {
            positionRecordDto.setName(positionRecordDto.getName().trim());
            positionRecordService.updatePositionRecord(positionRecordDto);
            return ResultDtoFactory.toAck("更新成功");
        } catch (Exception e) {
            e.printStackTrace();
            return ResultDtoFactory.toNack("更新失败,岗位名可能存在重复");
        }

    }

    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除参会岗位", notes = "必填 招聘会ID,岗位记录ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto delete(@RequestParam Integer positionID, @RequestParam Integer bookBoothID, @RequestParam Integer recruitmentID) {

        if (!positionRecordService.check(positionID)) {
            return ResultDtoFactory.toNack("已有用户投递");
        }
        if (positionRecordService.deleteByID(bookBoothID, positionID, recruitmentID) > 0) {
            return ResultDtoFactory.toAck("删除成功");
        }
        return ResultDtoFactory.toNack("删除失败");
    }

    @RequestMapping(value = "/updateOrder", method = RequestMethod.POST)
    @ApiOperation(value = "更新参会岗位排序序号", notes = "必填 岗位记录ID,订展ID 岗位记录序号")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto updateOrder(@RequestBody List<PositionRecordDto> positionRecordDtos) {

        positionRecordDtos.forEach(n -> positionRecordService.updateOrder(n));
        if (positionRecordDtos.size() != 0) {
            PositionRecord byID = positionRecordService.getByID(positionRecordDtos.get(0).getPositionRecordID());
            BookBooth bookBooth = boothService.getById(positionRecordDtos.get(0).getBookBoothID());
            Recruitment recruitment = recruitmentService.getById(byID.getRecruitmentId());
            if (recruitment.getStartType() == 1) {
                Map map = new HashMap();
                map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
                NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
            }
        }
        return ResultDtoFactory.toAck("更新成功");

    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getByID(@PathVariable Integer id) {
        return ResultDtoFactory.toAck("success", positionRecordService.getByID(id));
    }


}
