package com.hengtiansoft.servlet.applicant.shield.service.impl;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.CompanyDateDto;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.ShieldCompany;
import com.hengtiansoft.servlet.applicant.shield.service.ShieldService;
import com.hengtiansoft.servlet.mapper.ShieldCompanyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ShieldServiceImpl implements ShieldService {

    @Autowired
    ShieldCompanyMapper shieldCompanyMapper;


    @Override
    public ResultDto shieldCompany(List<ShieldCompany> shieldCompanys) {
        shieldCompanyMapper.insertAll(shieldCompanys);
        return ResultDtoFactory.toAck("success");
    }

    @Override
    public ResultDto getShieldCompanyList(Integer resumeId) {
        List<ShieldCompany> shieldCompanyList = shieldCompanyMapper.getShieldCompanyList(resumeId);
        return ResultDtoFactory.toAck("success", shieldCompanyList);
    }

    @Override
    public ResultDto delete(Integer id) {
        return ResultDtoFactory.toAck("success", shieldCompanyMapper.deleteByPrimaryKey(id));
    }

    @Override
    public List<CompanyDateDto> searchCompanyAndShield(Integer resumeId, String companySearch) {
        return shieldCompanyMapper.searchCompanyAndShield(resumeId, companySearch);
    }
}
