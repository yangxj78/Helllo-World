package com.hengtiansoft.servlet.applicant.resume.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "简历相关接口", description = "restful风格")
@RestController
@RequestMapping(value = {"/applicant/resume"})
public class ApplicantResumeController {
    @Autowired
    ResumeService resumeService;

    @ApiOperation(value = "微信用户简历删除", httpMethod = "DELETE", notes = "简历id")
    @RequestMapping(value = "/deleteResumeForApplicant", method = RequestMethod.DELETE)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto deleteResumeForApplicant(@ApiParam(value = "简历id", name = "id") @RequestParam Integer id) {
        return resumeService.deleteResumeForApplicant(id);
    }
}
