package com.hengtiansoft.servlet.applicant.resume.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MResumeDto;
import com.hengtiansoft.bean.tableModel.ResumeDeliveryPre;
import com.hengtiansoft.bean.tableModel.UserInfo;

import java.io.IOException;
import java.util.List;

public interface ResumeService {

    ResumeDto findResume(Integer resumeId, Integer userId);

    ResultDto findResumes(ResumeSearchDto resumeSearchDto);

    ResultDto postResume(ResumeDeliveryDto resumeDeliveryDto);

    ResultDto createResume(ResumeDto resumeDto,boolean perfectFlag);


    ResultDto defaultResume(Integer oldId, Integer newId);


    ResultDto deleteResume(Integer id);

    ResultDto deleteResumeForApplicant(Integer id);

    ResultDto deleteEducationExperience(Integer id);

    ResultDto deleteWorkExperience(Integer id);

    ResultDto deleteProjectExperience(Integer id);

    UserInfo findUserInfo(Integer userId);

    ResultDto getCountByUserId(Integer userId);

    List<ResumeDeliveryPreInfoDto> findResumeDeliveryPreInfo(CollectionPositionSearchDto searchDto);

    List<ResumeDeliveryInfoDto> findResumeDeliveryInfo(CollectionPositionSearchDto searchDto);

    List<RecruitmentSearchDto> listDeliveryRecruitmentSearchs(Integer userId);

    List<RecruitmentSearchDto> listDeliveryPreRecruitmentSearchs(Integer userId);

    ResumeDeliverySuccessDto getDeliverySuccessInfo(Integer userId, Integer positionRecordId);

    ResumeDeliveryPreInfoDto getDeliveryPreSuccessInfo(Integer userId, Integer positionRecordId);

    ResultDto createByMultiple(List<MResumeDto> resumes);

    /**
     * 简历图片扫描导入
     * @param resumeImgInfoDto
     * @return
     * @throws IOException
     */
    ResultDto<ResumeDto> createByScanImg(ResumeImgInfoDto resumeImgInfoDto);

    boolean sendInviteMessage(Integer recuritmentId, Integer resumeId);

    boolean check(Integer recruitmentID,Integer boothId);

    List<ResumeDeliveryPre> findResumeDeliveryPre(Integer boothID, Integer recruitmentID);

    void updateResumeDeliveryPre1(ResumeDeliveryPre resumeDeliveryPre1);
}
