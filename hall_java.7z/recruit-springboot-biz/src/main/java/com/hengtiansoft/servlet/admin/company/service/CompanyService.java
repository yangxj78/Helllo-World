package com.hengtiansoft.servlet.admin.company.service;

import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface CompanyService extends Service<Company> {
    List check(BoothSearch boothSearch);

    List<Company> getAll(CompanySearch companySearch);

    int createCompany(Company company);

    int updateCompany(Company company);

    int deleteCompany(Integer id);

    Company getById(int id);


    List<Company> listByRecruitment(CompanySearch companySearch);
  Company getRecruimentDetail(CompanySearch companySearch);

}
