package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PositionMapper extends MyMapper<Position> {
    List<Position> search(PositionSearch positionSearch);
    List<Position> getIDAndName(BoothSearch boothSearch);
    int add(PositionRecordDto positionRecordDto);
    int updateByID(Position position);

    Position selectByID(@Param("id") Integer id);
    int updateByCompanyID(Integer companyID);
}