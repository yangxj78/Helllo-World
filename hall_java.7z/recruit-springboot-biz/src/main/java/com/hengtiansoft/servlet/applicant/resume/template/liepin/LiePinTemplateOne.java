package com.hengtiansoft.servlet.applicant.resume.template.liepin;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.servlet.applicant.resume.resume.LiePinResume;

public class LiePinTemplateOne extends LiePinResume {
    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = content.split("<w:szCs w:val=\"30\"/></w:rPr><w:t>");
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                workExperience = filterExperience(str).replaceFirst("工作经历(&nbsp;)*", "");
            }
            if (str.startsWith("项目经历")) {
                projectExperience = filterExperience(str).replaceFirst("项目经历(&nbsp;)*", "");
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }
}
