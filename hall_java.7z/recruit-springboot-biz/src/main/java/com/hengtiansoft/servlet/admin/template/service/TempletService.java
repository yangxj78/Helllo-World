package com.hengtiansoft.servlet.admin.template.service;

import com.hengtiansoft.bean.tableModel.TempletBooth;
import com.hengtiansoft.common.service.Service;

import java.util.List;

public interface TempletService extends Service<TempletBooth> {
    Boolean configureTemplet(TempletBooth templetBooth);

    List<Integer> list(Integer recruitmentId, Integer templetId);

    TempletBooth getBy(Integer recruimentId, Integer boothId);

    List<TempletBooth> listTemplet8(Integer recruitmentId);

    void setTemplet8(List<TempletBooth> templetBooths);
}
