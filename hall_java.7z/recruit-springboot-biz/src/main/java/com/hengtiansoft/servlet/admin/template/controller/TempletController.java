package com.hengtiansoft.servlet.admin.template.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.tableModel.TempletBooth;
import com.hengtiansoft.servlet.admin.template.service.TempletService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController("/templet")
@Api(value = "电视机", description = "电视机相关接口")

public class TempletController {
    @Autowired
    TempletService templetService;

    @RequestMapping(value = "/configureTemplet", method = RequestMethod.POST)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public ResultDto configureTemplet(@RequestBody TempletBooth templetBooth) {
        if (templetService.configureTemplet(templetBooth)) {
            return ResultDtoFactory.toAck("使用成功");
        }
        return ResultDtoFactory.toNack("配置失败");
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public ResultDto list(@RequestParam Integer recruitmentId, @RequestParam Integer templetId) {
        return ResultDtoFactory.toAck("success",templetService.list(recruitmentId, templetId));
    }

    @GetMapping("/templet8")
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public  ResultDto templet8(@RequestParam Integer recruitmentId){
        return  ResultDtoFactory.toAck("success",templetService.listTemplet8(recruitmentId));
    }


    @PostMapping("/templet8")
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public  ResultDto setTemplet8(@RequestBody List<TempletBooth> templetBooths){
        templetService.setTemplet8(templetBooths);
        return  ResultDtoFactory.toAck("success");
    }

}
