package com.hengtiansoft.servlet.applicant.resume.template.zhilian;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.ZhiLianResume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ZhilianPersonTemplate extends ZhiLianResume {

    public void buildBaseInfo(String content, HrResume r) {
        String name = null;
        Document document = Jsoup.parse(content);

        Element nameElement = document.getElementsByClass("summary").get(0).children().get(1);
        if (nameElement != null) {
            name = nameElement.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                    .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
        }
        SexEnum sex = SexEnum.MAN;
        String city = null;
        int age = 0;
        Element baseNode = document.getElementsByClass("summary").get(0);
        String str = baseNode.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("&nbsp;", "")
                .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
        if (str.contains("年")) {
            age = getAgeFromBirth(strSubstring(str, "|", "年"), strSubstring(str, "年", "月"));
        }
        if (str.contains("女")) {
            sex = SexEnum.WOMAN;
        }

        // 过滤名字
        if (!StringUtils.isEmpty(name)) {
            Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]{2,4}");
            Matcher matcher = reg.matcher(name);
            while (matcher.find()) {
                name = matcher.group();
                break;
            }
        }

        String newContent = content.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                .replaceAll("\r", "").replaceAll(" ", "");

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setContent(newContent);
        r.setSource(ResumeSourceEnum.ZHILIANUPLOAD);
    }

    private int getAgeFromBirth(String birth_year, String birth_month) {
        int age = 0;

        Date now = new Date();

        SimpleDateFormat format_y = new SimpleDateFormat("yyyy");
        SimpleDateFormat format_M = new SimpleDateFormat("MM");

        String this_year = format_y.format(now);

        String this_month = format_M.format(now);

        age = Integer.parseInt(this_year) - Integer.parseInt(birth_year);

        if (this_month.compareTo(birth_month) < 0)
            age -= 1;
        if (age < 0)
            age = 0;
        return age;
    }

    public void buildContactInfo(String content, HrResume r) {

    }

    public void buildOtherInfo(String content, HrResume r) {
        String expectCity = "";
        String post = "", expectSalary = "";
        Document document = Jsoup.parse(content);
        Elements intentionElements = document.getElementsByClass("details").get(0).children().get(1).children().get(0)
                .children();
        if (intentionElements != null) {
            for (Element element : intentionElements) {
                String str = element.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                        .replaceAll("&nbsp;", "").replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "")
                        .replaceAll(" ", "");
                if (str.contains("期望职业")) {
                    post = str.replace("期望职业：", "");
                }
                if (str.contains("工作地区")) {
                    expectCity = str.replace("工作地区：", "");
                }
                if (str.contains("期望月薪")) {
                    expectSalary = str.replace("期望月薪：", "");
                    expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
                }
            }
        }

        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        String workExperience = "";
        String projectExperience = "";
        String education = "";
        String staffType = "";
        String school = null;
        String degree = null;
        String major = null;
        Document document = Jsoup.parse(content);
        Element eduElement = document.getElementsByClass("education-background").get(0).children().get(1);
        String eduStr = eduElement.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
        school = eduStr.substring(BEGIN_OFF_SET_ZERO, eduStr.indexOf("|"));
        major = strSubstring(eduStr, "|", "|");
        degree = eduStr.substring(eduStr.lastIndexOf("|") + 1);

        Elements workElement = document.getElementsByClass("work-experience");
        if (workElement != null) {
            for (Element wordnode : workElement) {
                workExperience += wordnode.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                        .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
            }
        }
        Elements proElement = document.getElementsByClass("project-experience");
        if (proElement != null) {
            for (Element pronode : proElement) {
                projectExperience += pronode.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                        .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
            }
        }
        Elements eduNodes = document.getElementsByClass("education-background");
        if (eduNodes != null) {
            for (Element edunode : eduNodes) {
                education += edunode.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                        .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
            }
        }
        Element staffTypeNode = document.getElementsByClass("details").get(0).children().get(1).children().get(0)
                .children().get(0);
        if (staffTypeNode != null) {
            String staffTypestr = staffTypeNode.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                    .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
            if (staffTypestr.contains("全职")) {
                staffType = "全职";
            } else if (staffTypestr.contains("兼职")) {
                staffType = "兼职";
            }
        }

        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
        r.setStaffType(staffType);
    }
}
