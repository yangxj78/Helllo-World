package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface UserWorkExperienceMapper extends MyMapper<UserWorkExperience> {

}