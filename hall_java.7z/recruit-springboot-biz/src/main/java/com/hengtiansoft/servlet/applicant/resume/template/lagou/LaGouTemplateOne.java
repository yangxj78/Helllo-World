package com.hengtiansoft.servlet.applicant.resume.template.lagou;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.LaGouResume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LaGouTemplateOne extends LaGouResume {

    public static final int NUM_ZERO = 0;
    public static final int NUM_ONE = 1;
    public static final int NUM_TWO = 2;
    public static final int NUM_THREE = 3;
    public static final int NUM_FOUR = 4;

    @Override
    public void buildContactInfo(String content, HrResume r) {
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String[] arr = content.split("\n");
        List<String> list = new ArrayList<String>();
        for (String str : arr) {
            if (!StringUtils.isBlank(str.trim())) {
                list.add(str.trim());
            }
        }

        String post = null;
        String expectCity = null;
        String staffType = null;
        String expectSalary = null;
        if (list.indexOf("期望工作") != -1) {
            String[] expectInfos = list.get(list.indexOf("期望工作") + NUM_ONE).replaceAll(" ", "").replaceAll(" ", "")
                    .split("，");
            post = fieldTrim(expectInfos[NUM_ZERO]);
            if (expectInfos.length > NUM_ONE)
                staffType = fieldTrim(expectInfos[NUM_ONE]);
            if (expectInfos.length > NUM_TWO)
                expectCity = fieldTrim(expectInfos[NUM_TWO]);
            if (expectInfos.length > NUM_THREE)
                expectSalary = fieldTrim(expectInfos[NUM_THREE]);
        }
        String englishLevel = getEnglishLevel(content);


        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setStaffType(staffType);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = "";
        String projectExperience = "";
        String education = "";
        String selfIntroduction = "";
        List<String> workExperienceList = new ArrayList<String>();
        List<String> eduExperienceList = new ArrayList<String>();
        int[] indexs = {
                content.indexOf("工作经历"),
                content.indexOf("项目经验"),
                content.indexOf("教育经历"),
                content.indexOf("自我描述"),
                content.indexOf("期望工作"),
                content.indexOf("作品展示"),
                content.indexOf("技能评价"),
                content.indexOf("实习经历")
        };
        Arrays.sort(indexs);
        String[] arr = new String[indexs.length];
        for (int i = 0; i < indexs.length; ++i) {
            if (indexs[i] == -1) arr[i] = "";
            else if (i + 1 < indexs.length)
                arr[i] = content.substring(indexs[i], indexs[i + 1]);
            else
                arr[i] = content.substring(indexs[i]);
        }

        for (int i = 0; i < arr.length; ++i) {
            String str = filtercontent(arr[i]).replace("\n", "");
            if (str.startsWith("工作经历") || str.startsWith("实习经历")) {
                workExperience = fieldTrim(str.replaceFirst("工作经历", "").replaceFirst("实习经历", ""));
                workExperienceList = getExperienceList(arr[i]);
            }
            if (str.startsWith("项目经验")) {
                projectExperience = fieldTrim(str.replaceFirst("项目经验", ""));
            }
            if (str.startsWith("教育经历")) {
                education = fieldTrim(str.replaceFirst("教育经历", ""));
                eduExperienceList = getExperienceList(arr[i]);
            }
            if (str.startsWith("自我描述")) {
                selfIntroduction = fieldTrim((str.replaceFirst("自我描述", "")));
            }
        }


        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
        r.setUserEducationExperienceList(getEduExpList(eduExperienceList, ifLocalZJ(r.getCity())));
        r.setSchool(r.getUserEducationExperienceList().get(0).getSchool());
        r.setMajor(r.getUserEducationExperienceList().get(0).getMajor());
        r.setGraduateDate(r.getUserEducationExperienceList().get(0).getEndTs());
        r.setDegree(EducationalEnum.getEduDesc(r.getUserEducationExperienceList().get(0).getEducational()));
        r.setUserWorkExperienceList(getWorkExpList(workExperienceList));
        r.setSelfIntroduction(selfIntroduction);
    }

    private List getExperienceList(String content) {
        String str, strs[];
        if (content.contains("工作经历") ||  content.contains("实习经历")) {
            str = content.replaceFirst("工作经历", "").replaceAll("实习经历", "").replaceFirst("教育经历", "");
            strs = content.split("\n \n");
        } else {
            str = content.replaceFirst("教育经历", "");
            str = str.replaceAll("毕业", "毕业##");
            strs = str.split("##");
        }
        List<String> exps = new ArrayList<>();
        for (String exp : strs) {
            if (!exp.equals("") && !exp.equals(" ") && !exp.contains("简历来自")) {
                exps.add(exp.replaceFirst("##", ""));
            }
        }
        return exps;
    }

    private List<UserEducationExperience> getEduExpList(List<String> expList, int city) {
        List<UserEducationExperience> eduExpList = new ArrayList<>();
        for (String str : expList) {
            str = fieldTrim(str);
            UserEducationExperience exp = new UserEducationExperience();
            exp.setLocalZj(city);
            str = fieldTrim(str.replaceAll("\n \n", "\n"));
            String[] strs = str.split("\n");
            if (strs.length == 3) {
                if (!fieldTrim(strs[0]).equals("") && !fieldTrim(strs[0]).equals("\n")) {
                    exp.setSchool(fieldTrim(strs[0]));
                } else exp.setSchool("");
                if (!fieldTrim(strs[1]).equals("") && !fieldTrim(strs[1]).equals("\n")) {
                    exp.setEducational(EducationalEnum.verifyEducation(strs[1]));
                    exp.setMajor(fieldTrim(strs[1].split("·")[1]));
                } else {
                    exp.setEducational(EducationalEnum.verifyEducation("本科"));
                    exp.setMajor("");
                }
                if (!fieldTrim(strs[0]).equals("") && !fieldTrim(strs[0]).equals("\n")) {
                    exp.setStartTs(fieldTrim(strs[2].replace("毕业", "")));
                    exp.setEndTs(fieldTrim(strs[2].replace("毕业", "")));
                } else {
                    exp.setStartTs("");
                    exp.setEndTs("");
                }
                eduExpList.add(exp);
            }
        }

        return eduExpList;
    }

    private List<UserWorkExperience> getWorkExpList(List<String> expList) {
        List<UserWorkExperience> workExpList = new ArrayList<>();
        for (String str : expList) {
            str = fieldTrim(str.replaceFirst("实习经历", "").replaceFirst("工作经历", ""));
            UserWorkExperience exp = new UserWorkExperience();
            int index = str.indexOf("  ");
            exp.setCompany(str.substring(0, index).replaceAll(" ", ""));
            str = fieldTrim(str.substring(index).replaceFirst("\n", ""));
            index = str.indexOf("  ");
            exp.setJob(str.substring(0, index).replaceAll(" ", ""));
            str = fieldTrim(str.substring(index).replaceFirst("\n", ""));
            index = str.indexOf("  ");
            String[] dates = str.substring(0, index).split("-");
            exp.setStartTs(dates[0].replaceAll("\\.", "-"));
            exp.setEndTs(dates[1].replaceAll("\\.", "-"));
            exp.setDescription(fieldTrim(str.substring(index)).replaceAll("\n", "").replaceAll(" ", ""));
            workExpList.add(exp);
        }
        return workExpList;
    }
    @Override
    public void buildBaseInfo(String content, HrResume r) {

        String birthDate = null;
        content = filtercontent(content);
        String[] arr = content.split("\n");
        List<String> list = new ArrayList<String>();
        for (String str : arr) {
            if (!StringUtils.isBlank(str.trim()) && !str.contains("简历来自：拉勾网 - 最专业的互联网招聘网站 - www.lagou.com")) {
                list.add(str.trim());
            }
        }

        String name = list.get(1);
        String year = getWorkedYears(content);

        {
            String regex = "[0-9]{4}\\.[0-1][0-9](\\.[1-3][0-9]){0,1}";
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(list.get(4));
            if (matcher.find()) {
                birthDate = matcher.group();
                String rg = "[0-9]{4}\\.[0-1][0-9]";
                Pattern ptn = Pattern.compile(rg);
                Matcher mc = ptn.matcher(birthDate);
                if (mc.matches()) {
                    birthDate += ".01";
                }
            } else {
                birthDate = "8888.12.31";
            }
        }
        SexEnum sex = SexEnum.MAN;
        String city = null;
        for (String str : list) {
            if (str.contains("工作经验")) {
                String[] infos = str.replaceAll(" ", "").split("︳");

                for (String s : infos) {
                    if ("女".equals(s)) {
                        sex = SexEnum.WOMAN;
                    }

                    if (s.contains("工作经验")) {
                        year = s.replaceAll("年工作经验", "");
                    }
                }

                city = infos[infos.length - NUM_ONE];
                break;
            }
        }

        r.setName(name);
        r.setSex(sex);
        r.setBirthDate(birthDate);
        r.setYears(year);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.LAGOUUPLOAD);
    }

    public String filtercontent(String content) {
        return content.replaceAll("", " ").replaceAll("", " ").replaceAll("", " ");
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);

        Document document = Jsoup.parse(content);
        Elements postElements = document.select("body div div div p");

        Elements postElement = postElements.select("span:containsOwn(拉勾网)");
        String rawPost = postElement.text();
        int postIndex = rawPost.indexOf("主题:（简历来自拉勾）");
        String post = rawPost.substring(postIndex + "主题:（简历来自拉勾）".length());
        post = post.replace("：", "");

        Elements elements = document.select("body table tr:eq(1) div:eq(2) p span:eq(0)");
        String rawContent = elements.text();
        String[] contentArray = rawContent.split("\\|");
        String name = contentArray[0];
        String sex = contentArray[1];
        String degree = contentArray[2];
        String rawYears = contentArray[3];

        SexEnum realSex = getRealSex(sex);

        r.setName(name);
        r.setAge(0);
        r.setDegree(degree);
        r.setContent(content);
        r.setYears(rawYears);
        r.setSex(realSex);
        r.setSource(ResumeSourceEnum.LAGOUCOLLECT);
        r.setPost(post);
    }
}
