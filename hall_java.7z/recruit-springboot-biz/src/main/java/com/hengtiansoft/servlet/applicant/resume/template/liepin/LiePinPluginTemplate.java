package com.hengtiansoft.servlet.applicant.resume.template.liepin;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.List;

public class LiePinPluginTemplate extends Job51Resume {

    public void buildBaseInfo(String content, HrResume r) {

    }

    public void buildContactInfo(String content, HrResume r) {

    }

    public void buildOtherInfo(String content, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = "";
        String projectExperience = "";
        String education = "";
        String school = "";
        String major = "";
        String degree = "";
        String graduateDate = "";

        Document document = Jsoup.parse(content);

        if (document.getElementById("workexp_anchor") != null
                && document.getElementById("workexp_anchor").getElementsByClass("exp") != null) {
            workExperience = document.getElementById("workexp_anchor").getElementsByClass("exp").toString();
            workExperience = workExperience.replaceAll("<.*?>", "").replaceAll("\r", "").replaceAll(" ", "")
                    .replaceAll("\n", TEMPLATE_CSS);
            workExperience = removeBr(workExperience);

        }

        if (document.getElementsByClass("exp") != null) {

            if (!StringUtils.isBlank(workExperience) && document.getElementsByClass("exp").get(1) != null) {
                projectExperience = document.getElementsByClass("exp").get(1).toString();
                projectExperience = projectExperience.replaceAll("<.*?>", "").replaceAll("\r", "").replaceAll(" ", "")
                        .replaceAll("\n", TEMPLATE_CSS);
                projectExperience = removeBr(projectExperience);
            }

        }
        if (document.getElementsByClass("cont") != null && document.getElementsByClass("cont").get(1) != null) {

            if (document.getElementsByClass("school") != null) {
                school = document.getElementsByClass("school").text();
            }
            List<Element> list = document.getElementsByClass("cont").get(1).select("tr");
            List<Element> list2 = null;
            for (Element node : list) {
                if (node.text().contains(school)) {
                    list2 = node.select("td");
                }

            }
            if (list2 == null) {
                list2 = list.get(0).select("td");
            }

            // school

            for (Element node : list2) {
                String str = node.text();
                if (str.contains("专业：")) {
                    major = str.replaceAll("专业：", "");
                } else if (str.contains("学历：")) {
                    degree = str.replaceAll("学历：", "");
                } else if (!StringUtils.isBlank(school) && str.contains(school)) {
                    graduateDate = str.substring(str.lastIndexOf("–") + 1, str.length());
                } else {
                    school = str.substring(0, str.indexOf(" "));
                    graduateDate = str.substring(str.lastIndexOf("–") + 1, str.length());
                }

            }

            education = document.getElementsByClass("cont").get(1).toString();
            education = education.replaceAll("<.*?>", "").replaceAll("\r", "").replaceAll(" ", "")
                    .replaceAll("\n", TEMPLATE_CSS);
            education = removeBr(education);
        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
        r.setDegree(degree);
        r.setMajor(major);
        r.setSchool(school);
        r.setGraduateDate(graduateDate);
    }

}
