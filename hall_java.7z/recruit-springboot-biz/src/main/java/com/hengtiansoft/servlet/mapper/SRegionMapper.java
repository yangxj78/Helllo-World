package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.SRegion;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface SRegionMapper extends MyMapper<SRegion> {
    List<SRegion> list(int i);
}