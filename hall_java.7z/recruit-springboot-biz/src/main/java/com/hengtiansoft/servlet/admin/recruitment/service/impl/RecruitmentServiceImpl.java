package com.hengtiansoft.servlet.admin.recruitment.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.enumeration.RecruitmentStartTypeEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentCacheService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.manage.companySign.CompanySignService;
import com.hengtiansoft.servlet.mapper.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class RecruitmentServiceImpl extends BaseService<Recruitment> implements RecruitmentService {

    @Autowired
    RecruitmentMapper recruitmentMapper;

    @Autowired
    CollectionPositionMapper collectionPositionMapper;
    @Autowired
    ReviewPositionRecordMapper reviewPositionRecordMapper;
    @Autowired
    ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    ResumeDeliveryPreMapper resumeDeliveryPreMapper;
    @Autowired
    TempletBoothMapper templetBoothMapper;
    @Autowired
    CompanySignService companySignService;
    @Autowired
    RecruitmentCacheService recruitmentCacheService;
    @Autowired
    BoothService boothService;
    private static final Logger LOGGER = LoggerFactory.getLogger(RecruitmentService.class);

    @Override
    public List<Recruitment> getAll(RecruitmentSearch recruitmentSearch) {
        return recruitmentMapper.getAll(recruitmentSearch);
    }

    @Override
    public Integer createRecruitment(Recruitment recruitment) {
        String name = SecurityContext.getCurrentUser().getUsername();
        recruitment.setCreateBy(name);
        recruitment.setUpdateBy(name);
        recruitmentMapper.add(recruitment);
        LOGGER.info(recruitment.getId().toString());
        TempletBooth templetBooth = new TempletBooth();
        //判断招聘会类型和招聘会是否使用设备
        if (recruitment.getDevice() && recruitment.getStyle() == 0) {
            for (int i = 1; i <= 60; i++) {
                templetBooth.setId(null);
                templetBooth.setRecruitmentId(recruitment.getId());
                templetBooth.setBoothId(i);
                templetBooth.setTempletId(1);
                templetBoothMapper.insertSelective(templetBooth);
            }
        } else if (recruitment.getDevice() && recruitment.getStyle() == 1) {
            for (int i = 1; i <= 60; i++) {
                templetBooth.setId(null);
                templetBooth.setRecruitmentId(recruitment.getId());
                templetBooth.setBoothId(i);
                templetBooth.setTempletId(2);
                templetBoothMapper.insertSelective(templetBooth);
            }
        }
        return recruitment.getId();
    }

    @Override
    @Transactional
    public int updateRecruitment(Recruitment recruitment) {
        recruitmentCacheService.flushCurrentRecruitment();
        String name = SecurityContext.getCurrentUser().getUsername();
        recruitment.setUpdateBy(name);
        recruitmentMapper.updateById(recruitment);
        //判断一天是否只存在一场使用设备招聘会
        if (recruitment.getDevice()) {
            RecruitmentSearch search = new RecruitmentSearch();
            search.setStartDate(recruitment.getDate());
            search.setEndDate(recruitment.getDate());
            search.setDevice(true);
            search.setAddress(recruitment.getAddress());
            if (recruitmentMapper.getAll(search).size() > 1) {
                throw new RuntimeException();
            }
        }
        TempletBooth templetBooth = new TempletBooth();
        //判断招聘是否使用设备和招聘会类型
        if (recruitment.getDevice() && recruitment.getStyle() == 0) {
            templetBooth.setRecruitmentId(recruitment.getId());
            templetBooth.setTempletId(1);
            templetBoothMapper.updateByRecruitment(templetBooth);
        } else if (recruitment.getDevice() && recruitment.getStyle() == 1) {
            templetBooth.setRecruitmentId(recruitment.getId());
            templetBooth.setTempletId(2);
            templetBoothMapper.updateByRecruitment(templetBooth);
        }
        Recruitment recruitment1 = recruitmentMapper.selectByPrimaryKey(recruitment.getId());
        if (recruitment1.getStartType() == 1) {
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.RECRUITMENT_UPDATE.getCode());
            for (int i = 1; i < 60; i++) {
                NettyClientUtil.notifyTv(i, JSON.toJSONString(map));
            }
        }
        return 1;
    }

    @Override
    public List<Recruitment> getRecruitmentByTypeId(Integer id) {
        return recruitmentMapper.getRecruitmentByTypeId(id);
    }

    @Override
    public Recruitment getRecruitmentMapperById(Integer id) {
        return recruitmentMapper.selectByPrimaryKey(id);
    }

    @Override
    /**
     *@Description: 获取招聘会统计表信息
     **/
    public List<RecruirmentTableDto> getRecruitmentTable(RecruitmentSearch recruitmentSearch) {
        return recruitmentMapper.getRecruitmentTable(recruitmentSearch);
    }

    @Override
    public int deleteRecruitment(Integer id) {
        Recruitment recruitment = new Recruitment();
        recruitment.setId(id);
        recruitment.setStatus(1);
        templetBoothMapper.deleteByRecruitment(id);
        return recruitmentMapper.updateById(recruitment);
    }

    @Override
    public List<RecruitmentDataDto> getRecruitmentData(RecruitmentSearch recruitmentSearch) {
        return recruitmentMapper.getRecruitmentData(recruitmentSearch);
    }

    @Override
    public List<EnrollTable> getEnrollTable(int id) {
        return recruitmentMapper.getEnrollTable(id);
    }

    @Override
    public List<RecruitmentAppDataDto> getRecruitmentDataForApplicant(RecruitmentSearch recruitmentSearch) {

        //查询定展数据源
        List<RecruitmentDataDto> dataDtos = getRecruitmentData(recruitmentSearch);

        if (CollectionUtils.isEmpty(dataDtos)) {
            return null;
        }

        List<RecruitmentAppDataDto> dtos = new ArrayList<>();


        //Map<展位号，List<岗位ID,岗位名>>
        Map<Integer, List<BaseIDNameDto>> companyMap = new HashMap<>();
        for (RecruitmentDataDto dataDto : dataDtos) {
            if (StringUtils.isEmpty(dataDto.getPositionName())) {
                continue;
            }
            if (companyMap.containsKey(dataDto.getBoothID())) {
                //重复的公司合并岗位名
                companyMap.get(dataDto.getBoothID())
                        .add(new BaseIDNameDto(dataDto.getPositionRecordID(), dataDto.getPositionName()));
            } else {
                List<BaseIDNameDto> list = new ArrayList<>();
                list.add(new BaseIDNameDto(dataDto.getPositionRecordID(), dataDto.getPositionName()));
                companyMap.put(dataDto.getBoothID(), list);
                RecruitmentAppDataDto recruitmentAppDataDto = new RecruitmentAppDataDto();
                recruitmentAppDataDto.setRecruitmentID(dataDto.getRecruitmentID());
                recruitmentAppDataDto.setBoothID(dataDto.getBoothID());
                recruitmentAppDataDto.setCompanyName(dataDto.getCompanyName());
                recruitmentAppDataDto.setCompanyId(dataDto.getCompanyID());
                recruitmentAppDataDto.setPositionRecordList(list);
                dtos.add(recruitmentAppDataDto);
            }
        }
        return dtos;
    }

    @Override
    public List<ExcelPositionData> getExcelPositionData(Integer id) {
        return recruitmentMapper.getExcelPositionData(id);
    }

    @Override
    public List<ExcelUserData> getExcelUserData(Integer id) {
        return recruitmentMapper.getExcelUserData(id);
    }

    @Override
    public List<ResumeDeliveryDataDto> getResumeDeliveryData(ResumeDeliveryDataSearchDto
                                                                     resumeDeliveryDataSearchDto) {
        return recruitmentMapper.getResumeDeliveryData(resumeDeliveryDataSearchDto);
    }

    @Override
    public Recruitment getCurrentRecruitment() {
        LOGGER.debug("start------------------------------------------------------------");
        return recruitmentCacheService.getCurrentRecruitment();
    }

    @Override
    public Recruitment getById(Integer id) {
        return recruitmentMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<ParkingAndMealDto> listParkingAndMeal(Integer recruitmentID) {
        return recruitmentMapper.listParkingAndMeal(recruitmentID);
    }

    @Override
    public Integer getTotalMealsNum(Integer recruitmentID) {
        return recruitmentMapper.getTotalMealsNum(recruitmentID);
    }

    @Override
    public ResultDto startRecruitment(Integer id) {
        if (getCurrentRecruitment() != null) {
            return ResultDtoFactory.toNack("现场已有进行中的招聘会");
        }
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(id);
        if (recruitment == null) {
            return ResultDtoFactory.toNack("无此招聘会");
        }

        recruitment.setStartType(RecruitmentStartTypeEnum.STARTED.getCode());
        recruitmentCacheService.flushCurrentRecruitment();
        recruitmentCacheService.updateCurrentRecruitment(recruitment);
        recruitmentMapper.updateById(recruitment);

        Map map = new HashMap();
        map.put("status", 1);
        map.put("nettyType", NettyInfoEnum.RECRUITMENT_START.getCode());
        String jsonString = JSON.toJSONString(map);
        NettyClientUtil.notifyAllHR(jsonString);
        NettyClientUtil.notifyBigScreen(jsonString);
        NettyClientUtil.notifyAllTv(jsonString);
        NettyClientUtil.notifySelfHelpMachine(jsonString);
        reviewPositionRecordMapper.reduction(id);

        return ResultDtoFactory.toAck("success");
    }

    @Override
    public ResultDto endRecruitment(Integer id) {
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(id);
        if (recruitment == null) {
            return ResultDtoFactory.toNack("无此招聘会");
        }
        if (!recruitment.getStartType().equals(RecruitmentStartTypeEnum.STARTED.getCode())) {
            return ResultDtoFactory.toNack("当前招聘会未进行");
        }
        recruitment.setStartType(RecruitmentStartTypeEnum.END.getCode());
        recruitmentCacheService.flushCurrentRecruitment();
        recruitmentMapper.updateById(recruitment);

        Map map = new HashMap();
        map.put("status", 2);
        map.put("nettyType", NettyInfoEnum.RECRUITMENT_END.getCode());
        String jsonString = JSON.toJSONString(map);
        NettyClientUtil.notifyAllHR(jsonString);
        NettyClientUtil.notifyBigScreen(jsonString);
        NettyClientUtil.notifyAllTv(jsonString);
        NettyClientUtil.notifySelfHelpMachine(jsonString);
        List<ReviewPositionRecord> expire = reviewPositionRecordMapper.getExpire();
        expire.forEach(n -> reviewPositionRecordMapper.operation(n.getId(), "招聘会已过期", 3));
        return ResultDtoFactory.toAck("success");
    }

    @Override
    public int getAttendOrLeaveNumber(int type, int recruitmentId) {
        Timestamp today = new Timestamp(System.currentTimeMillis());
        return recruitmentMapper.getAttendOrLeaveNumber(type, recruitmentId, today);
    }

    @Override
    public List<StationDto> getStationsByRecruitmentId(int recruitmentId) {
        return recruitmentMapper.getStationsByRecruitmentId(recruitmentId);
    }

    @Override
    public Map analysis(AnalysisDto analysisDto) {
        Map map = new HashMap();
        if (analysisDto.getType() == 0) {
            map.put("PositionAndCompnay", recruitmentMapper.analysisPositionAndCompnay(analysisDto));
            map.put("compnayType", recruitmentMapper.analysisCompnayType(analysisDto));
            map.put("totalCompany", recruitmentMapper.countCompany(analysisDto));
            map.put("compnayTrade", recruitmentMapper.analysisCompnayTrade(analysisDto));
            map.put("positionSalary", recruitmentMapper.analysisPositionSalary(analysisDto));
            map.put("totalPosition", recruitmentMapper.countPosition(analysisDto));
            map.put("positionEducation", recruitmentMapper.analysisPositionEducation(analysisDto));
            return map;
        }
        map.put("education", recruitmentMapper.analysisEducation(analysisDto));
        map.put("workYears", recruitmentMapper.analysisWorkYears(analysisDto));
        map.put("salary", recruitmentMapper.analysisSalary(analysisDto));
        map.put("delivery", recruitmentMapper.analysisDelivery(analysisDto));
        map.put("year", recruitmentMapper.analysisYear(analysisDto));
        return map;
    }

    @Override
    public ResultDto collectionPosition(CollectionPositionSearchDto searchDto) {
        if (getCollectionPosition(searchDto)) {
            return ResultDtoFactory.toNack("该岗位已经收藏");
        } else {
            if (collectionPositionMapper.insertCollectionPosition(searchDto) > 0) {
                return ResultDtoFactory.toAck("success");
            }
            return ResultDtoFactory.toNack("收藏失败");
        }
    }

    @Override
    public List<CollectionPositionDto> listCollectionPosition(CollectionPositionSearchDto searchDto) {
        return collectionPositionMapper.listCollectionPosition(searchDto);
    }

    @Override
    public List<RecruitmentSearchDto> listRecruitmentSearchs(Integer userId) {
        return collectionPositionMapper.listRecruitmentSearchs(userId);
    }

    @Override
    public List<RecruitmentDataDto> positionRecordSearch(PositionRecordSearch positionRecordSearch) {
        return recruitmentMapper.search(positionRecordSearch);
    }

    @Override
    public List<RecruitmentDataDto> positionRecordSearch2(PositionRecordSearch positionRecordSearch) {
        return recruitmentMapper.search2(positionRecordSearch);
    }

    @Override
    public Boolean getCollectionPosition(CollectionPositionSearchDto searchDto) {
        return collectionPositionMapper.getCollectionPosition(searchDto) != null;
    }

    @Override
    public Integer deleteCollectionPosition(CollectionPositionSearchDto searchDto) {
        Integer id = collectionPositionMapper.getCollectionPosition(searchDto);
        return collectionPositionMapper.deleteByPrimaryKey(id);
    }

    @Override
    public Boolean isDelivery(CollectionPositionSearchDto searchDto) {
        //判断岗位是否投递
        ResumeDelivery resumeDelivery = new ResumeDelivery();
        resumeDelivery.setUserId(searchDto.getUserId());
        resumeDelivery.setPositionRecordId(searchDto.getPositionRecordId());
        return CollectionUtils.isEmpty(resumeDeliveryMapper.select(resumeDelivery)) ? Boolean.FALSE : Boolean.TRUE;
    }

    @Override
    public Boolean isPreDelivery(CollectionPositionSearchDto searchDto) {
        //判断岗位是否预投递
        ResumeDeliveryPre resumeDeliveryPre = new ResumeDeliveryPre();
        resumeDeliveryPre.setUserId(searchDto.getUserId());
        resumeDeliveryPre.setPositionRecordId(searchDto.getPositionRecordId());
        return CollectionUtils.isEmpty(resumeDeliveryPreMapper.select(resumeDeliveryPre)) ? Boolean.FALSE : Boolean.TRUE;
    }
}
