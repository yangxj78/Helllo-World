package com.hengtiansoft.servlet.admin.recycle.service;

import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.common.service.Service;
import java.util.List;

public interface RecycleService extends Service<Recycle> {
    void deleteAll();
    int deleteByID(Integer id);
    List<Recycle> list();
}
