package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.until.ChineseName;
import org.ansj.domain.Term;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class CustomResume extends BaseResume {

    public static final int BEGIN_OFF_SET_ZERO = 0;
    public static final int BEGIN_OFF_SET_THREE = 3;
    public static final int BEGIN_OFF_SET_SIX = 6;
    public static final int BEGIN_OFF_SET_EIGHT = 8;
    public static final int END_OFF_SET_ZERO = 0;

    public void buildInfo(ConentType contentType, HrResume r) {
        String content = contentType.getContent();
        if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                || "html".equals(contentType.getType()) || "docx".equals(contentType.getType())) {
            content = filtercontent(content);
            content = content.replaceAll(" ", "");
        }
        String sentences = contentType.getContent();

        Map<String, Term> termMap = getResumeMatcheTerms(content);

        // 姓名
        if (StringUtils.isBlank(r.getName()) || r.getName().trim().length() > MagicNumConstant.FOUR) {
            String name = getPersonName(termMap);
            r.setName(name);
        }
        // 工作年限
        if (StringUtils.isBlank(r.getYears()) || r.getYears().length() > MagicNumConstant.TEN) {
            String year = getWorkYear(termMap);
            r.setYears(year);
        }
        // 性别
        if (r.getSex() == null) {
            r.setSex(SexEnum.MAN);
            String sex = getSex(termMap);
            if (sex != null) {
                sex = sex.trim();
            }
            if (SexEnum.WOMAN.getDesc().equals(sex)) {
                r.setSex(SexEnum.WOMAN);
            }
        }
        if (r.getSchool() == null) {
            String school = getSchoolByHanLp(sentences);
            r.setSchool(school);
        }
        if (r.getPost() != null && r.getPost().length() > MagicNumConstant.TWENTY) {
            r.setPost(r.getPost().substring(MagicNumConstant.ZERO, MagicNumConstant.TWENTY));
        }
        setSchoolAndMajor(content, r);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        if (StringUtils.isBlank(r.getEmail())) {
            r.setEmail(email);
        } else {
            String newRegEmail = getEmailAddress(r.getEmail());
            if (!r.getEmail().equals(newRegEmail)) {
                r.setEmail(newRegEmail);
            }
        }
        if (StringUtils.isBlank(r.getPhone())) {
            r.setPhone(phone);
        } else {
            String newRegPhone = getPhone(r.getPhone());
            if (!r.getPhone().equals(newRegPhone)) {
                r.setPhone(newRegPhone);
            }
        }

        if (StringUtils.isNotBlank(r.getStaffType()) && r.getStaffType().length() > MagicNumConstant.THREE) {
            r.setStaffType(r.getStaffType().substring(MagicNumConstant.ZERO, MagicNumConstant.THREE));
        }

        if (r.getExpectCity() != null && r.getExpectCity().length() > MagicNumConstant.TWENTY) {
            r.setExpectCity(r.getExpectCity().substring(MagicNumConstant.ZERO, MagicNumConstant.TWENTY));
        }

        String englishLevel = getEnglishLevel(content);
        if (StringUtils.isBlank(r.getEngLevel()) && StringUtils.isNotBlank(englishLevel)) {
            r.setEngLevel(englishLevel);
        }

        r.setSource(ResumeSourceEnum.OTHER);
    }

    public void buildInfoByOldParse(ConentType contentType, HrResume r) {
        String content = contentType.getContent();
        if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                || "html".equals(contentType.getType()) || "docx".equals(contentType.getType())) {
            content = filtercontent(content);
        }
        // 姓名
        if (StringUtils.isBlank(r.getName())) {
            String name = ChineseName.getName(content.substring(0, 300));
            if(name == null){
                name = ChineseName.getPersonNameByHanlp(content);
            }
            r.setName(name);
        }
        // 工作年限
        if (StringUtils.isBlank(r.getYears()) || r.getYears().length() > MagicNumConstant.TEN) {
            String year = getWorkedYears(content);
            r.setYears(year);
        }
        // 性别
        if (r.getSex() == null) {
            r.setSex(SexEnum.MAN);
            if (contentType.getContent().substring(MagicNumConstant.ZERO, MagicNumConstant.THREE_HUNDRED).contains("女")) {
                r.setSex(SexEnum.WOMAN);
            }
        }
        //年龄
        int age = getAge(content);
        r.setAge(age);
        if (StringUtils.isNotBlank(r.getStaffType()) && r.getStaffType().length() > MagicNumConstant.THREE) {
            r.setStaffType(r.getStaffType().substring(MagicNumConstant.ZERO, MagicNumConstant.THREE));
        }
        if (r.getPost() != null && r.getPost().length() > MagicNumConstant.TWENTY) {
            r.setPost(r.getPost().substring(MagicNumConstant.ZERO, MagicNumConstant.TWENTY));
        }
        if (r.getExpectCity() != null && r.getExpectCity().length() > MagicNumConstant.TWENTY) {
            r.setExpectCity(r.getExpectCity().substring(MagicNumConstant.ZERO, MagicNumConstant.TWENTY));
        }
        setSchoolAndMajor(content, r);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
        r.setSource(ResumeSourceEnum.OTHER);
        r.setContent(content);
    }

    @Override
    public void buildContactInfo(String content, HrResume r) {

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        if (content.contains("年工作经验") && StringUtils.isBlank(r.getYears())) {
            String year = getWorkedYears(content);
            r.setYears(year);
        }
        int age = getAge(content);
        r.setAge(age);

        if (StringUtils.isBlank(r.getName())) {
            String[] str = content.split("\r\n|\r|\n");
            for (int i = 0; i < 2; i++) {
                String name = ChineseName.getName(str[i]);
                if (!StringUtils.isBlank(name)) {
                    r.setName(name);
                }
            }
        }

    }

//    public String getName(String content, HrResume r) {
//        String name = null;
//        if (StringUtils.isBlank(r.getName())) {
//            String[] str = content.split("\r\n|\r|\n|\b|&nbsp;");
//            List<String> list = new ArrayList<String>();
//            Arrays.asList(str).forEach(e -> {
//                if (!StringUtils.isBlank(e)) {
//                    list.add(e);
//                }
//            });
//            for (int i = 0; i < list.size() && i < MagicNumConstant.TEN; i++) {
//                String name1 = ChineseName.getName(fieldTrim(list.get(i)));
//                if (StringUtils.isBlank(name) && !StringUtils.isBlank(name1) && !name1.startsWith("简历")
//                        && !name1.startsWith("毕业")) {
//                    name = name1;
//                    break;
//                }
//            }
//        }
//        return fieldTrim(name);
//    }

    public String filtercontent(String content) {
        return content.replaceAll("<xml>.*?</xml>", "").replaceAll("<style>.*?</style>", "").replaceAll("<.*?>", "");
    }

    public int getAge(String content) {
        Pattern reg = Pattern.compile("(\\d{2}\\s{0,2})岁");
        Matcher matcher = reg.matcher(content);
        int age = 0;
        while (matcher.find()) {
            age = Integer.parseInt(matcher.group(1).trim());
        }
        return age;
    }

    public void setSchoolAndMajor(String content, HrResume r) {
        String education;
        //数据切割
        if (content.contains("教育经历")) {
            education = content.substring(content.indexOf("教育经历"));
        } else if (content.contains("教育背景")) {
            education = content.substring(content.indexOf("教育背景"));
        } else {
            education = content;
        }
        //教育经历分段
        String[] str = education.split("\r\n|\r|\n|\b|&nbsp;|\\s+|\\(|（|\\)|）| |\\|");
        List<String> list = new ArrayList<String>();
        //数组转换成List，并去除空的String
        Arrays.asList(str).forEach(e -> {
            if (!StringUtils.isBlank(e)) {
                list.add(e);
            }
        });
        String school = r.getSchool();

        String major = r.getMajor();
        String degree = r.getDegree();
        Pattern reg;
        Matcher matcher;
        //如果简历中没有学校信息，去教育经历中查找
        if (StringUtils.isBlank(school) || school.length() > MagicNumConstant.TWENTY) {
            school = null;
            //寻找大学|学院|学校结尾的字符串
            reg = Pattern.compile("[\\u4e00-\\u9fa5]+(大学|学院|学校)");
            out: for (String s : list) {
                if (s.endsWith("大学") || s.endsWith("学院") || s.endsWith("学校")) {
                    matcher = reg.matcher(s);
                    while (matcher.find()) {
                        school = matcher.group();
                        break out;
                    }
                }
            }
        }
        //TODO npl词典解析专业
        //如果简历中没有专业信息，去教育经历中寻找
        if (StringUtils.isBlank(major) || major.length() > MagicNumConstant.TWENTY || major.equals("大专") || major.equals("本科")
                || major.equals("硕士") || major.equals("博士")) {
            major = null;
            reg = Pattern.compile("([\\u4e00-\\u9fa5]+)专业");
            out: for (String s : list) {
                if (s.contains("专业")) {
                    matcher = reg.matcher(s);
                    while (matcher.find()) {
                        major = matcher.group(1);
                        break out;
                    }
                }
            }
            if (null == major) {
                major = list.indexOf(school) > -1 ? list.get(list.indexOf(school) + 1) : null;
            }
        }
        //检查简历中有没有学历信息
        if (StringUtils.isBlank(degree) || degree.length() > MagicNumConstant.FIFTEEN) {
            degree = null;
            reg = Pattern.compile("大专|本科|硕士|博士");
            out: for (String s : list) {
                matcher = reg.matcher(s);
                while (matcher.find()) {
                    degree = matcher.group();
                    break out;
                }
            }
        }
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {

    }

}
