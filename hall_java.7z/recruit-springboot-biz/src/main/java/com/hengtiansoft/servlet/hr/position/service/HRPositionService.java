package com.hengtiansoft.servlet.hr.position.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.HRPositionRecordDto;
import com.hengtiansoft.bean.dataModel.InvitationDto;
import com.hengtiansoft.bean.dataModel.JobSeekerDto;
import com.hengtiansoft.bean.dataModel.PositionRecordSaveDto;

import java.util.List;

/**
 * Created by linwu on 7/25/2018.
 */
public interface HRPositionService {

    /**
     *
     * @param type 0: 获取现场招聘岗位列表, 1: 获取审核岗位列表
     * @param index
     * @param limit
     * @return
     */
    ResultDto<List<HRPositionRecordDto>> findPosition(Integer type, Integer status, Integer index, Integer limit);


    /**
     * 获取该岗位下的投递列表
     * @param id
     * @param index
     * @param limit
     * @return
     */
    ResultDto<List<JobSeekerDto>> findDeliveryList(Integer id, Integer index, Integer limit);


    /**
     * 新增编辑岗位
     * @param positionRecordSaveDto
     * @return
     */
    ResultDto<String> save(PositionRecordSaveDto positionRecordSaveDto);


    /**
     * 删除岗位
     * @param id
     * @return
     */
    ResultDto<String> delete(Integer id);


    /**
     * 智能推荐
     * @param id
     * @return
     */
    ResultDto<List<JobSeekerDto>> selectByMatch(Integer id, Integer index, Integer limit);


    /**
     * 邀约面试
     * @param invitationDto
     * @return
     */
    ResultDto invite(InvitationDto invitationDto);
}
