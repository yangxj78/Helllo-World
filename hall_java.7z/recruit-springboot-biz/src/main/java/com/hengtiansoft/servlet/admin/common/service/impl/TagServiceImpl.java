package com.hengtiansoft.servlet.admin.common.service.impl;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.collection.AhoCorasick.AhoCorasickDoubleArrayTrie;
import com.hankcs.hanlp.dictionary.BaseSearcher;
import com.hankcs.hanlp.dictionary.CoreDictionary;
import com.hankcs.hanlp.dictionary.CustomDictionary;
import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.common.Term;
import com.hengtiansoft.bean.dataModel.AmountDto;
import com.hengtiansoft.bean.tableModel.Tag;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.servlet.admin.common.service.TagService;
import com.hengtiansoft.servlet.mapper.TagMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TagServiceImpl extends BaseService<Tag>  implements TagService {

    @Autowired
    TagMapper tagMapper;
    @Override
    public List<Tag> list(int parentID) {
        return tagMapper.list(parentID);
    }

    @Override
    public Tag getByID(Integer id) {
        return tagMapper.selectByPrimaryKey(id);
    }

    @Override
    public void distinct(Set set) {

        Map<String,Integer> map = new HashMap();
        List<AmountDto> amountDtos = new ArrayList<>();
        for (Object o : set) {
            String s = o.toString();
            int i =  tagMapper.countByName("%"+s+"%");
            AmountDto amountDto = new AmountDto(s,i);
            amountDtos.add(amountDto);
        }
        Collections.sort(amountDtos);

    }

}
