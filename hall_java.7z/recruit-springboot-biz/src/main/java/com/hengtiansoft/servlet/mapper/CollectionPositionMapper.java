package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.CollectionPositionDto;
import com.hengtiansoft.bean.dataModel.CollectionPositionSearchDto;
import com.hengtiansoft.bean.dataModel.RecruitmentSearchDto;
import com.hengtiansoft.bean.tableModel.CollectionPosition;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CollectionPositionMapper extends MyMapper<CollectionPosition> {

    List<RecruitmentSearchDto> listRecruitmentSearchs(Integer userId);

    List<CollectionPositionDto> listCollectionPosition(CollectionPositionSearchDto collectionPositionSearchDto);

    Integer getCollectionPosition(CollectionPositionSearchDto searchDto);

    Integer insertCollectionPosition(CollectionPositionSearchDto searchDto);
}
