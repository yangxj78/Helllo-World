package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.ResumeSearchDto;
import com.hengtiansoft.common.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class ResumeProvider {

    public String selectSimpleResume(Map params){
        ResumeSearchDto resumeSearchDto = (ResumeSearchDto) params.get("resumeSearchDto");
        List<Integer> userIds = (List<Integer>) params.get("userIds");
        StringBuffer stringBuffer = new StringBuffer("select r.id" +
                ", r.user_id as userId" +
                ", ui.name as userName" +
                ", r.name as resumeName" +
                ", ui.educational" +
                ", ui.identity_card as identityCard" +
                ", ui.phone" +
                ", r.work_years as workYears" +
                ", r.source" +
                ", r.default_flag as defaultFlag" +
                ", r.perfect_flag as perfectFlag" +
                ", r.update_ts as updateTs" +
                ", r.status as status" +
                " from resume r" +
                " left join" +
                " user_info ui" +
                " on r.user_id = ui.user_id" +
                " where 1=1 ");

        if(!CollectionUtils.isEmpty(userIds)){
            String ids = StringUtils.join(userIds,",");
            stringBuffer.append(" and r.user_id in ( "+ids+" )");
        }

        if(resumeSearchDto.getWorkYears() != null){
            stringBuffer.append(" and r.work_years = #{resumeSearchDto.workYears}");
        }
        if(!StringUtils.isEmpty(resumeSearchDto.getUpdateBegin())){
            stringBuffer.append(" and r.update_ts >= #{resumeSearchDto.updateBegin}");
        }
        if(!StringUtils.isEmpty(resumeSearchDto.getUpdateEnd())){
            stringBuffer.append(" and r.update_ts <= #{resumeSearchDto.updateEnd}");
        }
        if(resumeSearchDto.getSource()!= null){
            stringBuffer.append(" and r.source = #{resumeSearchDto.source}");
        }
        if(resumeSearchDto.getStatus()!= null){
            stringBuffer.append(" and r.status = #{resumeSearchDto.status}");
        }

        return stringBuffer.toString();
    }
}
