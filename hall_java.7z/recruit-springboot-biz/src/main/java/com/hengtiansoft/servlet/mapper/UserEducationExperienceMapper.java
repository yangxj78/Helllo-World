package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface UserEducationExperienceMapper extends MyMapper<UserEducationExperience> {

}