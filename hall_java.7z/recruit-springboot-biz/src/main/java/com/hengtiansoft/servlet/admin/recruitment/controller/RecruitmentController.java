package com.hengtiansoft.servlet.admin.recruitment.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.RecruitmentSearch;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.servlet.admin.company.service.impl.CompanyServiceImpl;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentCacheService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.admin.recycle.service.RecycleService;
import org.springframework.beans.factory.annotation.Autowired;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@RestController
@RequestMapping("/admin/recruitment")
@Api(value = "招聘会controller", description = "招聘会管理相关接口")
public class RecruitmentController {


    private static final int APPEARANCES_MORNING = 0;
    private static final int APPEARANCES_AFTERNOON = 1;
    private static final int APPEARANCES_ALL_DAY = 2;

    @Autowired
    RecruitmentService recruitmentService;
    @Autowired
    RecycleService recycleService;
    @Autowired
    CompanyServiceImpl companyServiceImpl;
    @Autowired
    RecruitmentCacheService recruitmentCacheService;

    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiOperation(value = "获取招聘会列表", notes = "必填 分页标记位 0分页 1不分页 字段可选，招聘会类型ID，截止开始日期，招聘会关键字，")
    public ResultDto getRecruitmentList(@RequestBody RecruitmentSearch recruitmentSearch) {
        if (recruitmentSearch.getIsPage() == null) {
            return ResultDtoFactory.toNack("分页标记不能为空");
        }

        if (recruitmentSearch.getIsPage() == 0) {
            return ResultDtoFactory.toAck("success", recruitmentService.getAll(recruitmentSearch));
        } else {
            Integer pageNum = (recruitmentSearch.getPageNum() == null ? 1 : recruitmentSearch.getPageNum());
            Integer pageSize = (recruitmentSearch.getPageSize() == null ? MagicNumConstant.TEN : recruitmentSearch.getPageSize());
            PageHelper.startPage(pageNum, pageSize);
            return ResultDtoFactory.toAck("success", new PageInfo<>(recruitmentService.getAll(recruitmentSearch)));
        }
    }


    @RequestMapping(value = "/", method = RequestMethod.POST)
    @ApiOperation(value = "创建招聘会", notes = "必填 招聘会名字，场次，场地，是否提供多面标志位 ")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @Transactional
    public ResultDto createRecruitment(@RequestBody Recruitment recruitment) throws ParseException {
        if (null == recruitment || null == recruitment.getName() || null == recruitment.getAppearances() || null == recruitment.getAddress()) {
            return ResultDtoFactory.toNack("招聘会名字，场次，场地不能为空");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(sdf.format(new Date(System.currentTimeMillis())));
        Date date2 = sdf.parse(recruitment.getDate());
        if (date2.compareTo(date) < 0) {
            return ResultDtoFactory.toNack("无效的时间");

        }
        RecruitmentSearch recruitmentSearch = new RecruitmentSearch();
        recruitmentSearch.setAppearances(recruitment.getAppearances());
        recruitmentSearch.setStartDate(recruitment.getDate());
        recruitmentSearch.setEndDate(recruitment.getDate());
        recruitmentSearch.setAddress(recruitment.getAddress());
        if (recruitment.getDevice()) {
            recruitmentSearch.setDevice(true);
            if (recruitmentService.getAll(recruitmentSearch).size() != 0) {
                return ResultDtoFactory.toNack("当前时间已有招聘会存在");
            }
            if (recruitment.getAppearances() == (APPEARANCES_ALL_DAY)) {
                recruitmentSearch.setAppearances(APPEARANCES_MORNING);
                if (recruitmentService.getAll(recruitmentSearch).size() != 0) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
                recruitmentSearch.setAppearances(APPEARANCES_AFTERNOON);
                if (recruitmentService.getAll(recruitmentSearch).size() != 0) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
            } else {
                recruitmentSearch.setAppearances(APPEARANCES_ALL_DAY);
                if (recruitmentService.getAll(recruitmentSearch).size() != 0) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
            }

        }


        if (recruitmentService.createRecruitment(recruitment) != null) {
            return ResultDtoFactory.toAck("添加成功");
        }

        return ResultDtoFactory.toNack("添加失败");
    }


    @RequestMapping(value = "/", method = RequestMethod.PUT)
    @ApiOperation(value = "更新招聘会")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto updateRecruitment(@RequestBody Recruitment recruitment) throws ParseException {
        if (null == recruitment.getId()) {
            return ResultDtoFactory.toNack("招聘会id不能为空");
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = sdf.parse(sdf.format(new Date(System.currentTimeMillis())));
        Date date2 = sdf.parse(recruitment.getDate());
        if (date2.compareTo(date) == -1) {
            return ResultDtoFactory.toNack("招聘会已过期无法编辑");
        }
        RecruitmentSearch recruitmentSearch = new RecruitmentSearch();
        recruitmentSearch.setAppearances(recruitment.getAppearances());
        recruitmentSearch.setStartDate(recruitment.getDate());
        recruitmentSearch.setEndDate(recruitment.getDate());
        recruitmentSearch.setAddress(recruitment.getAddress());
        if (recruitment.getDevice()) {
            recruitmentSearch.setDevice(true);
            List<Recruitment> all = recruitmentService.getAll(recruitmentSearch);

            if (all != null && all.size() != 0 && !(all.get(0).getId().equals(recruitment.getId()))) {
                return ResultDtoFactory.toNack("当前时间已有招聘会存在");
            }
            if (recruitment.getAppearances() == (APPEARANCES_ALL_DAY)) {
                recruitmentSearch.setAppearances(APPEARANCES_MORNING);
                all = recruitmentService.getAll(recruitmentSearch);

                if (all != null && all.size() != 0 && !(all.get(0).getId().equals(recruitment.getId()))) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
                recruitmentSearch.setAppearances(APPEARANCES_AFTERNOON);
                all = recruitmentService.getAll(recruitmentSearch);
                if (all != null && all.size() != 0 && !(all.get(0).getId().equals(recruitment.getId()))) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
            } else {
                recruitmentSearch.setAppearances(APPEARANCES_ALL_DAY);
                all = recruitmentService.getAll(recruitmentSearch);

                if (all != null && all.size() != 0 && !(all.get(0).getId().equals(recruitment.getId()))) {
                    return ResultDtoFactory.toNack("当前时间已有招聘会存在");
                }
            }
        }
        try {
            recruitmentService.updateRecruitment(recruitment);
            recruitmentCacheService.flushCurrentRecruitment();
            return ResultDtoFactory.toAck("更新成功");
        } catch (
                Exception e) {
            return ResultDtoFactory.toNack("更新失败，当前时间已有招聘会存在");
        }

    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除招聘会")
    @Transactional
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto deleteRecruitment(@PathVariable @ApiParam(name = "id", value = "招聘会ID", required = true) Integer id) throws ParseException {
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setRecruitmentID(id);
        java.util.List<Company> ls = companyServiceImpl.check(boothSearch);
        if (ls.size() != 0) {
            return ResultDtoFactory.toNack("删除失败，已有企业关联");
        }
        Recruitment recruitment = recruitmentService.getRecruitmentMapperById(id);
        if (recruitment.getStartType() == 1) {
            return ResultDtoFactory.toNack("删除失败，招聘会进行中");

        }
        if (null == recruitment) {
            return ResultDtoFactory.toNack("删除失败，招聘会不存在");
        }
        Recycle recycle = new Recycle();
        recycle.setDeleteId(id);
        recycle.setType("招聘会");
        recycle.setName(recruitment.getName());
        recycleService.insert(recycle);

        if (recruitmentService.deleteRecruitment(id) > 0) {
            return ResultDtoFactory.toAck("删除成功");
        }
        return ResultDtoFactory.toNack("删除失败");
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据ID获取招聘会")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getByID(@PathVariable Integer id) {
        Recruitment recruitment = recruitmentService.getById(id);
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setRecruitmentID(id);
        java.util.List<Company> ls = companyServiceImpl.check(boothSearch);
        recruitment.setBookBooth(false);
        if (ls.size() != 0) {
            recruitment.setBookBooth(true);
        }
        return ResultDtoFactory.toAck("success", recruitment);
    }

    @RequestMapping(value = "/start", method = RequestMethod.GET)
    @ApiOperation(value = "开启招聘会")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto start(@RequestParam Integer id) {
        return recruitmentService.startRecruitment(id);
    }

    @RequestMapping(value = "/end", method = RequestMethod.GET)
    @ApiOperation(value = "关闭招聘会")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto end(@RequestParam Integer id) {
        return recruitmentService.endRecruitment(id);
    }
}
