package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.QrCode;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface QrCodeMapper extends MyMapper<QrCode> {

    List<Integer> findCurrentUser(@Param("recruitmentId") Integer recruitmentId);

    @Select("select * from qr_code where code = #{code}")
    QrCode findByCode(@Param("code") String code);

    @Select("select jump_type from qr_code where id = #{id}")
    boolean findTypeById(@Param("id") Integer id);

    @Update("update qr_code set jump_type = 0 where id = #{id}")
    void updateTypeById(@Param("id") Integer id);
}
