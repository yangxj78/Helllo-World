package com.hengtiansoft.servlet.applicant.resume.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MResumeDto;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserEducationExperience;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserProjectExperience;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MUserWorkExperience;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.RecruitmentStartTypeEnum;
import com.hengtiansoft.common.enumeration.SmsTypeEnum;
import com.hengtiansoft.common.enumeration.StatusEnum;
import com.hengtiansoft.common.util.DateTimeUtil;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.resume.service.ExtendExchangeService2;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.baidu.ocr.FileUtil;
import com.hengtiansoft.servlet.hr.delivery.service.DeliveryService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import com.hengtiansoft.servlet.mapper.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;

@Service
public class ResumeServiceImpl implements ResumeService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ResumeService.class);

    @Autowired
    ResumeMapper resumeMapper;

    @Autowired
    UserInfoMapper userInfoMapper;

    @Autowired
    MagicNumberMapper magicNumberMapper;

    @Autowired
    ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    UserEducationExperienceMapper userEducationExperienceMapper;

    @Autowired
    UserWorkExperienceMapper userWorkExperienceMapper;

    @Autowired
    UserProjectExperienceMapper userProjectExperienceMapper;

    @Autowired
    DeliveryService deliveryService;

    @Autowired
    RecruitmentService recruitmentService;

    @Autowired
    ExtendExchangeService2 extendExchangeService2;

    @Autowired
    RecruitmentMapper recruitmentMapper;

    @Autowired
    SmsService smsService;
    @Autowired
    ResumeDeliveryPreMapper resumeDeliveryPreMapper;

    @Autowired
    private ApplicantUserMapper applicantUserMapper;

    @Override
    public ResumeDto findResume(Integer resumeId, Integer userId) {
        ResumeDto resumeDto = new ResumeDto();
        //获取个人信息
        resumeDto.setUserInfo(userInfoMapper.selectOne(new UserInfo(userId)));
        //获取简历基本信息
        resumeDto.setResume(resumeMapper.selectByPrimaryKey(resumeId));
        //获取工作经历和教育经历
        resumeDto.setUserEducationExperienceList(userEducationExperienceMapper.select(new UserEducationExperience(resumeId)));
        resumeDto.setUserWorkExperienceList(userWorkExperienceMapper.select(new UserWorkExperience(resumeId)));
        resumeDto.setUserProjectExperienceList(userProjectExperienceMapper.select(new UserProjectExperience(resumeId)));
        ExperienceComparator comparator = new ExperienceComparator();
        if (!CollectionUtils.isEmpty(resumeDto.getUserEducationExperienceList())) {
            resumeDto.getUserEducationExperienceList().sort(comparator);
        }
        if (!CollectionUtils.isEmpty(resumeDto.getUserProjectExperienceList())) {
            resumeDto.getUserProjectExperienceList().sort(comparator);
        }
        if (!CollectionUtils.isEmpty(resumeDto.getUserWorkExperienceList())) {
            resumeDto.getUserWorkExperienceList().sort(comparator);
        }
        return resumeDto;
    }

    @Override
    public ResultDto findResumes(ResumeSearchDto resumeSearchDto) {
        String birthDateEnd = null;
        String birthDateBegin = null;
        if (resumeSearchDto.getMinAge() != null) {
            birthDateEnd = DateTimeUtil.getFirstDayOfYear(new Date(), -resumeSearchDto.getMinAge());
        }
        if (resumeSearchDto.getMaxAge() != null) {
            birthDateBegin = DateTimeUtil.getFirstDayOfYear(new Date(), -resumeSearchDto.getMaxAge());
        }
        List<Integer> userIds = userInfoMapper.selectUserId(resumeSearchDto, birthDateEnd, birthDateBegin,resumeSearchDto.getTelephone());

        if (CollectionUtils.isEmpty(userIds)) {
            return ResultDtoFactory.toAck("success");
        }
        Integer pageNum = (resumeSearchDto.getPageNumber() == null ? 1 : resumeSearchDto.getPageNumber());
        Integer pageSize = (resumeSearchDto.getPageSize() == null ? MagicNumConstant.TEN : resumeSearchDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize, "r.update_ts desc");
        return ResultDtoFactory.toAck("success", new PageInfo<ResumeSimpleDto>(resumeMapper.selectSimpleResume(resumeSearchDto, userIds)));
    }

    @Override
    public ResultDto postResume(ResumeDeliveryDto resumeDeliveryDto) {
        return deliveryService.postResume(resumeDeliveryDto);
    }


    public Integer getDefaultUserId() {
        Integer userId = null;
        MagicNumber magicNumber = magicNumberMapper.selectByPrimaryKey(1);
        if (magicNumber == null) {
            magicNumber = new MagicNumber();
            magicNumber.setType(1);
            magicNumber.setValue(0);
            magicNumber.setVersion(0);
            magicNumber.setNote("后台创建简历使用的userId，默认为负数自减");
            magicNumberMapper.insert(magicNumber);
        }
        userId = magicNumber.getValue();
        int success = magicNumberMapper.updateByVersion(magicNumber.getType(), magicNumber.getVersion());
        if (success == 0) {
            userId = getDefaultUserId();
        }
        return userId;
    }


    @Override
    public ResultDto createResume(ResumeDto resumeDto,boolean perfectFlag) {

        UserInfo userInfo = resumeDto.getUserInfo();
        Resume resume = resumeDto.getResume();
        List<UserWorkExperience> userWorkExperienceList = resumeDto.getUserWorkExperienceList();
        List<UserProjectExperience> userProjectExperienceList = resumeDto.getUserProjectExperienceList();
        List<UserEducationExperience> userEducationExperienceList = resumeDto.getUserEducationExperienceList();
        boolean updateTsFlag = false;
        boolean hasPerfectResume = false;
        //根据id判断userInfo是否为更新操作
        boolean isUpdate = false;
        Integer resumeId = null;
        Integer userId = null;

        if (userInfo != null) {
            if (userInfo.getId() != null) {
                //判断是否为更新操作
                isUpdate = true;
            }
            //后台创建简历需自定义userId
            userId = userInfo.getUserId();
            if (userId == null || userId<0) {
                ApplicantUser user = applicantUserMapper.selectOne(new ApplicantUser(userInfo.getPhone()));
                if(user!=null){
                    userId = user.getId();
                    userInfo.setUserId(userId);
                }else if(userId == null){
                    //后台创建简历需自定义userId
                    userId = getDefaultUserId();
                    userInfo.setUserId(userId);
                }
            }
            UserInfo existUi = userInfoMapper.selectOne(new UserInfo(userId));
           List<Resume> list = resumeMapper.select(new Resume(userInfo.getUserId()));
            if (!isUpdate&&!CollectionUtils.isEmpty(list) ) {
                //若存在已完善简历，则不更新userInfo
                hasPerfectResume = list.stream().anyMatch(r -> r.getPerfectFlag().equals(StatusEnum.YES.getCode()));
                if (!hasPerfectResume) {
                    isUpdate = true;
                    userInfo.setId(existUi.getId());
                }
            }else if(existUi!=null){
                isUpdate = true;
                userInfo.setId(existUi.getId());
            }
            if (isUpdate) {
                //更新
                userInfo.setUpdateTs(DateUtil.getDateFormate(new Date()));
                userInfoMapper.updateByPrimaryKey(userInfo);
            } else if(!hasPerfectResume){
                userInfoMapper.insert(userInfo);
            }
        }

        if (resume != null) {
            // 简历-简历信息
            if (resume.getId() == null) {
                //后台创建简历需自定义userId
                if (resume.getUserId() == null) {
                    resume.setUserId(userId);
                    //标记为未完善简历
                    perfectFlag = false;
                }
                //用户创建简历 判断简历数量是否大于5封
                List<Resume> list = resumeMapper.select(new Resume(resume.getUserId(), StatusEnum.YES.getCode()));
                if (list.size() >= 5) {
                    return ResultDtoFactory.toNack("用户简历数量已达上限（5封）");
                }
                resume.setPerfectFlag(perfectFlag?StatusEnum.YES.getCode():StatusEnum.NO.getCode());
                resume.setStatus(1);
                //新增
                resumeMapper.insert(resume);
                resumeId = resume.getId();
            } else {
                //更新
                resumeMapper.updateByPrimaryKey(resume);
            }
        }

        if (!CollectionUtils.isEmpty(userWorkExperienceList)) {
            // 简历-工作经历
            for (UserWorkExperience userWorkExperience : userWorkExperienceList) {
                if (userWorkExperience.getResumeId() == null) {
                    userWorkExperience.setResumeId(resumeId);
                } else {
                    resumeId = userWorkExperience.getResumeId();
                }
                if (userWorkExperience.getId() == null) {

                    //后台创建简历需自定义userId
                    if (userWorkExperience.getUserId() == null) {
                        userWorkExperience.setUserId(userId);
                    }
                    //新增
                    userWorkExperienceMapper.insert(userWorkExperience);
                } else {
                    //更新
                    userWorkExperience.setUpdateTs(DateUtil.getDateFormate(new Date()));
                    userWorkExperienceMapper.updateByPrimaryKey(userWorkExperience);
                }
            }
            updateTsFlag = true;

        }

        if (!CollectionUtils.isEmpty(userProjectExperienceList)) {
            // 简历-项目经历
            for (UserProjectExperience userProjectExperience : userProjectExperienceList) {
                if (userProjectExperience.getResumeId() == null) {
                    userProjectExperience.setResumeId(resumeId);
                } else {
                    resumeId = userProjectExperience.getResumeId();
                }
                if (userProjectExperience.getId() == null) {

                    //后台创建简历需自定义userId
                    if (userProjectExperience.getUserId() == null) {
                        userProjectExperience.setUserId(userId);
                    }
                    //新增
                    userProjectExperienceMapper.insert(userProjectExperience);
                } else {
                    //更新
                    userProjectExperienceMapper.updateByPrimaryKey(userProjectExperience);
                }
            }
            updateTsFlag = true;

        }

        if (!CollectionUtils.isEmpty(userEducationExperienceList)) {
            // 简历-教育经历
            for (UserEducationExperience userEducationExperience : userEducationExperienceList) {
                if (userEducationExperience.getResumeId() == null) {
                    userEducationExperience.setResumeId(resumeId);
                } else {
                    resumeId = userEducationExperience.getResumeId();
                }
                if (userEducationExperience.getId() == null) {
                    //后台创建简历需自定义userId
                    if (userEducationExperience.getUserId() == null) {
                        userEducationExperience.setUserId(userId);
                    }
                    //新增
                    userEducationExperienceMapper.insert(userEducationExperience);
                } else {
                    //更新
                    userEducationExperience.setUpdateTs(DateUtil.getDateFormate(new Date()));
                    userEducationExperienceMapper.updateByPrimaryKey(userEducationExperience);
                }
            }
            updateTsFlag = true;
        }

        //工作经历和教育经历更新时同步更新简历表的修改时间
        if (updateTsFlag) {
            Resume resumeUpdateTs = new Resume();
            resumeUpdateTs.setId(resumeId);
            resumeUpdateTs.setUpdateTs(DateUtil.getDateFormate(new Date()));
            resumeMapper.updateByPrimaryKeySelective(resumeUpdateTs);
        }

        return ResultDtoFactory.toAck("添加成功");
    }

    @Override
    @Transactional
    public ResultDto defaultResume(Integer oldId, Integer newId) {
        Resume resume = new Resume();
        resume.setId(oldId);
        resume.setDefaultFlag(StatusEnum.NO.getCode());
        resumeMapper.updateByPrimaryKeySelective(resume);
        resume.setId(newId);
        resume.setDefaultFlag(StatusEnum.YES.getCode());
        resumeMapper.updateByPrimaryKeySelective(resume);
        return ResultDtoFactory.toAck("编辑成功");
    }

    @Override
    @Transactional
    public ResultDto deleteResume(Integer id) {
        Recruitment currentRecruitment = recruitmentService.getCurrentRecruitment();
        if (currentRecruitment != null && resumeDeliveryMapper.countResume(id, currentRecruitment.getId()) > 0) {
            return ResultDtoFactory.toNack("简历正在当前招聘会使用中，请等待招聘会结束再操作");
        }
        resumeMapper.deleteByPrimaryKey(id);
        userWorkExperienceMapper.delete(new UserWorkExperience(id));
        userProjectExperienceMapper.delete(new UserProjectExperience(id));
        userEducationExperienceMapper.delete(new UserEducationExperience(id));
        return ResultDtoFactory.toAck("删除成功");
    }

    @Override
    @Transactional
    public ResultDto deleteResumeForApplicant(Integer id) {
        Recruitment currentRecruitment = recruitmentService.getCurrentRecruitment();
        if (currentRecruitment != null && resumeDeliveryMapper.countResume(id, currentRecruitment.getId()) > 0) {
            return ResultDtoFactory.toNack("简历正在当前招聘会使用中，请等待招聘会结束再操作");
        }
        resumeMapper.deleteForApplicant(id);
        return ResultDtoFactory.toAck("删除成功");
    }

    @Override
    public ResultDto deleteEducationExperience(Integer id) {
        userEducationExperienceMapper.deleteByPrimaryKey(id);
        return ResultDtoFactory.toAck("删除成功");
    }

    @Override
    public ResultDto deleteWorkExperience(Integer id) {
        userWorkExperienceMapper.deleteByPrimaryKey(id);
        return ResultDtoFactory.toAck("删除成功");
    }

    @Override
    public ResultDto deleteProjectExperience(Integer id) {
        userProjectExperienceMapper.deleteByPrimaryKey(id);
        return ResultDtoFactory.toAck("删除成功");
    }

    @Override
    public UserInfo findUserInfo(Integer userId) {
        return userInfoMapper.selectOne(new UserInfo(userId));
    }

    @Override
    public ResultDto getCountByUserId(Integer userId) {
        Map<String, Integer> result = new HashMap<>();
        Recruitment currentRecruitment = recruitmentService.getCurrentRecruitment();
        if (currentRecruitment != null) {
            result.put("delivery", resumeDeliveryMapper.countByUser(userId, currentRecruitment.getId()));
        } else {
            result.put("delivery", 0);
        }
        result.put("resumes", resumeMapper.countByUser(userId));
        return ResultDtoFactory.toAck("查询成功", result);
    }

    @Override
    public List<ResumeDeliveryPreInfoDto> findResumeDeliveryPreInfo(CollectionPositionSearchDto searchDto) {
        List<ResumeDeliveryPreInfoDto> result = new ArrayList<>();
        List<ResumeDeliveryPreDataDto> dataDtos = resumeDeliveryMapper.findDeliveryPreDataByUserId(searchDto);
        for (ResumeDeliveryPreDataDto resumeDeliveryPreDataDto : dataDtos) {
            ResumeDeliveryPreInfoDto temp = new ResumeDeliveryPreInfoDto(resumeDeliveryPreDataDto);
            result.add(temp);
        }

        return result;
    }

    @Override
    public List<ResumeDeliveryInfoDto> findResumeDeliveryInfo(CollectionPositionSearchDto searchDto) {
        List<ResumeDeliveryInfoDto> result = new ArrayList<>();
        List<ResumeDeliveryDate2Dto> dtos = resumeDeliveryMapper.findDeliveryInfoByUserId(searchDto);
        for (ResumeDeliveryDate2Dto dto : dtos) {
            ResumeDeliveryInfoDto temp = new ResumeDeliveryInfoDto(dto);
            if (temp.getRecruitmentStatus().equals(RecruitmentStartTypeEnum.STARTED.getCode())) {
                InterviewDeliveryDto interviewDeliveryDto = resumeDeliveryMapper.getCurrentInterviewer(dto.getBoothId(), dto.getRecruitmentId());
                if (interviewDeliveryDto == null) {
                    interviewDeliveryDto = resumeDeliveryMapper.getLastInterviewer(dto.getBoothId(), dto.getRecruitmentId());
                }
                if (interviewDeliveryDto != null) {
                    temp.setCurrentOrderNum(interviewDeliveryDto.getOrderNum());
                }
            }
            result.add(temp);
        }
        return result;
    }

    @Override
    public List<RecruitmentSearchDto> listDeliveryRecruitmentSearchs(Integer userId) {
        return resumeDeliveryMapper.listDeliveryRecruitmentSearchs(userId);
    }

    @Override
    public List<RecruitmentSearchDto> listDeliveryPreRecruitmentSearchs(Integer userId) {
        return resumeDeliveryMapper.listDeliveryPreRecruitmentSearchs(userId);
    }

    @Override
    public ResumeDeliverySuccessDto getDeliverySuccessInfo(Integer userId, Integer positionRecordId) {
        ResumeDeliveryDate2Dto temp = resumeDeliveryMapper.getDeliverySuccessInfo(userId, positionRecordId);
        ResumeDeliverySuccessDto result = new ResumeDeliverySuccessDto(temp);
        InterviewDeliveryDto interviewDeliveryDto = resumeDeliveryMapper.getCurrentInterviewer(temp.getBoothId(), temp.getRecruitmentId());
        if (interviewDeliveryDto == null) {
            interviewDeliveryDto = resumeDeliveryMapper.getLastInterviewer(temp.getBoothId(), temp.getRecruitmentId());
        }
        if (interviewDeliveryDto != null) {
            result.setCurrentOrderNum(interviewDeliveryDto.getOrderNum());
        }
        return result;
    }

    @Override
    public ResumeDeliveryPreInfoDto getDeliveryPreSuccessInfo(Integer userId, Integer positionRecordId) {
        ResumeDeliveryPreDataDto temp = resumeDeliveryMapper.getDeliveryPreSuccessInfo(userId, positionRecordId);
        return temp != null ? new ResumeDeliveryPreInfoDto(temp) : null;
    }

    @Override
    public ResultDto createByMultiple(List<MResumeDto> mResumeDtos) {
        for (MResumeDto mResumeDto : mResumeDtos) {
            ResumeDto resumeDto = new ResumeDto();
            if (mResumeDto.getmUserInfo() != null) {
                Integer userId = mResumeDto.getmUserInfo().getUserId();
                //数据库已有该用户基本信息，则不做新增
                UserInfo userInfo = findUserInfo(userId);
                if (userInfo == null) {
                    resumeDto.setUserInfo(new UserInfo(mResumeDto.getmUserInfo()));
                }
            }
            if (mResumeDto.getMResume() != null) {
                resumeDto.setResume(new Resume(mResumeDto.getMResume()));
            }
            if (!CollectionUtils.isEmpty(mResumeDto.getUserWorkExperienceList())) {
                List<UserWorkExperience> experiences = new ArrayList<>();
                for (MUserWorkExperience dto : mResumeDto.getUserWorkExperienceList()) {
                    experiences.add(new UserWorkExperience(dto));
                }
                resumeDto.setUserWorkExperienceList(experiences);
            }
            if (!CollectionUtils.isEmpty(mResumeDto.getUserProjectExperienceList())) {
                List<UserProjectExperience> experiences = new ArrayList<>();
                for (MUserProjectExperience dto : mResumeDto.getUserProjectExperienceList()) {
                    experiences.add(new UserProjectExperience(dto));
                }
                resumeDto.setUserProjectExperienceList(experiences);
            }
            if (!CollectionUtils.isEmpty(mResumeDto.getMUserEducationExperienceList())) {
                List<UserEducationExperience> experiences = new ArrayList<>();
                for (MUserEducationExperience dto : mResumeDto.getMUserEducationExperienceList()) {
                    experiences.add(new UserEducationExperience(dto));
                }
                resumeDto.setUserEducationExperienceList(experiences);
            }
            //保存简历
            createResume(resumeDto,false);
        }
        return ResultDtoFactory.toAck("保存成功");
    }

    @Override
    public ResultDto<ResumeDto> createByScanImg(ResumeImgInfoDto resumeImgInfoDto) {
        try {
            List<File> fileList = FileUtil.base64ToTempFile(resumeImgInfoDto.getBase64List(), resumeImgInfoDto.getFileName());
            if (fileList == null) {
                return ResultDtoFactory.toNack("简历图片无法识别");
            }
            List<MultipartFile> multipartFileList = new ArrayList<>();
            for (File file : fileList) {
                FileInputStream is = new FileInputStream(file);
                multipartFileList.add(new MockMultipartFile(file.getName(), file.getName(), resumeImgInfoDto.getContentType(), is));
                is.close();
            }
            System.out.println("========0");

            ResumeDto resume = extendExchangeService2.uploadTemplate2Resume(multipartFileList);
            System.out.println("========1");
            if (resume != null) {
                Integer userId = resumeImgInfoDto.getUserId();
                Optional.ofNullable(resume.getUserInfo()).ifPresent(u -> u.setUserId(userId));
                Optional.ofNullable(resume.getResume()).ifPresent(r -> {r.setUserId(userId);r.setName("图片导入简历");});
                Optional.ofNullable(resume.getUserWorkExperienceList()).ifPresent(ws -> ws.forEach(w -> w.setUserId(userId)));
                Optional.ofNullable(resume.getUserProjectExperienceList()).ifPresent(ps -> ps.forEach(p -> p.setUserId(userId)));
                Optional.ofNullable(resume.getUserEducationExperienceList()).ifPresent(es -> es.forEach(e -> e.setUserId(userId)));
                System.out.println("========2");
                this.createResume(resume,false);
                System.out.println("========3");
            } else {
                return ResultDtoFactory.toNack("简历图片无法识别");
            }
            return ResultDtoFactory.toAck("扫描成功", resume);
        } catch (Exception e) {
            LOGGER.error("扫描简历图片出错", e);
            return ResultDtoFactory.toNack("简历图片无法识别");
        }
    }

    @Override
    public boolean sendInviteMessage(Integer recruitmentId, Integer resumeId) {
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentId);
        Resume resume = resumeMapper.selectByPrimaryKey(resumeId);
        UserInfo temp = new UserInfo();
        temp.setUserId(resume.getUserId());
        UserInfo userInfo = userInfoMapper.selectOne(temp);
        SmsDto smsDto = new SmsDto();
        smsDto.setName(recruitment.getName());
        smsDto.setType(SmsTypeEnum.MATCHING.getCode());
        smsDto.setRecruitmentId(recruitmentId);
        smsDto.setPlace(recruitment.getAddress());
        smsDto.setTime(recruitment.getDate());

        smsDto.setMobile(userInfo.getPhone());
        smsDto.setUserId(userInfo.getUserId());

        return smsService.sendInvitation(smsDto);
    }

    @Override
    public boolean check(Integer recruitmentID, Integer boothId) {

        if (resumeMapper.check(recruitmentID, boothId) != 0) {
            return false;
        }
        return true;
    }

    @Override
    public List<ResumeDeliveryPre> findResumeDeliveryPre(Integer boothID, Integer recruitmentID) {
        return resumeDeliveryMapper.findResumeDeliveryPre(boothID, recruitmentID);
    }

    @Override
    public void updateResumeDeliveryPre1(ResumeDeliveryPre resumeDeliveryPre1) {
        resumeDeliveryPreMapper.updateByPrimaryKeySelective(resumeDeliveryPre1);
    }
}
class ExperienceComparator implements Comparator<Experience> {
    @Override
    public int compare(Experience o1, Experience o2) {
        return -o1.getStartTs().compareTo(o2.getStartTs());
    }
}
