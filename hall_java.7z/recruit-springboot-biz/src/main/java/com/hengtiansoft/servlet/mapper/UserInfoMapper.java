package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.ResumeSearchDto;
import com.hengtiansoft.bean.tableModel.UserInfo;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserInfoMapper extends MyMapper<UserInfo> {

    List<Integer> selectUserId(@Param(value = "resumeSearchDto") ResumeSearchDto resumeSearchDto,
                               @Param(value = "birthDateEnd") String birthDateEnd,
                               @Param(value = "birthDateBegin") String birthDateBegin,
                               @Param(value = "phone") String phone);


    @Select("Select phone FROM user_info WHERE user_id = #{userId}")
    String selectPhoneByUserId(Integer userId);

    @Select("Select user_id FROM user_info WHERE phone = #{phone}")
    List<Integer> selectUserIdByPhone(String phone);

    List<UserInfo> selectByUserIds(@Param(value = "userIds") List<Integer> userIds);

    void deleteEchoUser(List<Integer> ids);

}