package com.hengtiansoft.servlet.applicant.userManage.controller;

import java.util.HashMap;

public class Test extends Thread{
    public Test(String name) {
        super(name);
    }
}
