package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.ReviewPositionDto;
import com.hengtiansoft.bean.tableModel.ReviewPositionRecord;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ReviewPositionRecordMapper extends MyMapper<ReviewPositionRecord> {

    List<ReviewPositionRecord> ls(ReviewPositionDto reviewPositionDto);

    int operation(@Param("id") Integer id, @Param("suggestion") String suggestion, @Param("status") Integer status);

    PositionRecordDto selectByID(Integer id);

    @Select("select status from review_position_record where position_record_id =#{id} order by id desc limit 1 ")
    Integer getStatusByID(Integer id);

    List<ReviewPositionRecord> getExpire();

    void reduction(Integer recruitmentId);

    List<ReviewPositionRecord> getRefuse(ReviewPositionDto reviewPositionDto);
}