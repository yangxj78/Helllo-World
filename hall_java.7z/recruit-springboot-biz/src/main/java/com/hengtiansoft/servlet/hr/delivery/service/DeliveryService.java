package com.hengtiansoft.servlet.hr.delivery.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.InterviewDeliveryDto;
import com.hengtiansoft.bean.dataModel.InterviewSearchDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryDto;

import java.util.List;

/**
 * Created by linwu on 7/18/2018.
 */
public interface DeliveryService {

    /**
     * 简历投递 帮人写的
     * @param resumeDeliveryDto
     * @return
     */
    ResultDto postResume(ResumeDeliveryDto resumeDeliveryDto);


    /**
     * 分配展位
     * @param boothId
     * @param resumeDeliveryId
     * @return
     */
    ResultDto<InterviewDeliveryDto> allotBooth(Integer type, Integer boothId, Integer resumeDeliveryId);


    /**
     * 获取分流记录
     * @param searchDto
     * @return
     */
    ResultDto<List<InterviewDeliveryDto>> findAllotRecord(InterviewSearchDto searchDto);


    /**
     * 获取当前招聘会下的该展位是否被投递过
     * @param boothId
     * @param recruitmentId
     * @return
     */
    Boolean isDeliveryed(Integer boothId, Integer recruitmentId);

}
