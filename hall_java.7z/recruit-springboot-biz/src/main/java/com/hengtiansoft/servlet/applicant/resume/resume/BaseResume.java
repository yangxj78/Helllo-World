package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.Segment;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.common.utils.JsoupUtils;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeBuilder;
import lombok.extern.slf4j.Slf4j;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import org.ansj.domain.Result;
import org.ansj.domain.Term;
import org.ansj.splitWord.analysis.ToAnalysis;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.nodes.Document;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public abstract class BaseResume implements ResumeBuilder {

    public static final String TEMPLATE_CSS = "<w:p></w:p><w:rPr>"
            +"<w:rFonts w:ascii='微软雅黑' w:eastAsia='微软雅黑' w:hAnsi='微软雅黑'/>"
            +"<w:color w:val='5D5C67'/><w:sz w:val='27'/>"
            +"<w:szCs w:val='27'/></w:rPr>";

    public static final String[] ENGLISH_LEVEL_LIST = { "英语三级", "英语四级", "英语六级", "英语八级", "英语专业四级", "英语专业八级", "托福", "雅思",
            "CET4", "CET6" };
    protected static final Segment SEGMENT_CUSTOM = HanLP.newSegment().enableCustomDictionary(true);

    @Override
    public HrResume buildResume(String content) {
        HrResume r = new HrResume();
        buildBaseInfo(content, r);
        buildContactInfo(content, r);
        buildOtherInfo(content, r);
        buildExperienceInfo(content, r);
        return r;
    }

    @Override
    public HrResume buildResume(MailContent mailContent) {

        HrResume r = new HrResume();
        buildBaseInfo(mailContent, r);
        buildContactInfo(mailContent, r);
        buildOtherInfo(mailContent, r);
        buildExperienceInfo(mailContent, r);
        return r;
    }

    Set<String> expectedNature = new HashSet<String>() {
        {
            add("nr");// 王文辉
            add("b");// 男，女
            add("ntu");// 河南农业大学
            add("userDefine");// 年工作经验
        }
    };

    public Map<String, Term> getResumeMatcheTerms(String baseStr) {
        // 只关注这些词性的词
        Result result = ToAnalysis.parse(baseStr); // 分词结果的一个封装，主要是一个List<Term>的terms
        Map<String, Term> resultMap = new HashMap<String, Term>();
        List<Term> terms = result.getTerms(); // 拿到terms
        if (baseStr != null && terms != null) {
            for (Term term : terms) {
                String natureStr = term.getNatureStr(); // 拿到词性
                if (expectedNature.contains(natureStr) && (!resultMap.containsKey(natureStr))) {
                    resultMap.put(natureStr, term);
                }
            }
        }
        return resultMap;
    }

    public String getPersonName(Map<String, Term> termMap) {
        if (termMap.get("nr") != null) {
            return termMap.get("nr").getName();
        } else {
            return null;
        }
    }

    public String getSchoolName(Map<String, Term> termMap) {
        String key = "ntu";
        if (termMap.get(key) != null) {
            return termMap.get(key).getName();
        } else {
            return null;
        }
    }

    public String getSchoolByHanLp(String sentence) {
        if (sentence != null && StringUtils.isNotBlank(sentence)) {
            List<com.hankcs.hanlp.seg.common.Term> termList = SEGMENT_CUSTOM.seg(sentence);
            for (com.hankcs.hanlp.seg.common.Term term : termList) {
                if (term.nature.toString().equals("ntu")) {
                    return term.word;
                }
            }
        }
        return null;
    }

    public String getWorkYear(Map<String, Term> termMap) {
        if (termMap.get("userDefine") != null) {
            getWorkedYears(termMap.get("userDefine").getName());
        }
        return "0";
    }

    public String getSex(Map<String, Term> termMap) {
        if (termMap.get("b") != null) {
            return termMap.get("b").getName();
        } else {
            return "男";
        }
    }

    public String fieldTrim(String fieldStr) {
        if (fieldStr != null) {
            return fieldStr.trim();
        }
        return "";
    }

    public SexEnum getRealSex(String sex) {
        if (sex.length() > 0) {
            fieldTrim(sex);
        }
        if ("女".equals(sex)) {
            return SexEnum.WOMAN;
        }
        return SexEnum.MAN;
    }

    public String getEnglishLevel(String context) {
        String englishLevel = null;
        for (String englishLevelSingle : ENGLISH_LEVEL_LIST) {
            if (context.contains(englishLevelSingle)) {
                englishLevel = englishLevelSingle;
                break;
            }
        }
        return englishLevel;
    }

    // 得到年龄
    public int getRealAge(String years) {
        fieldTrim(years);
        try {
            return StringUtils.isWhitespace(years) ? 0 : Integer.parseInt(years.replaceAll("[年岁]", "").replace(" ", ""));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // 得到邮箱
    public String getEmail(Document document) {
        return JsoupUtils.parseRegularByDocument(document, "(\\w+(\\.\\w)*@\\w+(\\.\\w{2,3}){1,3})");
    }

    // 获取邮箱地址
    public String getEmailAddress(String context) {
        context.replaceAll(" ", "");
        Pattern emailer = Pattern.compile("(\\w+(\\.\\w)*@\\w+(\\.\\w{2,3}){1,3})");
        Matcher matcher = emailer.matcher(context);
        String email = null;
        while (matcher.find()) {
            email = matcher.group();
        }
        return email;
    }

    // 获取手机号
    public String getPhone(String context) {
        String str = context.replace("-", "").replace("—", "").replace("(", "").replace(")", "").replace("（", "")
                .replace("）", "").replaceAll(" ", "");
        Pattern phoneRex = Pattern.compile("\\d{13}");
        Matcher matcher = phoneRex.matcher(str);
        while (matcher.find()) {
            Pattern p = Pattern.compile("^[8][6][1][3456789][0-9]{9}$");
            String phone = matcher.group();
            Matcher m = p.matcher(phone);
            if (m.matches()) {
                return phone.substring(2);
            }
        }
        phoneRex = Pattern.compile("\\d{11}");
        matcher = phoneRex.matcher(str);
        while (matcher.find()) {
            Pattern p = Pattern.compile("^[1][3456789][0-9]{9}$");
            String phone = matcher.group();
            Matcher m = p.matcher(phone);
            if (m.matches()) {
                return phone;
            }
        }
        return null;
    }

    // 获取更新时间
    public String getUpdateDate(String context) {
        Pattern phoneRex = Pattern.compile("\\d{4}-\\d{2}-\\d{2}");
        Matcher matcher = phoneRex.matcher(context);
        while (matcher.find()) {
            return matcher.group();
        }
        return null;
    }

    // 获取工作年限
    public String getWorkedYears(String context) {
        Pattern yearsExg = Pattern.compile("(\\d*)年工作经验");
        Matcher matcher = yearsExg.matcher(context);
        String years = "0";
        while (matcher.find()) {
            return fieldTrim(matcher.group(1));
        }

        return fieldTrim(years);
    }

    public String filterName(String name) {
        String result = name;
        // 过滤名字
        if (!StringUtils.isEmpty(name)) {
            Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]{2,4}");
            Matcher matcher = reg.matcher(name);
            while (matcher.find()) {
                result = matcher.group();
                break;
            }
        }
        return result;
    }

    // 获取简历编号
    public String getNumber(String context) {
        Pattern numExg = Pattern.compile("[id|ID|Id|'简历编号'][:|：]([\\w|\\(|\\)]*)");
        Matcher matcher = numExg.matcher(context);
        while (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    // 获得学历时间
    public String getEduDate(String context) {
        Pattern eduDateExg = Pattern.compile("\\d{4}[/.]\\d{2}[–-](\\d{4}[/.]\\d{2}|至今)");
        Matcher matcher = eduDateExg.matcher(context);
        while (matcher.find()) {
            return matcher.group();
        }
        return "";
    }

    public String strSubstring(String str, String beginStr, String endStr) {
        if (!StringUtils.isEmpty(beginStr) && !StringUtils.isEmpty(endStr) && str.contains(beginStr)
                && str.contains(endStr)) {
            return str.substring(str.indexOf(beginStr), str.indexOf(endStr, str.indexOf(beginStr) + beginStr.length()))
                    .substring(beginStr.length());
        }
        return null;
    }

    public String strSubstring(String str, String beginStr, int beginOffSet, String endStr, int endOffSet) {
        if (!StringUtils.isEmpty(beginStr) && !StringUtils.isEmpty(endStr) && str.contains(beginStr)
                && str.contains(endStr) && (str.indexOf(beginStr) <= str.indexOf(endStr))) {
            return str.substring(str.indexOf(beginStr) + beginOffSet, str.indexOf(endStr) + endOffSet);
        }
        return null;
    }

    public String messageBody2String(MailContent content) {
        try {
            if (content.getMessageBody() != null) {
                return MessageBody.getStringFromMessageBody(content.getMessageBody());
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());

        }
        return (String) content.getContent();
    }

    public String filterExperience(String content) {
        return content.replaceAll("\\s*", "").replace("|", "").replaceAll("(<.*?>)+", "&nbsp;")
                .replaceAll("&emsp;", "").replaceAll("　", "").replaceAll("&#x20;", "").replaceAll(" ", "");
    }

    //根据时间为各类经验添加<br/>作为之后的分段标示
    public String enterExperience(String content) {
        String str = content;
        String br = "<br/>";
        Pattern exg = Pattern.compile("\\d{4}[/.]\\d{1,2}[–-](\\d{4}[/.]\\d{1,2}|至今)");
        if (!StringUtils.isEmpty(str)) {
            str = str.replace("&nbsp;至今", "至今");
            Matcher matcher = exg.matcher(str);
            int i = 0;
            while (matcher.find()) {
                if (i > 0)
                    str = str.replace(matcher.group(), br + matcher.group());
                i++;
            }
            str = str.replaceAll("(<br/>){2,}", br).replace("&nbsp;", " ");
        }
        if (!StringUtils.isEmpty(str) && str.startsWith(br)) {
            str = str.replaceFirst(br, "");
        }
        return str;
    }

    public String enterExperienceByEnter(String content) {
        String str = content;
        Pattern exg = Pattern.compile("\\d{4}[/.]\\d{1,2}[–-](\\d{4}[/.]\\d{1,2}|至今)");
        if (!StringUtils.isEmpty(str)) {
            Matcher matcher = exg.matcher(str);
            int i = 0;
            while (matcher.find()) {
                if (i > 0)
                    str = str.replace(matcher.group(), "\n" + matcher.group());
                i++;
            }
            str = str.replaceAll("(\n){2,}", "\n").replace("&nbsp;", " ");
        }
        if (!StringUtils.isEmpty(str) && str.startsWith("\n")) {
            str = str.replaceFirst("\n", "");
        }
        return str;
    }

    public String removeBr(String doc) {
        String str = doc;
        for (int i = 0; i < MagicNumConstant.FIVE; i++) {
            str = str.replaceAll(TEMPLATE_CSS + TEMPLATE_CSS, TEMPLATE_CSS);
        }

        return str.replaceFirst(TEMPLATE_CSS, "");
    }

    public int ifLocalZJ(String city){
        String[] citiesOfZJ = {"浙江","杭州","宁波","温州","绍兴","湖州","嘉兴","金华","衢州","台州","丽水","舟山"};
        if(StringUtils.isEmpty(city))
            return 0;
        for(String cityOfZJ:citiesOfZJ){
            if (city.contains(cityOfZJ)) {
                return 1;
            }
        }
        return 0;
    }
}
