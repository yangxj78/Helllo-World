package com.hengtiansoft.servlet.applicant.resume.template.dajiewang;

import com.hengtiansoft.servlet.applicant.resume.resume.DaJieWangResume;

public class DaJieWangDefaultTemplate extends DaJieWangResume {

}
