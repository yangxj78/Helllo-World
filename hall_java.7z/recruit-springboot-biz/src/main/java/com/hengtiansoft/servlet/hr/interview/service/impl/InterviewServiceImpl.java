package com.hengtiansoft.servlet.hr.interview.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.*;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.hr.interview.service.InterviewService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import com.hengtiansoft.servlet.mapper.ApplicantUserMapper;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryMapper;
import com.hengtiansoft.servlet.mapper.UserInfoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by linwu on 7/18/2018.
 */
@Service
public class InterviewServiceImpl implements InterviewService {

    private static final Logger LOGGER = LoggerFactory.getLogger(InterviewService.class);

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private ResumeService resumeService;

    @Autowired
    private RecruitmentMapper recruitmentMapper;

    @Autowired
    private SmsService smsService;
    @Autowired
    private InterviewService interviewService;

    @Override
    public ResultDto<List<PositionRecordDto>> findDeliveryPositions() {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        return ResultDtoFactory.toAck("获取成功", resumeDeliveryMapper
                .findDeliveryPositions(companySign.getBoothId(), companySign.getRecruitmentId()));
    }

    @Override
    public ResultDto<List<InterviewDeliveryDto>> findAllByCon(Integer status, InterviewSearchDto searchDto) {
        if (searchDto.getOffset() == null) {
            searchDto.setOffset(1);
        }
        if (searchDto.getLimit() == null) {
            searchDto.setLimit(10000);
        }
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        if (InterviewStatusEnum.READY.getCode().equals(status)) {
            return ResultDtoFactory.toAck("获取待面列表成功", resumeDeliveryMapper
                    .findReadyByCon(companySign.getBoothId(), companySign.getRecruitmentId(), searchDto));
        } else {
            return ResultDtoFactory.toAck("获取已面列表成功", resumeDeliveryMapper
                    .findFinishByCon(companySign.getBoothId(), companySign.getRecruitmentId(), searchDto));
        }
    }

    @Override
    public ResultDto<InterviewDeliveryDto> getCurrentInterviewer() {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        try {
            InterviewDeliveryDto interviewDeliveryDto = resumeDeliveryMapper.getStartingInterviewer(companySign.getBoothId(), companySign.getRecruitmentId());
            if (interviewDeliveryDto == null) {
                return ResultDtoFactory.toAck("获取成功", null);
            }
            return ResultDtoFactory.toAck("获取成功", interviewDeliveryDto);
        } catch (Exception e) {
            LOGGER.error("获取当前面试者失败", e);
            return ResultDtoFactory.toNack("获取当前面试者失败");
        }

    }

    @Override
    public InterviewDeliveryDto getFirst() {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        return resumeDeliveryMapper.findFirst(companySign.getBoothId(), companySign.getRecruitmentId());
    }

    @Override
    @Transactional
    public ResultDto<InterviewDeliveryDto> passOut(Integer resumeDeliveryId, Integer orderNum) {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        try {
            ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(resumeDeliveryId);
            if (resumeDelivery == null) {
                ResultDtoFactory.toNack("该投递不存在");
            }
            //是否已经pass过
            if (PassStatusEnum.NO_PASS.getCode().intValue() != resumeDelivery.getPassStatus().intValue()) {
                //已经pass过的删除该次投递
                resumeDeliveryMapper.deleteByPrimaryKey(resumeDeliveryId);
                //更新招聘会接待人数
                recruitmentMapper.updateByPeople(resumeDeliveryMapper.getUpdateNumber(companySign.getRecruitmentId()));
            } else {
                //当前投递人数小于呼叫延后的位数，直接放到最后一位
                int newOrderNum;
                if (resumeDeliveryMapper.countDeliveryAll(companySign.getBoothId(), companySign.getRecruitmentId()) <= 3) {
                    int lastOrderNum = resumeDeliveryMapper.findLastOrderNum(companySign.getBoothId(), companySign.getRecruitmentId());
                    newOrderNum = lastOrderNum + 1;
                } else {
                    newOrderNum = orderNum + 3;
                }
                resumeDeliveryMapper.updatePassList(companySign.getBoothId(), companySign.getRecruitmentId(), resumeDeliveryId, newOrderNum);
            }
        } catch (Exception e) {
            LOGGER.error("更新投递者列表出错", e);
            return ResultDtoFactory.toNack("呼叫下一位失败");
        }
        return ResultDtoFactory.toAck("获取成功", getFirst());
    }

    @Override
    public ResultDto<List<Map<Integer, Integer>>> getBooths() {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(companySign.getRecruitmentId());
        if (recruitment == null) {
            return ResultDtoFactory.toNack("当前招聘会不存在");
        }
        return ResultDtoFactory.toAck("获取成功", resumeDeliveryMapper.getBooths(recruitment.getStyle(),
                companySign.getCompanyId(), companySign.getRecruitmentId()));
    }

    @Override
    @Transactional
    public ResultDto<InterviewDetailDto> startInterview(Integer resumeDeliveryId) {
        ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(resumeDeliveryId);
        if (resumeDelivery == null) {
            return ResultDtoFactory.toNack("投递记录不存在");
        }
        try {
            resumeDelivery.setInterviewStatus(InterviewStatusEnum.ING.getCode());
            resumeDelivery.setUpdateTs(new Date());
            resumeDeliveryMapper.updateByPrimaryKey(resumeDelivery);
        }catch (Exception e) {
            LOGGER.error("开始面试失败", e);
            return ResultDtoFactory.toNack("开始面试失败");
        }

        return ResultDtoFactory.toAck("开始面试成功");
    }

    @Override
    public ResultDto notifyTv(Integer type) {
        Map map = new HashMap();
        if (InterviewStatusEnum.ING.getCode().equals(type)) {
            //开始面试
            map.put("nettyType", NettyInfoEnum.HR_INTERVIEW.getCode());
        } else if (InterviewStatusEnum.FINISH.getCode().equals(type)) {
            //结束面试
            map.put("nettyType", NettyInfoEnum.HR_INTERVIEW.getCode());
        } else if (InterviewStatusEnum.READY.getCode().equals(type)) {
            //待面
            map.put("nettyType", NettyInfoEnum.HR_DELIVERY.getCode());
        }
        NettyClientUtil.notifyTv(SecurityContext.getCurrentHRUser().getBoothId(), JSON.toJSONString(map));
        return ResultDtoFactory.toAck("通知成功");
    }


    @Override
    public ResultDto saveInterviewDetail(InterviewDetailDto interviewDetailDto) {
        String msg = validate(interviewDetailDto);
        if (msg != null) {
            return ResultDtoFactory.toNack(msg);
        }
        ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(interviewDetailDto.getId());
        if (resumeDelivery == null) {
            return ResultDtoFactory.toNack("投递记录不存在");
        }
        try {
            resumeDelivery.setInterviewResult(interviewDetailDto.getInterviewResult());
            resumeDelivery.setMatching(interviewDetailDto.getMatching());
            resumeDelivery.setProfession(interviewDetailDto.getProfession());
            resumeDelivery.setLearning(interviewDetailDto.getLearning());
            resumeDelivery.setCommunicate(interviewDetailDto.getCommunicate());
            resumeDelivery.setInterviewEvaluation(interviewDetailDto.getInterviewEvaluation());
            resumeDelivery.setUpdateTs(new Date());
            //结束面试
            if (InterviewEnum.END.getCode().equals(interviewDetailDto.getType())) {
                resumeDelivery.setInterviewStatus(InterviewStatusEnum.FINISH.getCode());
                resumeDelivery.setIsOver(interviewDetailDto.getIsOver());
            }
            resumeDeliveryMapper.updateByPrimaryKey(resumeDelivery);
        } catch (Exception e) {
            LOGGER.error("结束面试失败", e);
            return ResultDtoFactory.toNack("结束面试失败");
        }
        return ResultDtoFactory.toAck("结束面试成功");
    }

    @Override
    public ResultDto<ResumeInfoDto> getResumeDetail2(Integer resumeDeliveryId, Integer resumeId, Integer userId) {
        try {
            //获取简历详情
            ResumeDto resumeDto = resumeService.findResume(resumeId, userId);
            if (resumeDto == null) {
                return ResultDtoFactory.toNack("获取简历详情失败");
            }

            //放入简历详情
            ResumeInfoDto resumeInfoDto = new ResumeInfoDto();
            resumeInfoDto.setResumeDto(resumeDto);

            //获取面试结果
            ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(resumeDeliveryId);
            if (resumeDelivery != null) {
                //放入面试结果
                List<ResumeDelivery> resumeDeliveries = resumeDeliveryMapper.findInterviewResultByParentId(
                        resumeDelivery.getRecruitmentId(),
                        resumeDelivery.getCompanyId(),
                        userId,
                        resumeDelivery.getPositionRecordId());

                List<InterViewResultDto> interViewResultDtos = new ArrayList<>();
                resumeDeliveries.forEach(rd -> {
                    interViewResultDtos.add(new InterViewResultDto(
                            rd.getInterviewNum(),
                            InterviewResultEnum.getMap().get(rd.getInterviewResult()).getDesc(),
                            rd.getMatching(),
                            rd.getProfession(),
                            rd.getLearning(),
                            rd.getCommunicate(),
                            rd.getInterviewEvaluation()
                    ));
                });
                resumeInfoDto.setInterViewResultDtoList(interViewResultDtos);
            }
            return ResultDtoFactory.toAck("获取简历详情成功", resumeInfoDto);
        } catch (Exception e) {
            LOGGER.error("获取简历详情失败", e);
            return ResultDtoFactory.toNack("获取简历详情失败");
        }
    }

    @Override
    public void notifyUser(Integer resumeDeliveryId) {
        InterviewDeliveryDto interviewDeliveryDto = resumeDeliveryMapper.findCurrentApplicant(resumeDeliveryId);
        if (interviewDeliveryDto != null) {
            sendSms(interviewDeliveryDto, SmsTemplateCodeEnum.REMIND2.getCode());
        }
    }

    @Override
    public List<ResumeDeliveryDetail> getResumeDeliveryDetail(ResumeDeliverySearch resumeDeliverySearch) {
        return resumeDeliveryMapper.getResumeDeliveryDetail(resumeDeliverySearch);
    }

    @Override
    public List<ResumDeliveryResult> getResumeDeliveryDetailByBoothId(ResumeDeliveryDetailSearch resumeDeliverySearch) {

        return resumeDeliveryMapper.getResumeDeliveryDetailByBoothId(resumeDeliverySearch);
    }

    @Override
    public List<ResumDeliveryPREResult> getResumeDeliveryDetailPRE(ResumeDeliveryDetailSearch resumeDeliverySearch) {

        return resumeDeliveryMapper.getResumeDeliveryDetailPRE(resumeDeliverySearch);

    }

    @Override
    public ResumDeliveryPRENum getCount(Integer recruitmentId,String date) {
        return resumeDeliveryMapper.getCount(recruitmentId,date);
    }

    @Override
    public void setData(ResumDeliveryPREResult rs) {
      MaxEdu maxEdu = resumeDeliveryMapper.getMaxEdu(rs.getResumeId());
        if(maxEdu!=null){  rs.setMajor(maxEdu.getMajor());
        rs.setSchool(maxEdu.getSchool());}
    }

    @Override
    public void setData(ResumDeliveryResult rs) {
        MaxEdu maxEdu = resumeDeliveryMapper.getMaxEdu(rs.getResumeId());
        if(maxEdu!=null){   rs.setMajor(maxEdu.getMajor());
        rs.setSchool(maxEdu.getSchool());
        rs.setEducational(maxEdu.getEducation());}
    }

    @Override
    public void setData(ExcelUserData ex) {
        MaxEdu maxEdu = resumeDeliveryMapper.getMaxEdu(ex.getResumeId());

      if(maxEdu!=null){  ex.setMajor(maxEdu.getMajor());
        ex.setSchool(maxEdu.getSchool());
        ex.setEducation(maxEdu.getEducationName());
        ex.setEndTs(maxEdu.getEndTs());}
    }



    private void sendSms(InterviewDeliveryDto interviewDeliveryDto, String code) {
        SmsDto smsDto = new SmsDto();
        smsDto.setName(interviewDeliveryDto.getName());
        smsDto.setTemplateCode(code);
        smsDto.setBoothId(interviewDeliveryDto.getBoothId());
        smsDto.setMobile(interviewDeliveryDto.getContact());
        smsDto.setSmsInfo("展位" + interviewDeliveryDto.getBoothId() + ": " + interviewDeliveryDto.getName() + " 面试提醒");
        smsDto.setType(SmsTypeEnum.REMIND.getCode());
        smsService.sendRemind(smsDto);
    }

    private String validate(InterviewDetailDto interviewDetailDto) {
        if (interviewDetailDto == null) {
            return "未找到面试详细";
        }
        if (interviewDetailDto.getId() == null) {
            return "投递记录不存在";
        }
        if (InterviewEnum.END.getCode().equals(interviewDetailDto.getType()) && interviewDetailDto.getInterviewResult() == null) {
            return "未填写面试结果";
        }
        return null;
    }

    public ResultDto<ResumeInfoDto> getResumeDetail(Integer resumeDeliveryId, Integer resumeId, Integer userId) {
        try {
            //获取简历详情
            ResumeDto resumeDto = resumeService.findResume(resumeId, userId);
            if (resumeDto == null) {
                return ResultDtoFactory.toNack("获取简历详情失败");
            }

            //放入简历详情
            ResumeInfoDto resumeInfoDto = new ResumeInfoDto();
            resumeInfoDto.setResumeDto(resumeDto);

            //获取面试结果
            ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(resumeDeliveryId);
            if (resumeDelivery != null) {
                //放入面试结果
                CompanySign companySign = SecurityContext.getCurrentHRUser();
                List<ResumeDelivery> resumeDeliveries = resumeDeliveryMapper.findInterviewResultByParentId(
                        resumeDelivery.getRecruitmentId(),
                        companySign.getCompanyId(),
                        userId,
                        resumeDelivery.getPositionRecordId());

                List<InterViewResultDto> interViewResultDtos = new ArrayList<>();
                resumeDeliveries.forEach(rd -> {
                    interViewResultDtos.add(new InterViewResultDto(
                            rd.getInterviewNum(),
                            InterviewResultEnum.getMap().get(rd.getInterviewResult()).getDesc(),
                            rd.getMatching(),
                            rd.getProfession(),
                            rd.getLearning(),
                            rd.getCommunicate(),
                            rd.getInterviewEvaluation()
                    ));
                });
                resumeInfoDto.setInterViewResultDtoList(interViewResultDtos);
            }
            return ResultDtoFactory.toAck("获取简历详情成功", resumeInfoDto);
        } catch (Exception e) {
            LOGGER.error("获取简历详情失败", e);
            return ResultDtoFactory.toNack("获取简历详情失败");
        }
    }

}
