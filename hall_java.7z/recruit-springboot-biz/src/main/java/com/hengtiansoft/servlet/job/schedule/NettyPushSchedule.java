package com.hengtiansoft.servlet.job.schedule;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.dataModel.StatisticsDto;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.recruitment.service.RecruitmentReportService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class NettyPushSchedule {


    @Autowired
    private RecruitmentService recruitmentService;

    @Autowired
    private RecruitmentReportService recruitmentReportService;

   @Scheduled(cron = "0 0/1 *  * * ?")
    public void pushStatisticsBigScreen(){
        log.info("##############大屏数据  --> 统计信息相关 -->开始推送####### ###");
        Recruitment current = recruitmentService.getCurrentRecruitment();

        if (current != null) {
            Map<String, Object> resultMap = new HashMap<>();

            StatisticsDto totalCount = recruitmentReportService.getTotalCount(current);
            StatisticsDto ageCount = recruitmentReportService.getAgeCount(current);
            StatisticsDto educationCount = recruitmentReportService.getEducationCount(current);
            StatisticsDto entranceTime = recruitmentReportService.getEntranceTime(current);

            resultMap.put("totalCount", totalCount);
            resultMap.put("ageCount", ageCount);
            resultMap.put("educationCount", educationCount);
            resultMap.put("jobsTop5", recruitmentReportService.getJobTop5(current));
            resultMap.put("entranceTime", entranceTime);
            resultMap.put("style", current.getStyle());

            Map<String, Object> newResultMap = new HashMap<>();
            newResultMap.put("statistics",resultMap);
            String jsonString = JSON.toJSONString(newResultMap);

            NettyClientUtil.notifyBigScreen(jsonString);
        }
        log.info("##############大屏数据 --> 统计信息相关 -->结束推送####### ###");
    }

    @Scheduled(cron = "0 0/3 *  * * ?")
    public void pushSummaryBigScreen(){
        log.info("##############大屏数据 --> 公司和岗位数据 -->开始推送####### ###");
        Recruitment current = recruitmentService.getCurrentRecruitment();

        if (current != null) {
            Map<String, Object> newResultMap = new HashMap<>();
            newResultMap.put("summary",recruitmentReportService.getSummary(current));
            String jsonString = JSON.toJSONString(newResultMap);

            NettyClientUtil.notifyBigScreen(jsonString);
        }
        log.info("##############大屏数据 --> 公司和岗位数据 -->结束推送####### ###");
    }
}
