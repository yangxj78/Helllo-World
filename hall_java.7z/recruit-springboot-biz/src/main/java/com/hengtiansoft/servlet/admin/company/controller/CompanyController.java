package com.hengtiansoft.servlet.admin.company.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.CompanyPicture;
import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.util.FtpUtil;
import com.hengtiansoft.servlet.admin.company.service.CompanyPictureService;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;

import java.util.ArrayList;
import java.util.List;

import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.recycle.service.RecycleService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.*;
import java.util.Date;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/admin/company")
@Api(value = "公司controller", description = "公司管理相关接口")
public class CompanyController {

    private static final int VIDEO = 1;
    private static final int PICTRUE = 2;

    @Autowired
    CompanyService companyService;
    @Autowired
    RecycleService recycleService;
    @Autowired
    CompanyPictureService companyPictureService;
    @Autowired
    PositionService positionService;

    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiOperation(value = "获取公司列表", notes = "可选字段 公司名称，公司地址")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto listCompany(@RequestBody CompanySearch companySearch) {
        Integer pageNum = (companySearch.getPageNum() == null ? 1 : companySearch.getPageNum());
        Integer pageSize = (companySearch.getPageSize() == null ? MagicNumConstant.TEN : companySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<Company>(companyService.getAll(companySearch)));
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getById(@PathVariable Integer id) {
        //通过公司id获取公司
        return ResultDtoFactory.toAck("success", companyService.getById(id));
    }


    @RequestMapping(value = "/", method = RequestMethod.POST)
    @ApiOperation(value = "新增企业", notes = "必填 企业名字 企业类型Id 企业地址 公司联系人号码 公司客户经理ID  企业联系人姓名 参展联系人 参展联系人号码 企业状态（默认0） ，备注：参展联系人添加时与企业联系人一致")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto createCompany(@RequestBody Company company) throws FileNotFoundException {

        if (company.getName() == null || company.getAddress() == null) {
            return ResultDtoFactory.toNack("添加失败，公司名字和地址不能为空！");
        }
        if (company.getContactName() == null || company.getContactNumber() == null) {
            return ResultDtoFactory.toNack("添加失败，公司联系人和联系电话不能为空！");
        }
        CompanySearch companySearch = new CompanySearch();
        companySearch.setCompanyName(company.getName());
        if (companyService.getAll(companySearch).size() != 0) {
            return ResultDtoFactory.toNack("公司已存在 ！");
        }
        company.setCreateTs(new Date(System.currentTimeMillis()));
        if (companyService.createCompany(company) > 0) {
            if (null != company.getPictures() && !company.getPictures().isEmpty()) {
                CompanyPicture companyPicture = new CompanyPicture();
                for (String str : company.getPictures()) {
                    companyPicture.setCompanyId(company.getId());
                    companyPicture.setPictureId(str);
                    companyPictureService.insert(companyPicture);
                }
            }
            return ResultDtoFactory.toAck("添加成功！");
        }
        return ResultDtoFactory.toNack("添加失败！");
    }


    @RequestMapping(value = "/", method = RequestMethod.PUT)
    @ApiOperation(value = "更新企业", notes = "必填 企业ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto updateCompany(@RequestBody Company company) {
        if (null == company.getId()) {
            return ResultDtoFactory.toNack("企业ID不能为空");
        }

        if (null == companyService.getById(company.getId())) {
            return ResultDtoFactory.toNack("企业不存在，或已被删除请到回收站中查看！");
        }
        if (null != company.getPictures() && !company.getPictures().isEmpty()) {
            CompanyPicture companyPicture = new CompanyPicture();
            for (String str : company.getPictures()) {
                companyPicture.setCompanyId(company.getId());
                companyPicture.setPictureId(str);
                companyPictureService.insert(companyPicture);
            }
        }
        company.setUpdateTs(new Date(System.currentTimeMillis()));
        if (companyService.updateCompany(company) != 0) {
            return ResultDtoFactory.toAck("更新成功");
        }
        return ResultDtoFactory.toNack("更新失败");
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除企业", notes = "必填 企业ID")
    @Transactional
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto deleteCompany(@PathVariable @ApiParam(name = "id", value = "企业ID", required = true) Integer id) {
        Company company = companyService.getById(id);
        if (null == company) {
            return ResultDtoFactory.toNack("企业不存在，或已被删除请到回收站中查看！");
        }
        BoothSearch boothSearch = new BoothSearch();
        boothSearch.setcompanyID(id);
        if (companyService.check(boothSearch).size() != 0) {
            return ResultDtoFactory.toNack("企业与招聘会关联，无权删除");
        }
        Recycle recycle = new Recycle();
        recycle.setId(null);
        recycle.setDeleteId(id);
        recycle.setType("企业");
        recycle.setName(company.getName());
        recycleService.insert(recycle);
        if (companyService.deleteCompany(id) > 0) {
            List<Position> positions = positionService.getIDAndName(boothSearch);
            for (Position position : positions) {
                recycle.setId(null);
                recycle.setDeleteId(position.getId());
                recycle.setType("岗位");
                recycle.setName(position.getName());
                recycleService.insert(recycle);
            }
            positionService.updateByCompanyID(id);
            return ResultDtoFactory.toAck("删除成功!");
        }
        return ResultDtoFactory.toNack("删除失败!");
    }

    @RequestMapping(value = "/deleteFile", method = RequestMethod.GET)
    @ApiOperation(value = "删除文件", notes = "type 1 视频 2 图片")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto deleteFile(@RequestParam Integer companyID, @RequestParam String fileIDs, @RequestParam Integer type) throws IOException {
        CompanyPicture companyPicture = new CompanyPicture();
        Company company = new Company();
        for (String fileID : fileIDs.split(",")) {
            if (type == VIDEO) {
                FtpUtil.deleteFile("/video", fileID);
                company.setVideoID("");
                company.setId(companyID);
                companyService.updateCompany(company);
            }
            if (type == PICTRUE) {
                FtpUtil.deleteFile("/picture", fileID);
                companyPicture.setCompanyId(companyID);
                companyPicture.setPictureId(fileID);
                companyPictureService.delete(companyPicture);
            }
        }
        return ResultDtoFactory.toAck("删除成功");
    }

    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
    @ApiOperation(value = "上传文件", notes = "type 1 视频 2 图片")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto uploadFile(HttpServletRequest request, @RequestParam Integer type) {
        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");
        List arr = new ArrayList();
        for (MultipartFile file : files) {
            if (type == PICTRUE) {
                try {
                    InputStream inputStream = file.getInputStream();
                    String fileName = String.valueOf(System.currentTimeMillis());
                    String remoteName = file.getOriginalFilename();
                    fileName = remoteName.indexOf(".") == -1 ? null : fileName + remoteName.substring(remoteName.lastIndexOf("."), remoteName.length());
                    if (null == fileName) {
                        return ResultDtoFactory.toNack("文件格式有误");
                    }
                    if (FtpUtil.uploadFile("/picture", fileName, inputStream)) {
                        arr.add(fileName);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (type == VIDEO) {
                try {
                    InputStream inputStream = file.getInputStream();
                    String fileName = String.valueOf(System.currentTimeMillis());
                    String remoteName = file.getOriginalFilename();
                    fileName = remoteName.indexOf(".") == -1 ? null : fileName + remoteName.substring(remoteName.lastIndexOf("."), remoteName.length());
                    if (null == fileName) {
                        return ResultDtoFactory.toNack("文件格式有误");
                    }
                    if (FtpUtil.uploadVideo(fileName, inputStream)) {
                        arr.add(fileName);
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        if(arr.size()==0){
            return ResultDtoFactory.toNack("上传失败");

        }
        return ResultDtoFactory.toAck("上传成功", arr);

    }

    @RequestMapping(value = "/getRecruimentDetail", method = RequestMethod.POST)
    @ApiOperation(value = "获取某场招聘会的某一家的企业详情")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getRecruimentDetail(@RequestBody CompanySearch companySearch) {
        if (companySearch.getRecruitmentID() == null || companySearch.getBoothID() == null) {
            return ResultDtoFactory.toNack("招聘会ID展位ID不能为空");
        }
        if (companySearch.getCompanyID() == null) {
            return ResultDtoFactory.toNack("企业不能为空");
        }
        return ResultDtoFactory.toAck("上传成功", companyService.getRecruimentDetail(companySearch));

    }

}
