package com.hengtiansoft.servlet.applicant.resumeDeliveryPre.service.impl;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryPreDto;
import com.hengtiansoft.bean.tableModel.ResumeDeliveryPre;
import com.hengtiansoft.servlet.applicant.resumeDeliveryPre.service.DeliveryPreService;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryPreMapper;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Service
public class DeliveryPreServiceImpl implements DeliveryPreService {

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DeliveryPreService.class);

    @Autowired
    ResumeDeliveryPreMapper resumeDeliveryPreMapper;

    @Override
    @Transactional
    public ResultDto prePostResume(ResumeDeliveryPreDto resumeDeliveryPreDto) {
        String msg = validate(resumeDeliveryPreDto);
        if (resumeDeliveryPreMapper.countDelivery(resumeDeliveryPreDto.getResumeId(), resumeDeliveryPreDto.getPositionRecordId(), resumeDeliveryPreDto.getBoothId()) != 0)
            return ResultDtoFactory.toNack("预投递已经存在");
        if (msg != null) {
            return ResultDtoFactory.toNack(msg);
        }
        ResumeDeliveryPre resumeDeliveryPre = revertEntity(resumeDeliveryPreDto);
        resumeDeliveryPreMapper.insert(resumeDeliveryPre);
        return ResultDtoFactory.toAck("预投递成功");
    }

    private ResumeDeliveryPre revertEntity(ResumeDeliveryPreDto resumeDeliveryPreDto) {
        return new ResumeDeliveryPre(
                resumeDeliveryPreDto.getUserId(),
                resumeDeliveryPreDto.getResumeId(),
                resumeDeliveryPreDto.getRecruitmentId(),
                resumeDeliveryPreDto.getCompanyId(),
                resumeDeliveryPreDto.getPositionRecordId(),
                resumeDeliveryPreDto.getBoothId(),
                new Date()
        );
    }

    private String validate(ResumeDeliveryPreDto resumeDeliveryPreDto) {
        if (resumeDeliveryPreDto == null) {
            return "简历投递不存在";
        }
        if (resumeDeliveryPreDto.getBoothId() == null) {
            return "展位信息不能为空";
        }
        if (resumeDeliveryPreDto.getCompanyId() == null) {
            return "企业信息不能为空";
        }
        if (resumeDeliveryPreDto.getPositionRecordId() == null) {
            return "展位信息不能为空";
        }
        if (resumeDeliveryPreDto.getRecruitmentId() == null) {
            return "招聘会信息不能为空";
        }
        if (resumeDeliveryPreDto.getResumeId() == null) {
            return "简历信息不能为空";
        }
        if (resumeDeliveryPreDto.getUserId() == null) {
            return "用户信息不能为空";
        }
        return null;
    }
}
