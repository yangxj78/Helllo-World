package com.hengtiansoft.servlet.admin.bookBooth.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.enumeration.SmsTypeEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.common.util.Randoms;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.common.service.UpdateNumberService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import com.hengtiansoft.servlet.mapper.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


@Service
public class BoothServiceImpl extends BaseService<BookBooth> implements BoothService {
    @Autowired
    BookBoothMapper bookBoothMapper;

    @Autowired
    PositionMapper positionMapper;

    @Autowired
    CompanyMapper companyMapper;
    @Autowired
    ResumeService resumeService;
    @Autowired
    RecruitmentMapper recruitmentMapper;

    @Autowired
    UpdateNumberService updateNumberService;

    @Autowired
    BoothMapper boothMapper;

    @Autowired
    CompanySignMapper companySignMapper;


    @Autowired
    SmsService smsService;
    @Autowired
    BookBoothPositionRecordMapper bookBoothPositionRecordMapper;

    @Override
    @Transactional
    public List<Company> check(BoothSearch boothSearch) {
        return bookBoothMapper.check(boothSearch);
    }

    @Override
    @Transactional
    public int subscribe(BookBooth bookBooth) {
        BoothSearch search = new BoothSearch();
        search.setcompanyID(bookBooth.getCompanyID());
        String name = SecurityContext.getCurrentUser().getUsername();
        bookBooth.setCreateBy(name);
        bookBoothMapper.bookBooth(bookBooth);
        //获取本场招聘会所有企业ID
        NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(bookBooth.getRecruitmentID());
        updateNumberService.updateRecruitmentNumber(numberDto);
        return 1;
    }

    @Override
    @Transactional
    public List<BoothListDto> list(BoothSearch boothSearch) {
        return boothMapper.listBooth(boothSearch);
    }

    @Override
    @Transactional
    public int adjustBooth(BookBooth bookBooth) {
        CompanySign companySign = new CompanySign();
        companySign.setRecruitmentId(bookBooth.getRecruitmentID());
        companySign.setCompanyId(bookBooth.getCompanyID());
        companySign.setBoothId(bookBooth.getOldboothID());
        //查询是否有该展位是否已经发送短信  如果有则修改签到表的展位号
        CompanySign companySigns = companySignMapper.findOneByCon2(bookBooth.getOldboothID(), bookBooth.getRecruitmentID(), bookBooth.getCompanyID());
        //查询是否有该展位是否有预投递  如果有则修改预投递的中的展位号
        List<ResumeDeliveryPre> resumeDeliveryPre = resumeService.findResumeDeliveryPre(bookBooth.getOldboothID(), bookBooth.getRecruitmentID());
        if (null != resumeDeliveryPre) {
            for (ResumeDeliveryPre resumeDeliveryPre1 : resumeDeliveryPre) {
                resumeDeliveryPre1.setBoothId(bookBooth.getBoothID());
                resumeService.updateResumeDeliveryPre1(resumeDeliveryPre1);
            }
        }
        if (companySigns != null) {
            companySigns.setBoothId(bookBooth.getBoothID());
            companySigns.setUpdateTs(null);
            companySigns.setMealsNumber(null);
            companySignMapper.updateByPrimaryKeySelective(companySigns);
        }
        return boothMapper.updateBooth(bookBooth);
    }

    @Override
    @Transactional
    public int cancelBooth(BookBooth bookBooth) {
        //判断是否已经签到 若签到则返回2 不允许取消
        Integer status = companySignMapper.search(bookBooth.getRecruitmentID(), bookBooth.getBoothID());
        if (status != null && status == 1) {
            return 2;
        }
        Integer id = bookBooth.getRecruitmentID();
        BoothSearch search = new BoothSearch();
        search.setcompanyID(bookBooth.getCompanyID());
        List<BookBooth> select = bookBoothMapper.select(bookBooth);
        BookBoothPositionRecord bookBoothPositionRecord = new BookBoothPositionRecord();
        bookBoothPositionRecord.setBookBoothId(select.get(0).getId());
        bookBoothPositionRecordMapper.delete(bookBoothPositionRecord);

        //取消预定
        deleteBookBooth(bookBooth);
        //更新招聘会企业数量，招聘人数，岗位数量
        NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(id);
        numberDto.setRecruitmentID(id);
        updateNumberService.updateRecruitmentNumber(numberDto);
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(bookBooth.getRecruitmentID());

        if (recruitment.getStyle() == 1) {
            BoothSearch boothSearch = new BoothSearch();
            boothSearch.setRecruitmentID(bookBooth.getRecruitmentID());
            List<Company> check = bookBoothMapper.check(boothSearch);
            //该公司在这场招聘会中没有展位删除企业签到表
            if (check.size() == 0) {
                CompanySign companySign = new CompanySign();
                companySign.setRecruitmentId(bookBooth.getRecruitmentID());
                companySignMapper.deleteCaptcha(companySign);
                if (recruitment.getStartType() == 1) {
                    Map map = new HashMap();
                    map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
                    NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
                }
            } else {
                CompanySign companySign = new CompanySign();
                companySign.setRecruitmentId(bookBooth.getRecruitmentID());
                companySign.setBoothId(bookBooth.getBoothID());
                companySign.setCompanyId(bookBooth.getCompanyID());

                companySignMapper.deleteCaptcha(companySign);
                if (recruitment.getStartType() == 1) {
                    Map map = new HashMap();
                    map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
                    NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
                }
                return 1;
            }
        } else {
            //该公司在这场招聘会中没有展位删除企业签到表
            CompanySign companySign = new CompanySign();
            companySign.setRecruitmentId(bookBooth.getRecruitmentID());
            companySign.setBoothId(bookBooth.getBoothID());
            companySign.setCompanyId(bookBooth.getCompanyID());

            companySignMapper.deleteCaptcha(companySign);
        }
        if (recruitment.getStartType() == 1) {
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
            NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
        }
        return 1;
    }

    @Override
    @Transactional
    public int addPositionRecord(List<PositionRecordDto> positionRecordDtos) {
        return bookBoothMapper.addPositionRecord(positionRecordDtos);
    }

    @Override
    @Transactional
    public int updateByID(BookBooth bookBooth) {
        return bookBoothMapper.updateByID(bookBooth);
    }

    @Override
    public ResultDto sendCaptcha(Integer recruitmentID) {
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentID);
        List<CompanySign> companySigns = bookBoothMapper.getCaptchaCompany(recruitmentID);
        if (companySigns.size() == 0) {
            return ResultDtoFactory.toNack("本场招聘会已通知全部企业");
        }
        if (recruitment.getStyle() == 1) {
            String oneByCon3 = companySignMapper.findOneByCon3(recruitmentID);
            if (null != oneByCon3) {
                return ResultDtoFactory.toNack("本次为专场招聘会，无需再发送验证码");
            }

            CompanySign companySign2 = companySigns.get(0);
            companySign2.setCaptcha(String.valueOf(Randoms.num(100000, 999999)));
            companySign2.setStatus(0);
            companySign2 = check(companySign2);
            int boothId = companySign2.getBoothId();
            for (int i = 1; i < 60; i++) {
                companySign2.setBoothId(i);
                companySignMapper.insertCaptcha(companySign2);
            }
            companySign2.setBoothId(boothId);

            SmsDto dto = new SmsDto(SmsTypeEnum.BOOK_BOOTH.getCode(), companySign2.getPhone(), companySign2.getCompanyName(), null, null, companySign2.getCaptcha());
            try {
                dto.setName(companySign2.getRecruitmentName());
                dto.setBoothId(companySign2.getBoothId());
                dto.setPlace(companySign2.getPlace());
                dto.setTime(companySign2.getRecruitmentTime());
                if (!smsService.sendBookBooth(dto)) {
                    companySign2.setBoothId(null);
                    companySignMapper.deleteCaptcha(companySign2);
                    throw new RuntimeException();
                }
                if (recruitment.getStartType() == 1) {
                    Map map2 = new HashMap();
                    map2.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
                    companySigns.forEach(n -> {
                        NettyClientUtil.notifyTv(n.getBoothId(), JSON.toJSONString(map2));
                        NettyClientUtil.notifyHr(n.getBoothId(), JSON.toJSONString(map2));
                    });
                }
            } catch (Exception e) {
                throw new RuntimeException(companySign2.getCompanyName() + "验证码发送失败");
            }
        } else {
            HashMap<Integer, String> map = new HashMap();
            for (CompanySign companySign : companySigns) {
                if (map.containsKey(companySign.getCompanyId())) {
                    companySign.setCaptcha(map.get(companySign.getCompanyId()));
                } else {
                    String str = companySignMapper.getCaptcha(companySign);
                    if (str != null) {
                        companySign.setCaptcha(str);
                    } else {
                        companySign.setCaptcha(String.valueOf(Randoms.num(100000, 999999)));
                    }
                    map.put(companySign.getCompanyId(), companySign.getCaptcha());
                }
                companySign.setStatus(0);
                companySignMapper.insert(companySign);
                companySign = check(companySign);
                SmsDto dto = new SmsDto(SmsTypeEnum.BOOK_BOOTH.getCode(), companySign.getPhone(), null, null, null, companySign.getCaptcha());
                try {
                    dto.setName(companySign.getRecruitmentName());
                    dto.setBoothId(companySign.getBoothId());
                    dto.setPlace(companySign.getPlace());
                    dto.setTime(companySign.getRecruitmentTime());
                    if (!smsService.sendBookBooth(dto)) {
                        companySign.setBoothId(null);
                        companySignMapper.deleteCaptcha(companySign);
                        throw new RuntimeException();
                    }
                } catch (Exception e) {
                    companySign.setBoothId(null);
                    companySignMapper.deleteCaptcha(companySign);
                    throw new RuntimeException(companySign.getCompanyName() + "验证码发送失败");
                }
                if (recruitment.getStartType() == 1) {
                    Map map2 = new HashMap();
                    map2.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
                    NettyClientUtil.notifyTv(companySign.getBoothId(), JSON.toJSONString(map2));
                    NettyClientUtil.notifyHr(companySign.getBoothId(), JSON.toJSONString(map2));
                }
            }

        }
        return ResultDtoFactory.toAck("发送成功");
    }

    @Override
    public boolean isBoothed(Integer recruitmentId, Integer companyId, Integer boothId) {
        if (bookBoothMapper.findIdByCompanySign(recruitmentId, companyId, boothId) != null) {
            return true;
        }
        return false;
    }

    @Override
    public Boolean checkBooth(Integer recruitmentID, Integer boothId) {
        if (boothMapper.checkBooth(recruitmentID, boothId) == null) {
            return false;
        }
        return true;
    }

    @Override
    public void notify(Integer boothID, Integer oldBoothID) {
        Map map = new HashMap();
        if (boothID != null) {
            map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
            NettyClientUtil.notifyHr(oldBoothID, JSON.toJSONString(map));
            NettyClientUtil.notifyTv(oldBoothID, JSON.toJSONString(map));
            NettyClientUtil.notifyHr(boothID, JSON.toJSONString(map));
            NettyClientUtil.notifyTv(boothID, JSON.toJSONString(map));
        }
        map.put("nettyType", NettyInfoEnum.EXCHANGE.getCode());
        NettyClientUtil.notifyHr(oldBoothID, JSON.toJSONString(map));
        NettyClientUtil.notifyTv(oldBoothID, JSON.toJSONString(map));
    }

    @Override
    public BookBooth getById(Integer bookBoothID) {
        return bookBoothMapper.selectByPrimaryKey(bookBoothID);
    }

    @Transactional
    public CompanySign check(CompanySign companySign) {
        CompanySign companySign1 = new CompanySign();
        companySign.setIp(boothMapper.getIpByBoothId(companySign.getBoothId()));
        companySign1.setCaptcha(companySign.getCaptcha());
        companySign1.setIp(companySign.getIp());
        List<CompanySign> companySigns = companySignMapper.listByIpAndCaptcha(companySign1);
        if (companySigns.size() > 1) {
            companySign.setIp(boothMapper.getIpByBoothId(companySign.getBoothId()));
            companySign1.setCompanyId(companySign.getCompanyId());
            companySign1.setRecruitmentId(companySign.getRecruitmentId());
            companySign1.setCaptcha(String.valueOf(Randoms.num(100000, 999999)));
            companySignMapper.updateCaptcha(companySign1);
            companySign.setCaptcha(companySign1.getCaptcha());
            check(companySign);
        }
        return companySign;

    }

    @Transactional
    public void deleteBookBooth(BookBooth bookBooth) {
        boothMapper.cancelBooth(bookBooth);
    }


}
