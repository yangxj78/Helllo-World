package com.hengtiansoft.servlet.applicant.resume.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.dataModel.MultipleResumeDto.MResumeDto;
import com.hengtiansoft.bean.tableModel.UserInfo;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@Api(value = "简历相关接口", description = "restful风格")
@RestController
@RequestMapping(value = {"/applicant/resume", "/admin/resume"})
public class ResumeController {

    @Autowired
    ResumeService resumeService;

    @ApiOperation(value = "简历列表", httpMethod = "POST")
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto findResumeList(@ApiParam(value = "查询条件", name = "resumeSearchDto") @RequestBody ResumeSearchDto resumeSearchDto) {
        return resumeService.findResumes(resumeSearchDto);
    }

    @ApiOperation(value = "简历创建", httpMethod = "POST")
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto createResume(@RequestBody ResumeDto resumeDto) {
        if (resumeDto == null) {
            return ResultDtoFactory.toNack("data is null");
        }
        return resumeService.createResume(resumeDto,true);
    }

    @ApiOperation(value = "简历详情", httpMethod = "GET")
    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto<ResumeDto> findResume(@RequestParam(required = false) Integer resumeId, @RequestParam(required = false) Integer userId) {
        return ResultDtoFactory.toAck("success", resumeService.findResume(resumeId, userId));
    }

    @ApiOperation(value = "简历-获取基本信息", httpMethod = "GET")
    @RequestMapping(value = "/userInfo", method = RequestMethod.GET)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto<UserInfo> findUserInfo(@RequestParam Integer userId) {
        return ResultDtoFactory.toAck("success", resumeService.findUserInfo(userId));
    }

    @ApiOperation(value = "简历投递", httpMethod = "POST", notes = "")
    @RequestMapping(value = "/postResume", method = RequestMethod.POST)
    public ResultDto postResume(@ApiParam(value = "简历投递", name = "resumeDeliveryDto") @RequestBody ResumeDeliveryDto resumeDeliveryDto) {
        return resumeService.postResume(resumeDeliveryDto);
    }

    @ApiOperation(value = "简历设置默认", httpMethod = "POST", notes = "原默认简历id && 新默认简历id")
    @RequestMapping(value = "/defaultResume", method = RequestMethod.POST)
    public ResultDto defaultResume(@ApiParam(value = "原默认简历id", name = "oldId") @RequestParam Integer oldId,
                                   @ApiParam(value = "新默认简历id", name = "newId") @RequestParam Integer newId) {
        return resumeService.defaultResume(oldId, newId);
    }

    @ApiOperation(value = "简历删除", httpMethod = "DELETE", notes = "简历id")
    @RequestMapping(value = "/deleteResume", method = RequestMethod.DELETE)
    public ResultDto defaultResume(@ApiParam(value = "简历id", name = "id") @RequestParam Integer id) {
        return resumeService.deleteResume(id);
    }

    @ApiOperation(value = "简历工作经历删除", httpMethod = "DELETE", notes = "简历id")
    @RequestMapping(value = "/deleteWorkExperience", method = RequestMethod.DELETE)
    public ResultDto deleteWorkExperience(@ApiParam(value = "工作经历id", name = "id") @RequestParam Integer id) {
        return resumeService.deleteWorkExperience(id);
    }

    @ApiOperation(value = "简历教育经历删除", httpMethod = "DELETE", notes = "简历id")
    @RequestMapping(value = "/deleteEducationExperience", method = RequestMethod.DELETE)
    public ResultDto deleteEducationExperience(@ApiParam(value = "教育经历id", name = "id") @RequestParam Integer id) {
        return resumeService.deleteEducationExperience(id);
    }

    @ApiOperation(value = "简历项目经历删除", httpMethod = "DELETE", notes = "简历id")
    @RequestMapping(value = "/deleteProjectExperience", method = RequestMethod.DELETE)
    public ResultDto deleteProjectExperience(@ApiParam(value = "项目经历id", name = "id") @RequestParam Integer id) {
        return resumeService.deleteProjectExperience(id);
    }

    @ApiOperation(value = "查询投递岗位信息", httpMethod = "POST")
    @RequestMapping(value = "/findDeliveryInfo", method = RequestMethod.POST)
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto findDeliveryInfo(@ApiParam(name = "searchDto") @RequestBody CollectionPositionSearchDto searchDto) {

        return ResultDtoFactory.toAck("success", resumeService.findResumeDeliveryInfo(searchDto));
    }

    @ApiOperation(value = "查询预先投递岗位信息", httpMethod = "POST")
    @RequestMapping(value = "/findDeliveryPreInfo", method = RequestMethod.POST)
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto findDeliveryPreInfo(@ApiParam(name = "searchDto") @RequestBody CollectionPositionSearchDto searchDto) {
        return ResultDtoFactory.toAck("success", resumeService.findResumeDeliveryPreInfo(searchDto));
    }

    @RequestMapping(value = "/listDeliveryRecruitmentSearch", method = RequestMethod.GET)
    @ApiOperation(value = "遍历所投递简历的招聘会", notes = "必填 ：userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto listDeliveryRecruitmentSearch(@RequestParam Integer userId) {
        if (userId == null) {
            return ResultDtoFactory.toNack("用户Id不能为空");
        }
        return ResultDtoFactory.toAck("success", resumeService.listDeliveryRecruitmentSearchs(userId));
    }

    @RequestMapping(value = "/listDeliveryPreRecruitmentSearch", method = RequestMethod.GET)
    @ApiOperation(value = "遍历预投递简历的招聘会", notes = "必填 ：userId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto listDeliveryPreRecruitmentSearch(@RequestParam Integer userId) {
        if (userId == null) {
            return ResultDtoFactory.toNack("用户Id不能为空");
        }
        return ResultDtoFactory.toAck("success", resumeService.listDeliveryPreRecruitmentSearchs(userId));
    }

    @RequestMapping(value = "/getDeliverySuccessInfo", method = RequestMethod.GET)
    @ApiOperation(value = "简历投递后获取面试信息", notes = "必填 ：userId positionRecordId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto getDeliverySuccessInfo(@RequestParam("userId") Integer userId, @RequestParam("positionRecordId") Integer positionRecordId) {
        return ResultDtoFactory.toAck("success", resumeService.getDeliverySuccessInfo(userId, positionRecordId));
    }

    @RequestMapping(value = "/getDeliveryPreSuccessInfo", method = RequestMethod.GET)
    @ApiOperation(value = "简历预投递后获取预约信息", notes = "必填 ：userId positionRecordId")
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto getDeliveryPreSuccessInfo(@RequestParam("userId") Integer userId, @RequestParam("positionRecordId") Integer positionRecordId) {
        return ResultDtoFactory.toAck("success", resumeService.getDeliveryPreSuccessInfo(userId, positionRecordId));
    }


    @ApiOperation(value = "简历第三方导入", httpMethod = "POST")
    @RequestMapping(value = "/createByMultiple", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto createByMultiple(@RequestBody List<MResumeDto> mResumeDtos) {
        if (CollectionUtils.isEmpty(mResumeDtos)) {
            return ResultDtoFactory.toNack("data is null");
        }
        return resumeService.createByMultiple(mResumeDtos);
    }


    @ApiOperation(value = "简历图片扫描导入", httpMethod = "POST")
    @RequestMapping(value = "/createByScanImg", method = RequestMethod.POST)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto createByScanImg(@RequestBody ResumeImgInfoDto resumeImgInfoDto) {
        if (resumeImgInfoDto == null || resumeImgInfoDto.getUserId() == null) {
            return ResultDtoFactory.toNack("data is null");
        }
        return resumeService.createByScanImg(resumeImgInfoDto);
    }


}
