package com.hengtiansoft.servlet.admin.reviewPosition.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.ReviewPositionDto;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.servlet.admin.reviewPosition.service.ReviewPositionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping("/admin/review")
@Api(value = "审核岗位")
public class ReviewPosition {


    @Autowired
    ReviewPositionService reviewPositionService;

    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public ResultDto list(@RequestBody ReviewPositionDto reviewPositionDto) {
        Integer pageNum = (reviewPositionDto.getPageNum() == null ? 1 : reviewPositionDto.getPageNum());
        Integer pageSize = (reviewPositionDto.getPageSize() == null ? MagicNumConstant.TEN : reviewPositionDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<>(reviewPositionService.ls(reviewPositionDto)));
    }

    @RequestMapping(value = "/operation", method = RequestMethod.GET)
    @ApiOperation(value = "申请操作", notes = "必填 ：id 审核记录ID，type 审核状态 0未审核 1审核通过 2 审核未通过")
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = "header")})
    public ResultDto operation(@RequestParam Integer id, @RequestParam(required = false) String suggestion, @RequestParam Integer type) throws Exception {
        return reviewPositionService.operation(id, suggestion, type);
    }
}
