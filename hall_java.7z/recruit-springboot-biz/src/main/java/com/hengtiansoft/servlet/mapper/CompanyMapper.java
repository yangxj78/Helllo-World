package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.config.MyMapper;
import com.hengtiansoft.bean.tableModel.Company;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CompanyMapper extends MyMapper<Company> {
    List<Company> getAll(CompanySearch companySearch);

    int updateById(Integer id);

    Company getById(int id);

    int updateCompany(Company company);

    List<Company> listByRecruitment(CompanySearch companySearch);
    int createCompany(Company company);
}