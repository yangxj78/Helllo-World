package com.hengtiansoft.servlet.hr.login.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.HRLoginDto;
import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.BehaviorEnum;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import com.hengtiansoft.common.util.IpAdrressUtil;
import com.hengtiansoft.common.util.JWTUtil;
import com.hengtiansoft.config.JWTToken;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.exception.UnauthorizedException;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.hr.login.service.HrLoginService;
import io.swagger.annotations.*;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by linwu on 7/23/2018.
 */
@Api(value = "HR登录管理", description = "HR登录管理相关接口")
@RestController
public class HrLoginController {

    @Autowired
    private HrLoginService hrLoginService;

    @Autowired
    private BoothService boothService;

    @ApiOperation(value = "HR签到", httpMethod = "POST")
    @PostMapping("/signIn")
    public ResultDto<Map<String, Object>> signIn(@ApiParam(value = "登录信息", name = "hrLoginDto") @RequestBody HRLoginDto hrLoginDto, HttpServletRequest httpServletRequest) {
        String msg = validate(hrLoginDto);
        if (msg != null) {
            return ResultDtoFactory.toNack(msg);
        }
        if (hrLoginDto.getIp() == null) {
            hrLoginDto.setIp(IpAdrressUtil.getIpAddress(httpServletRequest));
        }
        Subject currentUser = SecurityUtils.getSubject();
        try {
            JWTToken token = new JWTToken(UserTypeEnum.HR.getCode(), BehaviorEnum.LOGIN.getCode(),
                    JWTUtil.hrSign(hrLoginDto.getIp(), hrLoginDto.getCaptcha()));
            currentUser.login(token);
        } catch (AuthenticationException e) {
            return ResultDtoFactory.toNack(e.getMessage());
        }

        CompanySign companySign = SecurityContext.getCurrentHRUser();

        Map<String, Object> rMap = new HashMap<String, Object>();
        if (companySign.getCaptcha().equals(hrLoginDto.getCaptcha())) {
            String token = JWTUtil.hrSign(hrLoginDto.getIp(), hrLoginDto.getCaptcha());
            rMap.put("token", token);
            companySign.setIsBoothed(boothService.isBoothed(companySign.getRecruitmentId(),
                    companySign.getCompanyId(), companySign.getBoothId()));
            companySign.setToken(token);
            rMap.put("info", companySign);
        } else {
            throw new UnauthorizedException();
        }
        if (!hrLoginService.signIn(companySign, hrLoginDto)) {
            return ResultDtoFactory.toNack("签到失败");
        }
        return ResultDtoFactory.toAck("签到成功", rMap);
    }

    @ApiOperation(value = "获取面试结果信息", httpMethod = "GET")
    @RequestMapping(value = "/hr/getInterviewResultInfo", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Map<String, Object>> getInterviewResultInfo() {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        return hrLoginService.getInterviewResultInfo(companySign.getCompanyId(), companySign.getRecruitmentId());
    }


    @ApiOperation(value = "HR签退", httpMethod = "POST")
    @RequestMapping(value = "/hr/singOut", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto singOut(@ApiParam(value = "邮箱", name = "mail") @RequestParam(defaultValue = "linwu@hengtiansoft.com", required = false) String mail,
                             @ApiParam(value = "是否发送邮件", name = "sendFlag") @RequestParam(defaultValue = "true", required = false) Boolean sendFlag) {
        return hrLoginService.signOut(mail, sendFlag);
    }

    @ApiOperation(value = "HR暂停面试", httpMethod = "POST")
    @RequestMapping(value = "/hr/suspend", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto suspend() {
        return hrLoginService.suspend();
    }

    @ApiOperation(value = "获取HR登录信息", httpMethod = "GET")
    @RequestMapping(value = "/hr/getInfo", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Map<String, Object>> getInfo() {
        return hrLoginService.getInfo();
    }


    @ApiOperation(value = "TV端获取HR登录信息", httpMethod = "GET")
    @RequestMapping(value = "/getHrLoginInfo", method = RequestMethod.GET)
    public ResultDto<String> getHrLoginInfo(@RequestParam Integer recruitmentId,@RequestParam  Integer companyId,@RequestParam  Integer boothId) {
        return hrLoginService.getHrLoginInfo(recruitmentId, companyId, boothId);
    }


    @ApiOperation(value = "获取当前招聘会信息", httpMethod = "GET", notes = "type HR: 1 , TV: 4")
    @RequestMapping(value = "/getRecruitmentInfo", method = RequestMethod.GET)
    public ResultDto<Map<String, Object>> getRecruitmentInfo(HttpServletRequest httpServletRequest,
                                                             @RequestParam Integer type,
                                                             @RequestParam(required = false) String ip) {
        if (ip != null) {
            return ResultDtoFactory.toAck("获取成功", hrLoginService.findRecruitmentStatus(type, ip));
        }
        return ResultDtoFactory.toAck("获取成功", hrLoginService.findRecruitmentStatus(type, IpAdrressUtil.getIpAddress(httpServletRequest)));
    }


    @ApiOperation(value = "HR端获取当前展位ID", httpMethod = "GET")
    @RequestMapping(value = "/getBoothId", method = RequestMethod.GET)
    public ResultDto<Integer> getBoothId(HttpServletRequest httpServletRequest,
                                         @RequestParam(required = false) String ip) {
        if (ip != null) {
            return hrLoginService.getBoothId(UserTypeEnum.HR.getDesc(), ip);
        }
        return hrLoginService.getBoothId(UserTypeEnum.HR.getDesc(), IpAdrressUtil.getIpAddress(httpServletRequest));
    }

    @ApiOperation(value = "TV端获取当前展位ID", httpMethod = "GET")
    @RequestMapping(value = "/getBoothIdByTvIp", method = RequestMethod.GET)
    public ResultDto<Integer> getBoothIdByTvIp(HttpServletRequest httpServletRequest,
                                               @RequestParam(required = false) String ip) {
        if (ip != null) {
            return hrLoginService.getBoothId(UserTypeEnum.TV.getDesc(), ip);
        }
        return hrLoginService.getBoothId(UserTypeEnum.TV.getDesc(), IpAdrressUtil.getIpAddress(httpServletRequest));
    }


    private String validate(HRLoginDto HRLoginDto) {
        if (HRLoginDto == null) {
            return "签到信息不存在";
        }
        if (HRLoginDto.getCaptcha() == null) {
            return "签到码必须填写";
        }
        return null;
    }


}
