package com.hengtiansoft.servlet.baidu.ocr;

import com.hengtiansoft.common.constant.SymbolConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * 文件读取工具类
 */
public class FileUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtil.class);

    private static final String REPLACE = "data:image/";

    /**
     * 根据文件路径读取byte[] 数组
     */
    public static byte[] readFileByBytes(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException(filePath);
        } else {
            return fileToByte(file);
        }
    }

    /**
     * 根据文件读取byte[] 数组
     */
    public static byte[] readFileByBytes(File file) throws IOException {
        if (!file.exists()) {
            throw new FileNotFoundException();
        } else {
            return fileToByte(file);
        }
    }


    private static byte[] fileToByte(File file) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream((int) file.length());
        BufferedInputStream in = null;

        try {
            in = new BufferedInputStream(new FileInputStream(file));
            short bufSize = 1024;
            byte[] buffer = new byte[bufSize];
            int len1;
            while (-1 != (len1 = in.read(buffer, 0, bufSize))) {
                bos.write(buffer, 0, len1);
            }

            byte[] var7 = bos.toByteArray();
            return var7;
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException var14) {
                var14.printStackTrace();
            }

            bos.close();
        }
    }


    public static File base64ToTempFile(String base64, String fileName) {
        //将base64转成二进制
        String suffix = "." + base64.substring(0, base64.indexOf(SymbolConstant.SEMICOLON)).replace(REPLACE, "");
        base64 = base64.substring(base64.indexOf(SymbolConstant.COMMA) + 1);
        BASE64Decoder decoder = new BASE64Decoder();
        // Base64解码
        byte[] imageByte = null;
        try {
            imageByte = decoder.decodeBuffer(base64);
            for (int i = 0; i < imageByte.length; ++i) {
                if (imageByte[i] < 0) {
                    imageByte[i] += 256;
                }
            }
        } catch (Exception e) {
            LOGGER.error("扫描简历图片出错", e);
            return null;
        }
        File imageFile = null;
        try {
            // 生成文件
            imageFile = File.createTempFile(fileName, suffix);
            OutputStream imageStream = new FileOutputStream(imageFile);
            imageStream.write(imageByte);
            imageStream.flush();
            imageStream.close();
        } catch (Exception e) {
            LOGGER.error("扫描简历图片出错", e);
            return null;
        }
        return imageFile;
    }


    public static List<File> base64ToTempFile(List<String> base64List, String fileName) {
        List<File> fileList = new ArrayList<>();
        for (int i = 0; i < base64List.size(); i++) {
            fileList.add(base64ToTempFile(base64List.get(i), String.valueOf(i) + fileName));
        }
        return fileList;
    }

}
