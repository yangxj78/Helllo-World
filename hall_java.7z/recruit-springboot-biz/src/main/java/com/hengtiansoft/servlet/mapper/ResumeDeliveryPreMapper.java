package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.ResumeDeliveryPre;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResumeDeliveryPreMapper extends MyMapper<ResumeDeliveryPre> {
    int updateUserid(@Param("userId")Integer userId,
                     @Param("oldUserId")Integer oldUserId);

    List<ResumeDeliveryPre> selectResumePre(@Param(value = "userId")Integer userId,
                                                    @Param(value = "recruitmentId")Integer recruitmentId);

    boolean updateDeliveryFlag(@Param(value = "userId")Integer userId,
                               @Param(value = "recruitmentId")Integer recruitmentId);

    @Select("SELECT COUNT(1) FROM resume_delivery_pre WHERE resume_id = #{resumeId} AND position_record_id = #{positionRecordId} AND booth_Id=#{boothId}")
    Integer countDelivery(@Param(value = "resumeId")Integer resumeId,
                          @Param(value = "positionRecordId")Integer positionRecordId,
                          @Param(value = "boothId")Integer boothId);
}
