package com.hengtiansoft.servlet.applicant.userManage.service;


import com.hengtiansoft.bean.dataModel.IdDownDto;
import com.hengtiansoft.bean.dataModel.IdUpDto;
import com.hengtiansoft.bean.dataModel.RegisterDto;
import com.hengtiansoft.bean.tableModel.ApplicantUser;
import com.hengtiansoft.bean.tableModel.Log;
import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.BehaviorEnum;
import com.hengtiansoft.common.enumeration.UserTypeEnum;
import com.hengtiansoft.common.util.EncryptUtil;
import com.hengtiansoft.common.util.JWTUtil;
import com.hengtiansoft.config.JWTToken;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.manage.applicationUser.ApplicantUserService;
import com.hengtiansoft.servlet.mapper.ApplicantUserMapper;
import com.hengtiansoft.servlet.mapper.LogMapper;
import com.hengtiansoft.servlet.mapper.ResumeMapper;
import com.hengtiansoft.servlet.mapper.UserInfoMapper;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.*;


/**
 * 微信端（申请者）用户的登录注册相关
 */

@Service
public class ApplicantUserLoginService {

    @Autowired
    private LogMapper operationLogMapper;

    @Autowired
    private ApplicantUserMapper applicantUserMapper;


    @Autowired
    private UserInfoMapper userInfoMapper;

    @Autowired
    private ResumeMapper resumeMapper;

    @Autowired
    private ApplicantUserService applicantUserService;


    /**
     * 手机号获取用户
     *
     * @param phone
     * @return
     */
    public ApplicantUser findApplicantUser(String phone) {
        return applicantUserMapper.selectOne(new ApplicantUser(phone));
    }

    /**
     * username获取用户
     *
     * @param username
     * @return
     */
    public ApplicantUser findApplicantUserByUsername(String username) {
        ApplicantUser user = new ApplicantUser();
        user.setUsername(username);
        return applicantUserMapper.selectOne(user);
    }


    /**
     * 登录
     *
     * @param userName
     * @param secret
     * @return
     */
    public Map<String, Object> login(String userName, String secret) {

        Subject currentUser = SecurityUtils.getSubject();

        JWTToken token = new JWTToken(UserTypeEnum.APPLICANT_USER.getCode(), BehaviorEnum.LOGIN.getCode(),
                JWTUtil.sign(userName, secret));
        currentUser.login(token);
        ApplicantUser applicantUser = SecurityContext.getCurrentApplicantUser();
        applicantUser.setToken(token.getCredentials().toString());

        Map<String, Object> rMap = new HashMap<String, Object>();
        rMap.put("userId", applicantUser.getId());
        rMap.put("userInfo", applicantUser);
        rMap.put("token", token.getCredentials());

        applicantUserMapper.updateToken(token.getCredentials().toString(), applicantUser.getId());

        return rMap;
    }


    /**
     * 新增用户
     */
    @Transactional
    public ApplicantUser saveUser(RegisterDto registerDto) {
        ApplicantUser applicantUser = new ApplicantUser();
        applicantUser.setPassword(registerDto.getPassword());
        applicantUser.setCreatedDate(new Date());
        applicantUser.setMobile(registerDto.getPhone());
        applicantUser.setStatus("A");
        applicantUser.setUsername(registerDto.getUsername());
        //密码加密
        String password2 = EncryptUtil.encryptMd5(applicantUser.getUsername(), applicantUser.getPassword());
        applicantUser.setPassword(password2);
        applicantUserMapper.insert(applicantUser);
        updateIdByPhone(registerDto.getPhone());
        //记录日志
        String afterValue = "用户名" + applicantUser.getUsername() + "姓名" + applicantUser.getUsername()
                + "申请者" + "手机号"
                + applicantUser.getMobile();
        //插入纪录
        Log log = new Log();
        log.setOperator("注册");
        log.setAction("增加");
        log.setTname("手机用户");
        log.setOperationTime(new Date());
        log.setComment("新建用户");
        log.setModuleName("申请者注册");
        log.setBeforeValue(null);
        log.setAfterValue(afterValue);
        operationLogMapper.insert(log);
        return applicantUser;
    }


    /**
     * 更新验证码
     *
     * @param phone
     * @return
     */
    public boolean updateCaptcha(String captcha, String phone) {

        return applicantUserMapper.updateCaptcha(captcha, phone) > 0;
    }


    public boolean resetPassword(RegisterDto registerDto) {
        ApplicantUser applicantUser = findApplicantUser(registerDto.getPhone());
        if (applicantUser == null) {
            return false;
        }

        //密码加密
        String password2 = EncryptUtil.encryptMd5(applicantUser.getUsername(), registerDto.getPassword());
        applicantUserMapper.updatePassword(password2, applicantUser.getId());
        //记录日志
        String afterValue = "用户名" + applicantUser.getUsername() + "修改密码";
        //插入纪录
        Log log = new Log();
        log.setOperator(applicantUser.getId().toString());
        log.setAction("修改");
        log.setTname("手机用户r");
        log.setOperationTime(new Date());
        log.setComment("修改用户");
        log.setModuleName("修改密码");
        log.setBeforeValue(null);
        log.setAfterValue(afterValue);
        operationLogMapper.insert(log);
        return true;
    }


    public int updateLoginTs(ApplicantUser applicantUser) {
        return applicantUserMapper.updateByPrimaryKeySelective(applicantUser);
    }

    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public void updateIdByPhone(String phone) {
        List<Integer> oldUserIds = userInfoMapper.selectUserIdByPhone(phone);

        if (!CollectionUtils.isEmpty(oldUserIds)) {
            if (oldUserIds.size() > 1) {
                Integer holdId = oldUserIds.remove(0);
                userInfoMapper.deleteEchoUser(oldUserIds);
                oldUserIds.add(holdId);
            }
            IdUpDto upDto = new IdUpDto();
            upDto.setVirtualIds(oldUserIds);
            ApplicantUser applicantUser = findApplicantUser(phone);
            if (applicantUser != null) {
                upDto.setRealId(applicantUser.getId());
                resumeMapper.updateUserInfoId(upDto);
                resumeMapper.updateResumeId(upDto);
                resumeMapper.updateUserWorkId(upDto);
                resumeMapper.updateUserProjectId(upDto);
                resumeMapper.updateUserEduExpId(upDto);
                resumeMapper.updateResumeDelPreId(upDto);
            }
        }
    }

}
