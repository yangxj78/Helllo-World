/**
 * @Description: 岗位controller
 **/
package com.hengtiansoft.servlet.admin.position.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.Position;
import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.recycle.service.RecycleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin/position")
@Api(value = "岗位controller", description = "岗位管理相关接口")
public class PositionController {


    @Autowired
    PositionService positionService;

    @Autowired
    RecycleService recycleService;

    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ApiOperation(value = "获取公司岗位列表", notes = "可选字段 公司名称（模糊匹配），岗位名称（模糊）")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto list(@RequestBody PositionSearch positionSearch) {
        Integer pageNum = (positionSearch.getPageNum() == null ? 1 : positionSearch.getPageNum());
        Integer pageSize = (positionSearch.getPageSize() == null ? MagicNumConstant.TEN : positionSearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<Position>(positionService.search(positionSearch)));
    }


    @RequestMapping(value = "/", method = RequestMethod.POST)
    @ApiOperation(value = "新增岗位", notes = "必填 公司ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto create(@RequestBody Position position) {
        position.setName(position.getName().trim());
        if (position.getCompanyID() == null) {
            return ResultDtoFactory.toNack("企业ID不能为空");
        }
        Position position1 = new Position();
        position1.setName(position.getName());
        position1.setCompanyID(position.getCompanyID());
        position1.setStatus(0);
        if (positionService.select(position1).size() != 0) {
            return ResultDtoFactory.toNack("岗位已经存在");

        }
        try {
            String name = SecurityContext.getCurrentUser().getUsername();
            position.setCreateBy(name);
            position.setUpdateBy(name);
            position.setStatus(0);
            position.setName(position.getName().trim());
            positionService.insert(position);
            return ResultDtoFactory.toAck("添加成功");
        } catch (Exception e) {
            return ResultDtoFactory.toNack("添加失败");
        }


    }

    @RequestMapping(value = "/", method = RequestMethod.PUT)
    @ApiOperation(value = "更新岗位", notes = "必填 岗位ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto update(@RequestBody Position position) {
        position.setName(position.getName().trim());
        if (position.getId() == null) {
            return ResultDtoFactory.toNack("岗位ID不能为空");
        }
        PositionSearch search = new PositionSearch();
        search.setCompanyID(position.getCompanyID());
        search.setName(position.getName());
        List<Position> ls2 = positionService.search(search);
        if (ls2.size() > 1) {
            return ResultDtoFactory.toNack("存在同名岗位");

        }
        position.setUpdateTs(new Date(System.currentTimeMillis()));
        try {
            String name = SecurityContext.getCurrentUser().getUsername();
            position.setUpdateBy(name);
            positionService.updateSelective(position);
            return ResultDtoFactory.toAck("更新成功");

        } catch (Exception e) {
            return ResultDtoFactory.toNack("更新失败");

        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ApiOperation(value = "删除岗位", notes = "必填 岗位ID")
    @Transactional
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto delete(@PathVariable @ApiParam(name = "id", value = "岗位ID", required = true) Integer id) {
        Position position = new Position();
        position.setId(id);
        position.setUpdateTs(new Date(System.currentTimeMillis()));
        position.setStatus(1);
        Recycle recycle = new Recycle();
        recycle.setDeleteId(id);
        recycle.setType("岗位");
        recycle.setName(positionService.selectByID(id).getName());
        recycleService.insert(recycle);
        try {
            positionService.updateSelective(position);
            return ResultDtoFactory.toAck("删除成功");

        } catch (Exception e) {
            return ResultDtoFactory.toNack("删除失败");

        }
    }


    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "根据ID查岗位", notes = "必填 岗位ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto get(@PathVariable @ApiParam(name = "id", value = "岗位ID", required = true) Integer id) {
        return ResultDtoFactory.toAck("success", positionService.selectByID(id));
    }


}
