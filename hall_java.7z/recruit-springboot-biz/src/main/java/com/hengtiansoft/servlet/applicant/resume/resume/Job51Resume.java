package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.template.custom.CustomDefaultTemplate;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class Job51Resume extends BaseResume {

    public static final int BEGIN_OFF_SET_ZERO = 0;
    public static final int BEGIN_OFF_SET_THREE = 3;
    public static final int BEGIN_OFF_SET_FIVE = 5;
    public static final int BEGIN_OFF_SET_SIX = 6;
    public static final int BEGIN_OFF_SET_SEVEN = 7;
    public static final int BEGIN_OFF_SET_EIGHT = 8;
    public static final int BEGIN_OFF_SET_NINE = 9;

    @Override
    public void buildContactInfo(String s, HrResume r) {
        String content = filtercontent(s);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);

        String post = strSubstring(content, "职能：", "工作类型：");
        if (content.contains("到岗时间：")) {
            post = strSubstring(content, "职能：", "到岗时间：");
        }
        if (!StringUtils.isEmpty(post) && post.contains("行业：")) {
            post = post.substring(BEGIN_OFF_SET_ZERO, post.indexOf("行业："));
        }
        if (StringUtils.isEmpty(post)) {
            post = strSubstring(content, "职位：", "专业：");
        }
        if (!StringUtils.isEmpty(post) && post.contains("公司：")) {
        	post = post.substring(BEGIN_OFF_SET_ZERO, post.indexOf("公司："));
        }
        String school = strSubstring(content, "学校：", "学历/学位：");
        String major = strSubstring(content, "专业：", "学校：");
        String degree = strSubstring(content, "学历/学位：", BEGIN_OFF_SET_SIX, "学历/学位：", BEGIN_OFF_SET_EIGHT);
        String expectCity = strSubstring(content, "地点：", "职能：");
        String eduDate = strSubstring(content, "教育经历", school);
        String graduateDate = "";
        String englishLevel = getEnglishLevel(content);
        if (!StringUtils.isEmpty(eduDate)) {
            graduateDate = eduDate.substring(eduDate.indexOf("-")).replace("-", "");
            if (!graduateDate.replace("/", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
        }
        String expectSalary = strSubstring(content, "期望薪资：", "地点");
        expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
        String annualIncome = strSubstring(content, "目前年收入：", "(包含基本工资、补贴、奖金、股权收益等)");
        String staffType = strSubstring(content, "工作类型：", BEGIN_OFF_SET_FIVE, "工作类型：", BEGIN_OFF_SET_SEVEN);
        if (!StringUtils.isEmpty(staffType) && staffType.contains("/")) {
            staffType = strSubstring(content, "工作类型：", BEGIN_OFF_SET_FIVE, "工作类型：", BEGIN_OFF_SET_NINE);
        }
        String selfIntroduction = strSubstring(content, "自我评价：", "工作经验");

        r.setSelfIntroduction(selfIntroduction);
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setGraduateDate(graduateDate);
        r.setExpectSalary(expectSalary);
        r.setAnnualIncome(annualIncome);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;

        String[] arr = content.split("<td class=\"plate1\">");
        if (arr.length < 2) {
            arr = content.split("arial;color:#3876c1'>");
        }
        if (arr.length < 2) {
            arr = content.split("\"microsoft yahei\";color:#818ba3'>");
        }
        for (String str : arr) {
            if (str.startsWith("工作经验")) {
                workExperience = filterExperience(str).replaceFirst("工作经验(&nbsp;)*", "");
                if (workExperience.contains("<spanlang=zh-cn")) {
                    workExperience = workExperience.substring(0, workExperience.indexOf("<spanlang=zh-cn"));
                }
            }
            if (str.startsWith("项目经验")) {
                projectExperience = filterExperience(str).replaceFirst("项目经验(&nbsp;)*", "");
                if (projectExperience.contains("<spanlang=zh-cn")) {
                    projectExperience = projectExperience.substring(0, projectExperience.indexOf("<spanlang=zh-cn"));
                }
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
                if (education.contains("<spanlang=zh-cn")) {
                    education = education.substring(0, education.indexOf("<spanlang=zh-cn"));
                }
            }
        }


        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setUserEducationExperienceList(educationExperienceConvert(education));
        r.setUserWorkExperienceList(workExperienceConvert(workExperience));
        r.setProjectExperienceList(projectExperienceConvert(projectExperience));

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);
        String[] arr = content.split("&nbsp;");
        List<String> list = new ArrayList<String>();
        for (String str : arr) {
            if (!StringUtils.isEmpty(str)) {
                list.add(str);
            }
        }
        String updateDate = getUpdateDate(content);
        String name = null;
        for (String str : list) {
            if (str.contains("流程状态")) {
                name = str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("流程状态"));
                continue;
            }
        }
        String year = getWorkedYears(content);
        String number = getNumber(content);
        String phone = getPhone(content);
        String info = content.substring(content.indexOf(phone));

        String[] infos = info.substring(BEGIN_OFF_SET_ZERO, info.indexOf("工作经验")).split("\\|");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        String birthDate = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
                birthDate = strSubstring(str, "（", "）");
                if (!StringUtils.isEmpty(birthDate)) {
                    birthDate = preProcessBirthDate(birthDate);
                }
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (str.contains("现居住")) {
                city = str.replace("现居住", "");
            }

        }

        // 过滤名字
        if (!StringUtils.isEmpty(name)) {
            Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]{2,4}");
            Matcher matcher = reg.matcher(name);
            while (matcher.find()) {
                name = matcher.group();
                break;
            }
        }

        if (StringUtils.isEmpty(name)) {
            name = StringUtils.substring(content, 0, content.indexOf("id"));
        }

        r.setBirthDate(birthDate);
        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.JOB51UPLOAD);
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

        String content = messageBody2String(mailContent);
        content = filtercontent(content);

        String[] postAndName = mailContent.getSubject().split("－");
        String post = null;
        String name = null;
        if (postAndName.length == 2) {
            post = fieldTrim(postAndName[0].substring("(51job.com)申请贵公司".length()));
            name = fieldTrim(postAndName[1]);
        }

        String year = getWorkedYears(content);
        String number = getNumber(content);

        String info = strSubstring(content, name, number).replaceAll("&nbsp;\\|&nbsp;", "");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        if (info.contains("女")) {
            sex = SexEnum.WOMAN;
        }
        if (info.contains("岁")) {
            try {
                age = Integer.parseInt(strSubstring(info, sex.getDesc(), "岁"));
            } catch (Exception e) {
            }

        }
        String city = strSubstring(content, "居住地：", "求职状态：");

        r.setPost(post);
        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.JOB51COLLECT);
    }

    public String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<style>.*?</style>", "").replaceAll("<.*?>", "")
                .replaceAll("&emsp;", "").replaceAll("　", "").replaceAll("&#x20;", "");
    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);

        String school = strSubstring(content, "学校：", "学历/学位：");
        String major = strSubstring(content, "专业：", "学校：");
        String degree = strSubstring(content, "学历/学位：", BEGIN_OFF_SET_SIX, "学历/学位：", BEGIN_OFF_SET_EIGHT);
        String expectCity = strSubstring(content, "地点：", "职能：");
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("教育经历") && !StringUtils.isEmpty(school)) {
            String eduDate = strSubstring(content, "教育经历", school);
            graduateDate = eduDate.substring(eduDate.indexOf("-")).replace("-", "");
            if (!graduateDate.replace("/", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
        }
        String matchDegree = strSubstring(content, "简历匹配：", r.getName()).replaceAll("&nbsp;", "").replaceAll("-->", "");
        String expectSalary = strSubstring(content, "期望薪资：", "地点");
        expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
        String annualIncome = strSubstring(content, "目前年收入", "（包含基本工资、补贴、奖金、股权收益等）");
        annualIncome = StringUtils.isEmpty(annualIncome) ? null : annualIncome.replace("&nbsp;", "");
        String staffType = strSubstring(content, "工作类型：", "工作经验");
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setGraduateDate(graduateDate);
        r.setMatchDegree(matchDegree);
        r.setExpectSalary(expectSalary);
        r.setAnnualIncome(annualIncome);
        r.setStaffType(staffType);
    }

    private String getTagByName(String content, String tagName) {
        StringBuffer sb = new StringBuffer();
        Document document = Jsoup.parse(content);
        document.getElementsByTag(tagName).stream().forEach((e) -> {
            sb.append(e.text());
            sb.append("\n");
        });
        return sb.toString();
    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);
        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String preWorkContent = content.substring(content.indexOf("年工作经验") + 5);
        String workExStr = strSubstring(preWorkContent, "工作经验", "项目经验");
        if (workExStr != null) {
            workExperience = workExStr.replaceAll("&nbsp;", "\n");
            String projectExStr = strSubstring(content, "项目经验", "教育经历");
            if (projectExStr != null) {
                projectExperience = projectExStr.replaceAll("&nbsp;", "\n");
            }
        } else {
            workExStr = strSubstring(preWorkContent, "工作经验", "教育经历");
            if (workExStr != null) {
                workExperience = workExStr.replaceAll("&nbsp;", "\n");
            }
        }
        String eduExStr = strSubstring(content, "教育经历", "技能特长");
        if (eduExStr != null) {
            education = eduExStr.replaceAll("&nbsp;", "\n");
        }
        workExperience = enterExperienceByEnter(workExperience);
        projectExperience = enterExperienceByEnter(projectExperience);
        education = enterExperienceByEnter(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    protected List<UserWorkExperience> workExperienceConvert(String workExperience) {
        if (StringUtils.isEmpty(workExperience)) {
            return null;
        }
        List<UserWorkExperience> result = new ArrayList<>();
        List<String> workDates = new ArrayList<>();

        String regex = "\\d{4}/\\d{1,2}[-—]*(\\d{4}/\\d{1,2}|至今)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(workExperience);
        while (matcher.find()) {
            workDates.add(matcher.group());
        }

        String[] str = workExperience.split("<br/>");

        List<String> workExperiences = Arrays.asList(str);

        int i = 0;
        while (i < workDates.size()) {
            UserWorkExperience temp = new UserWorkExperience();
            String[] times = workDates.get(i).split("-");

            temp.setStartTs(times[0].replaceAll("/", "-"));
            temp.setEndTs(times[1].replaceAll("/", "-"));

            String experience = workExperiences.get(i);

            int j = experience.indexOf(" 工作描述");
            if(j>=0){
                String info = workExperiences.get(i).substring(BEGIN_OFF_SET_ZERO, j);
                String[] strArray = info.split(" ");
                temp.setJob(strArray[1]);
                temp.setCompany(CustomDefaultTemplate.findCompanyName(info));

                /*匹配工作描述： 后的内容*/
                temp.setDescription(experience.substring(j + 7));
            }

            result.add(temp);
            i++;
        }

        return result;
    }

    protected List<UserEducationExperience> educationExperienceConvert(String educationExperience) {
        if (StringUtils.isEmpty(educationExperience)) {
            return null;
        }
        List<UserEducationExperience> result = new ArrayList<>();
        String[] eduArray = educationExperience.split("<br/>");

        for (String education : eduArray) {
            UserEducationExperience temp = new UserEducationExperience();
            String[] strArray = education.split(" ");
            temp.setSchool(strArray[1]);
            temp.setMajor(strArray[3]);
            temp.setEducational(EducationalEnum.verifyEducation(strArray[2]));

            String time = strArray[0];
            temp.setStartTs(time.substring(BEGIN_OFF_SET_ZERO, time.indexOf('-')).replaceAll("/","-"));
            temp.setEndTs(time.substring(time.indexOf('-') + 1).replaceAll("/","-"));

            result.add(temp);
        }
        return result;
    }

    protected List<UserProjectExperience> projectExperienceConvert(String projectExperience) {
        if (StringUtils.isEmpty(projectExperience)) {
            return null;
        }
        List<UserProjectExperience> result = new ArrayList<>();
        List<String> workDates = new ArrayList<>();

        String regex = "\\d{4}/\\d{1,2}[-—]*(\\d{4}/\\d{1,2}|至今)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(projectExperience);
        while (matcher.find()) {
            workDates.add(matcher.group());
        }

        String[] str = projectExperience.split("<br/>");

        List<String> projectExperiences = Arrays.asList(str);

        int i = 0;
        while (i < workDates.size()) {
            UserProjectExperience temp = new UserProjectExperience();
            String[] times = workDates.get(i).split("-");

            temp.setStartTs(times[0].replaceAll("/", "-"));
            temp.setEndTs(times[1].replaceAll("/", "-"));

            String experience = projectExperiences.get(i);

            int startIndex = experience.indexOf(' ');
            int endIndex = experience.indexOf(" ", startIndex + 1);
            String projectName = experience.substring(startIndex + 1, endIndex);
            temp.setProjectName(projectName);

            int descIndex = experience.indexOf(" 项目描述");
            int dutyIndex = experience.indexOf(" 责任描述");
            if (experience.contains("所属公司： ")) {
                String company = experience.substring(experience.indexOf("所属公司： ") + 6, descIndex);
                temp.setCompany(company);
            }


            /*匹配项目描述*/
            if (dutyIndex > -1) {
                temp.setDescription(experience.substring(descIndex + 7, experience.indexOf("责任描述")));
                temp.setDuty(experience.substring(dutyIndex + 7));
            } else {
                temp.setDescription(experience.substring(descIndex + 7));
            }

            result.add(temp);
            i++;
        }

        return result;
    }

    private String preProcessBirthDate(String str) {
        String regex = "[0-9]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            if (sb.length() == 0) {
                sb.append(matcher.group());
            } else {
                sb.append("-").append(matcher.group());
            }
        }
        return sb.toString();
    }
}
