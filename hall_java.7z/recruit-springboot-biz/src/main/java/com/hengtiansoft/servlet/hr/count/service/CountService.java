package com.hengtiansoft.servlet.hr.count.service;

import com.hengtiansoft.bean.ResultDto;

import java.util.List;
import java.util.Map;

/**
 * Created by linwu on 7/19/2018.
 */
public interface CountService {

    /**
     * 获取投递信息统计
     * @return
     */
    ResultDto<Map> findDeliveryInfo();

    /**
     * 获取职位信息统计
     * @return
     */
    ResultDto<List<Map<String, Object>>> findPositionInfo();

    /**
     * 获取工作年限学历统计
     * @return
     */
    ResultDto<Map> findWorkYearsAndEduInfo();
}
