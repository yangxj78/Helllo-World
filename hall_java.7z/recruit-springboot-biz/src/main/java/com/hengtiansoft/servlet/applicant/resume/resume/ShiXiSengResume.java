package com.hengtiansoft.servlet.applicant.resume.resume;


public abstract class ShiXiSengResume extends BaseResume {

}
