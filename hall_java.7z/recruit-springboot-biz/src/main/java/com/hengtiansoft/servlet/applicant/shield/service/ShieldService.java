package com.hengtiansoft.servlet.applicant.shield.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.CompanyDateDto;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.ShieldCompany;

import java.util.List;

public interface ShieldService {

    ResultDto shieldCompany(List<ShieldCompany> shieldCompanys);
    ResultDto getShieldCompanyList(Integer resumeId);

    ResultDto delete(Integer id);

    List<CompanyDateDto> searchCompanyAndShield(Integer resumeId, String companySearch);
}
