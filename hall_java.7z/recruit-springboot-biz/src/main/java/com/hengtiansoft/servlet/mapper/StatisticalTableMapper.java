package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.StatisticalTable;
import com.hengtiansoft.config.MyMapper;

public interface StatisticalTableMapper extends MyMapper<StatisticalTable> {
}