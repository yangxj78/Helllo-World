package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.List;

public abstract class LaGouResume extends BaseResume {

    public static final int NUM_ZERO = 0;
    public static final int NUM_ONE = 1;
    public static final int NUM_TWO = 2;
    public static final int NUM_THREE = 3;
    public static final int NUM_FOUR = 4;

    @Override
    public void buildContactInfo(String content, HrResume r) {
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String[] arr = content.split("\r");
        List<String> list = new ArrayList<String>();
        for (String str : arr) {
            if (!StringUtils.isBlank(str.trim())) {
                list.add(str.trim());
            }
        }

        String post = null;
        String expectCity = null;
        String staffType = null;
        String expectSalary = null;
        if (list.indexOf("期望工作") != -1) {
            String[] expectInfos = list.get(list.indexOf("期望工作") + NUM_ONE).replaceAll(" ", "").replaceAll(" ", "")
                    .split("，");
            post = fieldTrim(expectInfos[NUM_ZERO]);
            if (expectInfos.length > NUM_ONE)
                staffType = fieldTrim(expectInfos[NUM_ONE]);
            if (expectInfos.length > NUM_TWO)
                expectCity = fieldTrim(expectInfos[NUM_TWO]);
            if (expectInfos.length > NUM_THREE)
                expectSalary = fieldTrim(expectInfos[NUM_THREE]);
        }

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (list.indexOf("教育经历") != -1) {
            String eduExperience = content.substring(content.indexOf("教育经历"), content.lastIndexOf("项目经验"));
            String[] eduInfos = eduExperience.replaceAll(" ", "").split("\n");
            List<String> edulist = new ArrayList<String>();
            for (String str : eduInfos) {
                if (!StringUtils.isBlank(str) && !" ".equals(str) && !"教育经历".equals(str)) {
                    edulist.add(str);
                }
            }
            if (eduInfos.length == 1) {
                String[] eduInfos2 = list.get(list.indexOf("教育经历") + NUM_TWO).replaceAll("·", "").split("\\s+");
                for (String str : eduInfos2) {
                    if (!StringUtils.isBlank(str) && !" ".equals(str) && !"教育经历".equals(str)) {
                        edulist.add(str);
                    }
                }
            }
            school = fieldTrim(edulist.get(NUM_ZERO));
            if (edulist.size() > NUM_ONE)
                degree = fieldTrim(edulist.get(NUM_ONE));
            if (edulist.size() > NUM_TWO)
                major = fieldTrim(edulist.get(NUM_TWO));
            if (edulist.size() > NUM_THREE)
                graduateDate = fieldTrim(edulist.get(NUM_THREE)).substring(NUM_ZERO, NUM_FOUR);
        }
        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setStaffType(staffType);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = content.split(" ");
        for (String str : arr) {
            str = filtercontent(str).replace("", "");
            if (str.startsWith("工作经历")) {
                workExperience = fieldTrim(str.replaceFirst("工作经历", ""));
            }
            if (str.startsWith("项目经验")) {
                projectExperience = fieldTrim(str.replaceFirst("项目经验", ""));
            }
            if (str.startsWith("教育经历")) {
                education = fieldTrim(str.replaceFirst("教育经历", ""));
            }
        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);

    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);
        String[] arr = content.split("\r");
        List<String> list = new ArrayList<String>();
        for (String str : arr) {
            if (!StringUtils.isBlank(str.trim()) && !str.contains("简历来自：拉勾网 - 最专业的互联网招聘网站 - www.lagou.com")) {
                list.add(str.trim());
            }
        }

        String name = list.get(0);
        String year = getWorkedYears(content);

        SexEnum sex = SexEnum.MAN;
        String city = null;
        for (String str : list) {
            if (str.contains("工作经验")) {
                String[] infos = str.replaceAll(" ", "").split("︳");

                for (String s : infos) {
                    if ("女".equals(s)) {
                        sex = SexEnum.WOMAN;
                    }

                    if (s.contains("工作经验")) {
                        year = s.replaceAll("年工作经验", "");
                    }
                }

                city = infos[infos.length - NUM_ONE];
                break;
            }
        }

        r.setName(name);
        r.setSex(sex);
        r.setYears(year);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.LAGOUUPLOAD);
    }

    public String filtercontent(String content) {
        return content.replaceAll("", " ").replaceAll("", " ").replaceAll("", " ");
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);

        Document document = Jsoup.parse(content);
        Elements postElements = document.select("body div div div p");

        Elements postElement = postElements.select("span:containsOwn(拉勾网)");
        String rawPost = postElement.text();
        int postIndex = rawPost.indexOf("主题:（简历来自拉勾）");
        String post = rawPost.substring(postIndex + "主题:（简历来自拉勾）".length());
        post = post.replace("：", "");

        Elements elements = document.select("body table tr:eq(1) div:eq(2) p span:eq(0)");
        String rawContent = elements.text();
        String[] contentArray = rawContent.split("\\|");
        String name = contentArray[0];
        String sex = contentArray[1];
        String degree = contentArray[2];
        String rawYears = contentArray[3];

        SexEnum realSex = getRealSex(sex);

        r.setName(name);
        r.setAge(0);
        r.setDegree(degree);
        r.setContent(content);
        r.setYears(rawYears);
        r.setSex(realSex);
        r.setSource(ResumeSourceEnum.LAGOUCOLLECT);
        r.setPost(post);
    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {

    }
}
