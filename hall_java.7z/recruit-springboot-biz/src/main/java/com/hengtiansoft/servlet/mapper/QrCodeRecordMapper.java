package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.QrCodeRecord;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface QrCodeRecordMapper extends MyMapper<QrCodeRecord> {
    List<QrCodeRecord> findQCRByIndex(@Param("recruitmentId") int recruitmentId
            , @Param("startIndex") int startIndex
            , @Param("today")Timestamp today);

    //用户是否入场
    boolean hasSignIn(@Param("userId") Integer userId, @Param("positionRecordId") Integer positionRecordId);
}
