package com.hengtiansoft.servlet.applicant.resume.service;

import com.hengtiansoft.bean.dataModel.ResumeDto;
import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.converters.KeywordMatcher;
import com.hengtiansoft.common.enumeration.SourceEnum;
import com.hengtiansoft.common.exception.CustomException;
import com.hengtiansoft.common.exception.ParserException;
import com.hengtiansoft.common.utils.ExtendIOUtils;
import com.hengtiansoft.common.utils.FileTypeUtils;
import com.hengtiansoft.common.utils.ReadPDFUtil;
import com.hengtiansoft.servlet.applicant.resume.file.FileStorageService;
import com.hengtiansoft.servlet.applicant.resume.until.ChineseName;
import com.hengtiansoft.servlet.baidu.ocr.OcrService;
import lombok.extern.slf4j.Slf4j;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class ExtendExchangeService2 {

    private byte[] lock = new byte[0]; // 特殊的instance变量

    @Autowired
    private OcrService ocrService;

    @Autowired
    @Qualifier("local")
    private FileStorageService fileStorageService;


    public HrResume uploadTemplate2Resume(ConentType contentType) throws Exception {
        ResumeBuilder resumeBuilder = TempLateFactory.createBuilder(contentType);
        if (resumeBuilder != null) {
            return resumeBuilder.buildResume(contentType.getContent());
        } else {
            return null;
        }

    }


    public ResumeDto uploadTemplate2Resume(List<MultipartFile> files) throws FileUploadException, ParserException,
            CustomException {
        List<HrResume> resumes = new ArrayList<>();
        HrResume resume = null;
        String fileName = getFileNameWithoutPath(files.get(0).getOriginalFilename());
        if (fileName != null) {
            fileName = fileName.trim();
        }
        byte[] bytes;
        ConentType contentType;
        boolean isPicture = false;

        try {
            bytes = ExtendIOUtils.toBytes(files.get(0).getInputStream());
            String prefix = fileName.substring(fileName.lastIndexOf('.') + 1).toUpperCase();
            if (prefix.contains("PNG") || prefix.contains("JPG") || prefix.contains("JPEG") || prefix.contains("BMP")) {
                StringBuffer text = new StringBuffer();
                for (MultipartFile file : files) {
                    text.append(ocrService.getText(file.getBytes()));
                }
                contentType = new ConentType("image", text.toString(), text.toString().getBytes());
                isPicture = true;
            } else {

                contentType = FileTypeUtils.getFileType(ExtendIOUtils.toInputStream(bytes));
                // 获取pdf中图片的文本内容
                contentType = getPdfImageText(contentType);

            }
            if (contentType.getContent() != null) {
                try {
                    resume = uploadTemplate2Resume(contentType);
                } catch (CustomException e) {
                    log.error(e.getLocalizedMessage());
                    e.getStackTrace();
                } catch (Exception e) {
                    log.error(e.getLocalizedMessage());
                    e.getStackTrace();
                }

                // 主流渠道不能正确的得到简历就走智能解析
                if (resume == null || StringUtils.isEmpty(resume.getName()) || !checkphone(resume.getPhone())
                        || (CollectionUtils.isEmpty(resume.getProjectExperienceList()) && CollectionUtils.isEmpty(resume.getUserWorkExperienceList()))) {

                    // 智能解析 需要转成pdf在拿文本
//                    log.debug("###word2pdf");-
//                    String fileType = contentType.getType();
//                    if (!"pdf".equals(contentType.getType())) {
//                        contentType = getTranslationPdfText(ExtendIOUtils.toInputStream(bytes), contentType,
//                                fileName, "gxrc");
//                    }
//                    log.debug("###word2pdf end ");
                    resume = new HrResume();
                    KeywordMatcher keywordMatcher = new KeywordMatcher();
                    synchronized (lock) {
                        log.debug("###npl ");
                        nplParseResume(resume, contentType, keywordMatcher);
                        log.debug("###npl end");
                    }
                    if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                            || "html".equals(contentType.getType()) || "docx".equals(contentType.getType())) {
                        resume.setContent(keywordMatcher.filtercontent(contentType.getContent())); // set origin
                    } else {
                        resume.setContent(contentType.getContent()); // set origin full content;
                    }
                }
            } else {
                throw new ParserException("contentType getContent is null");
            }
            log.error("phonenum:" + resume.getPhone());
            if (StringUtils.isEmpty(resume.getName()) || resume.getName().length() < 2 || resume.getName().length() > 4) {// 从文件名获取姓名
                String personName = ChineseName.getPersonNameByHanlp(fileName);
                if (StringUtils.isBlank(personName)) {
                    personName = filterName(fileName);
                }
                if (StringUtils.isNotBlank(personName)) {
                    resume.setName(personName);
                }
            }
            log.error("phonenum2:" + resume.getPhone());

            // 判断电话号码和姓名是否存在 电话是否准确
            if (StringUtils.isEmpty(resume.getName()) || !checkphone(resume.getPhone())) {
                if (StringUtils.isEmpty(resume.getName())) {
                    throw new CustomException("not found name");
                } else if (!checkphone(resume.getPhone())) {
                    throw new CustomException("手机号未匹配");
                }
            }
            log.error("phonenum3:" + resume.getPhone());
        } catch (CustomException e) {
            log.error(e.getLocalizedMessage());
            throw new CustomException(e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.toString());
            throw new ParserException(e);
        }
        String uploadPath;
        String uploadPdfPath = null;
        try {
            log.error("phonenum4:" + resume.getPhone());

            uploadPath = fileStorageService.upload(files.get(0).getInputStream(), fileName, "");
            log.error("phonenum5:" + resume.getPhone());

        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            throw new FileUploadException(e.getLocalizedMessage());
        }

        resume.setPdfUrl(uploadPdfPath);
        resume.setWordUrl(uploadPath);
        if (isPicture) {
            resume.setPdfUrl(uploadPath);
        }
        resume.setPostTime(new Date());
        resumes.add(resume);

        ResumeDto temp = new ResumeDto(resume);
        temp.getResume().setName(fileName.substring(0, fileName.lastIndexOf('.')));
        temp.getResume().setSource(SourceEnum.LOCALIMPORT.getCode());
        //将简历的默认工作地点设置为浙江省杭州市滨江区
        temp.getResume().setRegion(330108);
        //将简历中的地址改为杭州
        temp.getUserInfo().setAddress("杭州");
        //对简历的工作经历、自我介绍和项目经历过长的公司名和描述进行处理
        if (!CollectionUtils.isEmpty(temp.getUserWorkExperienceList())) {
            for (UserWorkExperience workExperience : temp.getUserWorkExperienceList()) {
                workExperience.setDescription(trunDescription(workExperience.getDescription()));
                workExperience.setCompany(trunCompany(workExperience.getCompany()));
            }
        }

        if (!CollectionUtils.isEmpty(temp.getUserProjectExperienceList())) {
            for (UserProjectExperience projectExperience : temp.getUserProjectExperienceList()) {
                projectExperience.setDescription(trunDescription(projectExperience.getDescription()));
                projectExperience.setCompany(trunCompany(projectExperience.getCompany()));
                projectExperience.setDuty(trunDuty(projectExperience.getDuty()));
            }
        }

        temp.getResume().setSelfIntroduction(trunSelfIntroduction(temp.getResume().getSelfIntroduction()));
        log.error("phonenum6:" + resume.getPhone());

        return temp;
    }

    private String getFileNameWithoutPath(String fileOriName) {
        return fileOriName.indexOf('\\') > 0 ? fileOriName.substring(fileOriName.lastIndexOf('\\') + 1) : fileOriName;
    }

    /**
     * 得到pdf图片中的文字内容
     */
    private ConentType getPdfImageText(ConentType contentType) throws Exception {

        if ("pdf".equals(contentType.getType())) {
            String text = contentType.getContent();

            // 只有文字内容很少的时候才去读文件中图片的内容
            if (text.length() < 300) {
                List<byte[]> bytes = ReadPDFUtil.getImageBytes(new ByteArrayInputStream(contentType.getBytes()));
                for (byte[] b : bytes) {
                    String imageText = ocrService.getText(b);
                    text = text + "\n" + imageText;
                }
            }

            contentType.setContent(text);
        }
        return contentType;
    }

    public boolean checkphone(String phone) {
        if (StringUtils.isEmpty(phone)) {
            return false;
        }

        Pattern phoneRex = Pattern.compile("^[1][3456789][0-9]{9}$");
        Matcher matcher = phoneRex.matcher(phone);
        while (matcher.find()) {
            return true;
        }
        return false;
    }

    /**
     * Description: TODO
     *
     * @param content a
     * @return
     */
    public static String messageBody2String(MailContent content) {
        try {
            if (content.getMessageBody() != null) {
                return MessageBody.getStringFromMessageBody(content.getMessageBody());
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
        }
        return (String) content.getContent();
    }


    private void nplParseResume(HrResume resume, ConentType contentTypeNplPart, KeywordMatcher keywordMatcher)
            throws ParserException {
        Map<String, String> map = new HashMap<String, String>();
        try {

            resume.setEducation(null);
            resume.setWorkExpirence(null);
            keywordMatcher.processFileOld(contentTypeNplPart, resume);

        } catch (Exception e) {
            log.error("npl parse error:" + e.getLocalizedMessage());
            throw new ParserException(e);
        }
    }

    private String filterName(String name) {
        // 过滤名字
        if (!StringUtils.isEmpty(name)) {
            Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]{2,4}");
            Matcher matcher = reg.matcher(name);
            while (matcher.find()) {
                name = matcher.group();
                break;
            }
        }
        return name;
    }

    private String trunDescription(String str) {
        if (StringUtils.isEmpty(str)) {
            return "";
        }
        String result = str;
        if (str.length() > 2000) {
            int j = StringUtils.substring(str, 0, 2000).lastIndexOf("。");
            if (j > 0) {
                result = StringUtils.substring(str, 0, j);
            } else {
                result = StringUtils.substring(str, 0, 2000);
            }
        }
        return result;
    }

    private String trunDuty(String str) {
        if (StringUtils.isEmpty(str)) {
            return "";
        }
        String result = str;
        if (str.length() > 1000) {
            int j = StringUtils.substring(str, 0, 1000).lastIndexOf("。");
            if (j > 0 && j < 1000) {
                result = StringUtils.substring(str, 0, j);
            } else {
                result = StringUtils.substring(str, 0, 1000);
            }
        }
        return result;
    }

    private String trunSelfIntroduction(String str) {
        if (StringUtils.isEmpty(str)) {
            return "";
        }
        String result = str;
        if (str.length() > 1500) {
            int j = StringUtils.substring(str, 0, 1500).lastIndexOf("。");
            if (j > 0 && j < 1500) {
                result = StringUtils.substring(str, 0, j);
            } else {
                result = StringUtils.substring(str, 0, 1500);
            }
        }
        return result;
    }

    private String trunCompany(String str) {
        if (StringUtils.isEmpty(str)) {
            return "";
        }
        String result = str;
        StringBuilder temp = new StringBuilder(str).reverse();
        if (str.length() > 50) {
            int j = StringUtils.substring(str, 0, 50).lastIndexOf("。");
            if (j > 0 && j < 50) {
                result = new StringBuilder(temp.substring(0, j)).reverse().toString();
            } else {
                result = new StringBuilder(temp.substring(0, 50)).reverse().toString();
            }
        }
        return result;
    }

}
