/**
*@Description: 标签接口

**/
package com.hengtiansoft.servlet.admin.common.service;

import com.hengtiansoft.bean.tableModel.Tag;
import com.hengtiansoft.common.service.Service;
import java.util.List;
import java.util.Set;

public interface TagService extends Service<Tag> {
    List<Tag> list(int parentID );
    Tag getByID(Integer id);

    void distinct(Set set);
}
