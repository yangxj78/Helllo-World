package com.hengtiansoft.servlet.baidu.ocr;

/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import java.net.URLEncoder;

//import com.baidu.aip.util.Base64Util;

/**
 * OCR 通用识别
 */

@Getter
@Setter
@Service
@Slf4j
@PropertySource("classpath:ocr.properties")
public class OcrService {

    /**
     * 代码中所需工具类 FileUtil,Base64Util,HttpUtil请从 https://ai.baidu.com/file/BA73D199EED14D8AA5FC5A4BF4BDDA34
     * https://ai.baidu.com/file/C8D81F3301E24D2892968F09AE1AD6E2
     * https://ai.baidu.com/file/88C6E86FB5D141889391693FC84504B1 下载
     */

    private static final String CHARSET_UTF_8 = "UTF-8";

    @Value("${baidu.API_Key}")
    private String baiduAppKey;

    @Value("${baidu.Secret_Key}")
    private String baiduSecretKey;

    @Value("${baidu.request.url}")
    private String baiduResuestURL;

    public String getText(byte[] imgData) {
        // 本地图片路径
        try {
            String imgStr = Base64Util.encode(imgData);
            String params = URLEncoder.encode("image", CHARSET_UTF_8) + "=" + URLEncoder.encode(imgStr, CHARSET_UTF_8);
            /**
             * 线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
             */
            String accessToken = "";

            if (StringUtils.isEmpty(accessToken)) {
                log.info(baiduAppKey);
                accessToken = AuthService.getAuth(baiduAppKey, baiduSecretKey);
            }

            String result = HttpUtil.post(baiduResuestURL, accessToken, params);

            JSONObject jsonObject = new JSONObject(result);

            // 得到所有的文字
            String text = "";
            JSONArray arr = jsonObject.getJSONArray("words_result");
            for (int i = 0; i < arr.length(); i++) {

                JSONObject object = (JSONObject) arr.get(i);
                String words = object.getString("words");
                text = text + "\n" + words;

            }
            return text;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void main(String[] args) {
        // 通用识别url
        String otherHost = "https://aip.baidubce.com/rest/2.0/ocr/v1/accurate_basic";
        // 本地图片路径
        String filePath = "D:\\微信图片_20180601150348.png";
        try {
            byte[] imgData = FileUtil.readFileByBytes(filePath);
            String imgStr = Base64Util.encode(imgData);
            String params = URLEncoder.encode("image", CHARSET_UTF_8) + "=" + URLEncoder.encode(imgStr, CHARSET_UTF_8);
            /**
             * 线上环境access_token有过期时间， 客户端可自行缓存，过期后重新获取。
             */

            // 官网获取的 API Key 更新为你注册的
            String clientId = "tcE6rhr9c0WeoNsKHslwrlco";
            // 官网获取的 Secret Key 更新为你注册的
            String clientSecret = "7QjqfOdsPoLilkTRlLnbZ7SDZbGcGkwN";

            String accessToken = AuthService.getAuth(clientId, clientSecret);
            String result = HttpUtil.post(otherHost, accessToken, params);

            JSONObject jsonObject = new JSONObject(result);
            String text = "";
            JSONArray arr = jsonObject.getJSONArray("words_result");
            for (int i = 0; i < arr.length(); i++) {

                JSONObject object = (JSONObject) arr.get(i);
                String words = object.getString("words");
                text = text + words;
            }
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
        }
    }

}
