package com.hengtiansoft.servlet.applicant.resume.template.zhilian;

import com.hengtiansoft.servlet.applicant.resume.resume.ZhiLianResume;

public class ZhiLianDefaultTemplate extends ZhiLianResume {

}
