package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.CompanyPicture;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CompanyPictureMapper extends MyMapper<CompanyPicture> {
    List<String> getPictures(Integer id);
}