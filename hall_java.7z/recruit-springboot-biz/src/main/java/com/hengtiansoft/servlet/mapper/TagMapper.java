package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.Tag;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface TagMapper extends MyMapper<Tag> {


    List<Tag> list(int parentID );

    @Select("select if(count(id)!=1,0,id) from tag where name like #{name}")
    int countByName(@Param("name") String name);
}