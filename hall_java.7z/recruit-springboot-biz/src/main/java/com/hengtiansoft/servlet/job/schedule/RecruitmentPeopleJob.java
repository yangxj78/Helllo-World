package com.hengtiansoft.servlet.job.schedule;


import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.ReviewPositionRecord;
import com.hengtiansoft.bean.tableModel.UpdateTs;
import com.hengtiansoft.servlet.manage.email.EmailService;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryMapper;
import com.hengtiansoft.servlet.mapper.ReviewPositionRecordMapper;
import com.hengtiansoft.servlet.mapper.UpdateTsMapper;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@EnableScheduling
@Component
//@RestController
public class RecruitmentPeopleJob {

    @Autowired
    UpdateTsMapper updateTsMapper;

    @Autowired
    ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    ReviewPositionRecordMapper reviewPositionRecordMapper;
    @Autowired
    RecruitmentMapper recruitmentMapper;
    private static final Logger LOGGER = LoggerFactory.getLogger(EmailService.class);

    @Scheduled(cron = "*/10 * * * * ?")
    public void updateNumber() {
        LOGGER.info("job启动");
        UpdateTs updateTs = updateTsMapper.selectByPrimaryKey(1);
        UpdateTs updateTs2 = updateTsMapper.selectByPrimaryKey(2);

        if (updateTs == null) {
            updateTs = new UpdateTs();
            updateTs.setLastUpdateTs("2010-01-01 00:00:00");
            updateTsMapper.insert(updateTs);
            updateTs = updateTsMapper.selectByPrimaryKey(1);

        }
        if (updateTs.getLastUpdateTs() == null) {
            updateTs.setLastUpdateTs("2010-01-01 00:00:00");
            updateTsMapper.updateByPrimaryKey(updateTs);
        }


        if (updateTs2 == null) {
            updateTs2 = new UpdateTs();
            updateTs2.setLastUpdateTs("2010-01-01 00:00:00");
            updateTsMapper.insert(updateTs2);
            updateTs2 = updateTsMapper.selectByPrimaryKey(2);

        }
        if (updateTs2.getLastUpdateTs() == null) {
            updateTs2.setLastUpdateTs("2010-01-01 00:00:00");
            updateTsMapper.updateByPrimaryKey(updateTs2);
        }
        List<Integer> integers = resumeDeliveryMapper.getUpdateRecruitment(updateTs.getLastUpdateTs());
        List<Integer> integersPRE = resumeDeliveryMapper.getUpdateRecruitmentPRE(updateTs2.getLastUpdateTs());

        Recruitment updateNumber = null;
        if (integers.size() != 0) {
            for (Integer recruitmentID : integers) {
                updateNumber = resumeDeliveryMapper.getUpdateNumber(recruitmentID);
                recruitmentMapper.updateByPeople(updateNumber);
            }
            updateTs.setLastUpdateTs(resumeDeliveryMapper.maxCreateTs());
            updateTsMapper.updateByPrimaryKey(updateTs);
        }


        if (integersPRE.size() != 0) {
            for (Integer recruitmentID : integersPRE) {
                Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentID);
                if (recruitment != null && recruitment.getDate()!=null) {
                    updateNumber = resumeDeliveryMapper.getUpdateNumberPRE(recruitmentID, recruitment.getDate());
                    recruitmentMapper.updateByPeoplePRE(updateNumber);
                }
            }
            updateTs2.setLastUpdateTs(resumeDeliveryMapper.maxCreateTsPRE());
            updateTsMapper.updateByPrimaryKey(updateTs2);
        }
    }


}
