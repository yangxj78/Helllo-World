package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.TempletBooth;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TempletBoothMapper extends MyMapper<TempletBooth> {

    int config(TempletBooth templetBooth);

    @Delete("delete from templet_booth where recruitment_id =#{id}")
    void deleteByRecruitment(Integer id);

    @Update("update templet_booth set templet_id =#{templetId} where recruitment_id =#{recruitmentId}")
    void updateBy(TempletBooth templetBooth);

    @Update("update templet_booth set templet_id =#{templetId} where recruitment_id =#{recruitmentId} and operation = 0")
    void updateByRecruitment(TempletBooth templetBooth);

    List<Integer> list(@Param("recruitmentId") Integer recruitmentId, @Param("templetId") Integer templetId);

    @Select("select * from templet_booth where recruitment_id =#{recruitmentId} and booth_id =#{boothId}")
    TempletBooth getBy(@Param("recruitmentId") Integer recruimentId, @Param("boothId") Integer boothId);

    List<TempletBooth> listTemplet8(Integer recruitmentId);
}