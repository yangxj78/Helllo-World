package com.hengtiansoft.servlet.admin.reportCenter.controller;


import com.hengtiansoft.bean.dataModel.EnrollTable;
import com.hengtiansoft.bean.dataModel.ExcelPositionData;
import com.hengtiansoft.bean.dataModel.ExcelUserData;
import com.hengtiansoft.bean.dataModel.RecruitmentSearch;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.admin.common.util.ExcelUtil;
import com.hengtiansoft.servlet.hr.interview.service.InterviewService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;

@RestController
@RequestMapping("/excel")
@Api(value = "excel导出", description = "excel导出相关接口")

public class Excel {
    @Autowired
    RecruitmentService recruitmentService;
    @Autowired
    InterviewService interviewService;
    private static final Log LOG = LogFactory.getLog(Excel.class);


    @RequestMapping(value = "/recruitment/", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @ApiOperation(value = "招聘会统计表")
    public void recruitmentExcel(@RequestParam(required = false) String search, @RequestParam(required = false) String startDate, @RequestParam(required = false) String endDate, @RequestParam(required = false) Integer typeID, @RequestParam(required = false) Integer overDue, HttpServletResponse response) {

        String[] headers = {"招聘会类别", "召开日期", "招聘会名称", "企业数", "职位数", "需求人数", "实际接待人数", "通过人数", "待定人数","预投递人数","预投递岗位数"};
        RecruitmentSearch recruitmentSearch = new RecruitmentSearch();
        if (search != null) {
            recruitmentSearch.setSearch(search);
        }
        if (startDate != null) {
            recruitmentSearch.setStartDate(startDate);
        }
        if (endDate != null) {
            recruitmentSearch.setEndDate(endDate);
        }
        if (typeID != null) {
            recruitmentSearch.setType(typeID);
        }
        if (overDue != null) {
            recruitmentSearch.setOverDue(overDue);
        }
        List list = recruitmentService.getRecruitmentTable(recruitmentSearch);
        HSSFWorkbook hssfWorkbook = ExcelUtil.export(list, headers, 1, null);
        try {
            response.setContentType("application/vnd.ms-job");
            response.setHeader("realName", URLEncoder.encode("招聘会统计表", "UTF-8"));

            response.setHeader("Content-disposition", "attachment;filename=" + new String("招聘会统计表.xls".getBytes("UTF-8"), "ISO8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            hssfWorkbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
            ouputStream.close();

        } catch (Exception e
        ) {
            LOG.error("导出招聘会日志:", e);

        }
    }


    @RequestMapping(value = "/enroll/", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @ApiOperation(value = "招聘会报名表")
    public void enrollExcel(@RequestParam String id, HttpServletResponse response, HttpServletRequest request) throws IOException {
        List<EnrollTable> list = recruitmentService.getEnrollTable(Integer.valueOf(id));
        Recruitment recruitment = recruitmentService.getById(Integer.valueOf(id));
        String[] headers = {"展位号", "参会企业名称", "参展联系人", "联系电话"};
        HSSFWorkbook hssfWorkbook = ExcelUtil.export(list, headers, 1, null);

        try {
            response.setContentType("application/octet-stream");
            response.setHeader("realName", URLEncoder.encode(recruitment.getDate() + recruitment.getName() + "企业报名表", "UTF-8"));
            response.setHeader("Content-disposition", "attachment;filename=" + new String(recruitment.getDate().getBytes("UTF-8"), "ISO8859-1") + recruitment.getName() + new String(("招聘会报名表.xls".getBytes("UTF-8")), "ISO8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            hssfWorkbook.write(ouputStream);
        } catch (Exception e
        ) {
            LOG.error("导出招聘会报名表:", e);

        }
    }


    @RequestMapping(value = "/Position/", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @ApiOperation(value = "招聘会岗位统计表")
    public void getExcelPositionData(@RequestParam String id, HttpServletResponse response, HttpServletRequest request) throws IOException {
        List<ExcelPositionData> list = recruitmentService.getExcelPositionData(Integer.valueOf(id));
        Recruitment recruitment = recruitmentService.getById(Integer.valueOf(id));
        String[] headers = {"展位号", "参会企业名称", "岗位名称", "岗位描述", "学历", "招聘人数", "应聘人数", "通过人数", "待定人数", "招聘会名称"};
        HSSFWorkbook hssfWorkbook = ExcelUtil.export(list, headers, 1, null);

        try {
            response.setContentType("application/vnd.ms-job");
            response.setHeader("realName", URLEncoder.encode(recruitment.getDate() + recruitment.getName() + "岗位统计表", "UTF-8"));
            response.setHeader("Content-disposition", "attachment;filename=" + new String(recruitment.getDate().getBytes("UTF-8"), "ISO8859-1") + recruitment.getName() + new String(("报名表.xls".getBytes("UTF-8")), "ISO8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            hssfWorkbook.write(ouputStream);
        } catch (Exception e
        ) {
            LOG.error("招聘会岗位统计表:", e);

        }
    }


    @RequestMapping(value = "/resum/", method = RequestMethod.GET)
    @ApiImplicitParams({@ApiImplicitParam(name = "Authorization", required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    @ApiOperation(value = "招聘会求职者统计表")
    public void getExcelUserData(@RequestParam String id, HttpServletResponse response, HttpServletRequest request) throws IOException {
        List<ExcelUserData> list = recruitmentService.getExcelUserData(Integer.valueOf(id));
        for(ExcelUserData ex:list){
            interviewService.setData(ex);
        }
        Recruitment recruitment = recruitmentService.getById(Integer.valueOf(id));
        String[] headers = {"简历Id","应聘者姓名", "手机", "身份证号码", "最近毕业院校","毕业时间","专业","最高学历", "工作年限","应聘单位", "应聘职位", "面试结果","简历名称",  "信息来源","注册时间","扫码入场时间"};
        HSSFWorkbook hssfWorkbook = ExcelUtil.export(list, headers, 1, null);
        try {
            response.setContentType("application/vnd.ms-job");
            response.setHeader("realName", URLEncoder.encode(recruitment.getDate() + recruitment.getName() + "求职者统计表", "UTF-8"));
            response.setHeader("Content-disposition", "attachment;filename=" + new String(recruitment.getDate().getBytes("UTF-8"), "ISO8859-1") + recruitment.getName() + new String(("求职者报名表.xls".getBytes("UTF-8")), "ISO8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            hssfWorkbook.write(ouputStream);
        } catch (Exception e
        ) {
            LOG.error("招聘会求职者统计表:", e);

        }
    }
}
