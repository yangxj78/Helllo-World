package com.hengtiansoft.servlet.applicant.recruitment.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.StatisticsDto;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.recruitment.service.RecruitmentReportService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@Api(value = "大屏报表数据接口", description = "restful风格")
@RequestMapping(value = "/admin/screenReport")
@RestController
public class RecruitmentReportController {

    @Autowired
    private RecruitmentReportService recruitmentReportService;

    @Autowired
    private RecruitmentService recruitmentService;


    @RequestMapping(value = "/getStatistics", method = RequestMethod.GET)
    @ApiOperation(value = "返回综合数据")
    public ResultDto getRecruitmentStatistics() {
        Recruitment current = recruitmentService.getCurrentRecruitment();
        if (current == null) {
            return ResultDtoFactory.toNack("无正在进行的招聘会");
        }

        Map<String, Object> resultMap = new LinkedHashMap<>();

        StatisticsDto totalCount = recruitmentReportService.getTotalCount(current);
        StatisticsDto ageCount = recruitmentReportService.getAgeCount(current);
        StatisticsDto jobsTop5 = recruitmentReportService.getJobTop5(current);
        StatisticsDto educationCount = recruitmentReportService.getEducationCount(current);
        StatisticsDto entranceTime = recruitmentReportService.getEntranceTime(current);

        resultMap.put("totalCount", totalCount);
        resultMap.put("ageCount", ageCount);
        resultMap.put("jobsTop5", jobsTop5);
        resultMap.put("educationCount", educationCount);
        resultMap.put("entranceTime", entranceTime);
        resultMap.put("style", current.getStyle());

        return ResultDtoFactory.toAck("", resultMap);
    }

    @RequestMapping(value = "/getSummary", method = RequestMethod.GET)
    @ApiOperation(value = "返回招聘会标题及公司招聘信息滚动列表")
    public ResultDto getRecruitmentSummary() {
        Recruitment current = recruitmentService.getCurrentRecruitment();
        if (current == null) {
            return ResultDtoFactory.toNack("无正在进行的招聘会");
        }
        return ResultDtoFactory.toAck("", recruitmentReportService.getSummary(current));
    }

}
