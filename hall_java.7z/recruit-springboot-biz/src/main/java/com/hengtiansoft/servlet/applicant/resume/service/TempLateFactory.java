package com.hengtiansoft.servlet.applicant.resume.service;

import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.servlet.applicant.resume.template.boss.BossDefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.dajiewang.DaJieWangDefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.job.Job51defaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.job.Job51MailTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.job.Job51TemplateOne;
import com.hengtiansoft.servlet.applicant.resume.template.job.Job51TemplateTwo;
import com.hengtiansoft.servlet.applicant.resume.template.job.Job51TemplateThree;
import com.hengtiansoft.servlet.applicant.resume.template.lagou.LaGouDefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.lagou.LaGouMailTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.lagou.LaGouTemplateOne;
import com.hengtiansoft.servlet.applicant.resume.template.liepin.*;
import com.hengtiansoft.servlet.applicant.resume.template.tc58.TC58DefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.tc58.TC58MailTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.zhilian.ZhiLianDefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.zhilian.ZhiLianMailTemplate;
import com.hengtiansoft.servlet.applicant.resume.template.zhilian.ZhiLianTemplateOne;
import com.hengtiansoft.servlet.applicant.resume.template.zhilian.ZhiLianTemplateTwo;
import microsoft.exchange.webservices.data.property.complex.MessageBody;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public final class TempLateFactory {
    private TempLateFactory(){};
    private static final String LIEPIN_CONTENT = "猎聘网";
    private static final String ZHILIAN_CONTENT = "Zhaopin.com";
    private static final String JOB51_CONTENT = "前程无忧";
    private static final String LAGOU_CONTENT = "拉勾";
    private static final String TC58_CONTENT = "58.com";
    private static final CharSequence JOB51_CONTENT_EN = "51job.com";
    private static final String JOB51_LOWER="51job";
    private static final String JOB51_UP="51Job";
    private static final String LIUCHENGZHUANGTAI="流程状态";

    private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(TempLateFactory.class);
    private static Map<String, ResumeBuilder> parser = new HashMap<>();
    static {

        parser.put("Job51MailTemplate", new Job51MailTemplate());
        parser.put("Job51defaultTemplate", new Job51defaultTemplate());
        parser.put("Job51TemplateOne", new Job51TemplateOne());
        parser.put("Job51TemplateTwo", new Job51TemplateTwo());
        parser.put("Job51TemplateThree", new Job51TemplateThree());
        parser.put("ZhiLianMailTemplate", new ZhiLianMailTemplate());
        parser.put("ZhiLianDefaultTemplate", new ZhiLianDefaultTemplate());
        parser.put("ZhiLianTemplateOne", new ZhiLianTemplateOne());
        parser.put("ZhiLianTemplateTwo", new ZhiLianTemplateTwo());
        parser.put("BossDefaultTemplate", new BossDefaultTemplate());

        parser.put("LiePinMailTemplate", new LiePinMailTemplate());
        parser.put("LiePinDefaultTemplate", new LiePinDefaultTemplate());
        parser.put("LiePinTemplateOne", new LiePinTemplateOne());
        parser.put("LiePinTemplateTwo", new LiePinTemplateTwo());
        parser.put("LiePinTemplateThree", new LiePinTemplateThree());
        parser.put("LaGouMailTemplate", new LaGouMailTemplate());
        parser.put("LaGouDefaultTemplate", new LaGouDefaultTemplate());
        parser.put("LaGouTemplateOne", new LaGouTemplateOne());
        parser.put("TC58MailTemplate", new TC58MailTemplate());
        parser.put("TC58DefaultTemplate", new TC58DefaultTemplate());
        parser.put("DaJieWangDefaultTemplate", new DaJieWangDefaultTemplate());

    }

    public static ResumeBuilder createBuilder(ConentType conentType) throws Exception {
        String content = conentType.getContent();
        String fileType = conentType.getType();
        String builderType = null;
        if ("mht".equals(fileType)) {
            if (content.contains(JOB51_UP) || content.contains(LIUCHENGZHUANGTAI) || content.contains(JOB51_LOWER)) {
                if (content.contains("电　话：")) {
                    builderType = "Job51TemplateTwo";
                } else {
                    builderType = "Job51defaultTemplate";
                }
            }
            if (content.contains("58同城")) {
                builderType = "TC58DefaultTemplate";
            }
        }
        if ("htm".equals(fileType)) {
            if (content.contains("智联")) {
                builderType = "ZhiLianDefaultTemplate";
            }
            if (content.contains("zhaopin.cn")) {
                builderType = "ZhiLianTemplateTwo";
            }
            if (content.contains("lietou") || content.contains("liepin")) {
                if (content.contains("http://image0.lietou-static.com/img/569f308d45ceea11aa29f7a104a.jpg")) {
                    builderType = "LiePinTemplateTwo";
                } else if (content.contains("https://image0.lietou-static.com/img/569f31cb45ce9a6555837d7704a.png")) {
                    builderType = "LiePinTemplateThree";
                } else {
                    builderType = "LiePinDefaultTemplate";
                }
            }
            if (content.contains("hzrc") || content.contains("杭州人才")) {
                builderType = "LiePinDefaultTemplate";
            }
        }
        if ("docx".equals(fileType)) {
            if (content.contains(JOB51_UP) || content.contains(LIUCHENGZHUANGTAI) || content.contains(JOB51_LOWER)) {
                builderType = "Job51TemplateOne";
            }
            if (content.contains("lietou") || content.contains("liepin")) {
                builderType = "LiePinTemplateOne";
            }
            if (content.contains("智联") || content.contains("zhaopin.cn")) {
                builderType = "ZhiLianTemplateOne";
            }
            if (content.startsWith("\n\n")&&content.contains("\n\n\n\n个人优势")){
                builderType = "BossDefaultTemplate";
            }
        }
        if ("pdf".equals(fileType)) {
            if (content.contains("拉勾")) {
                builderType = "LaGouTemplateOne";
            }
            if (content.contains(JOB51_UP) || content.contains(LIUCHENGZHUANGTAI) || content.contains(JOB51_LOWER)) {
                builderType = "Job51defaultTemplate";
            }
        }
        if ("wps".equals(fileType)) {
            if (content.contains("拉勾")) {
                builderType = "LaGouDefaultTemplate";
            }
        }
        if ("html".equals(fileType)) {
            if (content.contains(JOB51_UP) || content.contains(LIUCHENGZHUANGTAI) || content.contains(JOB51_LOWER)) {
                builderType = "Job51TemplateThree";
            }
        }

        if ("xml".equals(fileType)) {
            if (content.contains("大街网")) {
                builderType = "DaJieWangDefaultTemplate";
            }
        }
        return getBuilder(builderType);
    }

    public static ResumeBuilder createBuilder(MailContent content) {
        String fromAddr = content.getFromAddress();
        String subject = content.getSubject();
        String builderType = getMailType(fromAddr);
        if ("".equals(builderType)) {
            builderType = getMailType(subject);
        }

        return getBuilder(builderType);

    }

    // 得到邮件内容
    public static String messageBody2String(MailContent content) {
        try {
            if (content.getMessageBody() != null) {
                return MessageBody.getStringFromMessageBody(content.getMessageBody());
            }
        } catch (Exception e) {
            LOGGER.error("获取邮件内容失败",e);
        }
        return (String) content.getContent();
    }

    public static ResumeBuilder getBuilder(String type) {
        if (!StringUtils.isEmpty(type)) {
            return parser.get(type);
        }
        return null;
    }

    public static String getMailType(String content) {

        String builderType = "";
        if (content.contains(LIEPIN_CONTENT)) {
            builderType = "LiePinMailTemplate";
        }
        if (content.contains(JOB51_CONTENT) || content.contains(JOB51_CONTENT_EN)) {
            builderType = "Job51MailTemplate";
        }
        if (content.contains(LAGOU_CONTENT)) {
            builderType = "LaGouMailTemplate";
        }
        if (content.contains(ZHILIAN_CONTENT) || content.contains("b1.service@zhaopinmail.com")) {
            builderType = "ZhiLianMailTemplate";
        }
        if (content.contains(TC58_CONTENT)) {
            builderType = "TC58MailTemplate";
        }
        return builderType;
    }
}
