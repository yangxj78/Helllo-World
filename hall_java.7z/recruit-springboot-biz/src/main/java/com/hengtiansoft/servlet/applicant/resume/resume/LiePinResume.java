package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.until.ChineseName;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class LiePinResume extends BaseResume {

    private static final int BEGIN_OFF_SET_FOUR = 4;

    @Override
    public void buildContactInfo(String content, HrResume r) {
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String post = strSubstring(content, "期望职位：", "期望地点：");
        String expectCity = strSubstring(content, "期望地点：", "期望年薪：");
        String school = null;
        String major = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        String degree = strSubstring(content, "教育程度：", "工作年限：");
        if (content.contains("教育经历")) {
            String eduExperience = strSubstring(content, "教育经历", "语言能力").replaceAll("(&nbsp;)+", "");
            String eduDate = getEduDate(eduExperience);
            if (eduDate.contains("至今")) {
                graduateDate = "暂未毕业";
            }
            school = eduExperience.substring(0, eduExperience.indexOf(eduDate));
            major = strSubstring(eduExperience, eduDate, degree);
        }
        content = content.replaceAll("&nbsp;", "");
        String annualIncome = strSubstring(content, "目前年薪：", "职业发展意向");
        String expectSalary = strSubstring(content, "期望年薪：", "工作经历");
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setGraduateDate(graduateDate);
        r.setAnnualIncome(annualIncome);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        List<UserWorkExperience> userWorkExperiences = new ArrayList<>();
        List<UserEducationExperience>userEducationExperiences = new ArrayList<>();
        String[] arr = content.split("<span style='font-size:15.0pt;");
        arr = content
                .split("<span style='font-size:15.0pt;\r\n  font-family:宋体;" +
                        "mso-ascii-font-family:Courier;mso-hansi-font-family:Courier;\r\n" +
                        "  mso-bidi-font-family:Courier;color:#404040'>");
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                workExperience = filterExperience(str).replaceFirst("工作经历(&nbsp;)*", "");
            }
            if (str.startsWith("项目经历")) {
                projectExperience = filterExperience(str).replaceFirst("项目经历(&nbsp;)*", "");
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        //解析简历名称
        //名字可能出现的内容
        String name;
        if (content.contains("<v:imagedata src=\"https://image0.lietou-static.com/img/5697690545cec841a3d9289b04a.png\"/>")) {
            String nameContent = StringUtils.substringAfter(content, "<v:imagedata src=\"https://image0.lietou-static.com/img/5697690545cec841a3d9289b04a.png\"/>").substring(0, 600);
            name = ChineseName.getName(filtercontent(nameContent));
        } else {
            name = ChineseName.getName(filtercontent(content).substring(0,300));
        }


        content = filtercontent(content);
        String updateDate = getUpdateDate(content);
        String year = strSubstring(content, "工作年限：", "年");
        String number = getNumber(content);
        int age = getRealAge((strSubstring(content, "年龄：", "婚姻")));
        SexEnum sex = SexEnum.MAN;
        if (content.substring(0, 100).contains("女")) {
            sex = SexEnum.WOMAN;
        }
        String city = strSubstring(content, "所在地：", "国籍");

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.LIEPINUPLOAD);
    }

    public String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<style>.*?</style>", "").replaceAll("<xml>.*?</xml>", "")
                .replaceAll("<.*?>", "").replaceAll("　", "");
    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);
        String post = null;
        String city = null;
        String subject = mailContent.getSubject();
        String name = fieldTrim(strSubstring(subject, "】", "_来自猎聘网的候选人"));
        String postAndCity = strSubstring(content, "您在猎聘网招聘的职位：", "收到一份");// 精英人才简历"
        if (postAndCity != null) {
            String[] postAndCityArray = postAndCity.split("\\|");
            post = fieldTrim(postAndCityArray[0]);
            city = fieldTrim(postAndCityArray[1]);
        }

        String updateDate = getUpdateDate(content);
        String year = strSubstring(content, "工作年限：", "年");
        String number = getNumber(content);
        int age = getRealAge((strSubstring(content, "年龄：", "教育程度")));
        SexEnum sex = SexEnum.MAN;
        if (content.contains("性别：")
                && "女".equals(content.substring(content.indexOf("性别："), content.indexOf("性别：") + BEGIN_OFF_SET_FOUR)
                        .replace("性别：", ""))) {
            sex = SexEnum.WOMAN;
        }

        r.setName(name);
        r.setPost(post);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.LIEPINCOLLECT);
    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);
        String email = getEmailAddress(content);
        String phone = getPhone(content);
        r.setEmail(email);
        r.setPhone(phone);
    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        content = filtercontent(content);
        String expectCity = strSubstring(content, "期望工作地点：", "工作经历").replace("&nbsp;", "");
        String school = null;
        String major = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        String degree = strSubstring(content, "教育程度：", "职业状态：");
        if (content.contains("教育经历")) {
            String eduExperience = strSubstring(content, "教育经历", "&nbsp;");
            String eduDate = getEduDate(eduExperience);
            if (eduDate.contains("至今")) {
                graduateDate = "暂未毕业";
            } else if (!"".equals(eduDate)) {
                graduateDate = eduDate.substring(eduDate.indexOf('-')).replace("-", "");
            }
            school = strSubstring(eduExperience, eduDate, "-专业：");
            major = strSubstring(eduExperience, "-专业：", "-学历：");
        }
        String annualIncome = strSubstring(content, "目前年薪：", "求职意向").replace("&nbsp;", "");
        String expectSalary = strSubstring(content, "期望年薪：", "期望从事行业：");
        r.setEngLevel(englishLevel);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setGraduateDate(graduateDate);
        r.setAnnualIncome(annualIncome);
        r.setExpectSalary(expectSalary);
    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
        String content = messageBody2String(mailContent);
        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String workExStr = content.substring(content.indexOf("工作经历"), content.lastIndexOf("项目经历"));
        workExperience = filterExperience(workExStr).replaceFirst("工作经历(&nbsp;)*", "").replaceAll("&nbsp;", "\n");
        String projectExStr = content.substring(content.indexOf("项目经历"), content.lastIndexOf("教育经历"));
        projectExperience = filterExperience(projectExStr).replaceFirst("项目经历(&nbsp;)*", "").replaceAll("&nbsp;", "\n");
        String eduExStr = content.substring(content.indexOf("教育经历"), content.lastIndexOf("自我评价"));
        education = filterExperience(eduExStr).replaceFirst("教育经历(&nbsp;)*", "").replaceAll("&nbsp;", "\n");
        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

}
