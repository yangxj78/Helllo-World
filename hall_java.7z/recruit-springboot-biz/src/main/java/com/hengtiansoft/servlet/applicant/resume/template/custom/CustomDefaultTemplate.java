package com.hengtiansoft.servlet.applicant.resume.template.custom;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.common.Term;
import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.converters.KeywordMatcher;
import com.hengtiansoft.common.converters.TagMatcher;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.CustomResume;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomDefaultTemplate extends CustomResume {

    private KeywordMatcher keywordMatcher = new KeywordMatcher();

    private static String[] eduDegree = {"本科", "专科", "硕士", "博士", "小学", "初中", "高中"};

    private static List<String> dateregexs;
    private static List<String> subdateregexs;

    static {
        dateregexs = new ArrayList<>();
        subdateregexs = new ArrayList<>();
        //匹配年月日模式的日期的正则表达式
        dateregexs.add("(\\d{4}\\D\\d{1,2}\\D\\d{1,2}([\\s\\S]{1,5})(\\d{4}\\D\\d{1,2}\\D\\d{1,2}日{0,1}|至今))");
        subdateregexs.add("((\\d{4}\\D\\d{1,2}\\D\\d{1,2})|至今)");
        //匹配年月模式日期的正则表达式
        dateregexs.add("(\\d{4}\\D\\d{1,2}([\\s\\S]{1,5})(\\d{4}\\D\\d{1,2}月{0,1}|至今))");
        subdateregexs.add("((\\d{4}\\D\\d{1,2})|至今)");
        //匹配只有年的日期正则表达式
        dateregexs.add("(\\d{4}([\\s\\S]{1,5})(\\d{4}年{0,1}|至今))");
        subdateregexs.add("(\\d{4}|至今)");
    }

    private List<UserWorkExperience> workExperienceConvert(String str) {
        List<UserWorkExperience> result = new ArrayList<>();

        //工作经历分段
        String[] tempArray = str.split("\\d{4}\\D\\d{1,2}([\\s\\S]{1,5})(\\d{4}\\D\\d{1,2}月?|至今)");
//        String[] tempArray = str.split("\\n\\n");
        List<String> workExperiences = new ArrayList<>();

        //去除空的工作经历
        for (String string : tempArray) {
            string = string.replaceFirst(" *", "");
            if (StringUtils.isNotBlank(string)) {
                workExperiences.add(string);
            }
        }

        //匹配工作经历里经历的开始、结束时间
        List<String> dates = parseDate(str);

        if (dates.size() < workExperiences.size()) {
            workExperiences.remove(0);
        }

        for (int i = 0; i < (workExperiences.size()>dates.size()?dates.size():workExperiences.size()); i++) {
            UserWorkExperience experienceTemp = new UserWorkExperience();
            String workExperience = workExperiences.get(i);

            if (dates.get(i) != null) {
                List<String> startStopDate = parseStartStopDate(dates.get(i));
                experienceTemp.setStartTs(startStopDate.get(0));
                experienceTemp.setEndTs(startStopDate.get(1));
            }

            //获取公司名
            String company = findCompanyName(workExperience);

            //填写工作经历的描述字段
            if (workExperience.contains("工作描述")) {
                experienceTemp.setDescription(StringUtils.substringAfter(workExperience, "工作描述").replaceAll("\\s", ""));
            } else {
                experienceTemp.setDescription(workExperience);
            }

            experienceTemp.setJob(new TagMatcher().getTag(workExperience));
            experienceTemp.setCompany(company);
            result.add(experienceTemp);
        }

        return result;
    }



    private List<String> parseDate(String str) {
        List<String> dates = new ArrayList<>();

        for (String regex : dateregexs) {
            Pattern pattern = Pattern.compile(regex);
            Matcher matcher = pattern.matcher(str);
            while (matcher.find()) {
                dates.add(matcher.group());
            }
            if (!CollectionUtils.isEmpty(dates)) {
                break;
            }
        }

        return dates;
    }

    private List<String> parseStartStopDate(String str) {
        List<String> result = new ArrayList<>();

        String startDate = null;
        String stopDate = null;

        if (str.contains("至今")) {
            stopDate = "至今";
        }

        //解析字符串中的年月
        List<String> temp = new ArrayList<>();
        String regex = "\\d+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            temp.add(matcher.group());
        }

        if (temp.size() == 1) {
            startDate = temp.get(0);
        } else if (temp.size() == 2) {
            if (temp.get(1).length() == 4) {
                startDate = temp.get(0);
                stopDate = temp.get(1);
            } else {
                startDate = temp.get(0) + "-" + temp.get(1);
            }
        } else if (temp.size() == 4) {
            startDate = temp.get(0) + "-" + temp.get(1);
            stopDate = temp.get(2) + "-" + temp.get(3);
        } else if (temp.size() == 3 || temp.size() == 6) {
            startDate = temp.get(0) + "-" + temp.get(1);
            if (StringUtils.isEmpty(stopDate)) {
                stopDate = temp.get(3) + "-" + temp.get(4);
            }
        }

        result.add(startDate);
        result.add(stopDate);
        return result;
    }

    public void buildWorkList(ConentType conentType, HrResume resume) {
        if (StringUtils.isNotEmpty(resume.getWorkExpirence())) {
            resume.setUserWorkExperienceList(workExperienceConvert(resume.getWorkExpirence()));
        }
    }

    //创建教育经历列表
    public void buildEduList(ConentType contentType, HrResume resume) {
        List<UserEducationExperience> userEducationExperiences = new ArrayList<>();
        if (resume.getEducation() != null) {
            userEducationExperiences = decomposeEducation(resume.getEducation(), ifLocalZJ(resume.getCity()));
            checkEducationList(resume, userEducationExperiences);
            checkResumeEdu(resume, userEducationExperiences);
            resume.setUserEducationExperienceList(userEducationExperiences);
        } else {
            userEducationExperiences = searchSchoolAndMajor(contentType.getContent(), ifLocalZJ(resume.getCity()));
            checkEducationList(resume, userEducationExperiences);
            checkResumeEdu(resume, userEducationExperiences);
            resume.setUserEducationExperienceList(userEducationExperiences);
        }
    }

    //正规标准格式教育经历的分割
    private List<UserEducationExperience> decomposeEducation(String eductionExperience, int local) {
        List<UserEducationExperience> userEducationExperiences = new ArrayList<>();
        List<String> educationList = new ArrayList<String>();
        educationList = cutEduExperience(eductionExperience);

        for (String experience : educationList) {
            UserEducationExperience userEducationExperience = analysisEducationExperience(experience);
            userEducationExperience.setLocalZj(local);
            userEducationExperiences.add(userEducationExperience);
        }
        //如果标准格式解析没有效果，进行原文解析
        if (userEducationExperiences.size() == 0) {
            userEducationExperiences = searchSchoolAndMajor(eductionExperience, local);
        }
        //当学校在时间前面时，需要修正学校信息
        updateSchool(eductionExperience, userEducationExperiences);

        return userEducationExperiences;
    }

    private void updateSchool(String eductionExperience, List<UserEducationExperience> userEducationExperiences) {
        if(userEducationExperiences.size() == 0){
            return;
        }
        List<String> schools = new ArrayList<>();
        List<Term> terms = HanLP.newSegment().enableCustomDictionaryForcing(true).seg(eductionExperience);
        for (Term term : terms) {
            if (term.nature.toString().equals("ntu")) {
                schools.add(term.word);
            }
        }
        if (schools.size() == userEducationExperiences.size()) {
            for (int i = 0; i < userEducationExperiences.size(); i++)
                userEducationExperiences.get(i).setSchool(schools.get(i));
        }
    }

    //正规标准格式教育经历的分析
    private UserEducationExperience analysisEducationExperience(String educationExperience) {
        UserEducationExperience userEducationExperience = new UserEducationExperience();
        String school = "";
        String educational = "";
        String major = "";
        String startTs = "";
        String endTs = "";
        Map<String, String> eduDate = cutDate(educationExperience);
        startTs = eduDate.get("startTs");
        endTs = eduDate.get("endTs");
        startTs = changeDateFormat(startTs);
        endTs = changeDateFormat(endTs);
        userEducationExperience.setStartTs(startTs);
        userEducationExperience.setEndTs(endTs);

        school = findSchoolName(educationExperience);
        major = findMajorName(educationExperience);
        for (String degree : eduDegree) {
            if (educationExperience.contains(degree)) {
                educational = degree;
                break;

            }
        }
        int degree = EducationalEnum.verifyEducation(educational);
        userEducationExperience.setSchool(school);
        userEducationExperience.setMajor(major);
        userEducationExperience.setEducational(degree);
        return userEducationExperience;
    }

    //正规格式匹配失败，全文搜索
    public List<UserEducationExperience> searchSchoolAndMajor(String content, int local) {
        List<UserEducationExperience> userEducationExperiences = new ArrayList<>();
        Map<String, Integer> schools = new HashMap<String, Integer>();
        UserEducationExperience userEducationExperience;
        String[] str = content.split("\r\n|\r|\n|\b|&nbsp;|\\s+|\\(|（|\\)|）| |\\|");
        List<String> list = new ArrayList<String>();
        Arrays.asList(str).forEach(e -> {
            if (!StringUtils.isBlank(e)) {
                list.add(e);
            }
        });
        Matcher matcher;
        Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]+(大学|学院|学校)");
        int schoolIndex = 0;
        out:
        for (String s : list) {
            if (s.endsWith("大学") || s.endsWith("学院") || s.endsWith("学校")) {
                matcher = reg.matcher(s);
                while (matcher.find()) {
                    schools.put(matcher.group(), schoolIndex);
                    break out;
                }
            }
            schoolIndex++;
        }
        //遍历map中的值
        for (Map.Entry<String, Integer> school : schools.entrySet()) {
            int schoolPosition = school.getValue();
            userEducationExperience = new UserEducationExperience();
            userEducationExperience.setSchool(school.getKey());
            int datePosition = -1, degreePosition = -1;
            for (int i = schoolPosition - 3; i < schoolPosition + 3; i++) {
                if (i < 0) {
                    continue;
                }
                if (datePosition > 0 && degreePosition > 0)
                    break;
                //在搜索到的学校字段周围寻找时间
                if (datePosition < 0) {
                    reg = Pattern.compile("\\d{4}(\\D\\d{1,2}(\\D\\d{1,2}){0,1}){0,1}([\\s\\S]{1,5})(\\d{4}(\\D\\d{1,2}(\\D\\d{1,2}){0,1}){0,1}|至今)");
                    matcher = reg.matcher(list.get(i));
                    if (matcher.find()) {
                        Map<String, String> date = cutDate(list.get(i));
                        datePosition = i;
                        userEducationExperience.setStartTs(changeDateFormat(date.get("startTs")));
                        userEducationExperience.setEndTs(changeDateFormat(date.get("endTs")));
                    }
                }
                //在搜索到的学校字段周围寻找学历
                if (degreePosition < 0) {
                    for (String degree : eduDegree) {
                        if (list.get(i).contains(degree)) {
                            degreePosition = i;
                            userEducationExperience.setEducational(EducationalEnum.verifyEducation(list.get(i)));
                        }
                    }
                }
            }
            //猜测专业位置
            int majarPosition = guessMajarPosition(schoolPosition, degreePosition, datePosition);
            if (majarPosition > 0)
                userEducationExperience.setMajor(list.get(majarPosition));
            userEducationExperience.setLocalZj(local);
            userEducationExperiences.add(userEducationExperience);
        }
        return userEducationExperiences;
    }

    private String trim(String str) {
        if (str == null)
            return null;
        char[] val = str.toCharArray();
        int st = 0;
        int len = val.length;
        //半角空格
        while ((st < len) && (val[st] == ' ')) {
            st++;
        }
        while ((st < len) && (val[len - 1] == ' ')) {
            len--;
        }
        //全角空格
        while ((st < len) && (val[st] == '　')) {
            st++;
        }
        while ((st < len) && (val[len - 1] == '　')) {
            len--;
        }
        return ((st > 0) || (len < val.length)) ? str.substring(st, len) : str;
    }

    private String changeDateFormat(String ts) {
        if (StringUtils.isEmpty(ts)) {
            return null;
        }
        if (ts.contains("/")) {
            return ts.replace("/", "-");
        }
        if (ts.contains(".")) {
            return ts.replace(".", "-");
        }
        return ts;
    }

    // 获得时间
    private Map<String, String> cutDate(String context) {
        Map<String, String> dates = new HashMap<>();
        String[] keys = {"startTs", "endTs", "startIndex", "endIndex"};
        for (int i = 0; i < 3; ++i) {
            Pattern pattern = Pattern.compile(dateregexs.get(i));
            Matcher matcher = pattern.matcher(context);
            if (matcher.find()) {
                pattern = Pattern.compile(subdateregexs.get(i));
                matcher = pattern.matcher(context);
                int j = 0;
                while (matcher.find()) {
                    String date = matcher.group();
                    if (j >=2) break;
                    if (i == 2) {
                        if (!date.contains("至今")) {
                            date += "-01";
                        }
                    }
                    dates.put(keys[j++], date);
                }
                dates.put(keys[2], String.valueOf(context.indexOf(dates.get(keys[0]))));
                dates.put(keys[3], String.valueOf(context.indexOf(dates.get(keys[1])) + dates.get(keys[1]).length()));
                return dates;
            }
        }
        return dates;
    }

    // 分割教育经验
    public List<String> cutEduExperience(String eduExperience) {
        List<String> edus = new ArrayList<>();
        Pattern eduDateExg = Pattern.compile("\\d{4}[\\/\\.]\\d{1,2}([\\s\\S]{1,5})(\\d{4}[\\/\\.]\\d{1,2}|至今)");
        Matcher matcher = eduDateExg.matcher(eduExperience);
        int indexFirst = 0, indexSecend = 0;
        if (matcher.find()) {
            indexFirst = matcher.start();
            while (matcher.find()) {
                indexSecend = matcher.start();
                if (indexFirst < indexSecend)
                    edus.add(eduExperience.substring(indexFirst, indexSecend));
                indexFirst = indexSecend;
            }
            edus.add(eduExperience.substring(indexFirst));
        }

        return edus;
    }

    //猜测专业位置
    private int guessMajarPosition(int schoolPosition, int degreePosition, int datePosition) {
        int majarPosition = -1;
        if (degreePosition < 0 && datePosition < 0) {
            majarPosition = schoolPosition + 1;
            return majarPosition;
        } else if (degreePosition < 0 && datePosition >= 0) {
            return schoolPosition + 1;
        } else if (degreePosition >= 0 && datePosition < 0) {
            if (Math.abs(schoolPosition - degreePosition) > 1)
                return schoolPosition < degreePosition ? schoolPosition + 1 : degreePosition + 1;
            else
                return schoolPosition > degreePosition ? schoolPosition + 1 : degreePosition + 1;
        } else {
            int[] array = {schoolPosition, degreePosition, datePosition};
            Arrays.sort(array);
            int a1 = array[1] - array[0];
            int a2 = array[2] - array[1];
            if (a1 == a2) {
                if (datePosition == array[0])
                    return array[2] + 1;
                if (datePosition == array[2])
                    return array[0] - 1;
                if (datePosition == array[1]) {
                    if (schoolPosition > degreePosition)
                        return schoolPosition + 1;
                    else {
                        return degreePosition + 1;
                    }
                }
            } else if (a1 < a2) {
                return array[1] + 1;
            } else {
                return array[1] - 1;
            }
        }
        return -1;
    }

    //填补Resume中缺失和教育有关的属性
    private void checkResumeEdu(HrResume resume, List<UserEducationExperience> userEducationExperiences) {
        if (userEducationExperiences.size() == 0)
            return;
        UserEducationExperience userEducationExperience = userEducationExperiences.get(0);
        if (StringUtils.isEmpty(resume.getDegree()) && userEducationExperience.getEducational() != null) {
            resume.setDegree(EducationalEnum.getEduDesc(userEducationExperience.getEducational()));
        }
        if (StringUtils.isEmpty(resume.getMajor()) && !StringUtils.isEmpty(userEducationExperience.getMajor())) {
            resume.setMajor(userEducationExperience.getMajor());
        }
        if (StringUtils.isEmpty(resume.getSchool()) && !StringUtils.isEmpty(userEducationExperience.getSchool())) {
            resume.setSchool(userEducationExperience.getSchool());
        }
        if (StringUtils.isEmpty(resume.getGraduateDate()) && !StringUtils.isEmpty(userEducationExperience.getEndTs())) {
            resume.setGraduateDate(userEducationExperience.getEndTs());
        }
        if (StringUtils.isEmpty(resume.getEducation())) {
            String educationExperience = "";
            if (!StringUtils.isEmpty(userEducationExperience.getStartTs()))
                educationExperience = educationExperience + " 开始时间： " + userEducationExperience.getStartTs();
            if (!StringUtils.isEmpty(userEducationExperience.getEndTs()))
                educationExperience = educationExperience + " 结束时间： " + userEducationExperience.getEndTs();
            if (!StringUtils.isEmpty(userEducationExperience.getSchool()))
                educationExperience = educationExperience + " 学校： " + userEducationExperience.getSchool();
            if (!StringUtils.isEmpty(userEducationExperience.getMajor()))
                educationExperience = educationExperience + " 专业： " + userEducationExperience.getMajor();
            if (userEducationExperience.getEducational() != null)
                educationExperience = educationExperience + " 学历： " + EducationalEnum.getEduDesc(userEducationExperience.getEducational());
            resume.setEducation(educationExperience);
        }
    }

    //填补eduList中缺失和教育有关的属性
    private void checkEducationList(HrResume resume, List<UserEducationExperience> userEducationExperiences) {
        if (userEducationExperiences.size() == 0)
            return;
        for (UserEducationExperience userEducationExperience : userEducationExperiences) {
            if (userEducationExperience.getEducational() == null && !StringUtils.isEmpty(resume.getDegree())) {
                userEducationExperience.setEducational(EducationalEnum.verifyEducation(resume.getDegree()));
            }
            if (StringUtils.isEmpty(userEducationExperience.getMajor()) && !StringUtils.isEmpty(resume.getMajor())) {
                userEducationExperience.setMajor(resume.getMajor());
            }
            if (StringUtils.isEmpty(userEducationExperience.getSchool()) && !StringUtils.isEmpty(resume.getSchool())) {
                userEducationExperience.setSchool(resume.getSchool());
            }
            if (StringUtils.isEmpty(userEducationExperience.getEndTs()) && !StringUtils.isEmpty(resume.getGraduateDate())) {
                userEducationExperience.setEndTs(resume.getGraduateDate());
            }
        }
    }

    public void buildProjectList(ConentType conentType, HrResume resume) {
        if (StringUtils.isNotEmpty(resume.getProjectExperience())) {
            resume.setProjectExperienceList(projectExperienceConvert(resume.getProjectExperience()));
        }
    }

    private List<UserProjectExperience> projectExperienceConvert(String str) {
        List<UserProjectExperience> result = new ArrayList<>();

        //工作经历分段
        String[] tempArray = str.split("\\d{4}\\D\\d{1,2}([\\s\\S]{1,5})(\\d{4}\\D\\d{1,2}月?|至今)");

        List<String> projectExperiences = new ArrayList<>();

        //去除空的工作经历
        for (String string : tempArray) {
            string = string.replaceFirst(" *", "");
            if (StringUtils.isNotBlank(string)) {
                projectExperiences.add(string);
            }
        }

        List<String> dates = parseDate(str);

        for (int i = 0; i < (projectExperiences.size()>dates.size()?dates.size():projectExperiences.size()); i++) {
            UserProjectExperience experienceTemp = new UserProjectExperience();
            String projectExperience = projectExperiences.get(i);

            keywordMatcher.contentParseToProjectExperience(projectExperience.replaceAll("\n",""), experienceTemp);

            //将项目经历的开始结束时间塞入
            if (dates.get(i) != null) {
                List<String> startStopDate = parseStartStopDate(dates.get(i));
                experienceTemp.setStartTs(startStopDate.get(0));
                experienceTemp.setEndTs(startStopDate.get(1));
            }

            if (StringUtils.isEmpty(experienceTemp.getDescription())) {
                experienceTemp.setDescription(projectExperience);
            }
            if (StringUtils.isEmpty(experienceTemp.getCompany())) {
                String company = findCompanyName(projectExperience);
                experienceTemp.setCompany(company);
            }

            result.add(experienceTemp);
        }

        return result;
    }

    public static String findCompanyName(String str) {
        if(StringUtils.isEmpty(str)){
            return null;
        }
        String company = null;
        str = str.replaceAll("\\s*[(（]\\s*[一-龥]+\\s*[)）]", "");
        String regex = "[\u4e00-\u9fa5]+((公司)|(联盟))";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            company = matcher.group();
        }
        return company;
    }

    public static String findMajorName(String str) {
        if(StringUtils.isEmpty(str)){
            return null;
        }
        List<Term> terms = HanLP.newSegment().enableCustomDictionaryForcing(true).seg(str);
        for (Term term : terms) {
            if(term.nature.toString().equals("major")){
                return term.word;
            }
        }
        return null;
    }

    public static String findSchoolName(String str) {
        if(StringUtils.isEmpty(str)){
            return null;
        }
        List<Term> terms = HanLP.newSegment().enableCustomDictionaryForcing(true).seg(str);
        for (Term term : terms) {
            if(term.nature.toString().equals("ntu")){
                return term.word;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        String s = "2005.09-2008.07专业名称英语学历本科是否统招否";
        System.out.println(findMajorName(s));
    }

}
