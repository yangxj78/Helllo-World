package com.hengtiansoft.servlet.hr.delivery.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.InterviewDeliveryDto;
import com.hengtiansoft.bean.dataModel.InterviewSearchDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryDto;
import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.bean.tableModel.ResumeDelivery;
import com.hengtiansoft.common.enumeration.InterviewResultEnum;
import com.hengtiansoft.common.enumeration.InterviewStatusEnum;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.enumeration.PassStatusEnum;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.hr.delivery.service.DeliveryService;
import com.hengtiansoft.servlet.hr.interview.service.InterviewService;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by linwu on 7/18/2018.
 */
@Service
public class DeliveryServiceImpl implements DeliveryService{

    private static final Logger LOGGER = LoggerFactory.getLogger(DeliveryService.class);

    //排队中
    private static final Integer QUEUING = 0;

    //面试中
    private static final Integer INTERVIEWING = 1;

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private InterviewService interviewService;

    @Override
    @Transactional
    public ResultDto postResume(ResumeDeliveryDto resumeDeliveryDto) {
        String msg = validate(resumeDeliveryDto);
        if (msg != null) {
            return ResultDtoFactory.toNack(msg);
        }
        try {
            ResumeDelivery resumeDelivery = revertEntity(resumeDeliveryDto);
            //获取该展位最后一位投递序号
            int orderNum=0;
            try {
                orderNum = resumeDeliveryMapper.findLastOrderNum(resumeDeliveryDto.getBoothId(), resumeDeliveryDto.getRecruitmentId());
            }catch(Exception e){
               LOGGER.info("这个展位第一个有简历投递");
            }
            resumeDelivery.setOrderNum(++orderNum);
            initDefalutProperty(resumeDelivery);
            resumeDeliveryMapper.insert(resumeDelivery);

            //提醒hr端刷新
            NettyClientUtil.notifyHr(resumeDeliveryDto.getBoothId());
            //提醒电视端刷新
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.HR_DELIVERY.getCode());
            NettyClientUtil.notifyTv(resumeDeliveryDto.getBoothId(), JSON.toJSONString(map));
        }catch (Exception e) {
            LOGGER.error("投递失败", e);
            return ResultDtoFactory.toNack("投递失败");
        }
        return ResultDtoFactory.toAck("投递成功");
    }


    /**
     * 第一次简历投递插入到数据库中有一些属性需要初始化
     * @param resumeDelivery
     */
    private void initDefalutProperty(ResumeDelivery resumeDelivery){
        resumeDelivery.setParentBoothId(0);
        resumeDelivery.setInterviewNum(1);
        resumeDelivery.setPassStatus(0);
        resumeDelivery.setMatching(0);
        resumeDelivery.setProfession(0);
        resumeDelivery.setLearning(0);
        resumeDelivery.setCommunicate(0);
    }


    @Override
    @Transactional
    public ResultDto<InterviewDeliveryDto> allotBooth(Integer type, Integer boothId, Integer resumeDeliveryId) {
        ResumeDelivery resumeDelivery = resumeDeliveryMapper.selectByPrimaryKey(resumeDeliveryId);
        if (resumeDelivery == null) {
            return ResultDtoFactory.toNack("简历不存在，分配展位失败");
        }
        try {
            long startTime = System.currentTimeMillis();
            //获取该展位最后一位投递序号
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            Integer orderNum = resumeDeliveryMapper.findLastOrderNum(boothId, companySign.getRecruitmentId());

            if (orderNum == null) {
                resumeDelivery.setOrderNum(1);
            } else {
                resumeDelivery.setOrderNum(++orderNum);
            }

            //如果是第一次分配，记录当前分配的展位id, 否则，记录当前分配展位的父展位Id parent_booth_id
            Integer parentBoothId = resumeDelivery.getParentBoothId();
            if (parentBoothId == null || parentBoothId.intValue() == 0) {
                resumeDelivery.setParentBoothId(companySign.getBoothId());
            } else {
                resumeDelivery.setParentBoothId(parentBoothId);
            }

            //如果是面试分配
            if (INTERVIEWING.intValue() == type.intValue()) {
                //获取其上一次面试轮次
                int interviewNum = resumeDelivery.getInterviewNum();
                resumeDelivery.setInterviewNum(++interviewNum);
            }

            resumeDelivery.setId(null);
            resumeDelivery.setBoothId(boothId);
            resumeDelivery.setCreateTs(new Date());
            resumeDelivery.setInterviewStatus(InterviewStatusEnum.READY.getCode());
            resumeDelivery.setInterviewResult(InterviewResultEnum.NULL.getCode());
            resumeDelivery.setInterviewEvaluation(null);

            //插入新的投递
            resumeDeliveryMapper.insert(resumeDelivery);


            //排队中还未进行面试的，要删除之前的投递
            if (QUEUING.intValue() == type.intValue()) {
                resumeDeliveryMapper.deleteByPrimaryKey(resumeDeliveryId);
            }

            //提醒hr端和电视端刷新
            NettyClientUtil.notifyHr(boothId);
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.HR_DELIVERY.getCode());
            NettyClientUtil.notifyTv(boothId, JSON.toJSONString(map));
            NettyClientUtil.notifyTv(companySign.getBoothId(), JSON.toJSONString(map));
        }catch (Exception e) {
            LOGGER.error("分配展位失败", e);
            return ResultDtoFactory.toNack("分配展位失败");
        }
        return ResultDtoFactory.toAck("分配成功", interviewService.getFirst());
    }

    @Override
    public ResultDto<List<InterviewDeliveryDto>> findAllotRecord(InterviewSearchDto searchDto) {
        CompanySign companySign = SecurityContext.getCurrentHRUser();
        if (searchDto.getOffset() == null) {
            searchDto.setOffset(1);
        }
        if (searchDto.getLimit() == null) {
            searchDto.setLimit(10000);
        }
        searchDto.setLimit(10000);
        return ResultDtoFactory.toAck("获取分流列表成功", resumeDeliveryMapper.findAllotRecord(companySign.getBoothId(), companySign.getRecruitmentId(), searchDto));
    }

    @Override
    public Boolean isDeliveryed(Integer boothId, Integer recruitmentId) {
        return resumeDeliveryMapper.findIsDeliveryed(boothId, recruitmentId) == null ? false : true;
    }

    private ResumeDelivery revertEntity(ResumeDeliveryDto resumeDeliveryDto){
        return new ResumeDelivery(
                resumeDeliveryDto.getUserId(),
                resumeDeliveryDto.getResumeId(),
                resumeDeliveryDto.getRecruitmentId(),
                resumeDeliveryDto.getCompanyId(),
                resumeDeliveryDto.getPositionRecordId(),
                resumeDeliveryDto.getBoothId(),
                InterviewStatusEnum.READY.getCode(),
                InterviewResultEnum.NULL.getCode(),
                PassStatusEnum.NO_PASS.getCode(),
                new Date(),
                new Date()
        );
    }

    private String validate(ResumeDeliveryDto resumeDeliveryDto) {
        if (resumeDeliveryDto == null) {
            return "简历投递不存在";
        }
        if (resumeDeliveryDto.getBoothId() == null) {
            return "展位信息不能为空";
        }
        if (resumeDeliveryDto.getCompanyId() == null) {
            return "企业信息不能为空";
        }
        if (resumeDeliveryDto.getPositionRecordId() == null) {
            return "展位信息不能为空";
        }
        if (resumeDeliveryDto.getRecruitmentId() == null) {
            return "招聘会信息不能为空";
        }
        if (resumeDeliveryDto.getResumeId() == null) {
            return "简历信息不能为空";
        }
        if (resumeDeliveryDto.getUserId() == null) {
            return "用户信息不能为空";
        }
        return null;
    }
}
