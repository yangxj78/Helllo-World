package com.hengtiansoft.servlet.admin.resume.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.ResumeDto;
import com.hengtiansoft.bean.dataModel.SendMessageDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "简历相关接口(后台)", description = "后台简历管理")
@RestController
@RequestMapping(value = "/admin/resume")
public class ResumeAdminController {

    @Autowired
    private ResumeService resumeService;

    @PostMapping(value = "/sendInvitationMessage")
    @ApiOperation(value = "发送邀约短信", notes = "")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto sendInviteMessage(@RequestBody SendMessageDto sendMessageDto) {
        List<Integer> resumes = sendMessageDto.getResumes();
        int recruitmentId = sendMessageDto.getRecruitmentID();
        int errorCount = 0;
        for (int resumeId : resumes) {
            if (!resumeService.sendInviteMessage(recruitmentId, resumeId)) {
                ++errorCount;
            }
        }
        if (errorCount > 0) {
            return ResultDtoFactory.toNack(errorCount + "人发送失败");
        }
        return ResultDtoFactory.toAck("全部发送成功");
    }



}
