package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.config.MyMapper;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface RecruitmentMapper extends MyMapper<Recruitment> {
    int add(Recruitment recruitment);

    List<Recruitment> getAll(RecruitmentSearch recruitmentSearch);

    List<Recruitment> getRecruitmentByTypeId(Integer id);

    int updateById(Recruitment recruitment);

    int updateRecruitmentNumber(NumberDto numberDto);

    NumberDto findRecruitmentNumber(Integer recruitmentID);

    List<RecruirmentTableDto> getRecruitmentTable(RecruitmentSearch recruitmentSearch);

    List<RecruitmentDataDto> getRecruitmentData(RecruitmentSearch recruitmentSearch);

    List<EnrollTable> getEnrollTable(int id);

    List<ExcelPositionData> getExcelPositionData(Integer id);

    List<ExcelUserData> getExcelUserData(Integer id);

    List<ResumeDeliveryDataDto> getResumeDeliveryData(ResumeDeliveryDataSearchDto resumeDeliveryDataSearchDto);

    /**
     * 获取当天的招聘会
     *
     * @return
     */
    List<Recruitment> getCurrentRecruitment();

    List<ParkingAndMealDto> listParkingAndMeal(Integer recruitmentID);

    int updateByPeople(Recruitment updateNumber);

    Integer getTotalMealsNum(Integer recruitmentID);

    int getAttendOrLeaveNumber(@Param("type") int type, @Param("recruitmentId") int recruitmentId, @Param("today") Timestamp today);

    List<StationDto> getStationsByRecruitmentId(int recruitmentId);

    List<AmountDto> getEducationCount(@Param("recruitmentId") int recruitmentId, @Param("today") Timestamp today);

    List<Date> getPresentBirthDate(@Param("recruitmentId") int recruitmentId, @Param("today") Timestamp today);

    List<AnalysisPositionAndCompnayDto> analysisPositionAndCompnay(AnalysisDto analysisDto);

    List<AnalysisCompnayTypeDto> analysisCompnayType(AnalysisDto analysisDto);

    List<AnalysisCompnayTradeDto> analysisCompnayTrade(AnalysisDto analysisDto);

    List<AnalysisPositionSalaryDto> analysisPositionSalary(AnalysisDto analysisDto);

    List<AnalysisPositionEducationDto> analysisPositionEducation(AnalysisDto analysisDto);

    List<AnalysisEducationDto> analysisEducation(AnalysisDto analysisDto);

    List<AnalysisWorkYearsDto> analysisWorkYears(AnalysisDto analysisDto);

    List<AnalysisSalaryDto> analysisSalary(AnalysisDto analysisDto);

    List<AnalysisDeliveryDto> analysisDelivery(AnalysisDto analysisDto);

    AnalysisYearDto analysisYear(AnalysisDto analysisDto);

    Integer countCompany(AnalysisDto analysisDto);

    Integer countPosition(AnalysisDto analysisDto);

    List<RecruitmentDataDto> search(PositionRecordSearch positionRecordSearch);
    List<RecruitmentDataDto> search2(PositionRecordSearch positionRecordSearch);

    Integer getCollectionPosition(CollectionPositionSearchDto searchDto);

    void updateByPeoplePRE(Recruitment updateNumber);
}