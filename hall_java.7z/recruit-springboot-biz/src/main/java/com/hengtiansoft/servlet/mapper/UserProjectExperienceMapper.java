package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

@Repository
public interface UserProjectExperienceMapper extends MyMapper<UserProjectExperience> {

}