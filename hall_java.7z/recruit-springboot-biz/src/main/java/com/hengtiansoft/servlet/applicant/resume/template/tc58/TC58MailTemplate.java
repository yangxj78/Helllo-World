package com.hengtiansoft.servlet.applicant.resume.template.tc58;

import com.hengtiansoft.servlet.applicant.resume.resume.TC58Resume;

public class TC58MailTemplate extends TC58Resume {

}
