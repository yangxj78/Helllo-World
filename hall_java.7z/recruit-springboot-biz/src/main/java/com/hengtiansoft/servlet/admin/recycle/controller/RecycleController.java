package com.hengtiansoft.servlet.admin.recycle.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.admin.recycle.service.RecycleService;
import com.hengtiansoft.servlet.admin.template.service.TempletService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@RestController
@RequestMapping("/admin/recycle")
public class RecycleController {

    @Autowired
    RecycleService recycleService;


    @Autowired
    CompanyService companyService;

    @Autowired
    RecruitmentService recruitmentService;

    @Autowired
    PositionService positionService;
    @Autowired
    TempletService templetService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    @ApiOperation(value = "获取回收站列表")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getRecruitmentList(@RequestParam(required = false) Integer pageSize, @RequestParam(required = false) Integer pageNum) {
        Integer pageNum1 = (pageNum == null ? 1 : pageNum);
        Integer pageSize1 = (pageSize == null ? MagicNumConstant.TEN : pageSize);
        PageHelper.startPage(pageNum1, pageSize1);
        return ResultDtoFactory.toAck("success", new PageInfo<Recycle>(recycleService.list()));
    }


    @RequestMapping(value = "/reduction", method = RequestMethod.POST)
    @ApiOperation(value = "还原", notes = "必填 分页标记位 0分页 1不分页 字段可选，招聘会类型ID，截止开始日期，招聘会关键字，")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto reduction(@RequestBody List<Recycle> recycles) {
        for (Recycle recycle : recycles) {
            switch (recycle.getType()) {
                case "企业":
                    Company company = new Company();
                    company.setId(recycle.getDeleteId());
                    company.setStatus(0);
                    companyService.updateCompany(company);
                    recycleService.delete(recycle);
                    break;
                case "招聘会":
                    Recruitment recruitment = recruitmentService.getById(recycle.getDeleteId());
                    recruitment.setStatus(0);
                    recruitmentService.updateRecruitment(recruitment);
                    recycleService.delete(recycle);
                    TempletBooth templetBooth = new TempletBooth();
                    if (recruitment.getDevice() && recruitment.getStyle() == 0) {
                        for (int i = 1; i <= 60; i++) {
                            templetBooth.setRecruitmentId(recruitment.getId());
                            templetBooth.setBoothId(i);
                            templetBooth.setTempletId(1);
                            templetBooth.setId(null);
                            templetService.insertSelective(templetBooth);
                        }
                    } else if (recruitment.getDevice() && recruitment.getStyle() == 1) {
                        for (int i = 1; i <= 60; i++) {
                            templetBooth.setRecruitmentId(recruitment.getId());
                            templetBooth.setBoothId(i);
                            templetBooth.setTempletId(2);
                            templetBooth.setId(null);
                            templetService.insertSelective(templetBooth);
                        }
                    }
                    break;
                case "岗位":
                    int id = recycle.getDeleteId();
                    Position position1 = positionService.selectByID(id);
                    PositionSearch search = new PositionSearch();
                    search.setName(position1.getName());
                    search.setCompanyID(position1.getCompanyID());
                    if (positionService.search(search).size() > 1) {
                        return ResultDtoFactory.toNack("还原失败，公司存在同名岗位");
                    }
                    position1.setStatus(0);
                    positionService.updateSelective(position1);
                    recycleService.deleteByID(recycle.getId());
                    break;
                default:
                    break;
            }
        }
        return ResultDtoFactory.toAck("还原成功");
    }

    @RequestMapping(value = "/clear", method = RequestMethod.GET)
    @ApiOperation(value = "清空回收站")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto clear() {
        recycleService.deleteAll();
        return ResultDtoFactory.toAck("清空完成");
    }
}
