package com.hengtiansoft.servlet.applicant.resume.template.zhilian;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.ZhiLianResume;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ZhiLianTemplateTwo extends ZhiLianResume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);

        String[] arr = content.split("(&nbsp;)+");
        String updateDate = getUpdateDate(content);
        String number = getNumber(content);
        SexEnum sex = SexEnum.MAN;

        String name = null;
        for (String str : arr) {
            if (str.contains("男")) {
                name = str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("男"));
                break;
            }
            if (str.contains("女")) {
                name = str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("女"));
                sex = SexEnum.WOMAN;
                break;
            }
        }
        String year = getWorkedYears(content);
        String info = strSubstring(content, name, "求职意向");

        String city = null;
        int age = 0;

        if (StringUtils.isNotEmpty(info)) {
            String[] infos = info.split("(&nbsp;)+");
            for (String str : infos) {
                if (str.contains("岁")) {
                    age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
                }
                if (str.contains("现居住地：")) {
                    if (str.contains("|")) {
                        city = strSubstring(str, "现居住地：", "|").replaceAll("现居住地：", "");
                    } else {
                        city = str.substring(str.indexOf("现居住地：") + BEGIN_OFF_SET_FIVE);
                    }
                }
            }
        }

        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.ZHILIANUPLOAD);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content);
        String post = null;
        String expectCity = null;
        String expectSalary = null;
        if (content.contains("求职意向")) {
            String jobObjective = content.substring(content.indexOf("求职意向"));
            post = strSubstring(jobObjective, "期望从事职业：", "期望从事行业：");
            expectCity = strSubstring(jobObjective, "期望工作地区：", "期望月薪：");
            expectSalary = strSubstring(jobObjective, "期望月薪：", "目前状况：");
        }
        expectSalary = StringUtils.isEmpty(expectSalary) || "不显示职位月薪范围".equals(expectSalary) ? "面议" : expectSalary;

        String school = null;
        String major = null;
        String degree = null;
        String graduateDate = null;
        String englishLevel = getEnglishLevel(content);
        if (content.contains("教育经历")) {
            String eduExperience = content.substring(content.indexOf("教育经历"));

            String[] eduInfo = eduExperience.split("(&nbsp;)+", BEGIN_OFF_SET_FIVE);
            int subNum = 0;
            if (eduInfo[BEGIN_OFF_SET_ZERO].contains("-")) {
                subNum = 1;
            }
            graduateDate = eduInfo[NUM_SUB_ONE - subNum].substring(eduInfo[NUM_SUB_ONE - subNum].indexOf("-"))
                    .replace("-", "");
            if (!graduateDate.replace(".", "").matches("[0-9]+")) {
                graduateDate = "暂未毕业";
            }
            school = eduInfo[NUM_SUB_TWO - subNum];
            major = eduInfo[NUM_SUB_THREE - subNum];
            degree = eduInfo[NUM_SUB_FOUR - subNum].substring(BEGIN_OFF_SET_ZERO, BEGIN_OFF_SET_TWO);
        }
        String staffType = strSubstring(content, "期望工作性质：", "期望从事职业：");
        String selfIntroduce = strSubstring(content, "自我评价", "工作经历");
        selfIntroduce = selfIntroduce.replaceAll("&nbsp;", "");

        r.setSelfIntroduction(selfIntroduce);
        r.setEngLevel(englishLevel);
        r.setPost(post);
        r.setExpectCity(expectCity);
        r.setExpectSalary(expectSalary);
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        String[] arr = {};
        if (content.contains("charset=utf-8")) {
            arr = content
                    .split("<span style='font-size:15.0pt;font-family:宋体;mso-ascii-font-family:\r\nCalibri;mso-ascii-theme-font:minor-latin;mso-fareast-font-family:宋体;mso-fareast-theme-font:\r\nminor-fareast;mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\r\nbackground:#D9D9D9;mso-shading:white;mso-pattern:gray-15 auto'>");

        } else if (content.contains("charset=unicode")) {
            arr = content
                    .split(";mso-hansi-font-family:Calibri;mso-hansi-theme-font:minor-latin;\r\n" +
                            "\\s*background:#D9D9D9;mso-shading:white;mso-pattern:gray-15 auto'>");
        }
        for (String str : arr) {
            if (str.startsWith("工作经历")) {
                workExperience = filterExperience(str).replaceFirst("工作经历(&nbsp;)*", "").replaceAll("<spanlang=ZH-CNstyle='font-size:15.0pt;font-family:宋体;mso-bidi-font-family:", "");
            }
            if (str.startsWith("项目经历")) {
                projectExperience = filterExperience(str).replaceFirst("项目经历(&nbsp;)*", "").replaceAll("<spanlang=ZH-CNstyle='font-size:15.0pt;font-family:宋体;mso-bidi-font-family:", "");
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "").replaceAll("<spanlang=ZH-CNstyle='font-size:15.0pt;font-family:宋体;mso-bidi-font-family:", "");
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setUserEducationExperienceList(educationExperienceConvert(education));
        r.setUserWorkExperienceList(workExperienceConvert(workExperience));
        r.setProjectExperienceList(projectExperienceConvert(projectExperience));

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    public String getWorkedYears(String context) {
        Pattern yearsExg = Pattern.compile("(\\d*)年年工作经验");
        Matcher matcher = yearsExg.matcher(context);
        String years = "0";
        if (matcher.find()) {
            return fieldTrim(matcher.group(0));
        }

        return fieldTrim(years);
    }

    private List<UserWorkExperience> workExperienceConvert(String workExperience) {
        List<UserWorkExperience> result = new ArrayList<>();
        List<String> workDates = new ArrayList<>();

        workExperience = workExperience.replaceAll(" +", " ");
        String regex = "\\d{4}[/.]\\d{1,2}-(\\d{4}[/.]\\d{1,2}|\\s*至今)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(workExperience);
        while (matcher.find()) {
            workDates.add(matcher.group());
        }

        String[] str = workExperience.split("<br/>");

        List<String> workExperiences = Arrays.asList(str);

        int i = 0;
        while (i < workDates.size()) {
            UserWorkExperience temp = new UserWorkExperience();
            String[] times = workDates.get(i).split("-");

            temp.setStartTs(times[0].replaceAll("[/.]", "-"));
            temp.setEndTs(times[1].replaceAll("[/.]", "-"));

            String experience = workExperiences.get(i);

            int j = experience.indexOf(" 工作描述");
            String[] strArray = workExperiences.get(i).substring(BEGIN_OFF_SET_ZERO, j).split(" ");
            temp.setCompany(strArray[1]);

            //去掉job后的薪资数据
            String jobPattern = "^[一-龥]+";
            Pattern r = Pattern.compile(jobPattern);
            Matcher m = r.matcher(strArray[2]);
            if (m.find()) {
                String job = m.group();
                temp.setJob(job);
            }

            /*匹配工作描述： 后的内容*/
            temp.setDescription(experience.substring(j + 7));

            result.add(temp);
            i++;
        }

        return result;
    }

    private List<UserEducationExperience> educationExperienceConvert(String educationExperience) {
        List<UserEducationExperience> result = new ArrayList<>();
        String[] eduArray = educationExperience.split("<br/>");

        for (String education : eduArray) {
            UserEducationExperience temp = new UserEducationExperience();
            String[] strArray = education.split("( )+");
            temp.setSchool(strArray[1]);
            temp.setEducational(EducationalEnum.verifyEducation(strArray[3]));
            temp.setMajor(strArray[2]);

            String time = strArray[0];
            temp.setStartTs(time.substring(BEGIN_OFF_SET_ZERO, time.indexOf('-')).replaceAll("/","-"));
            temp.setEndTs(time.substring(time.indexOf('-') + 1).replaceAll("/","-"));

            result.add(temp);
        }
        return result;
    }

    private List<UserProjectExperience> projectExperienceConvert(String projectExperience) {
        List<UserProjectExperience> result = new ArrayList<>();
        List<String> workDates = new ArrayList<>();

        projectExperience = projectExperience.replaceAll(" +", " ");
        String regex = "\\d{4}[/.]\\d{1,2}-(\\d{4}[/.]\\d{1,2}|\\s*至今)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(projectExperience);
        while (matcher.find()) {
            workDates.add(matcher.group());
        }

        String[] str = projectExperience.split("<br/>");

        List<String> projectExperiences = Arrays.asList(str);

        int i = 0;
        while (i < workDates.size()) {
            UserProjectExperience temp = new UserProjectExperience();
            String[] times = workDates.get(i).split("-");

            temp.setStartTs(times[0].replaceAll("[/.]", "-"));
            temp.setEndTs(times[1].replaceAll("[/.]", "-"));

            String experience = projectExperiences.get(i);

            experience = experience.replaceFirst(regex, "");
            int descIndex = experience.indexOf(" 项目描述");
            int dutyIndex = experience.indexOf(" 个人职责");
            String[] strArray = experience.substring(BEGIN_OFF_SET_ZERO, descIndex).split(" ");
            temp.setProjectName(strArray[0]);

            /*匹配工作描述： 后的内容*/
            if (dutyIndex > -1) {
                temp.setDescription(experience.substring(descIndex + 7, experience.indexOf("个人职责")));
                temp.setDuty(experience.substring(dutyIndex + 7));
            } else {
                temp.setDescription(experience.substring(descIndex + 7));
            }

            result.add(temp);
            i++;
        }

        return result;
    }

    @Override
    public String enterExperience(String content) {
        String str = content.replaceAll("&nbsp;至今","至今");
        String br = "<br/>";
        Pattern exg = Pattern.compile("\\d{4}[/.]\\d{1,2}[–-](\\d{4}[/.]\\d{1,2}|至今)");
        if (!StringUtils.isEmpty(str)) {
            Matcher matcher = exg.matcher(str);
            int i = 0;
            while (matcher.find()) {
                if (i > 0)
                    str = str.replace(matcher.group(), br + matcher.group());
                i++;
            }
            str = str.replaceAll("(<br/>){2,}", br).replace("&nbsp;", " ");
        }
        if (!StringUtils.isEmpty(str) && str.startsWith(br)) {
            str = str.replaceFirst(br, "");
        }
        return str;
    }
}
