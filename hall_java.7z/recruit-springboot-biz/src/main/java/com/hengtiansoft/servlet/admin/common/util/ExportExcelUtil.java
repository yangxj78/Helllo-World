package com.hengtiansoft.servlet.admin.common.util;


import com.hengtiansoft.bean.tableModel.Test;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.xssf.usermodel.*;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

public class ExportExcelUtil<T> {

    public static void main(String[] args) throws Exception {

        ExportExcelUtil export = new ExportExcelUtil();
        String srcFilePath = "d:/hahaha.xlsx";
        String fileName = "test_" + System.currentTimeMillis() + ".xls";
        String desFilePath = "d:/ceshi/" + fileName;
        Test t = new Test();
        t.setId(1);
        t.setName("ceshi1");
        t.setName2("ceshi2");
        t.setNumber("123");
        Test t2 = new Test();
        t2.setId(1);
        t2.setName("ceshi1");
        t2.setName2("ceshi2222222222");
        t2.setNumber("123");

        ArrayList<Test> arr = new ArrayList();
        arr.add(t);
        arr.add(t2);
        export.exportExcel(srcFilePath, desFilePath, arr);
        ZipUtils.doCompress("d:/ceshi", "d:/test.zip");
    }

    //根据指定的excel模板导出数据
    public void exportExcel(String srcFilePath, String desFilePath, Collection<T> ls) throws IOException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        //创建Excel文件的输入流对象
        FileInputStream fis = new FileInputStream(srcFilePath);
        //根据模板创建excel工作簿
        XSSFWorkbook workBook = new XSSFWorkbook(fis);
        //创建Excel文件输出流对象
        FileOutputStream fos = new FileOutputStream(desFilePath);
        //获取创建的工作簿第一页
        XSSFSheet sheet = workBook.getSheetAt(0);
        //给指定的sheet命名
        workBook.setSheetName(0, "2016-11-30");

        //修改标题

        int currentLastRowIndex = sheet.getLastRowNum();

        //获取指定单元格值

        if (currentLastRowIndex > 1) {
            XSSFRow row2 = sheet.getRow(1);
            XSSFCell cell3 = row2.getCell(0);
            String s = cell3.getStringCellValue();
            cell3.setCellValue("修改后的标题为:" + s);
        }


        //获取当前sheet最后一行数据对应的行索引
        int newRowIndex = currentLastRowIndex + 1;
        //开始创建并设置该行每一单元格的信息，该行单元格的索引从 0 开始

        //遍历集合取出数据
        Iterator<T> it = ls.iterator();
        while (it.hasNext()) {
            XSSFRow newRow = sheet.createRow(newRowIndex);
            newRowIndex++;
            T t = (T) it.next();
            // 利用反射，根据javabean属性的先后顺序，动态调用getXxx()方法得到属性值
            Field[] fields = t.getClass().getDeclaredFields();

            for (short cellIndex = 0; cellIndex < fields.length; cellIndex++) {
                XSSFCell cell2 = newRow.createCell(cellIndex);
                Field field = fields[cellIndex];
                String fieldName = field.getName();
                String getMethodName = "get"
                        + fieldName.substring(0, 1).toUpperCase()
                        + fieldName.substring(1);
                try {
                    Class tCls = t.getClass();
                    Method getMethod = tCls.getMethod(getMethodName,
                            new Class[]{});
                    Object value = getMethod.invoke(t, new Object[]{});
                    String textValue = null;


                    if (value instanceof Date) {
                        Date date = (Date) value;
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        textValue = sdf.format(date);
                    } else if (null == value) {
                        textValue = " ";
                    } else {
                        //其它数据类型都当作字符串简单处理
                        textValue = value.toString();
                    }

                    XSSFRichTextString richString = new XSSFRichTextString(textValue);
                    XSSFFont font3 = workBook.createFont();
                    font3.setColor(HSSFColor.BLACK.index);//定义Excel数据颜色
                    richString.applyFont(font3);
                    cell2.setCellValue(richString);

                } catch (Exception e) {
                    e.getStackTrace();
                }
            }
        }

        try {
            workBook.write(fos);
            //关闭流
            fis.close();
            fos.flush();
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
