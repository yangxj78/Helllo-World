package com.hengtiansoft.servlet.hr.interview.controller;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.ResultCode;
import com.hengtiansoft.common.enumeration.InterviewEnum;
import com.hengtiansoft.common.enumeration.InterviewStatusEnum;
import com.hengtiansoft.servlet.hr.interview.service.InterviewService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Api(value="面试管理", description = "面试管理相关接口")
@RestController
@RequestMapping("/hr/interview")
public class InterviewController {

    @Autowired
    InterviewService interviewService;

    @ApiOperation(value = "获取所有的投递岗位", httpMethod = "GET")
    @RequestMapping(value = "/findDeliveryPositions", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<PositionRecordDto>> findDeliveryPositions() {
        return interviewService.findDeliveryPositions();
    }

    @ApiOperation(value = "根据查询获取投递列表", httpMethod = "POST")
    @RequestMapping(value = "/list/{status}", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<InterviewDeliveryDto>> findAllByCon(@ApiParam(value = "面试状态: 0待面，1已面", name = "status") @PathVariable Integer status,
                                                              @ApiParam(value = "查询信息", name = "interviewSearch") @RequestBody InterviewSearchDto searchDto) {
        return interviewService.findAllByCon(status, searchDto);
    }


    @ApiOperation(value = "获取当前投递顺位第一位投递者", httpMethod = "GET")
    @RequestMapping(value = "/getFirst", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<InterviewDeliveryDto> getFirst() {
        InterviewDeliveryDto interviewDeliveryDto = interviewService.getFirst();
        if (interviewDeliveryDto == null) {
            return ResultDtoFactory.toAck("获取失败");
        }
        interviewService.notifyUser(interviewDeliveryDto.getId());
        return ResultDtoFactory.toAck("获取成功", interviewDeliveryDto);
    }


    @ApiOperation(value = "呼叫下一位", httpMethod = "GET")
    @RequestMapping(value = "/passOut/{resumeDeliveryId}/{orderNum}", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<InterviewDeliveryDto> passOut(@ApiParam(value = "投递id", name = "resumeDeliveryId") @PathVariable Integer resumeDeliveryId,
                                                   @ApiParam(value = "当前序号", name = "orderNum") @PathVariable Integer orderNum) {


        ResultDto resultDto = interviewService.passOut(resumeDeliveryId, orderNum);
        if (resultDto.getCode().equals(ResultCode.ACK)) {
            return interviewService.notifyTv(InterviewStatusEnum.READY.getCode());
        } else {
            return resultDto;
        }
    }

    @ApiOperation(value = "获取当前能分配的展位", httpMethod = "GET")
    @RequestMapping(value = "/getBooths", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<Map<Integer, Integer>>> getBooths() {
        return interviewService.getBooths();
    }

    @ApiOperation(value = "开始面试", httpMethod = "POST")
    @RequestMapping(value = "/startInterview", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<InterviewDetailDto> startInterview(@ApiParam(value = "投递id", name = "resumeDeliveryId") @RequestParam Integer resumeDeliveryId) {
        ResultDto resultDto = interviewService.startInterview(resumeDeliveryId);
        if (resultDto.getCode().equals(ResultCode.ACK)) {
            return interviewService.notifyTv(InterviewStatusEnum.ING.getCode());
        } else {
            return resultDto;
        }
    }

    @ApiOperation(value = "结束面试", httpMethod = "POST")
    @RequestMapping(value = "/saveInterviewDetail", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<InterviewDeliveryDto>> findAllByCon(@ApiParam(value = "面试详细", name = "interviewDetailDto") @RequestBody InterviewDetailDto interviewDetailDto) {
        ResultDto resultDto = interviewService.saveInterviewDetail(interviewDetailDto);
        if (InterviewEnum.END.getCode().equals(interviewDetailDto.getType()) && resultDto.getCode().equals(ResultCode.ACK)) {
            return interviewService.notifyTv(InterviewStatusEnum.FINISH.getCode());
        } else {
            return resultDto;
        }
    }

    @ApiOperation(value = "查看简历详情", httpMethod = "GET")
    @RequestMapping(value = "/getResumeDetail", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<ResumeInfoDto> getResumeDetail(@ApiParam(value = "投递id", name = "resumeDeliveryId") @RequestParam Integer resumeDeliveryId,
                                                    @ApiParam(value = "简历id", name = "resumeId") @RequestParam Integer resumeId,
                                                    @ApiParam(value = "用户id", name = "userId") @RequestParam Integer userId) {
        return interviewService.getResumeDetail(resumeDeliveryId, resumeId, userId);
    }


    @ApiOperation(value = "获取当前面试者", httpMethod = "GET")
    @RequestMapping(value = "/getCurrentInterviewer", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<InterviewDeliveryDto> getCurrentInterviewer() {
        return interviewService.getCurrentInterviewer();
    }

}
