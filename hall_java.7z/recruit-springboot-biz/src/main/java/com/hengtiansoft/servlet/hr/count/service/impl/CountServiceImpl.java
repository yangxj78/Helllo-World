package com.hengtiansoft.servlet.hr.count.service.impl;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.common.enumeration.InterviewResultEnum;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.hr.count.service.CountService;
import com.hengtiansoft.servlet.manage.dict.DictService;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by linwu on 7/19/2018.
 */
@Service
public class CountServiceImpl implements CountService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CountService.class);

    //计数类型 0：总数 ， 1：通过数
    private static final String COUNT_TYPE = "0";

    @Autowired
    private ResumeDeliveryMapper resumeDeliveryMapper;

    @Autowired
    private DictService dictService;

    @Override
    public ResultDto<Map> findDeliveryInfo() {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            Map<String, Object> resultMap = new HashMap<>();
            //放入投递信息
            List<Integer> tempDeliveryDto = resumeDeliveryMapper.findDeliveryInfo(companySign.getCompanyId(),
                    companySign.getRecruitmentId());
            resultMap.put("totalNum", tempDeliveryDto.get(0));
            resultMap.put("notPassNum", tempDeliveryDto.get(1));
            resultMap.put("passNum", tempDeliveryDto.get(2));
            resultMap.put("notSureNum", tempDeliveryDto.get(3));
            return ResultDtoFactory.toAck("获取统计信息成功", resultMap);
        } catch (Exception e) {
            LOGGER.error("获取统计信息出错", e);
            return ResultDtoFactory.toNack("获取统计信息出错");
        }
    }

    @Override
    public ResultDto<List<Map<String, Object>>> findPositionInfo() {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            //放入职位信息
            List<Map<String, Object>> tempPositionDto = resumeDeliveryMapper.findPositionInfo(companySign.getCompanyId(),
                    companySign.getRecruitmentId());
            Map<Integer, Map<String, Object>> resultPositionDto = new HashMap<>();
            tempPositionDto.forEach(tempMap -> {
                Map<String, Object> map = resultPositionDto.get(tempMap.get("id"));
                if (null == map) {
                    map = new HashMap<>();
                }
                if (COUNT_TYPE.equals(String.valueOf(tempMap.get("type")))) {
                    map.put("totalNum", tempMap.get("totalNum"));
                } else {
                    map.put("passNum", tempMap.get("passNum"));
                }
                map.put("name", tempMap.get("name"));
                resultPositionDto.put((Integer) tempMap.get("id"), map);
            });

            List<Map<String, Object>> result = new ArrayList<>();
            for (Map.Entry<Integer, Map<String, Object>> entry: resultPositionDto.entrySet()) {
                if (entry.getValue().get("totalNum") == null) {
                    entry.getValue().put("totalNum", 0);
                }
                if (entry.getValue().get("passNum") == null) {
                    entry.getValue().put("passNum", 0);
                }
                result.add(entry.getValue());
            }

            int countAll = resumeDeliveryMapper.countByCompanyAndRecruitment(companySign.getCompanyId(), companySign.getRecruitmentId());
            if (countAll >= result.size() && result.size() != 0) {
                Map<String, Object> map = new HashMap<>();
                map.put("name", "其他岗位");
                map.put("totalNum", 0);
                map.put("passNum", 0);
                result.add(map);
            }

            return ResultDtoFactory.toAck("获取统计信息成功", result);
        } catch (Exception e) {
            LOGGER.error("获取统计信息出错", e);
            return ResultDtoFactory.toNack("获取统计信息出错");
        }
    }

    @Override
    public ResultDto<Map> findWorkYearsAndEduInfo() {
        try {
            CompanySign companySign = SecurityContext.getCurrentHRUser();
            Map<String, Object> resultMap = new HashMap<>();
            //放入学习职位信息
            List<Integer> educationIds = Arrays.asList(16,17,18,19,20);//new ArrayList<>();
            List<Integer> workYearsIds = Arrays.asList(2,3,4,5,6);//new ArrayList<>();
            List<Map<String, Integer>> tempPassDto = resumeDeliveryMapper.countByWorkYearsAndEducation(companySign.getCompanyId(),
                    companySign.getRecruitmentId(), educationIds, workYearsIds, null);
            List<Map<String, Integer>> tempNotSureDto = resumeDeliveryMapper.countByWorkYearsAndEducation(companySign.getCompanyId(),
                    companySign.getRecruitmentId(), educationIds, workYearsIds, InterviewResultEnum.PASS.getCode());

            Map<String, Object> resultPassDto = new HashMap<>();
            Map<String, Object> resultNoSureDto = new HashMap<>();
            int i = 1;
            for (Integer educationId: educationIds) {
                List<Integer> dataPassList = new ArrayList<>();
                List<Integer> dataNotSureList = new ArrayList<>();
                for (Integer workYearsId: workYearsIds) {
                    dataPassList.add(tempPassDto.get(i).get("num"));
                    dataNotSureList.add(tempNotSureDto.get(i).get("num"));
                    i++;
                }
                resultPassDto.put(dictService.findById(educationId).getDictValue(), dataPassList);
                resultNoSureDto.put(dictService.findById(educationId).getDictValue(), dataNotSureList);
            }
            //数据反了，到时提醒前端修改
            resultMap.put("passInfo", resultNoSureDto);
            resultMap.put("notSureInfo", resultPassDto);

            //放入横轴信息
            List<String> workYearsStrs = new ArrayList<>();
            for (Integer workYearsId: workYearsIds) {
                workYearsStrs.add(dictService.findById(workYearsId).getDictValue());
            }
            resultMap.put("xAxis", workYearsStrs);


            return ResultDtoFactory.toAck("获取统计信息成功", resultMap);
        } catch (Exception e) {
            LOGGER.error("获取统计信息出错", e);
            return ResultDtoFactory.toNack("获取统计信息出错");
        }
    }
}
