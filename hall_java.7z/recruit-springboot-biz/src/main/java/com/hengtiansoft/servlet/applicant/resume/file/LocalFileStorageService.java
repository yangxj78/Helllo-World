package com.hengtiansoft.servlet.applicant.resume.file;

import com.google.common.io.Files;
import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.constant.FTPConstant;
import com.hengtiansoft.common.converters.WordToHTMLConveter;
import com.hengtiansoft.common.converters.WordToPdfConverter;
import com.hengtiansoft.common.util.FtpUtil;
import com.hengtiansoft.servlet.applicant.resume.service.DirectoryNameGenerateStrategy;
import com.hengtiansoft.servlet.applicant.resume.service.ExtendExchangeService2;
import com.hengtiansoft.servlet.applicant.resume.service.FileNameGenerateStrategy;
import freemarker.cache.FileTemplateLoader;
import freemarker.cache.TemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;
import sun.net.ftp.FtpClient;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("local")
@Slf4j
public class LocalFileStorageService implements FileStorageService {

    public static final String FILE_PDF_TYPE = "pdf";
    public static final String FILE_HTML_TYPE = "html";
    public static final String FILE_WORD_TYPE = "doc";
    public static final String FILE_WORD_EXTEND_TYPE = "docx";

    @Value("${ftp.host}")
    private String fileServerHost;
    @Value("${file.server.port}")
    private String fileServerPort;

    @Value("${file.upload_dir?:resume/pdf}")
    private String uploadDir;

    private WordToHTMLConveter convertToHTML = new WordToHTMLConveter();
    private WordToPdfConverter convert = new WordToPdfConverter();

    private String filterFileName(String filename) {

        return filename.replaceAll("&", "").replaceAll("\\+", "").replaceAll("$", "").replaceAll("#", "");

    }

    @Override
    public String upload(InputStream inputStream, String filename, String corporateName) throws Exception {

        filename = filterFileName(filename);
        FtpUtil.uploadResume(filename, inputStream);

        return filename;
    }

    @Override
    public String uploadImage(InputStream inputStream, String folder, String fileName) throws Exception {

        fileName = filterFileName(fileName);

        String generateDirectoryName = folder + File.separator;
        return createFile(generateDirectoryName, fileName, inputStream);
    }

    @Value("${domain.url}")
    @Setter
    private String domainUrl;

    @Override
    public InputStream download(String fileName, String member) throws IllegalAccessException,
            IllegalArgumentException, FileNotFoundException, MalformedURLException, IOException {
        String path = convertToPath(fileName);
        try {
            Resource resource = new ClassPathResource(path);
            if (!resource.exists()) {
                resource = new FileSystemResource(path);
            }
            if (!resource.exists()) {
                File file = FtpUtil.retrieveFileStream(FTPConstant.RESUME_PATH, fileName);
                return new FileInputStream(file);
            }
            if (!resource.exists()) {
                throw new IllegalArgumentException("cannot locate the resouce by :" + path);
            }

            return resource.getInputStream();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            throw new MalformedURLException(e.getLocalizedMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException(e.getLocalizedMessage());
        }
    }

    private void validate(String fileName) throws IllegalAccessException {
        if (!fileName.contains(HrResume.VALIDATE_FILE) && !fileName.contains("logo") && !fileName.contains("banner")
                && !fileName.contains("news")) {
            throw new IllegalAccessException("cannot download  the file" + fileName);
        }
    }

    @Override
    public String convertToUrl(String path) {
        if (fileServerHost == null) {
            fileServerHost = "localhost";
        }
        return path;
    }

    @Override
    public String convertToPath(String url) {
        return FTPConstant.RESUME_PATH + "/" + url;
    }

    @Override
    public String upload(MailContent mailContent, boolean uploadFile, boolean toWord, String corporateName) {
        OutputStream outputStream = null;
        if (uploadFile)
            try {
                byte[] byteArray = null;
                String content = ExtendExchangeService2.messageBody2String(mailContent);
                outputStream = convert.convert(new ByteArrayInputStream(content.getBytes("UTF-8")), true, false);
                if (outputStream instanceof ByteArrayOutputStream) {
                    byteArray = ((ByteArrayOutputStream) outputStream).toByteArray();
                }
                String fileName = mailContent.getSubject().replaceAll("\\+", "");
                if (toWord) {
                    fileName += "." + FILE_WORD_TYPE;
                } else {
                    fileName += "." + FILE_HTML_TYPE;
                }
                return upload(new ByteArrayInputStream(byteArray), fileName, corporateName);
            } catch (IOException e1) {

                log.error(e1.getLocalizedMessage());
            } catch (Exception e) {

                log.error(e.getLocalizedMessage());
            }
        return null;
    }

    @Override
    public String upload(ConentType contentType, String fileName, String corporateName) throws Exception {

        fileName = filterFileName(fileName);
        String destination = null;
        String type = contentType.getType();
        if ("docx".equals(type)) {
            destination = convertToHTML.writeDocxResumeHTML(new ByteArrayInputStream(contentType.getBytes()), fileName,
                    corporateName);
        }
        if ("doc".equals(type) || "wps".equals(type)) {
            destination = convertToHTML.poiWriteHTML(new ByteArrayInputStream(contentType.getBytes()), fileName,
                    corporateName);
        }
        if ("mht".equals(type) || "htm".equals(type) || "html".equals(type)) {
            String content = contentType.getContent();
            if (content.contains("智联")) {
                content = content.replace("智联招聘", "").replace("<table cellpadding=0 cellspacing=0>",
                        "<table cellpadding=0 cellspacing=0 style='visibility:hidden'>");
                contentType.setContent(content);
            }

            destination = convertToHTML.writeHTML(content, fileName, corporateName);
        }
        return convertToUrl(destination);
    }

    @Override
    public String upload(HrResume resume, String filename, String corporateName) throws Exception {

        Map<String, Object> cont = new HashMap<String, Object>();// 存储数据
        cont.put("name", converNull(resume.getName()));
        cont.put("post", converNull(resume.getPost()));
        cont.put("phone", converNull(resume.getPhone()));
        cont.put("email", converNull(resume.getEmail()));
        cont.put("sex", converNull(resume.getSex().getDesc()));
        cont.put("years", converNull(resume.getYears()));
        cont.put("school", converNull(resume.getSchool()));
        cont.put("major", converNull(resume.getMajor()));
        cont.put("degree", converNull(resume.getDegree()));
        cont.put("graduate_date", converNull(resume.getGraduateDate()));
        cont.put("city", converNull(resume.getCity()));
        cont.put("referrer", converNull(resume.getReferrer()));
        cont.put("expect_city", converNull(resume.getExpectCity()));
        cont.put("source", converNull(resume.getSource().getDescription()));
        cont.put("staff_type", converNull(resume.getStaffType()));

        cont.put("work_expirence", converNull(resume.getWorkExpirence()));
        cont.put("project_experience", converNull(resume.getProjectExperience()));
        cont.put("education", converNull(resume.getEducation()));

        return createTemplateFile(filename, corporateName, cont);
    }

    private String converNull(String str) {
        // &是特殊符号 不提除 会导致生成的doc文件不能使用
        if (str == null) {
            str = "";
        }
        str = str.replaceAll("&", "").replaceAll("~", "-").replaceAll("\\|", "");

        return str;
    }

    private String createTemplateFile(String filename, String corporateName, Map<String, Object> cont) throws Exception {
        filename = filterFileName(filename);
        String generateDirectoryName = null;
        DirectoryNameGenerateStrategy dirGenerate = () -> {
            return null;
        };
        generateDirectoryName = HrResume.FILE_UPLOAD_RESUME + corporateName + File.separator
                + dirGenerate.generateDirectoryName(HrResume.RESUME_WORD_UPLOAD);
        String realPath = null;
        if (!new File(generateDirectoryName).exists()) {
            if (!new File(generateDirectoryName).isAbsolute()) {
                realPath = new File("").getAbsolutePath() + File.separator + generateDirectoryName;
            }
            if (!new File(realPath).mkdirs()) {
                throw new Exception("create the folder " + realPath + " fail");
            }
        }
        if (realPath == null) {
            realPath = generateDirectoryName;
        }
        FileNameGenerateStrategy fileGenerate = () -> {
            return null;
        };
        String destination = fileGenerate.generateFileName(realPath, filename);
        if (new File(destination).isFile() && !new File(destination).exists()) {
            if (!new File(destination).createNewFile()) {
                throw new Exception("create the file " + destination + " fail");
            }
        }
        File destFile = new File(destination);

        try {
            // 模板的路径
            // File fir = new File("D://aaa//");

            URL base = this.getClass().getResource("/");
            File fir = new File(base.getFile());

            // 生成文件的路径及文件名。
            // File outFile = new File("D://aaa//生成的.doc");

            Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(destFile), "UTF-8"));

            // 使用FileTemplateLoader
            // 指定模板路径
            TemplateLoader templateLoader = null;
            templateLoader = new FileTemplateLoader(fir);
            String tempname = "简历模板.xml";

            Configuration cfg = new Configuration();
            cfg.setTemplateLoader(templateLoader);
            Template t = cfg.getTemplate(tempname, "UTF-8");

            t.process(cont, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        destination = destination.replace(new File("").getAbsolutePath() + File.separator, "");
        return convertToUrl(destination);
    }

    private String createFile(String generateDirectoryName, String fileName, InputStream inputStream) throws Exception {
        String realPath = null;
        if (!new File(generateDirectoryName).exists()) {
            if (!new File(generateDirectoryName).isAbsolute()) {
                realPath = new File("").getAbsolutePath() + File.separator + generateDirectoryName;
            }
            if (!new File(realPath).mkdirs()) {
                throw new Exception("create the folder " + realPath + " fail");
            }
        }
        if (realPath == null) {
            realPath = generateDirectoryName;
        }
        FileNameGenerateStrategy fileGenerate = () -> {
            return null;
        };
        String destination = fileGenerate.generateFileName(realPath, fileName);
        if (new File(destination).isFile() && !new File(destination).exists()) {
            if (!new File(destination).createNewFile()) {
                throw new Exception("create the file " + destination + " fail");
            }
        }
        File destFile = new File(destination);
        try {
            Files.createParentDirs(destFile);
            Files.write(IOUtils.toByteArray(inputStream), destFile);

        } catch (IOException e) {
            e.printStackTrace();
        }
        destination = destination.replace(new File("").getAbsolutePath() + File.separator, "");
        return convertToUrl(destination);
    }

}
