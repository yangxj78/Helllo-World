package com.hengtiansoft.servlet.applicant.resume.template.boss;

import com.hengtiansoft.servlet.applicant.resume.resume.BossResume;

public class BossDefaultTemplate extends BossResume {

}
