package com.hengtiansoft.servlet.applicant.resume.template.liepin;

import com.hengtiansoft.servlet.applicant.resume.resume.LiePinResume;

public class LiePinMailTemplate extends LiePinResume {

}
