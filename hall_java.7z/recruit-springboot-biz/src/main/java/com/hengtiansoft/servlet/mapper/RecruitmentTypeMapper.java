package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.RecruitmentType;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RecruitmentTypeMapper extends MyMapper<RecruitmentType> {
    List<RecruitmentType> search(String name);
    int updateByID(RecruitmentType recruitmentType);
}