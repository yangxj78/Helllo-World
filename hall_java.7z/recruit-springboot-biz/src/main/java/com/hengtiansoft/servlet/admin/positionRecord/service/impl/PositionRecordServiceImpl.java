package com.hengtiansoft.servlet.admin.positionRecord.service.impl;

import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.NumberDto;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.dataModel.PositionRecordSearch;
import com.hengtiansoft.bean.dataModel.PositionSearch;
import com.hengtiansoft.bean.tableModel.*;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.bookBooth.service.BoothService;
import com.hengtiansoft.servlet.admin.common.service.UpdateNumberService;
import com.hengtiansoft.servlet.admin.position.service.PositionService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.mapper.BookBoothMapper;
import com.hengtiansoft.servlet.mapper.BookBoothPositionRecordMapper;
import com.hengtiansoft.servlet.mapper.PositionRecordMapper;
import com.hengtiansoft.servlet.mapper.RecruitmentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;


@Service
@Transactional
public class PositionRecordServiceImpl extends BaseService<PositionRecord> implements PositionRecordService {


    @Autowired
    PositionRecordMapper positionRecordMapper;
    @Autowired
    BoothService boothService;

    @Autowired
    BookBoothMapper bookBoothMapper;

    @Autowired
    RecruitmentMapper recruitmentMapper;
    @Autowired
    UpdateNumberService updateNumberService;
    @Autowired
    PositionService positionService;
    @Autowired
    BookBoothPositionRecordMapper bookBoothPositionRecordMapper;

    @Override
    public List<PositionRecord> listPositionRecord(PositionRecordSearch positionRecordSearch) {
        return positionRecordMapper.listPositionRecord(positionRecordSearch);
    }

    @Override
    //根据positionid从position表中查询  然后插入进position_record表 判断此展位是否存在这个岗位
    // 若存在添加失败 在判断此公司其他展位是否存在这个岗位 若有则取id 无则添加
    public ResultDto batchAdd(List<PositionRecordDto> positionRecordDtos) {
        PositionRecordSearch search = new PositionRecordSearch();
        Set set = new HashSet();
        List<PositionRecordDto> ls3 = new LinkedList();
        int recruitmentID = 0;
        String name = SecurityContext.getCurrentUser().getUsername();
        for (PositionRecordDto positionRecordDto : positionRecordDtos) {

            Position position = positionService.selectByID(positionRecordDto.getPositionID());
            if (null == position) {
                return ResultDtoFactory.toNack("添加失败");
            }
            positionRecordDto.setName(position.getName());
            positionRecordDto.setDescription(null == position.getDescription() ? "无描述" : position.getDescription());
            positionRecordDto.setRecruitNumber(position.getRecruitNumber());
            positionRecordDto.setSalaryID(position.getSalaryId());
            positionRecordDto.setEducationID(position.getEducationId());
            positionRecordDto.setWorkingYearsID(position.getWorkingYearsId());
            positionRecordDto.setProperty(position.getProperty());
            positionRecordDto.setTagID(position.getTagID());
            positionRecordDto.setsRegionID(position.getsRegionID());
            recruitmentID = positionRecordDto.getRecruitmentID();
            search.setRecruitmentID(recruitmentID);
            search.setName(positionRecordDto.getName());
            search.setCompanyID(positionRecordDto.getCompanyID());
            List<PositionRecord> ls2 = positionRecordMapper.listPositionRecord(search);
            if (ls2.size() != 0) {
                ls2.forEach(n -> set.add(n.getBoothID()));
                if (set.contains(positionRecordDto.getBoothID())) {
                    return ResultDtoFactory.toNack("添加失败" + positionRecordDto.getBoothID() + "展位已存在" + positionRecordDto.getName());
                }
                PositionRecord positionRecord = ls2.get(0);
                positionRecordDto.setId(positionRecord.getId());
                positionRecordMapper.updatePositionRecord(positionRecordDto);
                positionRecordDto.setCreateBy(name);
                positionRecordDto.setId(positionRecord.getId());
                positionRecordDto.setOrder(0);
                ls3.add(positionRecordDto);
                set.clear();
            } else {
                positionRecordDto.setCreateBy(name);


                positionRecordMapper.add(positionRecordDto);

                positionRecordDto.setId(positionRecordDto.getId());
                positionRecordDto.setOrder(0);
                ls3.add(positionRecordDto);
            }
        }
        boothService.addPositionRecord(ls3);
        //更新招聘会数据
        NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(recruitmentID);
        updateNumberService.updateRecruitmentNumber(numberDto);

        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentID);
        if (recruitment.getStartType() == 1) {
            if (positionRecordDtos.size() != 0) {
                Map map = new HashMap();
                map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
                NettyClientUtil.notifyTv(positionRecordDtos.get(0).getBoothID(), JSON.toJSONString(map));
            }
        }
        return ResultDtoFactory.toAck("添加成功");
    }

    @Override
    //获取本场招聘会这个公司 这个名称的岗位 所在的展位 如果这个展位存在相同名字的岗位 则添加失败
    //如果本公司其他展位存在这个岗位 则获取岗位记录id 否则先插入岗位记录表获取生成id 在插入岗位表 若岗位表存在相同名字的则更新
    public ResultDto add(PositionRecordDto positionRecordDto) {
        positionRecordDto.setName(positionRecordDto.getName().trim());
        positionRecordDto.setSelectOrder(0);
        PositionRecordSearch search = new PositionRecordSearch();
        Set set = new HashSet();
        String name = SecurityContext.getCurrentUser().getUsername();

        int recruitmentID = positionRecordDto.getRecruitmentID();
        List<PositionRecordDto> ls3 = new LinkedList<>();
        search.setRecruitmentID(recruitmentID);
        search.setName(positionRecordDto.getName());
        search.setCompanyID(positionRecordDto.getCompanyID());
        List<PositionRecord> ls2 = positionRecordMapper.listPositionRecord(search);

        PositionSearch search2 = new PositionSearch();
        search2.setCompanyID(positionRecordDto.getCompanyID());
        search2.setName(positionRecordDto.getName());
        List<Position> ls = positionService.search(search2);
        if (ls.size() == 0) {
            positionRecordDto.setCreateBy(name);

            positionService.add(positionRecordDto);
        } else {
            Position position = ls.get(0);
            position.setRecruitNumber(positionRecordDto.getRecruitNumber());
            position.setDescription(positionRecordDto.getDescription());
            position.setUpdateBy(positionRecordDto.getCreateBy());
            position.setEducationId(positionRecordDto.getEducationID());
            position.setSalaryId(positionRecordDto.getSalaryID());
            position.setsRegionID(positionRecordDto.getsRegionID());
            positionService.updateByID(position);
        }
        if (ls2.size() != 0) {
            ls2.forEach(n -> set.add(n.getBoothID()));
            if (set.contains(positionRecordDto.getBoothID())) {
                return ResultDtoFactory.toNack("展位" + positionRecordDto.getBoothID() + "已存在" + positionRecordDto.getName());
            }
            PositionRecord positionRecord = ls2.get(0);
            positionRecordDto.setId(positionRecord.getId());
            positionRecordMapper.updatePositionRecord(positionRecordDto);
            ls3.add(positionRecordDto);
            set.clear();
            boothService.addPositionRecord(ls3);
        } else {
            positionRecordDto.setCreateBy(name);

            positionRecordMapper.add(positionRecordDto);

            positionRecordDto.setId(positionRecordDto.getId());

            ls3.add(positionRecordDto);
            boothService.addPositionRecord(ls3);
            //更新招聘会的企业数，岗位数，招聘人数
            NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(recruitmentID);
            updateNumberService.updateRecruitmentNumber(numberDto);
        }
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentID);
        if (recruitment.getStartType() == 1) {
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
            NettyClientUtil.notifyTv(positionRecordDto.getBoothID(), JSON.toJSONString(map));
        }
        return ResultDtoFactory.toAck("插入成功");
    }

    @Override
    //更新岗位记录的同时更新岗位库
    public int updatePositionRecord(PositionRecordDto positionRecordDto) {
        String name = SecurityContext.getCurrentUser().getUsername();
        positionRecordDto.setUpdateBy(name);
        PositionSearch search = new PositionSearch();
        positionRecordMapper.updatePositionRecord(positionRecordDto);
        search.setName(positionRecordDto.getOldName());
        search.setCompanyID(positionRecordDto.getCompanyID());
        List<Position> ls = positionService.search(search);

        if (ls.size() != 0) {
            Position position = ls.get(0);
            position.setRecruitNumber(positionRecordDto.getRecruitNumber());
            position.setName(positionRecordDto.getName());
            position.setDescription(positionRecordDto.getDescription());
            position.setUpdateBy(positionRecordDto.getCreateBy());
            position.setEducationId(positionRecordDto.getEducationID());
            position.setWorkingYearsId(positionRecordDto.getWorkingYearsID());
            position.setSalaryId(positionRecordDto.getSalaryID());
            position.setsRegionID(positionRecordDto.getsRegionID());
            position.setTagID(positionRecordDto.getTagID());
            position.setProperty(positionRecordDto.getProperty());
            positionService.updateByID(position);
        }
        search.setName(positionRecordDto.getName());
        List<Position> ls2 = positionService.search(search);
        if (ls2.size() > 1) {
            throw new RuntimeException();
        }
        //更新招聘会的企业数，岗位数，招聘人数
        NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(positionRecordDto.getRecruitmentID());
        updateNumberService.updateRecruitmentNumber(numberDto);
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(positionRecordDto.getRecruitmentID());
        if (recruitment.getStartType() == 1) {
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
            List<Integer> booth = bookBoothMapper.getBooth(positionRecordDto.getRecruitmentID(), positionRecordDto.getId());
            booth.forEach(n -> NettyClientUtil.notifyTv(n, JSON.toJSONString(map)));
        }
        return 1;
    }

    @Override
    public int deleteByID(int bookBoothID, int positionRecordID, int recruitmentID) {
        BookBoothPositionRecord bookBoothPositionRecord = new BookBoothPositionRecord();
        bookBoothPositionRecord.setBookBoothId(bookBoothID);
        bookBoothPositionRecord.setPositionRecordId(positionRecordID);
        positionRecordMapper.deleteByID(bookBoothPositionRecord);
        NumberDto numberDto = recruitmentMapper.findRecruitmentNumber(recruitmentID);
        updateNumberService.updateRecruitmentNumber(numberDto);
        BookBooth bookBooth = bookBoothMapper.selectByPrimaryKey(bookBoothID);
        Recruitment recruitment = recruitmentMapper.selectByPrimaryKey(recruitmentID);
        if (recruitment.getStartType() == 1) {
            Map map = new HashMap();
            map.put("nettyType", NettyInfoEnum.POSITION_UPDATE.getCode());
            NettyClientUtil.notifyTv(bookBooth.getBoothID(), JSON.toJSONString(map));
        }
        return 1;
    }

    @Override
    public int updateOrder(PositionRecordDto positionRecordDto) {
        return bookBoothPositionRecordMapper.updateOrder(positionRecordDto);
    }

    @Override
    public PositionRecord getByID(int id) {
        return positionRecordMapper.selectByPrimaryKey(id);
    }

    @Override
    public Boolean check(Integer positionID) {
        if (positionRecordMapper.check(positionID).size() != 0) {
            return false;
        }
        return true;
    }
}
