package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.UpdateTs;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;


@Repository
public interface UpdateTsMapper extends MyMapper<UpdateTs> {
}