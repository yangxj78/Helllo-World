package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.BookBoothPositionRecord;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface PositionRecordMapper extends MyMapper<PositionRecord> {

    List<PositionRecord> listPositionRecord(PositionRecordSearch positionRecordSearch);
    int add(PositionRecordDto positionRecordDto);
    int updatePositionRecord(PositionRecordDto positionRecordDto);
    int deleteByID(BookBoothPositionRecord bookBoothPositionRecord);
    List<PositionRecordIDAndName> getPositionRecordIDAndNames(CompanySearch companySearch);

    List<HRPositionRecordDto> findCurrentPosition(@Param("boothId") Integer boothId,
                                                  @Param("companyId") Integer companyId,
                                                  @Param("recruitmentId") Integer recruitmentId,
                                                  @Param("index") Integer index,
                                                  @Param("limit") Integer limit);


    List<HRPositionRecordDto> findAuditPosition(@Param("boothId") Integer boothId,
                                                  @Param("companyId") Integer companyId,
                                                  @Param("recruitmentId") Integer recruitmentId,
                                                  @Param("status") Integer status,
                                                  @Param("index") Integer index,
                                                  @Param("limit") Integer limit);


    List<JobSeekerDto> findDeliveryList(@Param("companyId") Integer companyId,
                                               @Param("recruitmentId") Integer recruitmentId,
                                               @Param("positionRecordId") Integer positionRecordId,
                                               @Param("index") Integer index,
                                               @Param("limit") Integer limit);

    List<Integer> check(Integer positionID);
}