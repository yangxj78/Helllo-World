package com.hengtiansoft.servlet.hr.count.controller;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.InterviewDeliveryDto;
import com.hengtiansoft.bean.dataModel.InterviewSearchDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.hr.count.service.CountService;
import com.hengtiansoft.servlet.hr.delivery.service.DeliveryService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Api(value="面试结果统计", description = "面试结果统计相关接口")
@RestController
@RequestMapping("/hr/count")
public class CountController {

    @Autowired
    CountService countService;

    @ApiOperation(value = "获取投递信息统计", httpMethod = "GET")
    @RequestMapping(value = "/findDeliveryInfo", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Map> findDeliveryInfo() {
        return countService.findDeliveryInfo();
    }


    @ApiOperation(value = "获取职位信息统计", httpMethod = "GET")
    @RequestMapping(value = "/findPositionInfo", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<Map<String, Object>>> findPositionInfo() {
        return countService.findPositionInfo();
    }

    @ApiOperation(value = "获取工作年限学历统计", httpMethod = "GET")
    @RequestMapping(value = "/findWorkYearsAndEduInfo", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<Map> findWorkYearsAndEduInfo() {
        return countService.findWorkYearsAndEduInfo();
    }
}
