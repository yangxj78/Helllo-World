package com.hengtiansoft.servlet.admin.company.service.impl;


import com.alibaba.fastjson.JSON;
import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.CompanySearch;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.CompanyPicture;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.enumeration.NettyInfoEnum;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.netty.NettyClientUtil;
import com.hengtiansoft.servlet.admin.company.service.CompanyPictureService;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.manage.companySign.CompanySignService;
import com.hengtiansoft.servlet.mapper.BookBoothMapper;
import com.hengtiansoft.servlet.mapper.CompanyMapper;
import com.hengtiansoft.servlet.mapper.PositionRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CompanyServiceImpl extends BaseService<Company> implements CompanyService {

    @Autowired
    BookBoothMapper bookBoothMapper;

    @Autowired
    CompanyMapper companyMapper;

    @Autowired
    PositionRecordMapper positionRecordMapper;

    @Autowired
    RecruitmentService recruitmentService;
    @Autowired
    CompanyPictureService companyPictureService;
    @Autowired
    CompanySignService companySignService;

    @Override
    public List check(BoothSearch boothSearch) {
        return bookBoothMapper.check(boothSearch);
    }

    @Override
    public List<Company> getAll(CompanySearch companySearch) {
        List<Company> ls = companyMapper.getAll(companySearch);
        ls.forEach(n -> n.setPictures(companyPictureService.getPictures(n.getId())));
        return ls;
    }

    @Override
    public int createCompany(Company company) {
        String name = SecurityContext.getCurrentUser().getUsername();
        company.setCreateBy(name);
        company.setUpdateBy(name);
        company.setStatus(0);
        company.setCreateTs(new Date(System.currentTimeMillis()));
        return companyMapper.createCompany(company);
    }

    @Override
    public int updateCompany(Company company) {
        String name = SecurityContext.getCurrentUser().getUsername();
        company.setUpdateBy(name);
        Map map = new HashMap();
        map.put("nettyType", NettyInfoEnum.COMPANY_UPDATE.getCode());
        Recruitment currentRecruitment = recruitmentService.getCurrentRecruitment();
        if (currentRecruitment != null) {
            List<Integer> boothByCompany = companySignService.findBoothByCompany(currentRecruitment.getId(), company.getId());
            boothByCompany.forEach(n -> NettyClientUtil.notifyTv(n, JSON.toJSONString(map)));
        }
        return companyMapper.updateCompany(company);
    }

    @Override
    public int deleteCompany(Integer id) {
        return companyMapper.updateById(id);
    }

    @Override
    public Company getById(int id) {
        CompanyPicture companyPicture = new CompanyPicture();
        companyPicture.setCompanyId(id);
        List<String> ls = companyPictureService.getPictures(id);
        Company company = companyMapper.getById(id);
        if (company == null) {
            return null;
        }
        company.setPictures(ls);
        return company;
    }

    @Override
    public List<Company> listByRecruitment(CompanySearch companySearch) {
        return companyMapper.listByRecruitment(companySearch);
    }

    @Override
    public Company getRecruimentDetail(CompanySearch companySearch) {
        Company company = getById(companySearch.getCompanyID());
        company.setPositionRecordIDAndNames(positionRecordMapper.getPositionRecordIDAndNames(companySearch));
        return company;
    }


}
