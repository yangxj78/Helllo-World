package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.Recycle;
import com.hengtiansoft.config.MyMapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface RecycleMapper extends MyMapper<Recycle> {
    void deleteAll();
    List<Recycle> list();
}