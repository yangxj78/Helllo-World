package com.hengtiansoft.servlet.applicant.resumeDeliveryPre.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryPreDto;

public interface DeliveryPreService {

    ResultDto prePostResume(ResumeDeliveryPreDto resumeDeliveryPreDto);
}
