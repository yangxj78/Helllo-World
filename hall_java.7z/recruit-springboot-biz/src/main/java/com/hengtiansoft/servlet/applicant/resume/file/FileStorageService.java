package com.hengtiansoft.servlet.applicant.resume.file;

import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

public interface FileStorageService {

    String upload(MailContent mailContent, boolean uploadFile, boolean toWord, String corporateName);

    String upload(InputStream inputStream, String filename, String corporateName) throws Exception;

    InputStream download(String url, String member) throws IllegalAccessException, FileNotFoundException,
            MalformedURLException, IOException;

    String convertToUrl(String path);

    String convertToPath(String url);

    String upload(ConentType contentType, String fileName, String corporateName) throws Exception;

    String upload(HrResume resume, String filename, String corporateName) throws Exception;

    String uploadImage(InputStream inputStream, String folder, String fileName) throws Exception;

}
