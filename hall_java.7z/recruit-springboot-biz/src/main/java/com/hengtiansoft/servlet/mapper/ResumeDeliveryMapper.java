package com.hengtiansoft.servlet.mapper;


import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.ResumeDelivery;
import com.hengtiansoft.bean.tableModel.ResumeDeliveryPre;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface ResumeDeliveryMapper extends MyMapper<ResumeDelivery> {


    List<PositionRecordDto> findDeliveryPositions(@Param("boothId") Integer boothId,
                                                  @Param("recruitmentId") Integer recruitmentId);

    /**
     * 获取待面列表
     *
     * @param boothId
     * @param recruitmentId
     * @param interviewSearchDto
     * @return
     */
    List<InterviewDeliveryDto> findReadyByCon(@Param("boothId") Integer boothId,
                                              @Param("recruitmentId") Integer recruitmentId,
                                              @Param("searchDto") InterviewSearchDto interviewSearchDto);

    /**
     * 获取已面列表
     *
     * @param boothId
     * @param recruitmentId
     * @param interviewSearchDto
     * @return
     */
    List<InterviewDeliveryDto> findFinishByCon(@Param("boothId") Integer boothId,
                                               @Param("recruitmentId") Integer recruitmentId,
                                               @Param("searchDto") InterviewSearchDto interviewSearchDto);

    List<InterviewDeliveryDto> findAllotRecord(@Param("boothId") Integer boothId,
                                               @Param("recruitmentId") Integer recruitmentId,
                                               @Param("searchDto") InterviewSearchDto interviewSearchDto);

    List<Map<Integer, Integer>> getBooths(@Param("status") Integer status,
                                          @Param("companyId") Integer companyId,
                                          @Param("recruitmentId") Integer recruitmentId);


    int countAllByCon(@Param("status") Integer status,
                      @Param("boothId") Integer boothId,
                      @Param("recruitmentId") Integer recruitmentId,
                      @Param("searchDto") InterviewSearchDto interviewSearchDto);


    InterviewDeliveryDto findFirst(@Param("boothId") Integer boothId,
                                   @Param("recruitmentId") Integer recruitmentId);


    InterviewDeliveryDto getCurrentInterviewer(@Param("boothId") Integer boothId,
                                               @Param("recruitmentId") Integer recruitmentId);

    InterviewDeliveryDto getLastInterviewer(@Param("boothId") Integer boothId,
                                            @Param("recruitmentId") Integer recruitmentId);

    InterviewDeliveryDto getStartingInterviewer(@Param("boothId") Integer boothId,
                                                @Param("recruitmentId") Integer recruitmentId);


    int updatePassList(@Param("boothId") Integer boothId,
                       @Param("recruitmentId") Integer recruitmentId,
                       @Param("id") Integer id,
                       @Param("newOrderNum") Integer newOrderNum);

    int updateAllotList(@Param("boothId") Integer boothId,
                        @Param("recruitmentId") Integer recruitmentId,
                        @Param("orderNum") Integer orderNum);


    Integer findLastOrderNum(@Param("boothId") Integer boothId,
                             @Param("recruitmentId") Integer recruitmentId);


    List<Integer> findDeliveryInfo(@Param("companyId") Integer companyId,
                                   @Param("recruitmentId") Integer recruitmentId);

    List<Map<String, Object>> findPositionInfo(@Param("companyId") Integer boothId,
                                               @Param("recruitmentId") Integer recruitmentId);


    int countDeliveryAll(@Param("boothId") Integer boothId,
                         @Param("recruitmentId") Integer recruitmentId);

    int countByCompanyAndRecruitment(@Param("companyId") Integer companyId,
                                     @Param("recruitmentId") Integer recruitmentId);

    int countResume(@Param("resumeId") Integer resumeId,
                    @Param("recruitmentId") Integer recruitmentId);

    int countByPositionId(@Param("id") Integer id);

    @Select("SELECT * FROM resume_delivery rd WHERE rd.recruitment_id = #{recruitmentId} AND rd.company_id  = #{companyId} AND rd.user_id = #{userId} AND rd.position_record_id = #{positionRecordId} AND rd.interview_status = 2 ORDER BY rd.interview_num")
    List<ResumeDelivery> findInterviewResultByParentId(@Param("recruitmentId") Integer recruitmentId,
                                                       @Param("companyId") Integer companyId,
                                                       @Param("userId") Integer userId,
                                                       @Param("positionRecordId") Integer positionRecordId);

    @Select("SELECT * FROM resume_delivery rd WHERE rd.id = 10116 AND rd.interview_status > 1 limit 1")
    ResumeDelivery findInterviewResultById(@Param("id") Integer id);

    @Select("SELECT * FROM resume_delivery rd WHERE rd.parent_booth_id = 1 AND rd.interview_status > 1 ORDER BY rd.interview_num")
    List<ResumeDelivery> findInterviewResultByParentId2(@Param("id") Integer parentId);

    @Select("SELECT distinct(recruitment_id) FROM resume_delivery rd WHERE   update_ts > #{updateTs} ")
    List<Integer> getUpdateRecruitment(String updateTs);

    Recruitment getUpdateNumber(@Param("recruitmentID") Integer recruitmentID);

    @Select("select max(update_ts) from resume_delivery")
    String maxCreateTs();

    List<Map<String, Integer>> countByWorkYearsAndEducation(@Param("companyId") Integer companyId,
                                                            @Param("recruitmentId") Integer recruitmentId,
                                                            @Param("educationIds") List<Integer> educationIds,
                                                            @Param("workYearsIds") List<Integer> workYearsIds,
                                                            @Param("interviewResult") Integer interviewResult);

    List<AmountDto> findPositionRecordTop5(@Param("recruitmentId") Integer recruitmentId);

    List<Map<String, Integer>> findDeliveryUserWorkYears(@Param("recruitmentId") Integer recruitmentId);


    /**
     * 获取用户投递数 根据resume_id,position_record_id去重
     */
    @Select("select count(distinct resume_id,position_record_id) from resume_delivery where user_id = #{userId} and recruitment_id = #{recruitmentId}")
    int countByUser(@Param("userId") Integer userId, @Param("recruitmentId") Integer recruitmentId);

    List<ResumeDeliveryPreDataDto> findDeliveryPreDataByUserId(CollectionPositionSearchDto searchDto);

    List<ResumeDeliveryDate2Dto> findDeliveryInfoByUserId(CollectionPositionSearchDto searchDto);

    List<RecruitmentSearchDto> listDeliveryRecruitmentSearchs(@Param("userId") Integer userId);

    List<RecruitmentSearchDto> listDeliveryPreRecruitmentSearchs(@Param("userId") Integer userId);

    ResumeDeliveryDate2Dto getDeliverySuccessInfo(@Param("userId") Integer userId, @Param("positionRecordId") Integer positionRecordId);

    ResumeDeliveryPreDataDto getDeliveryPreSuccessInfo(@Param("userId") Integer userId, @Param("positionRecordId") Integer positionRecordId);

    List<Map<String, String>> findResumeIdsAndUserIds(@Param("companyId") Integer companyId,
                                                      @Param("recruitmentId") Integer recruitmentId,
                                                      @Param("interviewResult") Integer interviewResult);


    Integer findIsDeliveryed(@Param("boothId") Integer boothId, @Param("recruitmentId") Integer recruitmentId);


    InterviewDeliveryDto findCurrentApplicant(@Param("id") Integer id);

    InterviewDeliveryDto findNextApplicant(@Param("id") Integer id);

    List<ResumeDeliveryPre> findResumeDeliveryPre(@Param("boothID") Integer boothID, @Param("recruitmentID") Integer recruitmentID);

    Integer getDeliveryCount(@Param("recruitmentId") Integer recruitmentId);

    List<ResumeDeliveryDetail> getResumeDeliveryDetail(ResumeDeliverySearch resumeDeliverySearch);

    List<ResumDeliveryResult> getResumeDeliveryDetailByBoothId(ResumeDeliveryDetailSearch resumeDeliverySearch);

    List<ResumDeliveryPREResult> getResumeDeliveryDetailPRE(ResumeDeliveryDetailSearch resumeDeliverySearch);

    ResumDeliveryPRENum getCount(@Param("recruitmentId") Integer recruitmentId, @Param("date") String date);

    @Select("SELECT distinct(recruitment_id) FROM resume_delivery_pre rd WHERE   create_ts > #{updateTs} ")
    List<Integer> getUpdateRecruitmentPRE(String lastUpdateTs);

    Recruitment getUpdateNumberPRE(@Param("recruitmentID") Integer recruitmentID,@Param("date") String date);

    @Select("select max(create_ts) from resume_delivery_pre")
    String maxCreateTsPRE();

    MaxEdu getMaxEdu(Integer resumeId);
}