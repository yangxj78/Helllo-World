package com.hengtiansoft.servlet.applicant.qrcode.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryDto;
import com.hengtiansoft.bean.dataModel.SmsDto;
import com.hengtiansoft.bean.dataModel.ZJRecordDto;
import com.hengtiansoft.bean.tableModel.QrCode;
import com.hengtiansoft.bean.tableModel.QrCodeRecord;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.ResumeDeliveryPre;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.SmsTypeEnum;
import com.hengtiansoft.common.enumeration.StatusEnum;
import com.hengtiansoft.common.util.DateTimeUtil;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.common.utils.HttpUtil;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.qrcode.service.QrCodeService;
import com.hengtiansoft.servlet.applicant.recruitment.service.CacheService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.manage.sms.SmsService;
import com.hengtiansoft.servlet.mapper.QrCodeMapper;
import com.hengtiansoft.servlet.mapper.QrCodeRecordMapper;
import com.hengtiansoft.servlet.mapper.ResumeDeliveryPreMapper;
import com.hengtiansoft.servlet.mapper.UserInfoMapper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class QrCodeServiceImpl implements QrCodeService {


    @Autowired
    QrCodeMapper qrCodeMapper;
    @Autowired
    QrCodeRecordMapper qrCodeRecordMapper;
    @Autowired
    SmsService smsService;
    @Autowired
    ResumeDeliveryPreMapper resumeDeliveryPreMapper;
    @Autowired
    ResumeService resumeService;
    @Autowired
    RecruitmentService recruitmentService;
    @Autowired
    UserInfoMapper userInfoMapper;
    @Autowired
    CacheService cacheService;

    @Value("${qrcode.url}")
    private String qrCodeUrl;
    @Override
    public ResultDto generateCompanyQrCode() {
        JSONObject object = getQrCodeNumber();
        if (object == null
                || StringUtils.isEmpty(object.getString("cardNumber"))) {
            return ResultDtoFactory.toNack("闸机卡号无法获取");
        }
        return ResultDtoFactory.toAck("success", object.getString("cardNumber"));
    }


    @Override
    public ResultDto generateQrCode(Integer userId) {

        JSONObject object = getQrCodeNumber();
        if(object == null
                || StringUtils.isEmpty(object.getString("cardNumber"))){
            return ResultDtoFactory.toNack("闸机卡号无法获取");
        }
        String code = object.getString("cardNumber");
        QrCode qrCode = new QrCode();
        qrCode.setUserId(userId);
        qrCode = qrCodeMapper.selectOne(qrCode);
        if (qrCode == null) {
            qrCode = new QrCode();
            qrCode.setUserId(userId);
            qrCode.setCode(code);
            qrCode.setJumpType(StatusEnum.NO.getCode());
            qrCodeMapper.insertUseGeneratedKeys(qrCode);
        }else{
            qrCode.setCode(code);
            qrCodeMapper.updateByPrimaryKey(qrCode);
        }
        return ResultDtoFactory.toAck("success", qrCode);
    }

    @Override
    @Transactional
    public boolean record(ZJRecordDto zjRecordDto) {

        Recruitment recruitment = recruitmentService.getCurrentRecruitment();
        QrCode qrCode = qrCodeMapper.findByCode(zjRecordDto.getCardNumber());
        if (zjRecordDto.isOpenResult() && recruitment != null && qrCode != null) {
            QrCodeRecord qrCodeRecord = new QrCodeRecord();
            qrCodeRecord.setQrCodeId(qrCode.getId());
            qrCodeRecord.setRecruitmentId(recruitment.getId());
            qrCodeRecord.setType(zjRecordDto.getEnterOrExist());
            qrCodeRecord.setCreateTs(zjRecordDto.getOpenTime());
            qrCodeRecordMapper.insertUseGeneratedKeys(qrCodeRecord);
            //入场扫码页面跳转
            if(zjRecordDto.getEnterOrExist().equals(MagicNumConstant.ONE)){
                qrCode.setJumpType(StatusEnum.YES.getCode());
                qrCodeMapper.updateByPrimaryKey(qrCode);
            }
            if (resumeDelivery(qrCode.getUserId(), recruitment.getId())) {
                //发送短信提醒
                sendMessage(qrCode.getUserId());
            }
            return true;
        }
        return false;
    }

    /**
     * 查询预投递，并实现真的投递
     */
    @Transactional
    public boolean resumeDelivery(Integer userId, Integer recruitmentId) {
        List<ResumeDeliveryPre> resumeDeliveryPres = resumeDeliveryPreMapper.selectResumePre(userId, recruitmentId);
        if (!CollectionUtils.isEmpty(resumeDeliveryPres)) {
            for (ResumeDeliveryPre resumeDeliveryPre : resumeDeliveryPres) {
                ResumeDeliveryDto resumeDeliveryDto = new ResumeDeliveryDto();
                ConvertToDeliveryDto(resumeDeliveryDto, resumeDeliveryPre);
                resumeService.postResume(resumeDeliveryDto);
                resumeDeliveryPreMapper.updateDeliveryFlag(userId, recruitmentId);
            }
            return true;
        }
        return false;
    }

    /**
     * ResumeDeliveryPre转化成ResumeDeliveryDto
     */
    private void ConvertToDeliveryDto(ResumeDeliveryDto resumeDeliveryDto, ResumeDeliveryPre resumeDeliveryPre) {
        resumeDeliveryDto.setBoothId(resumeDeliveryPre.getBoothId());
        resumeDeliveryDto.setCompanyId(resumeDeliveryPre.getCompanyId());
        resumeDeliveryDto.setPositionRecordId(resumeDeliveryPre.getPositionRecordId());
        resumeDeliveryDto.setRecruitmentId(resumeDeliveryPre.getRecruitmentId());
        resumeDeliveryDto.setResumeId(resumeDeliveryPre.getResumeId());
        resumeDeliveryDto.setUserId(resumeDeliveryPre.getUserId());
    }

    /**
     * 短信提醒用户
     */
    private void sendMessage(Integer userId) {
        SmsDto smsDto = new SmsDto();
        smsDto.setMobile(userInfoMapper.selectPhoneByUserId(userId));
        smsDto.setSmsInfo("您有简历投递记录，请打开面试查询页面查询。");
        smsDto.setType(SmsTypeEnum.QR_CODE.getCode());
        smsDto.setUserId(userId);
        smsService.send(smsDto);
    }

    @Override
    public boolean out() {
        Recruitment recruitment = recruitmentService.getCurrentRecruitment();
        if (recruitment == null) {
            return false;
        }
        QrCodeRecord qrCodeRecord = new QrCodeRecord();
        qrCodeRecord.setRecruitmentId(recruitment.getId());
        qrCodeRecord.setType(0);
        qrCodeRecordMapper.insertUseGeneratedKeys(qrCodeRecord);
        return true;
    }


    private JSONObject getQrCodeNumber(){
        String url = qrCodeUrl;
        //设置有效期
        String endTime = DateTimeUtil.dateFormat(DateUtil.offsetMonth(new Date(),3));

        Map<String,String> postHeaders = new HashMap<>();
        postHeaders.put("Accept","*/*");
        postHeaders.put("Content-Type","application/json");
        Map<String,String> postParams = new HashMap<>();
        postParams.put("endTime",endTime);
        return new HttpUtil().postRequest(url,postHeaders,postParams);
    }

    @Override
    public boolean hasRecord(Integer id) {
        if(qrCodeMapper.findTypeById(id)){
            qrCodeMapper.updateTypeById(id);
            return true;
        }
        return false;
    }

    @Override
    public boolean hasSignIn(Integer userId, Integer positionRecordId) {
        return qrCodeRecordMapper.hasSignIn(userId, positionRecordId);
    }
}
