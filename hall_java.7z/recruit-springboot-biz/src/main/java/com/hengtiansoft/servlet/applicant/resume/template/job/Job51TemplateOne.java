package com.hengtiansoft.servlet.applicant.resume.template.job;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.apache.commons.lang3.StringUtils;

public class Job51TemplateOne extends Job51Resume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content);
        String updateDate = getUpdateDate(content);
        String name = null;
        if (content.contains("流程状态")) {
            name = fieldTrim(strSubstring(content, updateDate, "流程状态")).replaceAll(" ", "");
        }
        if (!StringUtils.isEmpty(name) && name.contains("匹配度")) {
            name = name.substring(name.indexOf("%")).replace("%", "");
        }
        String year = getWorkedYears(content);
        String number = getNumber(content);
        String phone = getPhone(content);
        String info = content.substring(content.indexOf(phone));

        String[] infos = info.substring(BEGIN_OFF_SET_ZERO, info.indexOf("工作经验")).split("\\|");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (str.contains("现居住")) {
                city = str.replace("现居住", "");
            }
        }
        r.setName(name);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.JOB51UPLOAD);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;
        content = content.substring(content.indexOf("求职意向"), content.length());

        if (content.contains("工作经验")) {
            int index = content.length();
            if (content.contains("项目经验")) {
                index = content.indexOf("项目经验");
            } else if (content.contains("教育经历")) {
                index = content.indexOf("教育经历");
            }

            workExperience = content.substring(content.indexOf("工作经验"), index);
        }
        if (content.contains("项目经验")) {
            int index = content.length();
            if (content.contains("教育经历")) {
                index = content.indexOf("教育经历");
            }

            projectExperience = content.substring(content.indexOf("项目经验"), index);
        }
        if (content.contains("教育经历")) {
            int index = content.length();
            education = content.substring(content.indexOf("教育经历"), index);
        }

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    };

}
