package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.dataModel.BoothSearch;
import com.hengtiansoft.bean.dataModel.CompanyDto;
import com.hengtiansoft.bean.dataModel.PositionRecordDto;
import com.hengtiansoft.bean.tableModel.BookBooth;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookBoothMapper extends MyMapper<BookBooth> {
    List<Company> check(BoothSearch boothSearch);
    int  bookBooth (BookBooth bookBooth);
    int addPositionRecord(List<PositionRecordDto> positionRecordDtos);
    CompanyDto findNumber(BookBooth bookBooth);
    int updateByID(BookBooth bookBooth );

    List<CompanySign> getCaptchaCompany(Integer recruitmentID);


    @Select("SELECT bb.id FROM book_booth bb WHERE bb.recruitment_id = #{recruitmentId} AND bb.company_id = #{companyId} AND bb.booth_id = #{boothId}")
    Integer findIdByCompanySign(@Param("recruitmentId") Integer recruitmentId,
                                @Param("companyId") Integer companyId,
                                @Param("boothId") Integer boothId);



    @Select("select * from book_booth bb inner join booth b on bb.booth_id = b.id where bb.recruitment_id = #{recruitmentId} and b.tv_ip = #{ip} ")
    BookBooth findByRecIdAndTvIp(@Param("recruitmentId") Integer recruitmentId,
                                 @Param("ip") String ip);

    @Select("select * from book_booth bb where bb.recruitment_id = #{recruitmentId} and bb.company_id = #{companyId} limit 1 ")
    BookBooth findByRecIdAndComId(@Param("recruitmentId") Integer recruitmentId,
                                  @Param("companyId") Integer companyId);

    @Select("select bb.booth_id from book_booth bb where bb.recruitment_id = #{recruitmentId} and bb.company_id = #{companyId}")
    List<Integer> findBoothIdsByRecIdAndComId(@Param("recruitmentId") Integer recruitmentId,
                                              @Param("companyId") Integer companyId);
@Select("select bb.booth_id from book_booth bb left join book_booth_position_record br on br.book_booth_id = bb.id where bb.recruitment_id = #{recruitmentID} " +
        "and br.position_record_id = #{id} ")
    List<Integer> getBooth( @Param("recruitmentID")Integer recruitmentID, @Param("id") Integer id);
}