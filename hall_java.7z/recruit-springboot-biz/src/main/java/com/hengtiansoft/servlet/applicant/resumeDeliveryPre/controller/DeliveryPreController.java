package com.hengtiansoft.servlet.applicant.resumeDeliveryPre.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.ResumeDeliveryPreDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.servlet.applicant.resumeDeliveryPre.service.DeliveryPreService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Api(value="预投递接口", description = "在数据库中生成预投简历记录")
@RestController
@RequestMapping(value = "/applicant/deliverypre")
public class DeliveryPreController {
    @Autowired
    DeliveryPreService deliveryPreService;

    @ApiOperation(value = "简历预投递", httpMethod = "POST", notes = "admin用户的简历预投递")
    @RequestMapping(value = "/postResume", method = RequestMethod.POST)
    @ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)
    public ResultDto postResume(@ApiParam(value = "预投递", name = "resumeDeliveryDto") @RequestBody ResumeDeliveryPreDto resumeDeliveryPreDto) {
        return deliveryPreService.prePostResume(resumeDeliveryPreDto);
    }
}
