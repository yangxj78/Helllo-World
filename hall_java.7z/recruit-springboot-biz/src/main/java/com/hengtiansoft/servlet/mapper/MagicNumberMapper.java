package com.hengtiansoft.servlet.mapper;

import com.hengtiansoft.bean.tableModel.MagicNumber;
import com.hengtiansoft.config.MyMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MagicNumberMapper extends MyMapper<MagicNumber> {

   int updateByVersion(@Param("type") int type,@Param("version") int version);
}
