package com.hengtiansoft.servlet.applicant.recruitment.service;

import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.common.enumeration.EntranceTimeEnum;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;

import java.util.Map;

public interface CacheService {
    @Cacheable(value = CacheConstants.ENTRANCETIME, key = "'ENTRANCETIME_'+ #recruitmentId")
    Map<EntranceTimeEnum, Integer> getLastResultMap(Integer recruitmentId);

    @CachePut(value = CacheConstants.ENTRANCETIME, key = "'ENTRANCETIME_'+ #recruitmentId")
    Map<EntranceTimeEnum, Integer> updateEntranceTimeMap(Integer recruitmentId, Map<EntranceTimeEnum, Integer> map);

    @Cacheable(value = CacheConstants.ENTRANCETIME, key = "'QCR_'+ #recruitmentId")
    Integer getIndexID(Integer recruitmentId);

    @CachePut(value = CacheConstants.ENTRANCETIME, key = "'QCR_'+ #recruitmentId")
    Integer updateIndexID(Integer recruitmentId, Integer index);
}
