package com.hengtiansoft.servlet.applicant.qrcode.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.InterviewDeliveryDto;
import com.hengtiansoft.bean.dataModel.ZJRecordDto;
import com.hengtiansoft.bean.tableModel.QrCode;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.applicant.qrcode.service.QrCodeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(value = "二维码接口", description = "二维码生成、出入场记录")
@RestController
@RequestMapping(value = "/applicant/qrCode")
public class QrCodeController {

    @Autowired
    QrCodeService qrCodeService;


    @ApiOperation(value = "公司二维码生成", httpMethod = "GET")
    @RequestMapping(value = "/generateCompanyQrCode", method = RequestMethod.GET)
    public ResultDto<String> generateCompanyQrCode() {
        return qrCodeService.generateCompanyQrCode();
    }

    @ApiOperation(value = "二维码生成", httpMethod = "GET")
    @RequestMapping(value = "/generate", method = RequestMethod.GET)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto<String> generateQrCode() {
        Integer userId = SecurityContext.getCurrentApplicantUser().getId();
        return qrCodeService.generateQrCode(userId);
    }

    @ApiOperation(value = "入场记录", httpMethod = "POST")
    @RequestMapping(value = "/record", method = RequestMethod.POST)
    public boolean record(@RequestBody ZJRecordDto zjRecordDto) {

        return qrCodeService.record(zjRecordDto);
    }

    @ApiOperation(value = "红外线出场", httpMethod = "POST")
    @RequestMapping(value = "/out", method = RequestMethod.POST)
    public boolean out() {

        return qrCodeService.out();
    }

    @ApiOperation(value = "预投递转变成正式投递测试接口", httpMethod = "POST")
    @RequestMapping(value = "/trueDelivery", method = RequestMethod.POST)
    public ResultDto deliveryTrue(@RequestParam Integer userId, @RequestParam Integer recruitmentId) {
        return ResultDtoFactory.toAck("访问成功", qrCodeService.resumeDelivery(userId, recruitmentId));
    }

    @ApiOperation(value = "查询是否已扫码接口", httpMethod = "GET")
    @RequestMapping(value = "/hasRecord", method = RequestMethod.GET)
    @ApiImplicitParam(name = "Authorization", required = true, paramType = "header")
    public ResultDto deliveryTrue(@RequestParam Integer id) {
        return ResultDtoFactory.toAck("访问成功", qrCodeService.hasRecord(id));
    }


}
