package com.hengtiansoft.servlet.applicant.resume.resume;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.bean.tableModel.UserEducationExperience;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.bean.tableModel.UserWorkExperience;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.EducationalEnum;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class BossResume extends BaseResume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {
        String baseInfo = StringUtils.substring(content, 0, content.indexOf("\n\n\n\n个人优势"));
        String[] baseArray = baseInfo.replace("|", "").replaceAll("\\s+", " ").split(" ");
        r.setName(baseArray[1]);
        r.setAge(Integer.parseInt(baseArray[2].replace("岁","")));
        if (baseArray[3].equals("女")) {
            r.setSex(SexEnum.WOMAN);
        } else {
            r.setSex(SexEnum.MAN);
        }
        r.setEducation(baseArray[4]);
        r.setYears(baseArray[5]);
        r.setPhone(getPhone(baseInfo));
        r.setEmail(getEmailAddress(baseInfo));
    }

    @Override
    public void buildContactInfo(String content, HrResume r) {

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        String post = StringUtils.substringBetween(content, "期望职位", "工作经历").replaceAll("\n+", "");
        r.setSelfIntroduction(StringUtils.substringBetween(content,"个人优势", "期望职位").replaceAll("\n+",""));
        String[] strArrary = post.split("\\s+");
        r.setExpectCity(strArrary[1]);
        r.setExpectSalary(strArrary[2]);
        r.setPost(strArrary[3]);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        String workExperience;
        String eduExperience = "";
        String projectExperience = null;
        if (content.contains("\n\n\n项目经历")) {
            workExperience = StringUtils.substringBetween(content, "\n\n\n工作经历", "\n\n\n项目经历");
            projectExperience = StringUtils.substringBetween(content, "\n\n\n项目经历", "\n\n\n教育经历");
        } else {
            workExperience = StringUtils.substringBetween(content, "\n\n\n工作经历", "\n\n\n教育经历");
        }
        eduExperience = StringUtils.substringAfter(content, "\n\n\n教育经历");

        r.setUserWorkExperienceList(userWorkExperienceConvert(workExperience));
        r.setProjectExperienceList(projectExperienceConvert(projectExperience));
        r.setUserEducationExperienceList(eduExperienceConvert(eduExperience));

    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {

    }

    private List<UserWorkExperience> userWorkExperienceConvert(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }

        List<UserWorkExperience> result = new ArrayList<>();
        List<String> strList = Arrays.stream(str.split("\n\n"))
                .filter(value -> StringUtils.isNotEmpty(value)&&!value.startsWith("业绩")).collect(Collectors.toList());
        for (String experience: strList) {
            if (experience.startsWith("\n")) {
                experience = experience.replaceFirst("\n", "");
            }

            UserWorkExperience temp = new UserWorkExperience();

            String[] strings = experience.split("\n");
            temp.setCompany(strings[0].trim());
            if (strings[1].contains("|")) {
                temp.setJob(StringUtils.substringBefore(strings[1], "|").trim());
            } else {
                temp.setJob(strings[1].trim());
            }
            temp.setStartTs(StringUtils.substringBefore(strings[2],"—").replace(".","-").trim());
            temp.setEndTs(StringUtils.substringAfter(strings[2],"—").replace(".","-").trim());
            temp.setDescription(StringUtils.substringAfter(experience,"内容："));
            result.add(temp);
        }
        return result;
    }

    private List<UserProjectExperience> projectExperienceConvert(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith("\n\n")) {
            str = str.replaceFirst("\n\n", "");
        }

        List<UserProjectExperience> result = new ArrayList<>();

        List<String> experiences = Arrays.stream(str.split("\n\n\n"))
                .filter(value -> StringUtils.isNotEmpty(value)&&!value.startsWith("业绩")).collect(Collectors.toList());

        for (String experience : experiences) {
            UserProjectExperience temp = new UserProjectExperience();
            String[] strings = experience.split("\n");

            temp.setProjectName(strings[0].trim());
            temp.setStartTs(StringUtils.substringBefore(strings[2],"—").replace(".","-").trim());
            temp.setEndTs(StringUtils.substringAfter(strings[2],"—").replace(".","-").trim());
            if (experience.contains("业绩：")) {
                temp.setDuty(StringUtils.substringAfter(experience, "业绩："));
                temp.setDescription(StringUtils.substringBetween(experience, "描述：", "业绩："));
            } else {
                temp.setDescription(StringUtils.substringAfter(experience, "描述："));
            }

            result.add(temp);
        }

        return result;
    }

    private List<UserEducationExperience> eduExperienceConvert(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }

        if (str.startsWith("\n\n")) {
            str = str.replaceFirst("\n\n", "");
        }

        List<UserEducationExperience> result = new ArrayList<>();

        List<String> experiences = Arrays.stream(str.split("\n\n"))
                .filter(StringUtils::isNotEmpty).collect(Collectors.toList());

        for (String experience : experiences) {
            if (experience.equals("\n")) {
                continue;
            }

            UserEducationExperience temp = new UserEducationExperience();

            String[] strings = experience.split("\n");

            temp.setSchool(strings[0]);
            temp.setMajor(StringUtils.substringBefore(strings[1], "|"));
            temp.setEducational(EducationalEnum.verifyEducation(StringUtils.substringAfter(strings[1], "|")));
            temp.setStartTs(StringUtils.substringBefore(strings[2],"—").replace(".","-").trim());
            temp.setEndTs(StringUtils.substringAfter(strings[2],"—").replace(".","-").trim());

            result.add(temp);
        }

        return result;
    }
}
