package com.hengtiansoft.servlet.applicant.resume.template.yingjiesheng;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.servlet.applicant.resume.resume.YingJieShengResume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.Date;

public class YingJieShengPersonTemplate extends YingJieShengResume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {
        String baseStr = "";
        String schoolStr = "";
        Document document = Jsoup.parse(content);
        Element resumeElement = document.getElementsByClass("resume").get(0);
        Element baseElement = resumeElement.getElementsByClass("top").get(0);
        if (baseElement != null) {
            baseStr = baseElement.toString();
            baseStr = baseStr.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "");
        }
        Element schoolEle = (baseElement == null ? null : baseElement.getElementsByTag("p").get(1));
        if (schoolEle != null) {
            schoolStr = schoolEle.toString();
            schoolStr = schoolStr.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "");
        }
        int age = 0;
        String city = null;
        if (StringUtils.isNotBlank(baseStr)) {
            String[] infos = baseStr.split(",");
            if (infos[0].indexOf("所在地:") > -1) {
                String cityStr = infos[0].substring(infos[0].indexOf("所在地:"));
                city = cityStr.replace("所在地:", "");
            }
            String ageStr = null;
            if (infos[0].indexOf("男") > -1) {
                ageStr = infos[0].substring(infos[0].indexOf("男"));
            } else if (infos[0].indexOf("女") > -1) {
                ageStr = infos[0].substring(infos[0].indexOf("女"));
            }
            if (ageStr != null) {
                String ageInfos[] = ageStr.split(" ");
                for (int i = 0; i < ageInfos.length; i++) {
                    try {
                        age = Integer.parseInt(ageInfos[i]);
                        break;
                    } catch (NumberFormatException e) {
                        continue;
                    }
                }
            }
        }
        String school = null;
        String degree = null;
        String major = null;
        String[] schoolInfos = schoolStr.split(" ");
        if (StringUtils.isNotBlank(schoolInfos[0])) {
            school = schoolInfos[0];
        }
        if (StringUtils.isNotBlank(schoolInfos[1])) {
            degree = schoolInfos[1];
        }
        if (StringUtils.isNotBlank(schoolInfos[1])) {
            major = schoolInfos[2];
        }
        String newContent = content.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                .replaceAll("\r", "").replaceAll(" ", "");
        if (age > 0) {
            r.setAge(age);
        }
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setUpdateDate(DateUtil.getDateFormate3(new Date()));
        r.setCity(city);
        r.setContent(newContent);
        r.setSource(ResumeSourceEnum.CAMPUS);
    }

    @Override
    public void buildContactInfo(String content, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        Document document = Jsoup.parse(content);
        Element resumeElement = document.getElementsByClass("resume").get(0);
        Elements elements = resumeElement.getElementsByClass("header");
        String eduStr = "";
        String workExperienceStr = "";
        String englishStr = "";
        String jobWillStr = "";
        String post = "";
        String expectCity = "";
        String expectSalary = "";
        if (elements != null) {
            for (Element element : elements) {
                if (filterHtml(element).contains("教育经历")) {
                    eduStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("获奖情况")) {
                    eduStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("兼职实习及工作经历")) {
                    workExperienceStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("项目经验")) {
                    workExperienceStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("社团、学生会实践经历")) {
                    workExperienceStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("语言能力")) {
                    englishStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("培训经历")) {
                    eduStr += getElementsBetweenText(element);
                } else if (filterHtml(element).contains("求职意向")) {
                    jobWillStr += getElementsBetweenText(element);
                    String[] jobWillStrs = jobWillStr.split("\n");
                    for (int i = 0; i < jobWillStrs.length; i++) {
                        if (jobWillStrs[i].contains("职能职位：")) {
                            post = jobWillStrs[i + 1];
                        } else if (jobWillStrs[i].contains("工作地点：")) {
                            expectCity = jobWillStrs[i + 1];
                        } else if (jobWillStrs[i].contains("期望月薪：")) {
                            expectSalary = jobWillStrs[i + 1];
                        }
                    }

                }
            }
        }
        if (StringUtils.isNotBlank(eduStr)) {
            r.setEducation(eduStr);
        }
        if (StringUtils.isNotBlank(workExperienceStr)) {
            r.setWorkExpirence(workExperienceStr);
        }
        if (StringUtils.isNotBlank(englishStr)) {
            r.setEngLevel(englishStr.trim());
        }
        if (StringUtils.isNotBlank(post)) {
            r.setPost(post.trim());
        }
        if (StringUtils.isNotBlank(expectCity)) {
            r.setExpectCity(expectCity.trim());
        }
        if (StringUtils.isNotBlank(expectSalary)) {
            r.setExpectSalary(expectSalary.trim());
        }
    }

    private String getElementsBetweenText(Element elementBegin) {
        StringBuffer buffer = new StringBuffer(filterHtml(elementBegin));
        Element element = elementBegin.nextElementSibling();
        while (element != null && !("header".equals(element.className()))) {
            buffer.append("\n" + filterHtml(element));
            element = element.nextElementSibling();
        }
        return buffer.toString();
    }

    private String filterHtml(Element element) {
        return element.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "");
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildBaseInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildContactInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildOtherInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

    @Override
    public void buildExperienceInfo(MailContent mailContent, HrResume r) {
        // TODO Auto-generated method stub

    }

}
