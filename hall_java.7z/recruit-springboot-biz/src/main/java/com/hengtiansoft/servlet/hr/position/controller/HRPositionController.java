package com.hengtiansoft.servlet.hr.position.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.CompanySign;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.config.SecurityContext;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.hr.position.service.HRPositionService;
import io.swagger.annotations.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by linwu on 7/23/2018.
 */
@Api(value = "HR岗位管理", description = "HR岗位管理相关接口")
@RestController
@RequestMapping("/hr/position")
public class HRPositionController {

    private static final int CURRENT_POSITION = 0;

    private static final int AUDIT_POSITION = 1;

    @Autowired
    HRPositionService hrPositionService;

    @Autowired
    PositionRecordService positionRecordService;

    @ApiOperation(value = "获取现场招聘岗位列表", httpMethod = "GET")
    @RequestMapping(value = "/findCurrentPosition", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<HRPositionRecordDto>> findCurrentPosition(@ApiParam(value = "首页，默认为1", name = "index") @RequestParam(defaultValue = "1", required = false) Integer index,
                                                                    @ApiParam(value = "每页条数，默认为10000", name = "limit") @RequestParam(defaultValue = "10000", required = false) Integer limit) {
        return hrPositionService.findPosition(CURRENT_POSITION, null, index, limit);
    }

    @ApiOperation(value = "获取审核岗位列表", httpMethod = "GET")
    @RequestMapping(value = "/findAuditPosition", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<HRPositionRecordDto>> findAuditPosition(@ApiParam(value = "审核状态默认0 未审核 1审核通过 2审核未通过") @RequestParam(required = false) Integer status,
                                                                  @ApiParam(value = "首页，默认为1", name = "index") @RequestParam(defaultValue = "1", required = false) Integer index,
                                                                  @ApiParam(value = "每页条数，默认为10000", name = "limit") @RequestParam(defaultValue = "10000", required = false) Integer limit) {
        return hrPositionService.findPosition(AUDIT_POSITION, status, index, limit);
    }

    @ApiOperation(value = "获取该岗位下的投递列表", httpMethod = "GET")
    @RequestMapping(value = "/findDeliveryList/{id}", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<JobSeekerDto>> findDeliveryList(@ApiParam(value = "岗位id", name = "id") @PathVariable Integer id,
                                                          @ApiParam(value = "首页，默认为1", name = "index") @RequestParam(defaultValue = "1", required = false) Integer index,
                                                          @ApiParam(value = "每页条数，默认为10000", name = "limit") @RequestParam(defaultValue = "10000", required = false) Integer limit) {
        return hrPositionService.findDeliveryList(id, index, limit);
    }

    @ApiOperation(value = "新增编辑岗位", httpMethod = "POST")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<String> save(@ApiParam(value = "查询信息", name = "positionRecordSaveDto") @RequestBody PositionRecordSaveDto positionRecordSaveDto) {
        positionRecordSaveDto.setName(positionRecordSaveDto.getName().trim());
        return hrPositionService.save(positionRecordSaveDto);
    }

    @ApiOperation(value = "获取岗位详情", httpMethod = "POST")
    @RequestMapping(value = "/findDetail", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<PositionRecord> findDetail(@ApiParam(value = "岗位主键", name = "id") @RequestParam Integer id) {
        return ResultDtoFactory.toAck("success", positionRecordService.getByID(id));
    }

    @ApiOperation(value = "删除岗位", httpMethod = "DELETE")
    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<String> delete(@ApiParam(value = "之前发给你的职位主键", name = "id") @PathVariable Integer id) {
        return hrPositionService.delete(id);
    }


    @ApiOperation(value = "智能匹配", httpMethod = "GET")
    @RequestMapping(value = "/selectByMatch/{id}", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<List<JobSeekerDto>> selectByMatch(@ApiParam(value = "之前发给你的职位主键", name = "id") @PathVariable Integer id,
                                                       @ApiParam(value = "首页，默认为1", name = "index") @RequestParam(defaultValue = "1", required = false) Integer index,
                                                       @ApiParam(value = "每页条数，默认为10000", name = "limit") @RequestParam(defaultValue = "10", required = false) Integer limit) {
        return hrPositionService.selectByMatch(id, index, limit);
    }

    @ApiOperation(value = "邀约面试", httpMethod = "POST")
    @RequestMapping(value = "/invite", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto invite(@ApiParam(value = "用户ID", name = "userIds") @RequestBody InvitationDto invitationDto) {
        return hrPositionService.invite(invitationDto);
    }

}
