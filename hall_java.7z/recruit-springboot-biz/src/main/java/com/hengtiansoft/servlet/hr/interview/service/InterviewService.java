package com.hengtiansoft.servlet.hr.interview.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.*;

import java.util.List;
import java.util.Map;

/**
 * Created by linwu on 7/18/2018.
 */
public interface InterviewService {

    /**
     * 获取所有的投递岗位
     * @return
     */
    ResultDto<List<PositionRecordDto>> findDeliveryPositions();

    /**
     * 获取投递列表
     * @param status
     * @param searchDto
     * @return
     */
    ResultDto<List<InterviewDeliveryDto>> findAllByCon(Integer status, InterviewSearchDto searchDto);


    /**
     * 获取当前面试者
     * @return
     */
    ResultDto<InterviewDeliveryDto> getCurrentInterviewer();


    /**
     * 获取投递顺位第一位投递者
     * @return
     */
    InterviewDeliveryDto getFirst();


    /**
     * 呼叫下一位
     * @param resumeDeliveryId
     * @param orderNum
     * @return
     */
    ResultDto<InterviewDeliveryDto> passOut(Integer resumeDeliveryId, Integer orderNum);


    /**
     * 获取当前能分配的展位
     * @return
     */
    ResultDto<List<Map<Integer, Integer>>> getBooths();


    /**
     * 开始面试
     * @param resumeDeliveryId
     * @return
     */
    ResultDto<InterviewDetailDto> startInterview(Integer resumeDeliveryId);

    /**
     * 通知电视端
     * @param type
     * @return
     */
    ResultDto notifyTv(Integer type);

    /**
     * 结束面试，保存面试详细
     * @param interviewDetailDto
     * @return
     */
    ResultDto saveInterviewDetail(InterviewDetailDto interviewDetailDto);


    /**
     * HR端查看简历信息
     * @param resumeDeliveryId
     * @param userId
     * @return
     */
    ResultDto<ResumeInfoDto> getResumeDetail(Integer resumeDeliveryId, Integer resumeId, Integer userId);
    ResultDto<ResumeInfoDto> getResumeDetail2(Integer resumeDeliveryId, Integer resumeId, Integer userId);

    void notifyUser(Integer resumeDeliveryId);

    List<ResumeDeliveryDetail> getResumeDeliveryDetail(ResumeDeliverySearch resumeDeliverySearch);

    List<ResumDeliveryResult> getResumeDeliveryDetailByBoothId(ResumeDeliveryDetailSearch resumeDeliverySearch);

    List<ResumDeliveryPREResult> getResumeDeliveryDetailPRE(ResumeDeliveryDetailSearch resumeDeliverySearch);

    ResumDeliveryPRENum getCount(Integer recruitmentId,String date);

    void setData(ResumDeliveryPREResult rs);

    void setData(ResumDeliveryResult rs);


    void setData(ExcelUserData ex);
}
