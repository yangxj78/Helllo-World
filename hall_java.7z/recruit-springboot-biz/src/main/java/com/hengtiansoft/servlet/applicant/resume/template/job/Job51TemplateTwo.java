package com.hengtiansoft.servlet.applicant.resume.template.job;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Job51TemplateTwo extends Job51Resume {

    @Override
    public void buildBaseInfo(String content, HrResume r) {

        content = filtercontent(content).replace("&nbsp;", "");

        String updateDate = getUpdateDate(content);
        String year = "0".equals(getWorkedYearsWithLine(content)) ? getWorkedYears(content)
                : getWorkedYearsWithLine(content);
        String name = strSubstring(content, updateDate, "年工作经验");
        if (name.contains("匹配度")) {
            name = strSubstring(name, updateDate, "匹配度");
        }

        name = filterName(name);

        String number = getNumber(content).replace(")", "");
        String phone = getPhone(content);
        String info = content.substring(0, content.indexOf("居住地："));

        String[] infos = info.split("\\|");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")).replace("&nbsp;", ""));
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }

        }

        city = strSubstring(content, "居住地：", "电话：").replaceAll(year, "");

        r.setName(fieldTrim(name));
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setNumber(number);
        r.setUpdateDate(updateDate);
        r.setCity(city);
        r.setContent(content);
        r.setSource(ResumeSourceEnum.JOB51UPLOAD);
    }

    @Override
    public void buildOtherInfo(String content, HrResume r) {
        content = filtercontent(content).replace("&nbsp;", "");

        String post = strSubstring(content, "目标职能：", "求职状态：");

        String school = strSubstring(content, "学校：", "目前薪资");
        if (StringUtils.isEmpty(school)) {
            school = strSubstring(content, "学校：", "自我评价");
        }
        String major = strSubstring(content, "专业：", "学校：");
        String degree = strSubstring(content, "学历：", "专业：");
        String expectCity = strSubstring(content, "目标地点：", "期望薪资：");
        String eduDate = "";
        if (content.contains("教育经历")) {
            eduDate = content.substring(content.indexOf("教育经历"), content.length());
        }
        String graduateDate = "";
        if (!StringUtils.isEmpty(eduDate)) {
            if (eduDate.contains("至今")) {
                graduateDate = "暂未毕业";
            } else {
                graduateDate = strSubstring(eduDate, "教育经历", school);
            }
        }
        String expectSalary = strSubstring(content, "期望薪资：", "目标职能：");
        expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
        String annualIncome = strSubstring(content, "目前年收入：", "(包含基本工资、补贴、奖金、股权收益等)");
        String staffType = strSubstring(content, "工作性质：", "希望行业：");

        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setGraduateDate(graduateDate);
        r.setExpectSalary(expectSalary);
        r.setAnnualIncome(annualIncome);
        r.setStaffType(staffType);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {

        String workExperience = null;
        String projectExperience = null;
        String education = null;

        String[] arr = content.split("<td align=\"left\" valign=\"middle\" class=\"cvtitle\">");
        if (arr.length < 2) {
            arr = content.split("arial;color:#2670b7'>");
        }
        for (String str : arr) {
            if (str.startsWith("工作经验")) {
                workExperience = filterExperience(str).replaceFirst("工作经验(&nbsp;)*", "");
                if (workExperience.contains("<spanstyle='font-size")) {
                    workExperience = workExperience.substring(0, workExperience.indexOf("<spanstyle='font-size"));
                }
            }
            if (str.startsWith("项目经验")) {
                projectExperience = filterExperience(str).replaceFirst("项目经验(&nbsp;)*", "");
                if (projectExperience.contains("<spanstyle='font-size")) {
                    projectExperience = projectExperience.substring(0,
                            projectExperience.indexOf("<spanstyle='font-size"));
                }
            }
            if (str.startsWith("教育经历")) {
                education = filterExperience(str).replaceFirst("教育经历(&nbsp;)*", "");
                if (education.contains("<spanstyle='font-size")) {
                    education = education.substring(0, education.indexOf("<spanstyle='font-size"));
                }
            }
        }

        workExperience = enterExperience(workExperience);
        projectExperience = enterExperience(projectExperience);
        education = enterExperience(education);

        r.setUserWorkExperienceList(workExperienceConvert(workExperience));
        r.setUserEducationExperienceList(educationExperienceConvert(education));
        r.setProjectExperienceList(projectExperienceConvert(projectExperience));

        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
    }

    public String getWorkedYearsWithLine(String content) {
        Pattern yearsExg = Pattern.compile("(\\d*)-(\\d*)年工作经验");
        Matcher matcher = yearsExg.matcher(content);
        String years = "0";
        while (matcher.find()) {
            return fieldTrim(matcher.group().replace("年工作经验", ""));
        }
        return fieldTrim(years);
    }
}
