package com.hengtiansoft.servlet.applicant.resume.service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;

@FunctionalInterface
public interface DirectoryNameGenerateStrategy {

	String nop();

	default public String generateDirectoryName(String baseDir) {
		StringBuilder sb = new StringBuilder(baseDir);

		if (!baseDir.substring(0, 1).equals(File.separator)) {
			sb.append(File.separator);
		}
		return sb.append(new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime()))
				.append(File.separator).toString();
	}
}
