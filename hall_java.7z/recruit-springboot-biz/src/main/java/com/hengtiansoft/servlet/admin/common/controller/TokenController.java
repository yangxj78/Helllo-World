package com.hengtiansoft.servlet.admin.common.controller;

import com.hengtiansoft.common.util.JWTUtil;
import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("token")
@Api(value = "Token验证")
public class TokenController {
    @GetMapping("getUserName")
    public String getUserNameBytoken(@RequestParam String token) {
        return JWTUtil.getUsername(token);
    }
}
