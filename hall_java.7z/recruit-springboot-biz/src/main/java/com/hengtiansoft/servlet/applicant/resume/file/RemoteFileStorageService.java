package com.hengtiansoft.servlet.applicant.resume.file;

import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.ipeopleModel.MailContent;
import org.springframework.stereotype.Component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

@Component("remote")
public class RemoteFileStorageService implements FileStorageService {

    @Override
    public String upload(MailContent mailContent, boolean uploadFile, boolean toWord, String corporateName) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String upload(InputStream inputStream, String filename, String corporateName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public InputStream download(String url, String member) throws IllegalAccessException, FileNotFoundException,
            MalformedURLException, IOException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String convertToUrl(String path) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String convertToPath(String url) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String upload(ConentType contentType, String fileName, String corporateName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String upload(HrResume resume, String filename, String corporateName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String uploadImage(InputStream inputStream, String folder, String fileName) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

}
