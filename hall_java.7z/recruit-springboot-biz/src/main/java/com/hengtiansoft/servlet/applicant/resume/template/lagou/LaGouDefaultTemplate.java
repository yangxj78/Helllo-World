package com.hengtiansoft.servlet.applicant.resume.template.lagou;

import com.hengtiansoft.servlet.applicant.resume.resume.LaGouResume;

public class LaGouDefaultTemplate extends LaGouResume {

}
