package com.hengtiansoft.servlet.admin.company.service.impl;

import com.hengtiansoft.bean.tableModel.CompanyPicture;
import com.hengtiansoft.common.service.impl.BaseService;
import com.hengtiansoft.servlet.admin.company.service.CompanyPictureService;
import com.hengtiansoft.servlet.mapper.CompanyPictureMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CompanyPictureServiceImpl extends BaseService<CompanyPicture> implements CompanyPictureService {

    @Autowired
    CompanyPictureMapper companyPictureMapper;
    @Override
    public List<String> getPictures(Integer id) {
        return companyPictureMapper.getPictures(id);
    }
}
