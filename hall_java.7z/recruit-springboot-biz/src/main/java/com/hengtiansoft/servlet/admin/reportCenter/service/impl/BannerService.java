package com.hengtiansoft.servlet.admin.reportCenter.service.impl;

import com.hengtiansoft.bean.tableModel.Banner;
import com.hengtiansoft.servlet.mapper.BannerMapper;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BannerService {
    @Autowired
    BannerMapper bannerMapper;

    public int insert(Banner banner) {
        return bannerMapper.insert(banner);
    }

    public int update(Banner banner) {
        return bannerMapper.updateByPrimaryKeySelective(banner);
    }

    public int  delete(int id) {
        return bannerMapper.deleteByPrimaryKey(id);
    }

    public Banner getById(Integer id) {
        return bannerMapper.selectByPrimaryKey(id);
    }

    public List<Banner> select() {
        return bannerMapper.selectDesc();

    }
}
