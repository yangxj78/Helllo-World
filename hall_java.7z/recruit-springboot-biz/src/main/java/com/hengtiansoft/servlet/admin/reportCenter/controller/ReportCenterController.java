package com.hengtiansoft.servlet.admin.reportCenter.controller;


import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.Company;
import com.hengtiansoft.bean.tableModel.PositionRecord;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.bean.tableModel.UserInfo;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.servlet.admin.company.service.CompanyService;
import com.hengtiansoft.servlet.admin.positionRecord.service.PositionRecordService;
import com.hengtiansoft.servlet.admin.recruitment.service.RecruitmentService;
import com.hengtiansoft.servlet.applicant.resume.service.ResumeService;
import com.hengtiansoft.servlet.hr.interview.service.InterviewService;
import com.hengtiansoft.servlet.manage.email.EmailService;
import io.swagger.annotations.*;
import org.apache.ibatis.builder.ResultMapResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/admin/reportCenter")
@Api(value = "报表中心", description = "报表中心相关接口")
public class ReportCenterController {

    private static final int SPECIAL = 1;//专场招聘会
    private static final int COMPREHENSIVE = 0;//综合招聘会

    @Autowired
    RecruitmentService recruitmentService;

    @Autowired
    CompanyService companyService;

    @Autowired
    PositionRecordService positionRecordService;

    @Autowired
    EmailService emailService;
    @Autowired
    ResumeService resumeService;
    @Autowired
    InterviewService interviewService;

    @RequestMapping(value = "/listRecruitment", method = RequestMethod.POST)
    @ApiOperation(value = "获取招聘会列表", notes = "字段可选，招聘会类型ID，截止开始日期，招聘会关键字,是否过期")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getRecruitmentList(@RequestBody RecruitmentSearch recruitmentSearch, @RequestParam Integer isPage) {
        Integer pageNum = (recruitmentSearch.getPageNum() == null ? 1 : recruitmentSearch.getPageNum());
        Integer pageSize = (recruitmentSearch.getPageSize() == null ? MagicNumConstant.TEN : recruitmentSearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        HashMap map = new HashMap();
        map.put("list", new PageInfo<Recruitment>(recruitmentService.getAll(recruitmentSearch)));
        map.put("hasStart", 0);
        RecruitmentSearch search = new RecruitmentSearch();
        search.setStartType(1);
        if (recruitmentService.getAll(search).size() != 0) {
            map.put("hasStart", 1);
        }
        return ResultDtoFactory.toAck("success", map);
    }

    @RequestMapping(value = "/listCompany", method = RequestMethod.POST)
    @ApiOperation(value = "获取公司列表", notes = "必填 招聘会ID 可选字段 公司名称，公司地址 备注：可以看到已经失效的企业 status=1")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto listCompany(@RequestBody CompanySearch companySearch) {
        if (companySearch.getRecruitmentID() == null) {
            return ResultDtoFactory.toNack("招聘会ID不能为空！");
        }
        Integer pageNum = (companySearch.getPageNum() == null ? 1 : companySearch.getPageNum());
        Integer pageSize = (companySearch.getPageSize() == null ? MagicNumConstant.TEN : companySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<Company>(companyService.listByRecruitment(companySearch)));
    }

    @RequestMapping(value = "/listPositionRecord", method = RequestMethod.POST)
    @ApiOperation(value = "获取招聘会某个展位的岗位列表", notes = "必填 ：招聘会ID 展位ID 字段可选岗位关键字，学历ID，工作年限ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto listPositionRecord(@RequestBody PositionRecordSearch positionRecordSearch) {
        if (positionRecordSearch.getRecruitmentID() == null || positionRecordSearch.getBoothID() == null) {
            return ResultDtoFactory.toNack("招聘会ID和展位ID不能为空");
        }
        return ResultDtoFactory.toAck("success", new PageInfo<PositionRecord>(positionRecordService.listPositionRecord(positionRecordSearch)));
    }

    //
    @RequestMapping(value = "/recruitmentData", method = RequestMethod.POST)
    @ApiOperation(value = "招聘会数据中心", notes = "必填 ：招聘会ID 展位ID 字段可选岗位关键字，学历ID，工作年限ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto recruitmentData(@RequestBody RecruitmentSearch recruitmentSearch) {
        Integer pageNum = (recruitmentSearch.getPageNum() == null ? 1 : recruitmentSearch.getPageNum());
        Integer pageSize = (recruitmentSearch.getPageSize() == null ? MagicNumConstant.TEN : recruitmentSearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<RecruitmentDataDto>(recruitmentService.getRecruitmentData(recruitmentSearch)));
    }


    @RequestMapping(value = "/resumeData", method = RequestMethod.POST)
    @ApiOperation(value = "求职者数据中心", notes = "必填 ：招聘会ID 展位ID 字段可选岗位关键字，学历ID，工作年限ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto getResumeDeliveryData(@RequestBody ResumeDeliveryDataSearchDto resumeDeliveryDataSearchDto) {
        Integer pageNum = (resumeDeliveryDataSearchDto.getPageNum() == null ? 1 : resumeDeliveryDataSearchDto.getPageNum());
        Integer pageSize = (resumeDeliveryDataSearchDto.getPageSize() == null ? MagicNumConstant.TEN : resumeDeliveryDataSearchDto.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        return ResultDtoFactory.toAck("success", new PageInfo<ResumeDeliveryDataDto>(recruitmentService.getResumeDeliveryData(resumeDeliveryDataSearchDto)));
    }


    @RequestMapping(value = "/sendMail", method = RequestMethod.POST)
    @ApiOperation(value = "发送邮件", notes = "招聘会ID，求职者ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto sendMail(@RequestBody SendMailDto sendMailDto) {
        Integer recruitmentID = sendMailDto.getRecruitmentID();
        List<Integer> users = sendMailDto.getUsers();
        Recruitment recruitment = recruitmentService.getById(recruitmentID);
        String recruitmentTime = "";
        String str = "";
        if (recruitment.getAppearances() == 0) {

            recruitmentTime = "上午9点";
        } else if (recruitment.getAppearances() == 1) {
            recruitmentTime = "下午13点";
        } else {
            recruitmentTime = "全天";
        }
        for (Integer uid : users) {
            UserInfo user = resumeService.findUserInfo(uid);
            if (user.getEmail() != null) {
                //综合场招聘会
                if (recruitment.getStyle() == COMPREHENSIVE) {
                    String recruitmentDate = recruitment.getDate().substring(recruitment.getDate().indexOf("-") + 1, recruitment.getDate().length());
                    recruitmentDate = recruitmentDate.replace("-", "月");
                    recruitmentDate = recruitmentDate + "日";
                    str = "<!DOCTYPE html>\n" +
                            "<html>\n" +
                            "\n" +
                            "<head>\n" +
                            "    <meta charset=\"utf-8\">\n" +
                            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">\n" +
                            "    <title>" + recruitment.getName() + "面试邀请函</title>\n" +
                            "</head>\n" +
                            "\n" +
                            "<body>\n" +
                            "    <div style=\"margin: 10px\">\n" +
                            "        <p style=\"margin: 5px 0;\">" + user.getName() + "：</p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;\">您好！</p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;line-height: 26px;\">" + recruitmentDate + "(" + DateUtil.dateToWeek(recruitmentTime) + ")" + recruitmentTime + "举办" + recruitment.getName() + "（地点：" + recruitment.getAddress() + "），欢迎您前来面试洽谈，关注“相约在高新”微信公众号，注册/登陆后获取入场二维码，查阅岗位信息。<a href='www.hhrc.com.cn'>www.hhrc.com.cn</a> <span>(登陆注册的页面)</span></p>\n" +
                            "        <div style=\"text-align: center;padding: 10px;\">\n" +
                            "        </div>\n" +
                            "        <p style=\"text-align: right;margin: 5px 0;\">杭州人才市场</p>\n" +
                            "        <p style=\"text-align: right;margin: 5px 0;\">" + DateUtil.getFullDateString() + "</p>\n" +
                            "    </div>\n" +
                            "</body>\n" +
                            "\n" +
                            "</html>";

                    if (emailService.sendMail(user.getEmail(), recruitment.getName() + "面试邀请函", str)) {

                    } else {
                        return ResultDtoFactory.toNack("发送失败");
                    }
                } else if (recruitment.getStyle() == SPECIAL) {
                    //专场招聘会
                    String recruitmentDate = recruitment.getDate().substring(recruitment.getDate().indexOf("-") + 1, recruitment.getDate().length());
                    recruitmentDate = recruitmentDate.replace("-", "月");
                    recruitmentDate = recruitmentDate + "日";
                    PositionRecordSearch positionRecordSearch = new PositionRecordSearch();
                    positionRecordSearch.setRecruitmentID(recruitmentID);
                    List<PositionRecord> positionRecords = positionRecordService.listPositionRecord(positionRecordSearch);
                    StringBuffer stringBuffer = new StringBuffer();
                    if (positionRecords != null) {
                        for (PositionRecord positionRecord : positionRecords) {
                            stringBuffer.append("<p style=\"text-indent: 2em;margin: 5px 0;\">"
                                    + positionRecord.getName() +
                                    " </p>");
                        }
                    }
                    CompanySearch companySearch = new CompanySearch();
                    companySearch.setRecruitmentID(recruitmentID);
                    List<Company> companies = companyService.listByRecruitment(companySearch);
                    if (companies == null || companies.size() == 0) {
                        return ResultDtoFactory.toNack("无公司预定本场招聘会");

                    }
                    Company company = companyService.getById(companies.get(0).getId());

                    str = "<!DOCTYPE html>\n" +
                            "<html>\n" +
                            "\n" +
                            "<head>\n" +
                            "    <meta charset=\"utf-8\">\n" +
                            "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
                            "    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\">\n" +
                            "    <title>" + company.getName() + "面试邀请函</title>\n" +
                            "</head>\n" +
                            "\n" +
                            "<body>\n" +
                            "    <div style=\"margin: 10px\">\n" +
                            "        <p style=\"margin: 5px 0;\">" + user.getName() + "：</p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;\">您好！</p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;line-height: 26px;\">\n" +
                            "            诚邀您参加" + recruitmentDate + "(" + DateUtil.dateToWeek(recruitment.getDate()) + ")" + recruitmentTime + recruitment.getName() + "（地点：" + recruitment.getAddress() + "），基于您简历的基础数据，与公司岗位刚相对匹配，欢迎您前来洽谈！\n" +
                            "        </p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;\">公司背景说明：</p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;\">\n" +
                            "        " + company.getName() +
                            "        </p>\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;\">\n" +
                            "        " + company.getDescription() +
                            "        </p>\n" +
                            "  <p style=\"text-indent: 2em;margin: 5px 0;\">办公地点：" + company.getAddress() + "</p>\n" +

                            "  <p style=\"text-indent: 2em;margin: 5px 0;\">岗位：</p>\n" +
                            stringBuffer.toString() +

                            "\n" +
                            "        <p style=\"text-indent: 2em;margin: 5px 0;line-height: 26px;\">关注“相约在高新”微信公众号，注册/登陆后获取入场二维码，查阅岗位信息。 <a href='www.hhrc.com.cn'>www.hhrc.com.cn</a> <span>(登陆注册的页面)</span></p>\n" +
                            "        <div style=\"text-align: center;padding: 10px;\">\n" +
                            "        </div>\n" +
                            "        <p style=\"text-align: right;margin: 5px 0;\">杭州人才市场</p>\n" +
                            "        <p style=\"text-align: right;margin: 5px 0;\">" + DateUtil.getFullDateString() + "</p>\n" +
                            "    </div>\n" +
                            "</body>\n" +
                            "\n" +
                            "</html>";
                    if (emailService.sendMail(user.getEmail(), company.getName() + "面试邀请函", str)) {
                    } else {
                        return ResultDtoFactory.toNack("发送失败");
                    }
                }
            }
        }
        return ResultDtoFactory.toAck("发送成功");
    }

    @RequestMapping(value = "/parkingAndMeal", method = RequestMethod.GET)
    @ApiOperation(value = "获取就餐停车详情", notes = "招聘会ID")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto listParkingAndMeal(@RequestParam Integer recruitmentID) {
        HashMap map = new HashMap();
        map.put("totalMealsNumber", recruitmentService.getTotalMealsNum(recruitmentID));
        map.put("parkingAndMeal", recruitmentService.listParkingAndMeal(recruitmentID));
        return ResultDtoFactory.toAck("success", map);
    }

    @RequestMapping(value = "/Analysis", method = RequestMethod.POST)
    @ApiOperation(value = "分析接口", notes = "1 企业分析 2应聘者分析")
    @ApiImplicitParams({@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER)})
    public ResultDto analysis(@RequestBody AnalysisDto analysisDto) {
        if (null == analysisDto.getStartDate() && analysisDto.getEndDate() == null) {
            Map map = new HashMap();
            List list = new ArrayList();
            if (analysisDto.getType() == 0) {
                map.put("PositionAndCompnay", list);
                map.put("compnayType", list);
                map.put("totalCompany", 0);
                map.put("compnayTrade", list);
                map.put("positionSalary", list);
                map.put("totalPosition", 0);
                map.put("positionEducation", list);
            } else if (analysisDto.getType() == 1) {
                map.put("education", list);
                map.put("workYears", list);
                map.put("salary", list);
                map.put("delivery", list);
                map.put("year", new AnalysisYearDto());
            }
            return ResultDtoFactory.toAck("success", map);
        }
        return ResultDtoFactory.toAck("success", recruitmentService.analysis(analysisDto));
    }

    @ApiOperation(value = "查看简历详情", httpMethod = "GET")
    @RequestMapping(value = "/getResumeDetail", method = RequestMethod.GET)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto<ResumeInfoDto> getResumeDetail(@ApiParam(value = "投递id", name = "resumeDeliveryId") @RequestParam Integer resumeDeliveryId,
                                                    @ApiParam(value = "简历id", name = "resumeId") @RequestParam Integer resumeId,
                                                    @ApiParam(value = "用户id", name = "userId") @RequestParam Integer userId) {
        return interviewService.getResumeDetail2(resumeDeliveryId, resumeId, userId);
    }

    @ApiOperation(value = "投递信息查询", httpMethod = "POST")
    @RequestMapping(value = "/getResumeDeliveryDetail", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto getResumeDetail(@RequestBody ResumeDeliverySearch resumeDeliverySearch) {

        Integer pageNum = (resumeDeliverySearch.getPageNum() == null ? 1 : resumeDeliverySearch.getPageNum());
        Integer pageSize = (resumeDeliverySearch.getPageSize() == null ? MagicNumConstant.TEN : resumeDeliverySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        if (resumeDeliverySearch.getRecruitmentId() == null) {
            return ResultDtoFactory.toNack("招聘会Id不能为空");
        }
        return ResultDtoFactory.toAck("success", new PageInfo<>(interviewService.getResumeDeliveryDetail(resumeDeliverySearch)));
    }

    @ApiOperation(value = "投递详情查询", httpMethod = "POST")
    @RequestMapping(value = "/getResumeDeliveryDetailByBoothId", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto getResumeDetail(@RequestBody ResumeDeliveryDetailSearch resumeDeliverySearch) {
        Integer pageNum = (resumeDeliverySearch.getPageNum() == null ? 1 : resumeDeliverySearch.getPageNum());
        Integer pageSize = (resumeDeliverySearch.getPageSize() == null ? MagicNumConstant.TEN : resumeDeliverySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        if (resumeDeliverySearch.getRecruitmentId() == null) {
            return ResultDtoFactory.toNack("招聘会Id不能为空");
        }
        if (resumeDeliverySearch.getBoothId() == null) {
            return ResultDtoFactory.toNack("展位不能为空");
        }
        PageInfo<ResumDeliveryResult> resumDeliveryResultPageInfo = new PageInfo<>(interviewService.getResumeDeliveryDetailByBoothId(resumeDeliverySearch));

        List<ResumDeliveryResult> list = resumDeliveryResultPageInfo.getList();

        for(ResumDeliveryResult rs:list){
            interviewService.setData(rs);
        }
        return ResultDtoFactory.toAck("success", resumDeliveryResultPageInfo);
    }


    @ApiOperation(value = "预投递详情查询", httpMethod = "POST")
    @RequestMapping(value = "/getResumeDeliveryDetailPRE", method = RequestMethod.POST)
    @ApiImplicitParams(@ApiImplicitParam(name = ApplicationConstant.AUTHORIZATION, required = true, paramType = ApplicationConstant.HTTP_HEADER))
    public ResultDto getResumeDetailPRE(@RequestBody ResumeDeliveryDetailSearch resumeDeliverySearch) {
        Integer pageNum = (resumeDeliverySearch.getPageNum() == null ? 1 : resumeDeliverySearch.getPageNum());
        Integer pageSize = (resumeDeliverySearch.getPageSize() == null ? MagicNumConstant.TEN : resumeDeliverySearch.getPageSize());
        PageHelper.startPage(pageNum, pageSize);
        if (resumeDeliverySearch.getRecruitmentId() == null) {
            return ResultDtoFactory.toNack("招聘会Id不能为空");
        }
        Recruitment byId = recruitmentService.getById(resumeDeliverySearch.getRecruitmentId());
        resumeDeliverySearch.setDate(byId.getDate());
        PageInfo<ResumDeliveryPREResult> resumDeliveryPREResultPageInfo = new PageInfo<>(interviewService.getResumeDeliveryDetailPRE(resumeDeliverySearch));

        List<ResumDeliveryPREResult> list = resumDeliveryPREResultPageInfo.getList();
        for (ResumDeliveryPREResult rs : list) {
            interviewService.setData(rs);
        }

        return ResultDtoFactory.toAck("success", resumDeliveryPREResultPageInfo);
    }
}
