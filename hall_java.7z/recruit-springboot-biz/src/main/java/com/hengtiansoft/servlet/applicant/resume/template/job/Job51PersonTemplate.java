package com.hengtiansoft.servlet.applicant.resume.template.job;

import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.enumeration.ResumeSourceEnum;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.common.util.DateUtil;
import com.hengtiansoft.servlet.applicant.resume.resume.Job51Resume;
import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Job51PersonTemplate extends Job51Resume {

    public void buildBaseInfo(String content, HrResume r) {
        String baseStr = "";
        String name = null;
        Document document = Jsoup.parse(content);
        Element baseElement = document.getElementById("basedetail");
        if (baseElement != null) {
            baseStr = baseElement.toString();
            baseStr = baseStr.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "").replaceAll(" ", "");
        }

        Element nameElement = document.getElementsByClass("name").get(1);
        if (nameElement != null) {
            name = nameElement.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "")
                    .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
        }
        String year = getWorkedYears(baseStr);
        String phone = getPhone(baseStr);

        Node nodeInfo = nameElement.nextElementSibling();
        String infoStr = nodeInfo.toString().replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("&nbsp;", "")
                .replaceAll("<td[\\s\\S]*?>", "").replaceAll("\r", "").replaceAll(" ", "");
        String[] infos = infoStr.split("\\│");
        SexEnum sex = SexEnum.MAN;
        int age = 0;
        String city = null;
        for (String str : infos) {
            if (str.contains("岁")) {
                age = getRealAge(str.substring(BEGIN_OFF_SET_ZERO, str.indexOf("岁")));
            }
            if (str.contains("女")) {
                sex = SexEnum.WOMAN;
            }
            if (str.contains("现居住")) {
                city = str.replace("现居住", "");
            }
        }

        // 过滤名字
        if (!StringUtils.isEmpty(name)) {
            Pattern reg = Pattern.compile("[\\u4e00-\\u9fa5]{2,4}");
            Matcher matcher = reg.matcher(name);
            while (matcher.find()) {
                name = matcher.group();
                break;
            }
        }

        String newContent = content.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                .replaceAll("\r", "").replaceAll(" ", "");

        String email = getEmailAddress(baseStr);

        r.setName(name);
        r.setPhone(phone);
        r.setEmail(email);
        r.setAge(age);
        r.setSex(sex);
        r.setYears(year);
        r.setUpdateDate(DateUtil.getDateFormate3(new Date()));
        r.setCity(city);
        r.setContent(newContent);
        r.setSource(ResumeSourceEnum.JOB51UPLOAD);
    }

    public void buildContactInfo(String content, HrResume r) {

    }

    public void buildOtherInfo(String content, HrResume r) {
        String expectCity = "";
        String post = "";
        Document document = Jsoup.parse(content);
        Element intentionElement = document.getElementById("intention");
        Elements intentionElements = intentionElement.getElementsByClass("e");
        if (intentionElements != null && intentionElements.size() > 0) {
            for (Element element : intentionElements) {
                if (StringUtils.isBlank(expectCity) && element.toString().contains("地点")) {
                    String expectCityStr = filtercontent(element.toString());
                    expectCity = expectCityStr.substring(expectCityStr.indexOf("地点：") + 3);
                } else if (StringUtils.isBlank(post) && element.toString().contains("职能")) {
                    String postStr = filtercontent(element.toString());
                    post = postStr.substring(postStr.indexOf("职能：") + 3);
                    post = post.split("&nbsp;")[0];
                }
            }
        }
        content = filtercontent(content);
        String expectSalary = strSubstring(content, "期望薪资：", "地点");
        expectSalary = StringUtils.isEmpty(expectSalary) ? "面议" : expectSalary;
        String annualIncome = strSubstring(content, "目前年收入：", "(包含基本工资、补贴、奖金、股权收益等)");
        r.setExpectCity(expectCity);
        r.setPost(post);
        r.setExpectSalary(expectSalary);
        r.setAnnualIncome(annualIncome);
    }

    @Override
    public void buildExperienceInfo(String content, HrResume r) {
        String workExperience = "";
        String projectExperience = "";
        String education = "";
        String staffType = "";
        Document document = Jsoup.parse(content);
        Element workElement = document.getElementById("work");
        Element projectElement = document.getElementById("project");
        Element educationElement = document.getElementById("education");
        Element intentionElement = document.getElementById("intention");
        if (workElement != null) {
            String str = workElement.toString();
            workExperience = str.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "").replaceAll(" ", "");
        }
        if (projectElement != null) {
            String str = projectElement.toString();
            projectExperience = str.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "").replaceAll(" ", "");
        }
        if (educationElement != null) {
            String str = educationElement.toString();
            education = str.replaceAll("<.*?>", "").replaceAll("<td.*?>", "").replaceAll("<td[\\s\\S]*?>", "")
                    .replaceAll("\r", "").replaceAll(" ", "");
        }
        if (intentionElement != null) {
            String str = intentionElement.toString();
            if (str.contains("全职")) {
                staffType = "全职";
            } else if (str.contains("兼职")) {
                staffType = "兼职";
            }
        }
        String school = null;
        String degree = null;
        String major = null;
        String eduDate = null;
        String graduateDate = "";
        String[] str = education.split("\n");
        List<String> list = new ArrayList<String>();
        Arrays.asList(str).forEach(e -> {
            if (!StringUtils.isBlank(e)) {
                list.add(e);
            }
        });

        Pattern reg;
        Matcher matcher;
        reg = Pattern.compile("[\\u4e00-\\u9fa5]+(大学|学院|学校)");
        out: for (String s : list) {
            if (s.endsWith("大学") || s.endsWith("学院") || s.endsWith("学校")) {
                matcher = reg.matcher(s);
                while (matcher.find()) {
                    school = matcher.group();
                    break out;
                }
            }
        }

        Elements elements = educationElement.getElementsByClass("sp");
        if (elements != null && elements.size() > 0) {
            List<Node> nodes = elements.first().childNodes();
            if (nodes != null && nodes.size() > 3) {
                eduDate = filtercontent(nodes.get(1).toString());
                major = filtercontent(nodes.get(3).toString());
            }

            if (!StringUtils.isEmpty(eduDate)) {
                graduateDate = eduDate.substring(eduDate.indexOf("-")).replace("-", "");
                if (!graduateDate.replace("/", "").matches("[0-9]+")) {
                    graduateDate = "暂未毕业";
                }
            }
        }
        reg = Pattern.compile("大专|本科|硕士|博士");
        out: for (String s : list) {
            matcher = reg.matcher(s);
            while (matcher.find()) {
                degree = matcher.group();
                break out;
            }
        }
        r.setSchool(school);
        r.setMajor(major);
        r.setDegree(degree);
        r.setGraduateDate(graduateDate);
        r.setWorkExpirence(workExperience);
        r.setProjectExperience(projectExperience);
        r.setEducation(education);
        r.setStaffType(staffType);
    }
}
