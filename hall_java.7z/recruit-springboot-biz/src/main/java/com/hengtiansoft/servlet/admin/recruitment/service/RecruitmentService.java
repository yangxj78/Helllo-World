package com.hengtiansoft.servlet.admin.recruitment.service;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.dataModel.*;
import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.service.Service;

import java.util.List;
import java.util.Map;

public interface RecruitmentService extends Service<Recruitment> {
    List<Recruitment> getAll(RecruitmentSearch recruitmentSearch);

    Integer createRecruitment(Recruitment recruitment);

    int updateRecruitment(Recruitment recruitment);

    List<Recruitment> getRecruitmentByTypeId(Integer id);

    Recruitment getRecruitmentMapperById(Integer id);

    List<RecruirmentTableDto> getRecruitmentTable(RecruitmentSearch recruitmentSearch);

    int deleteRecruitment(Integer id);

    List<RecruitmentDataDto> getRecruitmentData(RecruitmentSearch recruitmentSearch);

    List<EnrollTable> getEnrollTable(int id);

    List<RecruitmentAppDataDto> getRecruitmentDataForApplicant(RecruitmentSearch recruitmentSearch);

    List<ExcelPositionData> getExcelPositionData(Integer id);


    List<ExcelUserData> getExcelUserData(Integer id);

    List<ResumeDeliveryDataDto> getResumeDeliveryData(ResumeDeliveryDataSearchDto resumeDeliveryDataSearchDto);

    /**
     * 当前当前正在进行的招聘会
     *
     * @return
     * @throw RecruitmentException
     */
    Recruitment getCurrentRecruitment();

    Recruitment getById(Integer id);

    List<ParkingAndMealDto> listParkingAndMeal(Integer recruitmentID);
    Integer getTotalMealsNum(Integer recruitmentID);

    ResultDto startRecruitment(Integer id);

    ResultDto endRecruitment(Integer id);

    int getAttendOrLeaveNumber(int type, int recruitmentId);

    List<StationDto> getStationsByRecruitmentId(int recruitmentId);

    Map analysis(AnalysisDto analysisDto);

    ResultDto collectionPosition(CollectionPositionSearchDto searchDto);

    List<CollectionPositionDto> listCollectionPosition(CollectionPositionSearchDto searchDto);

    List<RecruitmentSearchDto> listRecruitmentSearchs(Integer userId);

    List<RecruitmentDataDto> positionRecordSearch(PositionRecordSearch positionRecordSearch);
    List<RecruitmentDataDto> positionRecordSearch2(PositionRecordSearch positionRecordSearch);
    Boolean getCollectionPosition(CollectionPositionSearchDto searchDto);

    Integer deleteCollectionPosition(CollectionPositionSearchDto searchDto);

    Boolean isDelivery(CollectionPositionSearchDto searchDto);

    Boolean isPreDelivery(CollectionPositionSearchDto searchDto);
}
