package com.hengtiansoft.servlet.applicant.recruitment.service;

import com.hengtiansoft.bean.dataModel.StatisticsDto;
import com.hengtiansoft.bean.tableModel.Recruitment;

import java.util.HashMap;
import java.util.List;

public interface RecruitmentReportService {

    StatisticsDto getTotalCount(Recruitment recruitment);

    StatisticsDto getEducationCount(Recruitment recruitment);

    StatisticsDto getAgeCount(Recruitment recruitment);

    StatisticsDto getEntranceTime(Recruitment recruitment);

    StatisticsDto getJobTop5(Recruitment recruitment);

    HashMap<String, Object> getSummary(Recruitment recruitment);
}
