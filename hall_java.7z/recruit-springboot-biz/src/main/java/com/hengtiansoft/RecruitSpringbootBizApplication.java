package com.hengtiansoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruitSpringbootBizApplication {

	public static void main(String[] args) {

		SpringApplication.run(RecruitSpringbootBizApplication.class, args);
	}
}
