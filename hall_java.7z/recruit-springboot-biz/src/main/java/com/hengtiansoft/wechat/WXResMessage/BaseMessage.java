package com.hengtiansoft.wechat.WXResMessage;

public class BaseMessage {
    String ToUserName;
    String FromUserName;
    String CreateTime;
    String MsgType;
}
