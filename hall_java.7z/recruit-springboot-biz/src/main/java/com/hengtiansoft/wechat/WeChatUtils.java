package com.hengtiansoft.wechat;


import net.sf.json.JSONObject;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class WeChatUtils {


    public static JSONObject doGetStr(String url) throws Exception{
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        CloseableHttpClient httpClient = httpClientBuilder.build();
        HttpGet httpGet = new HttpGet(url);
        CloseableHttpResponse httpResponse = httpClient.execute(httpGet);

        HttpEntity httpEntity = httpResponse.getEntity();
        JSONObject jsonObject = null;
        if(httpEntity != null){
            String result = EntityUtils.toString(httpEntity,"utf-8");
            jsonObject = JSONObject.fromObject(result);
        }
        return jsonObject;
    }

    public static Signature signature(String JsApiTicket, String url) {
        String noncestr = RandomStringUtils.randomAlphanumeric(16);
        String timestamp = Long.toString(System.currentTimeMillis() / 1000);
        String str = "jsapi_ticket=" + JsApiTicket +
                "&noncestr=" + noncestr +
                "&timestamp=" + timestamp +
                "&url=" + url;
        //sha1加密
        return new Signature(timestamp, noncestr,SHA1Util.encode(str));
    }
}
