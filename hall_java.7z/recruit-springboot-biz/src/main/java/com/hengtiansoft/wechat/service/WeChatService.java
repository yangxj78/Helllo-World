package com.hengtiansoft.wechat.service;

import com.hengtiansoft.common.constant.CacheConstants;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;

import javax.servlet.http.HttpServletRequest;
import java.security.NoSuchAlgorithmException;

public interface WeChatService {

    String getAccessToken();


    String getJSApiTicket(String token);

    String doGet(HttpServletRequest request) throws NoSuchAlgorithmException;

    String doPost(HttpServletRequest request);
}
