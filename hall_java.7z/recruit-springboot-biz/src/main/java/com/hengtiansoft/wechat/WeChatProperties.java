package com.hengtiansoft.wechat;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * 保存获取access_token所需的APPID、APPSECRET和ACCESS_TOKEN_URL的Java bean
 */
@Component
@PropertySource("classpath:wechat.properties")
public class WeChatProperties {

    @Value("${wechat.APPID}")
    private String AppId;

    @Value("${wechat.APPSECRET}")
    private String AppSecret;

    @Value("${wechat.ACCESS_TOKEN_URL}")
    private String ACCESS_TOKEN_URL;

    @Value("${wechat.JSAPI_TICKET_URL}")
    private String JSAPI_TICKET_URL;

    public String getJSAPI_TICKET_URL() {
        return JSAPI_TICKET_URL;
    }

    public void setJSAPI_TICKET_URL(String JSAPI_TICKET_URL) {
        this.JSAPI_TICKET_URL = JSAPI_TICKET_URL;
    }

    public String getAppId() {
        return AppId;
    }

    public String getAppSecret() {
        return AppSecret;
    }

    public String getACCESS_TOKEN_URL() {
        return ACCESS_TOKEN_URL;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public void setAppSecret(String appSecret) {
        AppSecret = appSecret;
    }

    public void setACCESS_TOKEN_URL(String ACCESS_TOKEN_URL) {
        this.ACCESS_TOKEN_URL = ACCESS_TOKEN_URL;
    }

    @Override
    public String toString() {
        return "WeChatProperties{" +
                "APPID='" + AppId + '\'' +
                ", APPSECRET='" + AppSecret + '\'' +
                ", ACCESS_TOKEN_URL='" + ACCESS_TOKEN_URL + '\'' +
                '}';
    }
}