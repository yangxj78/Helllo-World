package com.hengtiansoft.wechat.controller;

import com.hengtiansoft.bean.ResultDto;
import com.hengtiansoft.bean.ResultDtoFactory;
import com.hengtiansoft.wechat.WeChatUtils;
import com.hengtiansoft.wechat.service.WeChatService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

@RestController
@Api(value = "微信接口", description = "access_token获取")
@RequestMapping(value = "/wechat")
public class WeChatController {

    @Autowired
    private WeChatService weChatService;


    @RequestMapping(value = "/getSignature", method = RequestMethod.GET)
    @ApiOperation(value = "获取微信Signature")
    public ResultDto getJSApiTicket(@RequestParam String url) {
        String token = weChatService.getAccessToken();
        String ticket = weChatService.getJSApiTicket(token);
        return StringUtils.isEmpty(token) ? ResultDtoFactory.toNack("signature获取失败")
                : ResultDtoFactory.toAck("success", WeChatUtils.signature(ticket, url));
    }

    @RequestMapping(value = "/getToken", method = {RequestMethod.GET,RequestMethod.POST})
    @ApiOperation(value = "获取token")
    public void getToken(HttpServletRequest request, HttpServletResponse response) {
        boolean isGet = request.getMethod().toLowerCase().equals("get");
        try(PrintWriter out = response.getWriter()) {
            if(isGet){
                out.print(weChatService.doGet(request));
            }else {
                out.print(weChatService.doPost(request));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
