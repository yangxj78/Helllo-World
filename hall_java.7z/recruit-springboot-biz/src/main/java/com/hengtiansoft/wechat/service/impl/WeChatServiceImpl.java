package com.hengtiansoft.wechat.service.impl;

import com.hengtiansoft.common.constant.CacheConstants;
import com.hengtiansoft.wechat.*;
import com.hengtiansoft.wechat.WXResMessage.TextMessage;
import com.hengtiansoft.wechat.service.WeChatService;
import net.sf.json.JSONObject;
import org.apache.commons.codec.binary.Hex;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Date;
import java.util.Map;

@Service
public class WeChatServiceImpl implements WeChatService {

    @Autowired
    private WeChatProperties weChatProperties;

    public static final String TOKEN = "hallqa";


    /**
     * 从缓存中获取access token,如果缓存为空，则获取产生新的access token
     *
     * @return
     */
    @Override
    @Cacheable(value = CacheConstants.JSAPITICKET, key = "'ACCESS_TOKEN'")
    public String getAccessToken() {
        return generateAccessToken().getToken();
    }

    /**
     * 在缓存中的access token 失效之后，用来生成新的accesss_token
     *
     * @return
     */
    private AccessToken generateAccessToken() {
        AccessToken accessToken = new AccessToken();
        String url = weChatProperties.getACCESS_TOKEN_URL().replace("APPID", weChatProperties.getAppId()).replace("APPSECRET", weChatProperties.getAppSecret());
        try {
            JSONObject jsonObject = WeChatUtils.doGetStr(url);
            if (jsonObject != null) {
                accessToken.setToken(jsonObject.getString("access_token"));
                accessToken.setExpiresIn(jsonObject.getInt("expires_in"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return accessToken;
    }

    @Override
    @Cacheable(value = CacheConstants.JSAPITICKET, key = "'JSAPITICKET'")
    public String getJSApiTicket(String token) {
        return generateJSAPITicket(token).getTicket();
    }

    private JSAPITicket generateJSAPITicket(String token) {
        JSAPITicket jsapiTicket = new JSAPITicket();
        String JSAPI_TICKET_URL = weChatProperties.getJSAPI_TICKET_URL().replace("ACCESS_TOKEN", token);
        try {
            JSONObject jsonObject = WeChatUtils.doGetStr(JSAPI_TICKET_URL);
            if (jsonObject != null && jsonObject.getInt("errcode") == 0) {
                jsapiTicket.setTicket(jsonObject.getString("ticket"));
                jsapiTicket.setExpiresIn(jsonObject.getInt("expires_in"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return jsapiTicket;
    }

    @Override
    public String doGet(HttpServletRequest request) throws NoSuchAlgorithmException {

        // 开发者提交信息后，微信服务器将发送GET请求到填写的服务器地址URL上，GET请求携带参数
        String signature = request.getParameter("signature");// 微信加密签名（token、timestamp、nonce。）
        String timestamp = request.getParameter("timestamp");// 时间戳
        String nonce = request.getParameter("nonce");// 随机数
        String echostr = request.getParameter("echostr");// 随机字符串

        // 将token、timestamp、nonce三个参数进行字典序排序
        String[] params = new String[]{TOKEN, timestamp, nonce};
        Arrays.sort(params);
        // 将三个参数字符串拼接成一个字符串进行sha1加密
        String clearText = params[0] + params[1] + params[2];
        String algorithm = "SHA-1";
        String sign = new String(
                Hex.encodeHex(MessageDigest.getInstance(algorithm).digest((clearText).getBytes()), true));
        // 开发者获得加密后的字符串可与signature对比，标识该请求来源于微信
        if (signature.equals(sign)) {
            return echostr;
        }
        return "";
    }

    @Override
    public String doPost(HttpServletRequest request) {
        String respMessage = null;
        try {

            // xml请求解析
            Map<String, String> requestMap = MessageUtil.xmlToMap(request);

            // 发送方帐号（open_id）
            String fromUserName = requestMap.get("FromUserName");
            // 公众帐号
            String toUserName = requestMap.get("ToUserName");
            // 消息类型
            String msgType = requestMap.get("MsgType");
            // 消息内容
            String content = requestMap.get("Content");

            //返回信息的对象
            TextMessage text = new TextMessage(fromUserName, toUserName);
            // 文本消息
            if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_TEXT)) {
                if (content.equals("123")) {
                    //关键字自动回复功能
                    //todo 从数据库取
                    text.setContent("the text is" + content);
                    text.setMsgType(msgType);
                } else {
                    //普通自动回复
                    //todo 从数据库取
                    text.setContent("123123");
                    text.setMsgType(msgType);
                }
            }
            // 事件推送
            else if (msgType.equals(MessageUtil.REQ_MESSAGE_TYPE_EVENT)) {
                String eventType = requestMap.get("Event");// 事件类型
                // 关注
                if (eventType.equals(MessageUtil.EVENT_TYPE_SUBSCRIBE)) {
                    //关注自动回复
                    //todo 从数据库取
                    text.setContent("欢迎关注，xxx");
                    text.setMsgType(MessageUtil.RESP_MESSAGE_TYPE_TEXT);

                }
                // TODO 取消关注后用户再收不到公众号发送的消息，因此不需要回复消息
                else if (eventType.equals(MessageUtil.EVENT_TYPE_UNSUBSCRIBE)) {// 取消订阅

                }
                // 自定义菜单点击事件
                else if (eventType.equals(MessageUtil.EVENT_TYPE_CLICK)) {

                }
            }
            respMessage = MessageUtil.textMessageToXml(text);
        } catch (Exception e) {
        }
        return respMessage;
    }
}
