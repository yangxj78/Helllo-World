package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * 招聘会启动类型
 */
public enum RecruitmentStartTypeEnum {

    NOT_START(0, "未开始"), STARTED(1, "进行中"), END(2, "已结束");

    private Integer code;

    private String desc;

    private static final Map<Integer, RecruitmentStartTypeEnum> map;

    static {
        map = new HashMap<>();
        for (RecruitmentStartTypeEnum recruitmentStartTypeEnum : RecruitmentStartTypeEnum.values()) {
            map.put(recruitmentStartTypeEnum.code, recruitmentStartTypeEnum);
        }
    }

    RecruitmentStartTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }


    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }


    public static Map<Integer, RecruitmentStartTypeEnum> getMap() {
        return map;
    }
}
