package com.hengtiansoft.common.converters;

import com.google.common.io.Files;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.common.exception.ConvertResumeException;
import com.hengtiansoft.servlet.applicant.resume.service.DirectoryNameGenerateStrategy;
import com.hengtiansoft.servlet.applicant.resume.service.FileNameGenerateStrategy;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.xwpf.converter.core.FileImageExtractor;
import org.apache.poi.xwpf.converter.core.FileURIResolver;
import org.apache.poi.xwpf.converter.xhtml.XHTMLConverter;
import org.apache.poi.xwpf.converter.xhtml.XHTMLOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;

@Slf4j
public class WordToHTMLConveter {

    public String writeDocxResumeHTML(InputStream inputStream, String fileName, String corporateName)
            throws ConvertResumeException, IOException {
        String destination = getFilePath(fileName, corporateName);
        XWPFDocument document = new XWPFDocument(inputStream);
        XHTMLOptions options = XHTMLOptions.create().indent(4);
        // 导出图片
        File imageFolder = new File(getfolderPath("images/", destination, fileName));
        options.setExtractor(new FileImageExtractor(imageFolder));
        // URI resolver
        options.URIResolver(new FileURIResolver(imageFolder));
        File destFile = new File(destination);
        OutputStream out = new FileOutputStream(destFile);
        XHTMLConverter.getInstance().convert(document, out, options);
        return destination.replace(new File("").getAbsolutePath(), "");

    }

    public String writeHTML(String parsedContent, String fileName, String corporateName) throws ConvertResumeException,
            UnsupportedEncodingException {
        String destination = getFilePath(fileName, corporateName);
        File destFile = new File(destination);
        String strReplace = "<meta http-equiv='content-type' content='text/html; charset=utf-8'>";
        String utf8Content = parsedContent.replaceAll("<(?i)meta.*?charset=.*?>", strReplace);
        try {
            Files.createParentDirs(destFile);
            Files.write(utf8Content.getBytes(), destFile);
        } catch (IOException e) {
            log.error(e.getLocalizedMessage());
        }
        return destination.replace(new File("").getAbsolutePath(), "");
    }

    public String poiWriteHTML(InputStream inputStream, String fileName, String corporateName)
            throws ConvertResumeException {
        try {
            String destination = getFilePath(fileName, corporateName);
            File destFile = new File(destination);
            if (!destFile.exists()) {
                destFile.createNewFile();
            }
            HWPFDocument wordDocument = new HWPFDocument(inputStream);
            Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
            WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter(document);
            // 保存图片，并返回图片的相对路径
            wordToHtmlConverter
                    .setPicturesManager((content, pictureType, name, width, height) -> {
                        try (FileOutputStream out = new FileOutputStream(
                                getfolderPath("images/", destination, fileName) + name)) {
                            out.write(content);
                        } catch (Exception e) {
                            log.error(e.getLocalizedMessage());
                        }
                        return "images/" + name;
                    });
            wordToHtmlConverter.processDocument(wordDocument);
            Document htmlDocument = wordToHtmlConverter.getDocument();
            DOMSource domSource = new DOMSource(htmlDocument);
            StreamResult streamResult = new StreamResult(new FileOutputStream(destFile));

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer serializer = tf.newTransformer();
            serializer.setOutputProperty(OutputKeys.ENCODING, "utf-8");
            serializer.setOutputProperty(OutputKeys.INDENT, "yes");
            serializer.setOutputProperty(OutputKeys.METHOD, "html");
            serializer.transform(domSource, streamResult);
            return destination.replace(new File("").getAbsolutePath(), "");
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            throw new ConvertResumeException(e);
        }
    }

    public String getFilePath(String fileName, String corporateName) throws ConvertResumeException {
        try {
            String generateDirectoryName;
            String realPath;
            String finalFileName = null;
            DirectoryNameGenerateStrategy dirGenerate = () -> null;
            generateDirectoryName = HrResume.FILE_UPLOAD_RESUME + corporateName + File.separator
                    + dirGenerate.generateDirectoryName(HrResume.RESUME_HTML_UPLOAD);
            if (!new File(generateDirectoryName).exists() && !new File(generateDirectoryName).isAbsolute()) {
                realPath = new File("").getAbsolutePath() + File.separator + generateDirectoryName;
            } else {
                realPath = generateDirectoryName;
            }
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdirs();
            }
            FileNameGenerateStrategy fileGenerate = () -> null;

            finalFileName = fileName.substring(0, fileName.indexOf('.')) + ".html";

            String destination = fileGenerate.generateFileName(realPath, finalFileName);
            if (new File(destination).isFile() && !new File(destination).exists()
                    && !new File(destination).createNewFile()) {
                throw new IOException("create the file " + destination + " fail");
            }
            return destination;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            throw new ConvertResumeException(e);
        }
    }

    private String getfolderPath(String folderName, String path, String fileName) throws ConvertResumeException {
        try {
            fileName = fileName.substring(0, fileName.lastIndexOf('.'));
            String folderPath = path.substring(0, path.lastIndexOf(fileName)) + folderName;
            File file = new File(folderPath);
            if (!file.exists()) {
                file.mkdirs();
            }

            return folderPath;
        } catch (Exception e) {
            log.error(e.getLocalizedMessage(), e);
            throw new ConvertResumeException(e);
        }
    }
}
