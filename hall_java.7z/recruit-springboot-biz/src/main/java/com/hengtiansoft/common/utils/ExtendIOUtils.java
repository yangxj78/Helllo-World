package com.hengtiansoft.common.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ExtendIOUtils {

	private ExtendIOUtils(){};
	private static Logger LOGGER = LoggerFactory.getLogger(ExtendIOUtils.class);

	public static String getHTMLContent(InputStream content, String encoding) {
		String htmText = null;
		try {
			htmText = IOUtils.toString(content, encoding);
			int index = htmText.indexOf("<head>");
			if (index != -1) {
				htmText = htmText.substring(index);
				htmText = JsoupUtils.getAllStringByTagTd(htmText);
			}
		} catch (Exception e) {
			LOGGER.error(e.getLocalizedMessage());
		}
		return htmText;
	}

	public static String getHTMLContent(InputStream content) {
		return getHTMLContent(content, "UTF-8");
	}

	public static byte[] toBytes(InputStream inStream) {
		ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
		try {
			IOUtils.copy(inStream, swapStream);
		} catch (IOException e) {
			LOGGER.info(e.getLocalizedMessage());
		} finally {
			IOUtils.closeQuietly(inStream);
		}

		return swapStream.toByteArray();
	}

	public static InputStream copy(InputStream content) {
		byte[] bytes = toBytes(content);
		return toInputStream(bytes);
	}

	public static InputStream toInputStream(byte[] bytes) {
		return new ByteArrayInputStream(bytes);
	}

	public static String toString(InputStream inputStream, String... encodings) {
		if (encodings.length > 1) {
			throw new IllegalArgumentException();
		}
		try {
			if (encodings.length == 1)
				return IOUtils.toString(inputStream, encodings[0]);
			return IOUtils.toString(inputStream, "UTF-8");
		} catch (IOException e) {
			LOGGER.info(e.getLocalizedMessage());
		} finally{			
			IOUtils.closeQuietly(inputStream);
		}
		return null;
	}
}
