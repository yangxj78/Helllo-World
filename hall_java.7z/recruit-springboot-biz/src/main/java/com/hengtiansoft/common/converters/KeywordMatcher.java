package com.hengtiansoft.common.converters;

import com.hengtiansoft.bean.ipeopleModel.AbstractBaseEntity;
import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.bean.ipeopleModel.HrResume;
import com.hengtiansoft.bean.tableModel.UserProjectExperience;
import com.hengtiansoft.common.enumeration.SexEnum;
import com.hengtiansoft.servlet.applicant.resume.template.custom.CustomDefaultTemplate;
import com.hengtiansoft.servlet.applicant.resume.until.ChineseName;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.ArrayList;
import java.util.Set;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Slf4j
public class KeywordMatcher {

    private static Map<String, Field> baseInfoKeywordMap = new HashMap<String, Field>();
    private static Map<String, Field> experienceKeywordMap = new HashMap<>();
    private static Map<String, Field> projectKeywordMap = new HashMap<String, Field>();

    private static String filterChar[] = { "：", ":", "|", "", "　　", "&nbsp;", "\t", "\r", "" };
    private static final String EDDUCATION = "education";
    private static final String GRADUATE_DATE = "graduateDate";
    private static final String CITY = "city";
    private static final String POST = "post";
    private static final String STAFF_TYPE = "staffType";
    private static final String EXPECT_CITY = "expectCity";
    private static final String EXPECT_SALARY = "expectSalary";
    private static final String PHONE = "phone";
    private static final String EMAIL = "email";
    private static final String NAME = "name";
    private static final String SEX = "sex";
    private static final String YEARS = "years";
    private static final String AGE = "age";
    private static final String DEGREE = "degree";
    private static final String MAJOR = "major";
    private static final String SCHOOL = "school";
    private static final String WORK_EXPIRENCE = "workExpirence";
    private static final String PROJECT_EXPERIENCE = "projectExperience";
    private static final String ANNUAL_INCOME = "annualIncome";
    private static final String ENG_LEVEL = "engLevel";
    private static final String SELF_INTRODUCTION = "selfIntroduction";

//    {
//        try {
//            baseInfoKeywordMap.put("个人简历", null);
//            baseInfoKeywordMap.put("教育经历", HrResume.class.getDeclaredField(EDDUCATION));
//            baseInfoKeywordMap.put("教育背景", HrResume.class.getDeclaredField(EDDUCATION));
//            baseInfoKeywordMap.put("毕业年份", HrResume.class.getDeclaredField(GRADUATE_DATE));
//            baseInfoKeywordMap.put("毕业时间", HrResume.class.getDeclaredField(GRADUATE_DATE));
//            baseInfoKeywordMap.put("住址", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("现居住于", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("现居住地", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("现居住", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("现居地", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("现所在地", HrResume.class.getDeclaredField(CITY));
//            baseInfoKeywordMap.put("职业方向", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("职业目标", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("目标职位", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("目标职能", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("求职意向", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("工作性质", HrResume.class.getDeclaredField(STAFF_TYPE));
//            baseInfoKeywordMap.put("期望职业", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("期望从事职业", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("期望职位", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("工作地区", HrResume.class.getDeclaredField(EXPECT_CITY));
//            baseInfoKeywordMap.put("工作地点", HrResume.class.getDeclaredField(EXPECT_CITY));
//            baseInfoKeywordMap.put("期望地点", HrResume.class.getDeclaredField(EXPECT_CITY));
//            baseInfoKeywordMap.put("目标地址", HrResume.class.getDeclaredField(EXPECT_CITY));
//            baseInfoKeywordMap.put("地点", HrResume.class.getDeclaredField(EXPECT_CITY));
//            baseInfoKeywordMap.put("期望月薪", HrResume.class.getDeclaredField(EXPECT_SALARY));
//            baseInfoKeywordMap.put("期望薪资", HrResume.class.getDeclaredField(EXPECT_SALARY));
//            baseInfoKeywordMap.put("薪资", HrResume.class.getDeclaredField(EXPECT_SALARY));
//            baseInfoKeywordMap.put("目前状况", null);
//            baseInfoKeywordMap.put("手机号码", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("手机", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("电话", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("电话号码", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("联系电话", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("联系方式", HrResume.class.getDeclaredField(PHONE));
//            baseInfoKeywordMap.put("E-mail", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("e-mail", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("电子邮件", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("电子邮箱", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("工作邮箱", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("邮箱", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("邮箱地址", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("电子信箱", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("电邮", HrResume.class.getDeclaredField(EMAIL));
//            baseInfoKeywordMap.put("身份证号码", null);
//            baseInfoKeywordMap.put("姓名", AbstractBaseEntity.class.getDeclaredField(NAME));
//            baseInfoKeywordMap.put("性别", HrResume.class.getDeclaredField(SEX));
//            baseInfoKeywordMap.put("工作年限", HrResume.class.getDeclaredField(YEARS));
//            baseInfoKeywordMap.put("工作时间", HrResume.class.getDeclaredField(YEARS));
//            baseInfoKeywordMap.put("民族", null);
//            baseInfoKeywordMap.put("籍贯", null);
//            baseInfoKeywordMap.put("户籍", null);
//            baseInfoKeywordMap.put("国籍", null);
//            baseInfoKeywordMap.put("年龄", HrResume.class.getDeclaredField(AGE));
//            baseInfoKeywordMap.put("学历/学位", HrResume.class.getDeclaredField(DEGREE));
//            baseInfoKeywordMap.put("学历", HrResume.class.getDeclaredField(DEGREE));
//            baseInfoKeywordMap.put("专业名称", HrResume.class.getDeclaredField(MAJOR));
//            baseInfoKeywordMap.put("所学专业", HrResume.class.getDeclaredField(MAJOR));
//            baseInfoKeywordMap.put("专业", HrResume.class.getDeclaredField(MAJOR));
//            baseInfoKeywordMap.put("婚否", null);
//            baseInfoKeywordMap.put("婚姻状况", null);
//            baseInfoKeywordMap.put("出生年月", null);
//            baseInfoKeywordMap.put("出生日期", null);
//            baseInfoKeywordMap.put("政治面貌", null);
//            baseInfoKeywordMap.put("毕业院校", HrResume.class.getDeclaredField(SCHOOL));
//            baseInfoKeywordMap.put("毕业学校", HrResume.class.getDeclaredField(SCHOOL));
//            baseInfoKeywordMap.put("学校", HrResume.class.getDeclaredField(SCHOOL));
//            baseInfoKeywordMap.put("户口", HrResume.class.getDeclaredField(CITY));
//
//            baseInfoKeywordMap.put("工作经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("工作经验", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("主要经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("实习经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("学术经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("工作实践经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
//            baseInfoKeywordMap.put("项目经验", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
//            baseInfoKeywordMap.put("项目信息", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
//            baseInfoKeywordMap.put("项目经历", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
//            baseInfoKeywordMap.put("到岗时间", null);
//            baseInfoKeywordMap.put("个人能力", null);
//            baseInfoKeywordMap.put("校园实践经历", null);
//            baseInfoKeywordMap.put("获奖情况", null);
//            baseInfoKeywordMap.put("补充说明 ", null);
//            baseInfoKeywordMap.put("工作技能及语言技能", null);
//            baseInfoKeywordMap.put("在校学习情况", null);
//            baseInfoKeywordMap.put("培训经历", null);
//            baseInfoKeywordMap.put("语言能力", null);
//            baseInfoKeywordMap.put("专业技能", null);
//            baseInfoKeywordMap.put("职业技能", null);
//            baseInfoKeywordMap.put("综合技能", null);
//            baseInfoKeywordMap.put("身体状况", null);
//            baseInfoKeywordMap.put("特长", null);
//            baseInfoKeywordMap.put("爱好", null);
//            baseInfoKeywordMap.put("英语水平", null);
//            baseInfoKeywordMap.put("证书", null);
//            baseInfoKeywordMap.put("职能", null);
//            baseInfoKeywordMap.put("行业", null);
//            baseInfoKeywordMap.put("自我简介", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
//            baseInfoKeywordMap.put("个人技能", null);
//            baseInfoKeywordMap.put("基本资料", null);
//            baseInfoKeywordMap.put("期望行业", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("期望从事行业", HrResume.class.getDeclaredField(POST));
//            baseInfoKeywordMap.put("目前年薪", HrResume.class.getDeclaredField(ANNUAL_INCOME));
//            baseInfoKeywordMap.put("外语水平", HrResume.class.getDeclaredField(ENG_LEVEL));
//            baseInfoKeywordMap.put("自我介绍", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
//            baseInfoKeywordMap.put("个人优势", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
//            baseInfoKeywordMap.put("自我评价", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
//
//        } catch (NoSuchFieldException | SecurityException e) {
//            log.debug(e.getLocalizedMessage());
//        }
//    }

    {
        try {
            baseInfoKeywordMap.put("个人简历", null);
            baseInfoKeywordMap.put("教育经历", null);
            baseInfoKeywordMap.put("教育背景", null);
            baseInfoKeywordMap.put("毕业年份", HrResume.class.getDeclaredField(GRADUATE_DATE));
            baseInfoKeywordMap.put("毕业时间", HrResume.class.getDeclaredField(GRADUATE_DATE));
            baseInfoKeywordMap.put("住址", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("现居住于", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("现居住地", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("现居住", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("现居地", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("现所在地", HrResume.class.getDeclaredField(CITY));
            baseInfoKeywordMap.put("职业方向", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("职业目标", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("目标职位", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("目标职能", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("求职意向", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("工作性质", HrResume.class.getDeclaredField(STAFF_TYPE));
            baseInfoKeywordMap.put("期望职业", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("期望从事职业", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("期望职位", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("工作地区", HrResume.class.getDeclaredField(EXPECT_CITY));
            baseInfoKeywordMap.put("工作地点", HrResume.class.getDeclaredField(EXPECT_CITY));
            baseInfoKeywordMap.put("期望地点", HrResume.class.getDeclaredField(EXPECT_CITY));
            baseInfoKeywordMap.put("目标地址", HrResume.class.getDeclaredField(EXPECT_CITY));
            baseInfoKeywordMap.put("地点", HrResume.class.getDeclaredField(EXPECT_CITY));
            baseInfoKeywordMap.put("期望月薪", HrResume.class.getDeclaredField(EXPECT_SALARY));
            baseInfoKeywordMap.put("期望薪资", HrResume.class.getDeclaredField(EXPECT_SALARY));
            baseInfoKeywordMap.put("薪资", HrResume.class.getDeclaredField(EXPECT_SALARY));
            baseInfoKeywordMap.put("目前状况", null);
            baseInfoKeywordMap.put("手机号码", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("手机", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("电话", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("电话号码", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("联系电话", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("联系方式", HrResume.class.getDeclaredField(PHONE));
            baseInfoKeywordMap.put("E-mail", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("e-mail", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("电子邮件", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("电子邮箱", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("工作邮箱", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("邮箱", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("邮箱地址", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("电子信箱", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("电邮", HrResume.class.getDeclaredField(EMAIL));
            baseInfoKeywordMap.put("身份证号码", null);
            baseInfoKeywordMap.put("姓名", AbstractBaseEntity.class.getDeclaredField(NAME));
            baseInfoKeywordMap.put("性别", HrResume.class.getDeclaredField(SEX));
            baseInfoKeywordMap.put("工作年限", HrResume.class.getDeclaredField(YEARS));
            baseInfoKeywordMap.put("工作时间", HrResume.class.getDeclaredField(YEARS));
            baseInfoKeywordMap.put("民族", null);
            baseInfoKeywordMap.put("籍贯", null);
            baseInfoKeywordMap.put("户籍", null);
            baseInfoKeywordMap.put("国籍", null);
            baseInfoKeywordMap.put("年龄", null);
            baseInfoKeywordMap.put("学历/学位", HrResume.class.getDeclaredField(DEGREE));
            baseInfoKeywordMap.put("学历", HrResume.class.getDeclaredField(DEGREE));
            baseInfoKeywordMap.put("专业名称", HrResume.class.getDeclaredField(MAJOR));
            baseInfoKeywordMap.put("所学专业", HrResume.class.getDeclaredField(MAJOR));
            baseInfoKeywordMap.put("专业", HrResume.class.getDeclaredField(MAJOR));
            baseInfoKeywordMap.put("婚否", null);
            baseInfoKeywordMap.put("婚姻状况", null);
            baseInfoKeywordMap.put("出生年月", null);
            baseInfoKeywordMap.put("出生日期", null);
            baseInfoKeywordMap.put("政治面貌", null);
            baseInfoKeywordMap.put("毕业院校", HrResume.class.getDeclaredField(SCHOOL));
            baseInfoKeywordMap.put("毕业学校", HrResume.class.getDeclaredField(SCHOOL));
            baseInfoKeywordMap.put("学校", HrResume.class.getDeclaredField(SCHOOL));
            baseInfoKeywordMap.put("户口", HrResume.class.getDeclaredField(CITY));

            baseInfoKeywordMap.put("工作经历", null);
            baseInfoKeywordMap.put("工作经验", null);
            baseInfoKeywordMap.put("主要经历", null);
            baseInfoKeywordMap.put("实习经历", null);
            baseInfoKeywordMap.put("学术经历", null);
            baseInfoKeywordMap.put("工作实践经历", null);
            baseInfoKeywordMap.put("项目经验", null);
            baseInfoKeywordMap.put("项目信息", null);
            baseInfoKeywordMap.put("项目经历", null);
            baseInfoKeywordMap.put("到岗时间", null);
            baseInfoKeywordMap.put("个人能力", null);
            baseInfoKeywordMap.put("校园实践经历", null);
            baseInfoKeywordMap.put("获奖情况", null);
            baseInfoKeywordMap.put("补充说明 ", null);
            baseInfoKeywordMap.put("工作技能及语言技能", null);
            baseInfoKeywordMap.put("在校学习情况", null);
            baseInfoKeywordMap.put("培训经历", null);
            baseInfoKeywordMap.put("语言能力", null);
            baseInfoKeywordMap.put("专业技能", null);
            baseInfoKeywordMap.put("职业技能", null);
            baseInfoKeywordMap.put("综合技能", null);
            baseInfoKeywordMap.put("身体状况", null);
            baseInfoKeywordMap.put("特长", null);
            baseInfoKeywordMap.put("爱好", null);
            baseInfoKeywordMap.put("英语水平", null);
            baseInfoKeywordMap.put("证书", null);
            baseInfoKeywordMap.put("职能", null);
            baseInfoKeywordMap.put("行业", null);
            baseInfoKeywordMap.put("自我简介", null);
            baseInfoKeywordMap.put("个人技能", null);
            baseInfoKeywordMap.put("基本资料", null);
            baseInfoKeywordMap.put("期望行业", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("期望从事行业", HrResume.class.getDeclaredField(POST));
            baseInfoKeywordMap.put("目前年薪", HrResume.class.getDeclaredField(ANNUAL_INCOME));
            baseInfoKeywordMap.put("外语水平", HrResume.class.getDeclaredField(ENG_LEVEL));
            baseInfoKeywordMap.put("自我介绍", null);
            baseInfoKeywordMap.put("个人优势", null);
            baseInfoKeywordMap.put("自我评价", null);

        } catch (NoSuchFieldException | SecurityException e) {
            log.error(e.getMessage());
        }
    }

    static {
        try {
            projectKeywordMap.put("职责描述", UserProjectExperience.class.getDeclaredField("duty"));
            projectKeywordMap.put("项目职责", UserProjectExperience.class.getDeclaredField("duty"));
            projectKeywordMap.put("本人主要工作", UserProjectExperience.class.getDeclaredField("duty"));
            projectKeywordMap.put("所在公司", UserProjectExperience.class.getDeclaredField("company"));
            projectKeywordMap.put("项目描述", UserProjectExperience.class.getDeclaredField("description"));
            projectKeywordMap.put("项目简介", UserProjectExperience.class.getDeclaredField("description"));
        } catch ( NoSuchFieldException | SecurityException e) {
            log.error(e.getLocalizedMessage());
        }

    }

    static {
        try {
            experienceKeywordMap.put("工作经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("工作经验", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("主要经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("主要经验", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("实习经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("学术经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("工作实践经历", HrResume.class.getDeclaredField(WORK_EXPIRENCE));
            experienceKeywordMap.put("项目经验", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
            experienceKeywordMap.put("项目信息", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
            experienceKeywordMap.put("项目经历", HrResume.class.getDeclaredField(PROJECT_EXPERIENCE));
            experienceKeywordMap.put("自我简介", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
            experienceKeywordMap.put("自我介绍", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
            experienceKeywordMap.put("个人优势", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
            experienceKeywordMap.put("自我评价", HrResume.class.getDeclaredField(SELF_INTRODUCTION));
            experienceKeywordMap.put("培训经历", null);
            experienceKeywordMap.put("基本信息", null);
            experienceKeywordMap.put("教育经历", HrResume.class.getDeclaredField(EDDUCATION));
            experienceKeywordMap.put("教育背景", HrResume.class.getDeclaredField(EDDUCATION));
            experienceKeywordMap.put("求职意向", null);
            experienceKeywordMap.put("语言能力", null);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    /**
     * Description: TODO
     *
     * @param resume
     */
    public void processFile(ConentType contentType, HrResume resume) {
        try {
            if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                    || "html".equals(contentType.getType()) || "docx".equals(contentType.getType())) {
                contentParseToResume(filterContentForNpl(contentType.getContent()), resume);
            } else {
                contentParseToResume(contentType.getContent(), resume);
            }
            CustomDefaultTemplate temp = new CustomDefaultTemplate();
            temp.buildInfo(contentType, resume);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    public void processFileOld(ConentType contentType, HrResume resume) {
        try {
            if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                    || "html".equals(contentType.getType()) || "docx".equals(contentType.getType())) {
                contentParseToResume(filterContentForNpl(contentType.getContent()).replaceAll("[^\u0020-\u9FA5]", ""), resume);
            } else {
                contentParseToResume(contentType.getContent().replaceAll("[^\u0020-\u9FA5]", ""), resume);
            }
            CustomDefaultTemplate temp = new CustomDefaultTemplate();
            temp.buildInfoByOldParse(contentType, resume);
            temp.buildWorkList(contentType, resume);
            temp.buildProjectList(contentType, resume);
            temp.buildEduList(contentType, resume);
        } catch (Exception e) {
            log.error(e.getLocalizedMessage());
            e.printStackTrace();
        }
    }

    /**
     * Description: TODO
     *
     * @param content
     * @return
     */
    public static String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<xml>.*?</xml>", "").replaceAll("<style>.*?</style>", "")
                .replaceAll("<.*?>", "");
    }

    public static String filterContentForNpl(String content) {
        return content.replaceAll("\\s+", " ").replaceAll("<xml>.*?</xml>", " ").replaceAll("<style>.*?</style>", " ")
                .replaceAll("<.*?>", " ").replaceAll(" +"," ");
    }

    /**
     * Description: TODO
     *
     * @param content
     * @param resume
     */
    public void contentParseToResume(String content, HrResume resume) {
        String newContent = filterContent(content);
        newContent = newContent.replace("年工作经验", "");
        List<KeywordEntity> resultList = getMatchedKeywords(newContent);
        List<KeywordEntity> experienceResultList = getMatchedProjectKeywords(newContent, experienceKeywordMap);
        setKeywordContentToMap(newContent, resultList);
        checkFormat(content,resultList);
        setKeywordContentToMap(newContent, experienceResultList);
        setDbValueByMatcheredKeyword(resultList, resume);
        setDbValueByMatcheredKeyword(experienceResultList, resume);
    }



    /**
     * Description: TODO
     *
     * @param resultList
     * @param resume
     */
    public void setDbValueByMatcheredKeyword(List<KeywordEntity> resultList, HrResume resume) {
        resultList.forEach(e -> {
            setValue(resume, e.getResumeField(), e.getKeyContent());
        });
    }

    private void setValue(Object bean, Field field, String matcheredValue) {
        if (field != null && matcheredValue != null) {
            String fieldSetName = parSetName(field.getName());
            Class<?> cls = bean.getClass();
            try {

                PropertyDescriptor pd = new PropertyDescriptor(field.getName(), cls);
                Method getMethod = pd.getReadMethod();

                Object checkExistValue = getMethod.invoke(bean, new Object[] {});
                if (checkExistValue != null && checkExistValue instanceof String
                        && StringUtils.isNotBlank((String) checkExistValue)) {
                    return;
                }
                Method fieldSetMet = cls.getMethod(fieldSetName, field.getType());
                String value = matcheredValue;
                if (matcheredValue.contains("\r\n")) {
                    matcheredValue = trimStart(matcheredValue,"\r\n");
                    value = matcheredValue.substring(0, matcheredValue.indexOf("\r\n"));
                } else if (matcheredValue.contains("\n")) {
                    matcheredValue = trimStart(matcheredValue,"\n");
                    value = matcheredValue.substring(0, matcheredValue.indexOf('\n'));
                } else if (matcheredValue.contains("\r")) {
                    matcheredValue = trimStart(matcheredValue,"\r");
                    value = matcheredValue.substring(0, matcheredValue.indexOf('\r'));
                } else if (matcheredValue.contains("\t")) {
                    matcheredValue = trimStart(matcheredValue,"\t");
                    value = matcheredValue.substring(0, matcheredValue.indexOf('\t'));
                }

                value = value.replace("\b", "");

                if (field.getName().equals(WORK_EXPIRENCE)
                        || field.getName().equals(PROJECT_EXPERIENCE)
                        || field.getName().equals(EDDUCATION)) {
                    value = matcheredValue;
                }
                if (null != value && !"".equals(value)) {
                    String fieldType = field.getType().getSimpleName();
                    if ("String".equals(fieldType)) {
                        fieldSetMet.invoke(bean, value);
                    } else if ("Date".equals(fieldType)) {
                        Date temp = parseDate(value);
                        fieldSetMet.invoke(bean, temp);
                    } else if ("Integer".equals(fieldType) || "int".equals(fieldType)) {
                        Integer intval = Integer.parseInt(value);
                        fieldSetMet.invoke(bean, intval);
                    } else if ("Long".equalsIgnoreCase(fieldType)) {
                        Long temp = Long.parseLong(value);
                        fieldSetMet.invoke(bean, temp);
                    } else if ("Double".equalsIgnoreCase(fieldType)) {
                        Double temp = Double.parseDouble(value);
                        fieldSetMet.invoke(bean, temp);
                    } else if ("Boolean".equalsIgnoreCase(fieldType)) {
                        Boolean temp = Boolean.parseBoolean(value);
                        fieldSetMet.invoke(bean, temp);
                    } else if ("SexEnum".equals(fieldType)) {
                        SexEnum sexEnum = parseSexEnum(value);
                        fieldSetMet.invoke(bean, sexEnum);
                    } else {
                        log.debug("not supper type" + fieldType);
                    }
                }
            } catch (Exception e) {
                log.error(e.getLocalizedMessage());
                e.printStackTrace();
            }
        }
    }

    private static String trimStart(String s,String regex){
        s =StringUtils.removeStart(s,regex);
        if(s.startsWith(regex)){
           s= trimStart(s,regex);
        }
        return s;
    }


    /**
     * 格式化string为Date
     *
     * @return date
     */
    private SexEnum parseSexEnum(String value) {
        if (SexEnum.WOMAN.getDesc().equals(value)) {
            return SexEnum.WOMAN;
        } else {
            return SexEnum.MAN;
        }
    }

    /**
     * 格式化string为Date
     *
     * @param datestr
     * @return date
     */
    private Date parseDate(String datestr) {
        if (null == datestr || "".equals(datestr)) {
            return null;
        }
        try {
            String fmtstr = null;
            if (datestr.indexOf(':') > 0) {
                fmtstr = "yyyy-MM-dd HH:mm:ss";
            } else {
                fmtstr = "yyyy-MM-dd";
            }
            SimpleDateFormat sdf = new SimpleDateFormat(fmtstr);
            return sdf.parse(datestr);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 拼接在某属性的 set方法
     *
     * @param fieldName
     * @return String
     */
    private String parSetName(String fieldName) {
        if (null == fieldName || "".equals(fieldName)) {
            return null;
        }
        return "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
    }

    /**
     * Description: TODO
     *
     * @param str
     * @param beginStr
     * @param endStr
     * @return
     */
    public String strSubstring(String str, String beginStr, String endStr) {
        if (str.contains(beginStr) && str.contains(endStr)) {
            int startIdx = str.indexOf(endStr, str.indexOf(beginStr) + beginStr.length());
            if (startIdx != -1) {
                return str.substring(str.indexOf(beginStr),
                        str.indexOf(endStr, str.indexOf(beginStr) + beginStr.length())).substring(beginStr.length());
            }
        }
        return "";
    }

    public List<KeywordEntity> getMatchedKeywords(String content) {
        Set<Map.Entry<String, Field>> keySet = baseInfoKeywordMap.entrySet();
        List<KeywordEntity> resultList = new ArrayList<KeywordEntity>();
        Map<Integer, String> map = new HashMap<Integer, String>();

        keySet.forEach(e -> {
            int index = content.indexOf(e.getKey());
            if (index > -1) {
                map.get(index);
                boolean temp = true;

                if (e.getKey().equals("手机")) {
                    String teleStr = content.substring(index, index + 25).replaceAll(" ", "");
                    String regex = "1[0-9]{2}.{4}[0-9]{4}";
                    Pattern pattern = Pattern.compile(regex);
                    Matcher matcher = pattern.matcher(teleStr);
                    if (!matcher.find()) return;
                }

                if (!map.containsKey(index) && temp) {
                    KeywordEntity keywordEntity = new KeywordEntity(index, e.getKey(), "", e.getValue());
                    resultList.add(keywordEntity);
                    map.put(index, e.getKey());
                }
            }
        });
        return resultList;
    }

    public List<KeywordEntity> getMatchedProjectKeywords(String content, Map<String, Field> keywordMap) {
        Set<Map.Entry<String, Field>> keySet = keywordMap.entrySet();
        List<KeywordEntity> resultList = new ArrayList<KeywordEntity>();
        Map<Integer, String> map = new HashMap<Integer, String>();

        keySet.forEach(e -> {
            int index = content.indexOf(e.getKey());
            if (index > -1) {
                if (!map.containsKey(index)) {
                    KeywordEntity keywordEntity = new KeywordEntity(index, e.getKey(), "", e.getValue());
                    resultList.add(keywordEntity);
                    map.put(index, e.getKey());
                }
            }
        });
        return resultList;
    }

    public List<KeywordEntity> setKeywordContentToMap(String content, List<KeywordEntity> resultList) {
        List<KeywordEntity> newResultList = new ArrayList<KeywordEntity>();
        newResultList.addAll(resultList);
        Collections.sort(newResultList);
        for (int i = 0; i < newResultList.size(); i++) {
            KeywordEntity keywordEntity = newResultList.get(i);
            if (i < (resultList.size() - 1)) {
                KeywordEntity nextKeywordEntity = newResultList.get(i + 1);
                try {

                    String keyContent = strSubstring(content, keywordEntity.getKeyword(),
                            nextKeywordEntity.getKeyword());
                    keywordEntity.setKeyContent(keyContent);
                } catch (Exception e) {
                    log.debug("begin str:" + keywordEntity.getKeyword() + " end str:" + nextKeywordEntity.getKeyword());
                    log.error(e.getLocalizedMessage());
                    e.printStackTrace();
                }
            } else {
                String keyContent = content.substring(content.indexOf(keywordEntity.getKeyword())).substring(
                        keywordEntity.getKeyword().length());
                keywordEntity.setKeyContent(keyContent);
            }
        }
        return newResultList;
    }

    /**
     * Description: TODO
     *
     * @param content
     * @return
     */
    public String filterContent(String content) {
        String newContent = "";
        if (content != null) {
            for (int i = 0; i < filterChar.length; i++) {
                if (i == 0) {
                    newContent = content.replaceAll(filterChar[i], "");
                } else {
                    newContent = newContent.replaceAll(filterChar[i], "");
                }
            }
        }
        newContent = newContent.trim();
        return newContent;
    }

    @Data
    class KeywordEntity implements Comparable<KeywordEntity> {
        private int index;
        private String keyword;
        private String keyContent;
        private Field resumeField;

        public KeywordEntity(int index, String keyword, String keyContent, Field resumeField) {
            this.index = index;
            this.keyword = keyword;
            this.keyContent = keyContent;
            this.resumeField = resumeField;
        }

        @Override
        public int compareTo(KeywordEntity o) {
            KeywordEntity k = (KeywordEntity) o;
            return this.index - k.index;
        }
    }

    private void checkFormat(String content,List<KeywordMatcher.KeywordEntity> resultList){
        List<KeywordMatcher.KeywordEntity> newResultList = new ArrayList<KeywordMatcher.KeywordEntity>();
        newResultList.addAll(resultList);
        for (int i = 0; i < newResultList.size(); i++) {
            KeywordMatcher.KeywordEntity keywordEntity = newResultList.get(i);
            String newCheckContent = keywordEntity.keyContent;
            if (newCheckContent.contains("】"))
                newCheckContent = newCheckContent.substring(newCheckContent.indexOf("】")+1);
            if (newCheckContent.contains("【"))
                newCheckContent = newCheckContent.substring(0,newCheckContent.indexOf("【"));
            keywordEntity.setKeyContent(newCheckContent);
        }
    }

    public void contentParseToProjectExperience(String content, UserProjectExperience experience) {
        String newContent = filterContent(content);
        List<KeywordEntity> resultList = getMatchedProjectKeywords(newContent, projectKeywordMap);
        setKeywordContentToMap(newContent, resultList);
        checkFormat(content,resultList);
        setDbValueByMatcheredKeyword(resultList, experience);
    }

    private void setDbValueByMatcheredKeyword(List<KeywordEntity> resultList, UserProjectExperience experience) {
        resultList.forEach(e -> {
            setValue(experience, e.getResumeField(), e.getKeyContent());
        });
    }
}
