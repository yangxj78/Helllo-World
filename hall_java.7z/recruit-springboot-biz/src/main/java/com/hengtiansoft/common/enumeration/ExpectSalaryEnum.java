package com.hengtiansoft.common.enumeration;

import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum ExpectSalaryEnum {

    SALARY_INTERVIEW(null, "面议"), LESS_THAN_FIVE_THOUSAND(8, "5k以下")
    , LESS_THAN_EIGHT_THOUSAND(9, "5k-8k"), LESS_THAN_TWELVE_THOUSAND(10, "8k-12k")
    , LESS_THAN_TWENTY_THOUSAND(11, "12k-20k"), MORE_THAN_TWENTY_THOUSAND(12, "20k以上");


    private Integer code;
    private String desc;

    ExpectSalaryEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Integer verifyExpectSalary(String str) {
        if(StringUtils.isEmpty(str)){
            return SALARY_INTERVIEW.getCode();
        }
        int unit = 1;
        if (str.contains("千") || str.toLowerCase().contains("k")) {
            unit = 1000;
        } else if (str.contains("万") || str.toLowerCase().contains("w") ) {
            unit = 10000;
        }
        if (str.contains("年")) {
            unit /= 12;
        }
        String regex = "^[0-9]+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            int salary = Integer.parseInt(matcher.group()) * unit;
            if (salary < 5000) {
                return LESS_THAN_FIVE_THOUSAND.getCode();
            } else if (salary < 8000) {
                return LESS_THAN_EIGHT_THOUSAND.getCode();
            } else if (salary < 12000) {
                return LESS_THAN_TWELVE_THOUSAND.getCode();
            } else if (salary < 20000) {
                return LESS_THAN_TWENTY_THOUSAND.getCode();
            } else {
                return MORE_THAN_TWENTY_THOUSAND.getCode();
            }
        }
        return SALARY_INTERVIEW.getCode();
    }

}
