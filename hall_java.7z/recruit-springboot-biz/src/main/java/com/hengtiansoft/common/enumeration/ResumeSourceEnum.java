package com.hengtiansoft.common.enumeration;

import lombok.Getter;
import lombok.Setter;

public enum ResumeSourceEnum {
    JOB51COLLECT("51jobCollect", "51JOB网络收集"), JOB51UPLOAD("51jobUpload", "51JOB网络下载"), ZHILIANCOLLECT(
            "zhilianCollect", "智联网络收集"), ZHILIANUPLOAD("zhilianUpload", "智联网络下载"), LIEPINCOLLECT("liepinCollect",
            "猎聘网络收集"), LIEPINUPLOAD("liepinUpload", "猎聘网络下载"), TC58COLLECT("TC58Collect", "58同城网络收集"), TC58UPLOAD(
            "TC58Upload", "58同城网络下载"), LAGOUCOLLECT("lagouCollect", "拉勾网络收集"), LAGOUUPLOAD("lagouUpload", "拉勾网络下载"), HEADHUNTER(
            "headhunter", "猎头"), INSTITUTE("institute", "培训机构"), CAMPUS("campus", "校园招聘"), INTERNAL("internal", "内部推荐"), SPECIAL(
            "special", "专场招聘"), DAJIEUPLOAD("dajieupload", "大街网下载"), OTHER("other", "其他");

    @Getter
    @Setter
    private String description;
    @Getter
    @Setter
    private String name;

    ResumeSourceEnum(String name, String desc) {
        setName(name);
        this.description = desc;
    }
}
