package com.hengtiansoft.common.enumeration;

/**
 * 面试邀约状态枚举类
 * Created by linwu on 7/18/2018.
 */
public enum InvitedStatusEnum {

    UNSOLICITED(0, "未邀约"), HAVE_BEEN_INVITED(1, "已邀约") ;

    private Integer code;

    private String desc;

    InvitedStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
