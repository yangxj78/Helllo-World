package com.hengtiansoft.common.utils;

import com.hengtiansoft.bean.dataModel.InterViewResultDto;
import com.hengtiansoft.bean.dataModel.InterviewExcelDataDto;
import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.enumeration.InterviewResultEnum;
import com.hengtiansoft.common.util.SpringContextUtil;
import com.hengtiansoft.common.util.StringUtils;
import io.netty.util.internal.StringUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFDataFormat;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.util.ResourceUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 根据excel模板生成面试统计记录
 */
public class ExcelUtils {

    private static final String INTERVIEW_EXCEL_TEMPLATE = "面试评价汇总.xlsx";

    private static final String INTERVIEW_EXCEL_TEMPLATE_PATH = "classpath:templates/";

    public static File getInterviewEvaluationSummary(List<InterviewExcelDataDto> interviewExcelDataDtoList) {
        File result = null;
        InputStream input;
        try {
            File template = null;
            if (ApplicationConstant.DEV.equals(SpringContextUtil.getActiveProfile())) {
                template = ResourceUtils.getFile(INTERVIEW_EXCEL_TEMPLATE_PATH + INTERVIEW_EXCEL_TEMPLATE);
            } else {
                template = new File(INTERVIEW_EXCEL_TEMPLATE);
            }
            input = new FileInputStream(template);
            OPCPackage pkg = OPCPackage.open(input);
            XSSFWorkbook wb = new XSSFWorkbook(pkg);
            Sheet sheet = wb.getSheetAt(0);
            CreationHelper createHelper = wb.getCreationHelper();

            for (int i = 0; i < interviewExcelDataDtoList.size(); i++) {
                Row currentRow = sheet.createRow(i + 2);
                InterviewExcelDataDto temp = interviewExcelDataDtoList.get(i);

                //填入面试者基础信息
                createCell(wb, currentRow, 0).setCellValue(i + 1);
                createCell(wb, currentRow, 1).setCellValue(temp.getName());
                createCell(wb, currentRow, 2).setCellValue(StringUtils.nullToEmpty(temp.getBirthDate()));
                createCell(wb, currentRow, 3).setCellValue(StringUtils.nullToEmpty(temp.getSex()));
                createCell(wb, currentRow, 4).setCellValue(StringUtils.nullToEmpty(temp.getSchool()));
                createCell(wb, currentRow, 5).setCellValue(StringUtils.nullToEmpty(temp.getMajor()));
                createCell(wb, currentRow, 6).setCellValue(StringUtils.nullToEmpty(temp.getEducational()));
                createCell(wb, currentRow, 7).setCellValue(StringUtils.nullToEmpty(temp.getWorkYears()));
                createCell(wb, currentRow, 8).setCellValue(StringUtils.nullToEmpty(temp.getPositionRecordName()));

                for (int j = 0; j < 5; j++) {
                    int columnTemp = 8 + 6 * j;
                    if (j < temp.getInterviewList().size()) {
                        InterViewResultDto interViewResultDto = temp.getInterviewList().get(j);
                        createCell(wb, currentRow, columnTemp + 1).setCellValue(judgeReturn(interViewResultDto.getMatching()));
                        createCell(wb, currentRow, columnTemp + 2).setCellValue(judgeReturn(interViewResultDto.getProfession()));
                        createCell(wb, currentRow, columnTemp + 3).setCellValue(judgeReturn(interViewResultDto.getLearning()));
                        createCell(wb, currentRow, columnTemp + 4).setCellValue(judgeReturn(interViewResultDto.getCommunicate()));
                        createCell(wb, currentRow, columnTemp + 5).setCellValue(interViewResultDto.getInterviewEvaluation());
                        currentRow.getCell(columnTemp + 5).getCellStyle().setWrapText(true);
                        createCell(wb, currentRow, columnTemp + 6).setCellValue(interViewResultDto.getInterviewResult());
                    } else {
                        createCell(wb, currentRow, columnTemp + 1);
                        createCell(wb, currentRow, columnTemp + 2);
                        createCell(wb, currentRow, columnTemp + 3);
                        createCell(wb, currentRow, columnTemp + 4);
                        createCell(wb, currentRow, columnTemp + 5);
                        createCell(wb, currentRow, columnTemp + 6);
                    }


                }
            }

            result = File.createTempFile("tempExcel", ".xlsx");
            wb.write(new FileOutputStream(result));

            pkg.close();
        } catch (InvalidFormatException | IOException e) {
            e.printStackTrace();
        }

        return result;
    }


    /**
     * Creates a cell and aligns it a certain way.
     *
     * @param wb     the workbook
     * @param row    the row to create the cell in
     * @param column the column number to create the cell in
     */
    private static Cell createCell(Workbook wb, Row row, int column) {
        Cell cell = row.createCell(column);
        CellStyle cellStyle = wb.createCellStyle();
        cellStyle.setAlignment(cellStyle.ALIGN_CENTER);
        cellStyle.setVerticalAlignment(cellStyle.VERTICAL_CENTER);

        // Style the cell with borders all around.
        cellStyle.setBorderLeft(cellStyle.BORDER_THIN);
        cellStyle.setBorderRight(cellStyle.BORDER_THIN);
        cellStyle.setBorderTop(cellStyle.BORDER_THIN);
        cellStyle.setBorderBottom(cellStyle.BORDER_THIN);
        cell.setCellStyle(cellStyle);
        return cell;
    }

    private static String judgeReturn(Integer var) {
        return var != null ? (var * 100) / 5 + "%" : "";
    }

}
