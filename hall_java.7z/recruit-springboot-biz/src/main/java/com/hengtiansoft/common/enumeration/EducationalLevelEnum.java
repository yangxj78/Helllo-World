package com.hengtiansoft.common.enumeration;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public enum EducationalLevelEnum {
    UNLIMITED(15, "不限"), DOCTOR(16, "博士研究生")
    , MASTER(17, "硕士研究生"),UNDERGRADUATE_COLLEGE(18,"大学本科")
    ,COLLEGE(19,"大学专科"),BELOW_COLLEGE(20,"大专以下");

    private Integer code;
    private String desc;
    private static final Map<Integer, EducationalLevelEnum> map;

    static {
        map = new HashMap<>();
        for (EducationalLevelEnum educationalLevelEnum : EducationalLevelEnum.values()) {
            map.put(educationalLevelEnum.code, educationalLevelEnum);
        }
    }

    EducationalLevelEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Map<Integer, EducationalLevelEnum> getMap() {
        return map;
    }

    public static Integer verifyEducationLevel(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        if (str.contains("博士")){
            return DOCTOR.getCode();
        } else if (str.contains("硕士")||str.contains("研究生")) {
            return MASTER.getCode();
        } else if (str.contains("本科")) {
            return UNDERGRADUATE_COLLEGE.getCode();
        } else if (!str.contains("大专以下")&&(str.contains("大专")||str.contains("大学专科"))) {
            return COLLEGE.getCode();
        } else if (str.contains("大专以下")) {
            return BELOW_COLLEGE.getCode();
        }
        return null;
    }
}
