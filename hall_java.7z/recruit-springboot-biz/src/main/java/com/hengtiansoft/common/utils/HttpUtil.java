package com.hengtiansoft.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;

/**
 * 网络请求处理工具
 */
public class HttpUtil {

    /**
     * post请求统一处理工具
     * @param url
     * @param headers
     * @param params
     * @param type
     * @return
     */
   public JSONObject postRequest(String url, Map<String,String> headers, Map<String,String> params) {
       CloseableHttpClient  httpClient= HttpClients.createDefault();

       HttpPost httpPost = null;
       CloseableHttpResponse httpResponse;
       JSONObject result = null;
       try{
           httpPost = new HttpPost(url);
           Gson gson = new Gson();
           String parameter = gson.toJson(params);
           StringEntity stringEntity = new StringEntity(parameter);
           httpPost.setEntity(stringEntity);
           //设置请求header
           if(headers != null && headers.size() > 0){
               for (String str:headers.keySet()) {
                   httpPost.addHeader(str, headers.get(str));
               }
           }
           httpResponse = httpClient.execute(httpPost);
           HttpEntity entity = httpResponse.getEntity();
           String resultStr = EntityUtils.toString(entity, "UTF-8");
           result = JSONObject.parseObject(resultStr);
       }catch(Exception e){
           e.printStackTrace();
       }finally {
           if(httpPost!=null) {
               httpPost.releaseConnection();
           }
       }
       return result;
   }

    /**
     * get请求统一处理工具
     * @param url
     * @param headers
     * @return
     */
   public CookieStore getRequest(String url, Map<String,String> headers, CookieStore cookieStore){
       DefaultHttpClient httpClient=new DefaultHttpClient();
       if(cookieStore != null){
           httpClient.setCookieStore(cookieStore);
       }
       HttpGet httpGet = null;
       try{
           httpGet = new HttpGet(url);
           //设置请求头(headers)
           //设置请求header
           if(headers != null && headers.size() > 0){
               for (String str:headers.keySet()) {
                   httpGet.addHeader(str, headers.get(str));
               }
           }
           HttpResponse responseGet = httpClient.execute(httpGet);
           String result = EntityUtils.toString(responseGet.getEntity(), "UTF-8");
       }catch(Exception e){
           e.printStackTrace();
       }finally {
           if(httpGet != null){
              httpGet.releaseConnection();
           }
       }
       return httpClient.getCookieStore();
   }

   public void download(String urlStr,String filename,String savePath){
       try {
           URL url = new URL(urlStr);
           URLConnection con = url.openConnection();
           InputStream inStream = con.getInputStream();
           ByteArrayOutputStream outStream = new ByteArrayOutputStream();
           byte[] buf = new byte[1024];
           int len = 0;
           while ((len = inStream.read(buf)) != -1) {
               outStream.write(buf, 0, len);
           }
           inStream.close();
           outStream.close();
           File file = new File(savePath+File.separator+filename);    //图片下载地址
           FileOutputStream op = new FileOutputStream(file);
           op.write(outStream.toByteArray());
           op.close();
       }catch(Exception e){
           e.printStackTrace();
       }
   }

}
