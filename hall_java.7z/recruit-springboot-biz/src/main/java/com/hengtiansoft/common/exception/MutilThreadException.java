package com.hengtiansoft.common.exception;

public class MutilThreadException extends Exception {

	public MutilThreadException(Exception e2) {
		super(e2);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -936174945156933041L;

}
