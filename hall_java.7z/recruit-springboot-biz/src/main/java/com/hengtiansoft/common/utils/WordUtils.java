package com.hengtiansoft.common.utils;


import com.hengtiansoft.common.constant.ApplicationConstant;
import com.hengtiansoft.common.util.SpringContextUtil;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.springframework.util.ResourceUtils;

import javax.servlet.ServletOutputStream;
import javax.swing.*;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简历邮件ftl模板转word
 * Created by linwu on 9/18/2018.
 */
public class WordUtils {

    private static final String RESUME_TEMPLATE_PATH = "classpath:templates";

    private static final String RESUME_TEMPLATE = "简历模板.ftl";

    private static Configuration configuration = null;

    static {
        configuration = new Configuration();
        configuration.setDefaultEncoding("UTF-8");
        try {
            if (ApplicationConstant.DEV.equals(SpringContextUtil.getActiveProfile())) {
                configuration.setDirectoryForTemplateLoading(ResourceUtils.getFile(RESUME_TEMPLATE_PATH));
            } else {
                configuration.setDirectoryForTemplateLoading(new File(RESUME_TEMPLATE));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private WordUtils() {

    }

    public static File exportMillCertificateWord(Map map) throws IOException{
        Template freemarkerTemplate = configuration.getTemplate(RESUME_TEMPLATE);
        File file = null;
        try {
            file = createDoc(map, freemarkerTemplate);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }

    private static File createDoc(Map<?, ?> dataMap, Template template) throws IOException {
        File f = File.createTempFile("temp", ".doc");
        //File f = new File("F:\\temp.doc");
        Template t = template;
        try {
            Writer w = new OutputStreamWriter(new FileOutputStream(f), "utf-8");
            t.process(dataMap, w);
            w.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException();
        }
        return f;
    }

    public static void main(String[] args) throws IOException {
        Map<String, Object> map = new HashMap<>();
        map.put("name", "linwu");
        map.put("sex", "男");
        map.put("birthdate", "1994-12-23");
        map.put("phone", "15168289465");
        map.put("email", "1025405803@qq.com");
        map.put("workType", "java工程师");
        map.put("expectedSalary", "15k~20k");
        map.put("workTimeType", "全职");
        map.put("region", "杭州");
        List<Map<String, Object>> userEducationExperienceList = new ArrayList<>();
        Map<String, Object> map1 = new HashMap<>();
        map1.put("startTs", "2010.10");
        map1.put("endTs", "2014.10");
        map1.put("school", "浙江大学城市学院");
        map1.put("major", "导弹工程");
        map1.put("educational", "大学本科");
        userEducationExperienceList.add(map1);
        Map<String, Object> map2 = new HashMap<>();
        map2.put("startTs", "2014.10");
        map2.put("endTs", "2018.10");
        map2.put("school", "浙江大学城市学院2");
        map2.put("major", "导弹工程2");
        map2.put("educational", "大学本科2");
        userEducationExperienceList.add(map2);
        map.put("userEducationExperienceList", userEducationExperienceList);

        List<Map<String, Object>> userWorkExperienceList = new ArrayList<>();
        for (int i = 1; i <= 2; i++) {
            Map<String, Object> map3 = new HashMap<>();
            map3.put("company", "浙江网新恒天软件有限公司" + i);
            map3.put("job", "软件工程师" + i);
            map3.put("startTs", "2010.10");
            map3.put("endTs", "2014.10");
            map3.put("description", "参与软件开发" + i);
            userWorkExperienceList.add(map3);
        }
        map.put("userWorkExperienceList", userWorkExperienceList);

        List<Map<String, Object>> userProjectExperienceList = new ArrayList<>();
        for (int i = 1; i <= 2; i++) {
            Map<String, Object> map4 = new HashMap<>();
            map4.put("projectName", "美国医疗系统ALS" + i);
            map4.put("startTs", "2010.10");
            map4.put("endTs", "2014.10");
            map4.put("description", "美国最大医疗系统信息网站" + i);
            map4.put("duty", "参与软件开发" + i);
            userProjectExperienceList.add(map4);
        }
        map.put("userProjectExperienceList", userProjectExperienceList);

        map.put("selfIntroduction", "1个人优势\n" +
                "专业:熟悉测试理论,测试流程及测试技术,丰富的测试经验\n" +
                "态度:为人踏实,善于沟通,具有良好的团队合作精神\n" +
                "工作:具有强烈的责任感和敬业精神,做事负责,认真,细\n" +
                "特长:适应能力强,有较强的学领悟力和观察力\n" +
                "1期室职位\n" +
                "移动端测试杭州12k-15k移动互联网·计算机软件\n" +
                "1工作经历\n" +
                "武汉佰钧成技术有限责任公司\"1个人优势\\n\" +\n" +
                "                \"专业:熟悉测试理论,测试流程及测试技术,丰富的测试经验\\n\" +\n" +
                "                \"态度:为人踏实,善于沟通,具有良好的团队合作精神\\n\" +\n" +
                "                \"工作:具有强烈的责任感和敬业精神,做事负责,认真,细\\n\" +\n" +
                "                \"特长:适应能力强,有较强的学领悟力和观察力\\n\" +\n" +
                "                \"1期室职位\\n\" +\n" +
                "                \"移动端测试杭州12k-15k移动互联网·计算机软件\\n\" +\n" +
                "                \"1工作经历\\n\" +\n" +
                "                \"武汉佰钧成技术有限责任公司");

        exportMillCertificateWord(map);
    }


}
