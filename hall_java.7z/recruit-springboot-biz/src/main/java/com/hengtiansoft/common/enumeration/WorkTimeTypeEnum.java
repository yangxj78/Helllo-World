package com.hengtiansoft.common.enumeration;

import org.apache.commons.lang3.StringUtils;

public enum WorkTimeTypeEnum {

    PART_TIME_EMPLOYEE(37, "兼职"), FULL_TIME_EMPLOYEE(36, "全职");


    private Integer code;
    private String desc;

    WorkTimeTypeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Integer verifyWorkTimeType(String str) {
        if (StringUtils.isEmpty(str)) {
            return FULL_TIME_EMPLOYEE.getCode();
        }
        if (str.contains("全职")) {
            return FULL_TIME_EMPLOYEE.getCode();
        } else if (str.contains("兼职")) {
            return PART_TIME_EMPLOYEE.getCode();
        }

        return FULL_TIME_EMPLOYEE.getCode();
    }

}
