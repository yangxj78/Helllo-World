package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * 面试枚举类
 * Created by linwu on 7/18/2018.
 */
public enum InterviewEnum {

    END(0, "结束"), CONTINUE(1, "继续");

    private Integer code;

    private String desc;

    private static final Map<Integer, InterviewEnum> map;

    static {
        map = new HashMap<>();
        for (InterviewEnum interviewResultEnum : InterviewEnum.values()) {
            map.put(interviewResultEnum.code, interviewResultEnum);
        }
    }

    InterviewEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }


    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }


    public static Map<Integer, InterviewEnum> getMap() {
        return map;
    }


}
