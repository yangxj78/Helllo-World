package com.hengtiansoft.common.converters;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.Segment;
import com.hankcs.hanlp.seg.common.Term;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegionMatcher {

    //根据SHORT_NAME（市级）搜索得到唯一id
    private static Map<String, Integer> keywordMap1 = new HashMap<String, Integer>();

    //找不到市再找省
    private static Map<String, Integer> keywordMap2 = new HashMap<String, Integer>();


    {
        keywordMap1.put("北京",110100);
        keywordMap1.put("天津",120100);
        keywordMap1.put("石家庄",130100);
        keywordMap1.put("唐山",130200);
        keywordMap1.put("秦皇岛",130300);
        keywordMap1.put("邯郸",130400);
        keywordMap1.put("邢台",130500);
        keywordMap1.put("保定",130600);
        keywordMap1.put("张家口",130700);
        keywordMap1.put("承德",130800);
        keywordMap1.put("沧州",130900);
        keywordMap1.put("廊坊",131000);
        keywordMap1.put("衡水",131100);
        keywordMap1.put("太原",140100);
        keywordMap1.put("大同",140200);
        keywordMap1.put("阳泉",140300);
        keywordMap1.put("长治",140400);
        keywordMap1.put("晋城",140500);
        keywordMap1.put("朔州",140600);
        keywordMap1.put("晋中",140700);
        keywordMap1.put("运城",140800);
        keywordMap1.put("忻州",140900);
        keywordMap1.put("临汾",141000);
        keywordMap1.put("吕梁",141100);
        keywordMap1.put("呼和浩特",150100);
        keywordMap1.put("包头",150200);
        keywordMap1.put("乌海",150300);
        keywordMap1.put("赤峰",150400);
        keywordMap1.put("通辽",150500);
        keywordMap1.put("鄂尔多斯",150600);
        keywordMap1.put("呼伦贝尔",150700);
        keywordMap1.put("巴彦淖尔",150800);
        keywordMap1.put("乌兰察布",150900);
        keywordMap1.put("兴安盟",152200);
        keywordMap1.put("锡林郭勒盟",152500);
        keywordMap1.put("阿拉善盟",152900);
        keywordMap1.put("沈阳",210100);
        keywordMap1.put("大连",210200);
        keywordMap1.put("鞍山",210300);
        keywordMap1.put("抚顺",210400);
        keywordMap1.put("本溪",210500);
        keywordMap1.put("丹东",210600);
        keywordMap1.put("锦州",210700);
        keywordMap1.put("营口",210800);
        keywordMap1.put("阜新",210900);
        keywordMap1.put("辽阳",211000);
        keywordMap1.put("盘锦",211100);
        keywordMap1.put("铁岭",211200);
        keywordMap1.put("朝阳",211300);
        keywordMap1.put("葫芦岛",211400);
        keywordMap1.put("金普新区",211500);
        keywordMap1.put("长春",220100);
        keywordMap1.put("吉林",220200);
        keywordMap1.put("四平",220300);
        keywordMap1.put("辽源",220400);
        keywordMap1.put("通化",220500);
        keywordMap1.put("白山",220600);
        keywordMap1.put("松原",220700);
        keywordMap1.put("白城",220800);
        keywordMap1.put("延边",222400);
        keywordMap1.put("哈尔滨",230100);
        keywordMap1.put("齐齐哈尔",230200);
        keywordMap1.put("鸡西",230300);
        keywordMap1.put("鹤岗",230400);
        keywordMap1.put("双鸭山",230500);
        keywordMap1.put("大庆",230600);
        keywordMap1.put("伊春",230700);
        keywordMap1.put("佳木斯",230800);
        keywordMap1.put("七台河",230900);
        keywordMap1.put("牡丹江",231000);
        keywordMap1.put("黑河",231100);
        keywordMap1.put("绥化",231200);
        keywordMap1.put("大兴安岭",232700);
        keywordMap1.put("上海",310100);
        keywordMap1.put("南京",320100);
        keywordMap1.put("无锡",320200);
        keywordMap1.put("徐州",320300);
        keywordMap1.put("常州",320400);
        keywordMap1.put("苏州",320500);
        keywordMap1.put("南通",320600);
        keywordMap1.put("连云港",320700);
        keywordMap1.put("淮安",320800);
        keywordMap1.put("盐城",320900);
        keywordMap1.put("扬州",321000);
        keywordMap1.put("镇江",321100);
        keywordMap1.put("泰州",321200);
        keywordMap1.put("宿迁",321300);
        keywordMap1.put("杭州",330100);
        keywordMap1.put("宁波",330200);
        keywordMap1.put("温州",330300);
        keywordMap1.put("嘉兴",330400);
        keywordMap1.put("湖州",330500);
        keywordMap1.put("绍兴",330600);
        keywordMap1.put("金华",330700);
        keywordMap1.put("衢州",330800);
        keywordMap1.put("舟山",330900);
        keywordMap1.put("台州",331000);
        keywordMap1.put("丽水",331100);
        keywordMap1.put("舟山新区",331200);
        keywordMap1.put("合肥",340100);
        keywordMap1.put("芜湖",340200);
        keywordMap1.put("蚌埠",340300);
        keywordMap1.put("淮南",340400);
        keywordMap1.put("马鞍山",340500);
        keywordMap1.put("淮北",340600);
        keywordMap1.put("铜陵",340700);
        keywordMap1.put("安庆",340800);
        keywordMap1.put("黄山",341000);
        keywordMap1.put("滁州",341100);
        keywordMap1.put("阜阳",341200);
        keywordMap1.put("宿州",341300);
        keywordMap1.put("六安",341500);
        keywordMap1.put("亳州",341600);
        keywordMap1.put("池州",341700);
        keywordMap1.put("宣城",341800);
        keywordMap1.put("福州",350100);
        keywordMap1.put("厦门",350200);
        keywordMap1.put("莆田",350300);
        keywordMap1.put("三明",350400);
        keywordMap1.put("泉州",350500);
        keywordMap1.put("漳州",350600);
        keywordMap1.put("南平",350700);
        keywordMap1.put("龙岩",350800);
        keywordMap1.put("宁德",350900);
        keywordMap1.put("南昌",360100);
        keywordMap1.put("景德镇",360200);
        keywordMap1.put("萍乡",360300);
        keywordMap1.put("九江",360400);
        keywordMap1.put("新余",360500);
        keywordMap1.put("鹰潭",360600);
        keywordMap1.put("赣州",360700);
        keywordMap1.put("吉安",360800);
        keywordMap1.put("宜春",360900);
        keywordMap1.put("抚州",361000);
        keywordMap1.put("上饶",361100);
        keywordMap1.put("济南",370100);
        keywordMap1.put("青岛",370200);
        keywordMap1.put("淄博",370300);
        keywordMap1.put("枣庄",370400);
        keywordMap1.put("东营",370500);
        keywordMap1.put("烟台",370600);
        keywordMap1.put("潍坊",370700);
        keywordMap1.put("济宁",370800);
        keywordMap1.put("泰安",370900);
        keywordMap1.put("威海",371000);
        keywordMap1.put("日照",371100);
        keywordMap1.put("莱芜",371200);
        keywordMap1.put("临沂",371300);
        keywordMap1.put("德州",371400);
        keywordMap1.put("聊城",371500);
        keywordMap1.put("滨州",371600);
        keywordMap1.put("菏泽",371700);
        keywordMap1.put("郑州",410100);
        keywordMap1.put("开封",410200);
        keywordMap1.put("洛阳",410300);
        keywordMap1.put("平顶山",410400);
        keywordMap1.put("安阳",410500);
        keywordMap1.put("鹤壁",410600);
        keywordMap1.put("新乡",410700);
        keywordMap1.put("焦作",410800);
        keywordMap1.put("濮阳",410900);
        keywordMap1.put("许昌",411000);
        keywordMap1.put("漯河",411100);
        keywordMap1.put("三门峡",411200);
        keywordMap1.put("南阳",411300);
        keywordMap1.put("商丘",411400);
        keywordMap1.put("信阳",411500);
        keywordMap1.put("周口",411600);
        keywordMap1.put("驻马店",411700);
        keywordMap1.put("武汉",420100);
        keywordMap1.put("黄石",420200);
        keywordMap1.put("十堰",420300);
        keywordMap1.put("宜昌",420500);
        keywordMap1.put("襄阳",420600);
        keywordMap1.put("鄂州",420700);
        keywordMap1.put("荆门",420800);
        keywordMap1.put("孝感",420900);
        keywordMap1.put("荆州",421000);
        keywordMap1.put("黄冈",421100);
        keywordMap1.put("咸宁",421200);
        keywordMap1.put("随州",421300);
        keywordMap1.put("恩施",422800);
        keywordMap1.put("长沙",430100);
        keywordMap1.put("株洲",430200);
        keywordMap1.put("湘潭",430300);
        keywordMap1.put("衡阳",430400);
        keywordMap1.put("邵阳",430500);
        keywordMap1.put("岳阳",430600);
        keywordMap1.put("常德",430700);
        keywordMap1.put("张家界",430800);
        keywordMap1.put("益阳",430900);
        keywordMap1.put("郴州",431000);
        keywordMap1.put("永州",431100);
        keywordMap1.put("怀化",431200);
        keywordMap1.put("娄底",431300);
        keywordMap1.put("湘西",433100);
        keywordMap1.put("广州",440100);
        keywordMap1.put("韶关",440200);
        keywordMap1.put("深圳",440300);
        keywordMap1.put("珠海",440400);
        keywordMap1.put("汕头",440500);
        keywordMap1.put("佛山",440600);
        keywordMap1.put("江门",440700);
        keywordMap1.put("湛江",440800);
        keywordMap1.put("茂名",440900);
        keywordMap1.put("肇庆",441200);
        keywordMap1.put("惠州",441300);
        keywordMap1.put("梅州",441400);
        keywordMap1.put("汕尾",441500);
        keywordMap1.put("河源",441600);
        keywordMap1.put("阳江",441700);
        keywordMap1.put("清远",441800);
        keywordMap1.put("东莞",441900);
        keywordMap1.put("中山",442000);
        keywordMap1.put("潮州",445100);
        keywordMap1.put("揭阳",445200);
        keywordMap1.put("云浮",445300);
        keywordMap1.put("南宁",450100);
        keywordMap1.put("柳州",450200);
        keywordMap1.put("桂林",450300);
        keywordMap1.put("梧州",450400);
        keywordMap1.put("北海",450500);
        keywordMap1.put("防城港",450600);
        keywordMap1.put("钦州",450700);
        keywordMap1.put("贵港",450800);
        keywordMap1.put("玉林",450900);
        keywordMap1.put("百色",451000);
        keywordMap1.put("贺州",451100);
        keywordMap1.put("河池",451200);
        keywordMap1.put("来宾",451300);
        keywordMap1.put("崇左",451400);
        keywordMap1.put("海口",460100);
        keywordMap1.put("三亚",460200);
        keywordMap1.put("三沙",460300);
        keywordMap1.put("重庆",500100);
        keywordMap1.put("两江新区",500300);
        keywordMap1.put("成都",510100);
        keywordMap1.put("自贡",510300);
        keywordMap1.put("攀枝花",510400);
        keywordMap1.put("泸州",510500);
        keywordMap1.put("德阳",510600);
        keywordMap1.put("绵阳",510700);
        keywordMap1.put("广元",510800);
        keywordMap1.put("遂宁",510900);
        keywordMap1.put("内江",511000);
        keywordMap1.put("乐山",511100);
        keywordMap1.put("南充",511300);
        keywordMap1.put("眉山",511400);
        keywordMap1.put("宜宾",511500);
        keywordMap1.put("广安",511600);
        keywordMap1.put("达州",511700);
        keywordMap1.put("雅安",511800);
        keywordMap1.put("巴中",511900);
        keywordMap1.put("资阳",512000);
        keywordMap1.put("阿坝",513200);
        keywordMap1.put("甘孜",513300);
        keywordMap1.put("凉山",513400);
        keywordMap1.put("贵阳",520100);
        keywordMap1.put("六盘水",520200);
        keywordMap1.put("遵义",520300);
        keywordMap1.put("安顺",520400);
        keywordMap1.put("毕节",520500);
        keywordMap1.put("铜仁",520600);
        keywordMap1.put("黔西南",522300);
        keywordMap1.put("黔东南",522600);
        keywordMap1.put("黔南",522700);
        keywordMap1.put("昆明",530100);
        keywordMap1.put("曲靖",530300);
        keywordMap1.put("玉溪",530400);
        keywordMap1.put("保山",530500);
        keywordMap1.put("昭通",530600);
        keywordMap1.put("丽江",530700);
        keywordMap1.put("普洱",530800);
        keywordMap1.put("临沧",530900);
        keywordMap1.put("楚雄",532300);
        keywordMap1.put("红河",532500);
        keywordMap1.put("文山",532600);
        keywordMap1.put("西双版纳",532800);
        keywordMap1.put("大理",532900);
        keywordMap1.put("德宏",533100);
        keywordMap1.put("怒江",533300);
        keywordMap1.put("迪庆",533400);
        keywordMap1.put("拉萨",540100);
        keywordMap1.put("日喀则",540200);
        keywordMap1.put("昌都",540300);
        keywordMap1.put("山南",542200);
        keywordMap1.put("那曲",542400);
        keywordMap1.put("阿里",542500);
        keywordMap1.put("林芝",542600);
        keywordMap1.put("西安",610100);
        keywordMap1.put("铜川",610200);
        keywordMap1.put("宝鸡",610300);
        keywordMap1.put("咸阳",610400);
        keywordMap1.put("渭南",610500);
        keywordMap1.put("延安",610600);
        keywordMap1.put("汉中",610700);
        keywordMap1.put("榆林",610800);
        keywordMap1.put("安康",610900);
        keywordMap1.put("商洛",611000);
        keywordMap1.put("西咸",611100);
        keywordMap1.put("兰州",620100);
        keywordMap1.put("嘉峪关",620200);
        keywordMap1.put("金昌",620300);
        keywordMap1.put("白银",620400);
        keywordMap1.put("天水",620500);
        keywordMap1.put("武威",620600);
        keywordMap1.put("张掖",620700);
        keywordMap1.put("平凉",620800);
        keywordMap1.put("酒泉",620900);
        keywordMap1.put("庆阳",621000);
        keywordMap1.put("定西",621100);
        keywordMap1.put("陇南",621200);
        keywordMap1.put("临夏",622900);
        keywordMap1.put("甘南",623000);
        keywordMap1.put("西宁",630100);
        keywordMap1.put("海东",630200);
        keywordMap1.put("海北",632200);
        keywordMap1.put("黄南",632300);
        keywordMap1.put("海南",632500);
        keywordMap1.put("果洛",632600);
        keywordMap1.put("玉树",632700);
        keywordMap1.put("海西",632800);
        keywordMap1.put("银川",640100);
        keywordMap1.put("石嘴山",640200);
        keywordMap1.put("吴忠",640300);
        keywordMap1.put("固原",640400);
        keywordMap1.put("中卫",640500);
        keywordMap1.put("乌鲁木齐",650100);
        keywordMap1.put("克拉玛依",650200);
        keywordMap1.put("吐鲁番",652100);
        keywordMap1.put("哈密",652200);
        keywordMap1.put("昌吉",652300);
        keywordMap1.put("博尔塔拉",652700);
        keywordMap1.put("巴音郭楞",652800);
        keywordMap1.put("阿克苏",652900);
        keywordMap1.put("克孜勒苏",653000);
        keywordMap1.put("喀什",653100);
        keywordMap1.put("和田",653200);
        keywordMap1.put("伊犁",654000);
        keywordMap1.put("塔城",654200);
        keywordMap1.put("阿勒泰",654300);

        keywordMap2.put("北京",110000);
        keywordMap2.put("天津",120000);
        keywordMap2.put("河北",130000);
        keywordMap2.put("山西",140000);
        keywordMap2.put("内蒙古",150000);
        keywordMap2.put("辽宁",210000);
        keywordMap2.put("吉林",220000);
        keywordMap2.put("黑龙江",230000);
        keywordMap2.put("上海",310000);
        keywordMap2.put("江苏",320000);
        keywordMap2.put("浙江",330000);
        keywordMap2.put("安徽",340000);
        keywordMap2.put("福建",350000);
        keywordMap2.put("江西",360000);
        keywordMap2.put("山东",370000);
        keywordMap2.put("河南",410000);
        keywordMap2.put("湖北",420000);
        keywordMap2.put("湖南",430000);
        keywordMap2.put("广东",440000);
        keywordMap2.put("广西",450000);
        keywordMap2.put("海南",460000);
        keywordMap2.put("重庆",500000);
        keywordMap2.put("四川",510000);
        keywordMap2.put("贵州",520000);
        keywordMap2.put("云南",530000);
        keywordMap2.put("西藏",540000);
        keywordMap2.put("陕西",610000);
        keywordMap2.put("甘肃",620000);
        keywordMap2.put("青海",630000);
        keywordMap2.put("宁夏",640000);
        keywordMap2.put("新疆",650000);

    }


    public Integer getRegionId(String string) {
        if(StringUtils.isEmpty(string)){
            return 100000;
        }

        Segment segment = HanLP.newSegment().enableCustomDictionary(true);
        List<Term> terms = segment.seg(string);
        List<String> strings =new ArrayList<>();
        for (Term term : terms) {
            if(term.nature.toString().equals("region")){
                strings.add(term.word);
            }
        }

        //先从精确map中找
        for (String s : strings) {
            if (keywordMap1.containsKey(s)) {
                return keywordMap1.get(s);
            }
        }
        //再从非精确map中找
        for (String s : strings) {
            if (keywordMap2.containsKey(s)) {
                return keywordMap2.get(s);
            }
        }
        //默认返回中国
        return 100000;
    }

    public String getRegion(String string) {
        if(StringUtils.isEmpty(string)){
            return "";
        }

        Segment segment = HanLP.newSegment().enableCustomDictionary(true);
        List<Term> terms = segment.seg(string);
        List<String> strings =new ArrayList<>();
        for (Term term : terms) {
            if(term.nature.toString().equals("region")){
                strings.add(term.word);
            }
        }

        //先从精确map中找
        for (String s : strings) {
            if (keywordMap1.containsKey(s)) {
                return s;
            }
        }
        //再从非精确map中找
        for (String s : strings) {
            if (keywordMap2.containsKey(s)) {
                return s;
            }
        }
        //默认返回其他
        return "中国";
    }

    public static void main(String[] args) {
        String  string = "搜索现场职位数据来源范围正确性各搜索条件的正确过滤③登录手机号验证码登录今天主要测试阻碍进入招聘会详情企业详情及职位详情数据显示不出来导致投递收藏相关功能无法测试1.智联招聘工作内容各种时间介绍自己匹配不到2.前程无忧工作内容介绍自己匹配不到3.猎聘网导入一直失败2018.03-至今上海网新恒天软件有限公司公司行业计算机硬件/网络设备JAVA开发2018.03-至今工作地点南京下属人数0职责业绩职责业绩本周后台管理系统大部分功能都已提测以下为系统测试进度汇总请知悉说明本段时间主要测试--后台管理系统微信端个人求职系统HR端招聘系统这三大块的整体功能所以已经测试覆盖的点暂时不再进行全量回归测试麻烦开发同学保持系统的整体稳定谢谢大家好以下为当前微信公众号端测试进度汇总今天主要测试模块为①简历在线创建简历各字段校验简历编辑简历删除②职位搜索现场职位数据来源范围正确性各搜索条件的正确过滤③登录手机号验证码登录今天主要测试阻碍进入招聘会详情企业详情及职位详情数据显示不出来导致投递收藏相关功能无法测试2016.03-2018.03杭州慧聪电子商务有限公司公司描述公司描述内容慧聪网HK8292成立于1992年是国内领先的B2B电子商务服务提供商依托其核心互联网产品买卖通以及雄厚的传统营销渠道--慧聪商情广告与中国资讯大全、研究院行业分析报告为客户提供线上、线下的全方";
        string = string.substring(0,300);
//        System.out.println(string.length());
        List<Term> terms = HanLP.newSegment().enableCustomDictionary(true).seg(string);
        List<String> strings =new ArrayList<>();
         for (Term term : terms) {
            if(term.nature.toString().equals("region")){
                System.out.println(term.word);
            }
        }
    }
}
