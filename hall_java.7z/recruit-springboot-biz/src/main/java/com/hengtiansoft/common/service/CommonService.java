package com.hengtiansoft.common.service;

import com.hengtiansoft.bean.tableModel.Recruitment;

/**
 *　
 * Created by linwu on 7/19/2018.
 */
public interface CommonService {


}
