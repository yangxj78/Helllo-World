package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

public enum EntranceTimeForAllDayEnum {

    BEFORE_TEN(0,"9:00-10:00"), BEFORE_ELEVEN(1, "10:00-11:00")
    , BEFORE_TWELVE(2,"11:00-12:00"), BEFORE_THIRTEEN(3,"12:00-13:00")
    , BEFORE_FOURTEEN(4, "13:00-14:00"), BEFORE_FIFTEEN(5, "14:00-15:00")
    , BEFORE_SIXTEEN(6, "15:00-16:00"), BEFORE_SEVENTEEN(7, "16:00-17:00")
    , BEFORE_EIGHTEEN(8, "17:00-18:00");


    private Integer code;
    private String desc;

    EntranceTimeForAllDayEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    private static final Map<Integer, EntranceTimeForAllDayEnum> map;
    static {
        map = new HashMap<>();
        for (EntranceTimeForAllDayEnum temp : EntranceTimeForAllDayEnum.values()) {
            map.put(temp.code, temp);
        }
    }

    public static Map<Integer, EntranceTimeForAllDayEnum> getMap() {
        return map;
    }
}
