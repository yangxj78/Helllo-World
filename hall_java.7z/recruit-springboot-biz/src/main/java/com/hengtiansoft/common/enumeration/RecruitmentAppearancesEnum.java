package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * 招聘会场次枚举类
 * Created by linwu on 7/18/2018.
 */
public enum RecruitmentAppearancesEnum {

    MORNING(0, "上午场"), AFTERNOON(1, "下午场"), ALL_DAY(2, "全天场");

    private Integer code;

    private String desc;

    private static final Map<Integer, RecruitmentAppearancesEnum> map;

    static {
        map = new HashMap<>();
        for (RecruitmentAppearancesEnum recruitmentAppearancesEnum : RecruitmentAppearancesEnum.values()) {
            map.put(recruitmentAppearancesEnum.code, recruitmentAppearancesEnum);
        }
    }

    RecruitmentAppearancesEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }


    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }


    public static Map<Integer, RecruitmentAppearancesEnum> getMap() {
        return map;
    }


}
