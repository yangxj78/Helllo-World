package com.hengtiansoft.common.exception;

import org.springframework.dao.DataAccessException;

public class ResourceCreateOrUpdateException extends Exception {

	public ResourceCreateOrUpdateException(DataAccessException e) {
		super(e);
	}

	public ResourceCreateOrUpdateException(String localizedMessage) {
		super(localizedMessage);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7296632023011233386L;

}
