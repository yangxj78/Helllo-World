package com.hengtiansoft.common.enumeration;

import java.util.Calendar;
import java.util.Date;

public enum AgeScopeEnum {

    UNLIMITED(38, "不限"),BETWEEN_EIGHTEEN_TWENTY_FIVE(39,"18-25岁")
    , LESS_THAN_THIRTY_FIVE(40, "26-35岁"), LESS_THAN_FIFTY(41, "36-50岁")
    , MORE_THAN_FIFTY(42, "50岁以上");

    private Integer code;
    private String desc;

    AgeScopeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static AgeScopeEnum DetermineScope(Date birthDate) {
        if(birthDate == null){
            return UNLIMITED;
        }
        Calendar cal = Calendar.getInstance();

        if (cal.before(birthDate)) {
            return UNLIMITED;
        }

        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH);
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
        cal.setTime(birthDate);

        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH);
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);

        int age = yearNow - yearBirth;

        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) {
                    age--;
                }
            }else{
                age--;
            }
        }
        if (age < 18) {
            return UNLIMITED;
        }else if ( age <= 25) {
            return BETWEEN_EIGHTEEN_TWENTY_FIVE;
        } else if (age <= 35) {
            return LESS_THAN_THIRTY_FIVE;
        } else if (age <= 50) {
            return LESS_THAN_FIFTY;
        } else {
            return MORE_THAN_FIFTY;
        }
    }
}
