package com.hengtiansoft.common.enumeration;

public enum SourceEnum {

    LOCALCREATE(32, "本地创建"),
    BOSS(33, "BOSS直聘"),
    ZHILIAN(34, "智联招聘"),
    GAOXIN(35, "高新人才网"),
    LOCALIMPORT(63, "本地导入"),
    JOB(77, "51JOB"),
    LIEPIN(76, "猎聘"),
    ;

    private Integer code;
    private String desc;

    SourceEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

}
