package com.hengtiansoft.common.enumeration;

import lombok.Getter;
import lombok.Setter;

public enum NplClassEnum {
    FULL("full", "resume full classify", new String[] { "base", "work", "edu" }), BASE("base", "resume base classify",
            new String[] { "post", "school", "other" }), WORK("work", "resume work classify", new String[] { "company",
            "date", "other" });

    @Getter
    @Setter
    private String desc;
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private String[] classArray;

    NplClassEnum(String name, String desc, String[] classArray) {
        this.desc = desc;
        this.name = name;
        this.classArray = classArray.clone();
    }
}
