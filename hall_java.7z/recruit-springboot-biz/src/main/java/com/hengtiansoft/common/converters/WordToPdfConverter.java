package com.hengtiansoft.common.converters;

import com.itextpdf.text.pdf.BaseFont;
import com.lowagie.text.DocumentException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.poi.hwpf.HWPFDocumentCore;
import org.apache.poi.hwpf.converter.WordToHtmlConverter;
import org.apache.poi.hwpf.converter.WordToHtmlUtils;
import org.docx4j.org.xhtmlrenderer.pdf.ITextFontResolver;
import org.docx4j.org.xhtmlrenderer.pdf.ITextRenderer;
import org.jsoup.Jsoup;
import org.jsoup.helper.W3CDom;
import org.springframework.core.io.ClassPathResource;
import org.w3c.dom.Document;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.io.BufferedWriter;

@Slf4j
public class WordToPdfConverter
		implements org.springframework.core.convert.converter.Converter<InputStream, OutputStream> {

	public OutputStream convert(InputStream source, boolean w3cDocument, boolean toPdf) {
		if (!w3cDocument) {
			return convert(source);
		}
		byte[] buffer = new byte[2048 * 100];
		try {
			IOUtils.read(source, buffer);
		} catch (IOException e) {
			log.error(e.getLocalizedMessage());
		}
		String jsouString = new String(buffer);
		org.jsoup.nodes.Document jsoupDocument = Jsoup.parse(jsouString);

		W3CDom w3cDom = new W3CDom();
		Document w3cDoc = w3cDom.fromJsoup(jsoupDocument);

		byte[] byteArrays = null;
		try {
			byteArrays = writeDocument(w3cDoc);
		} catch (TransformerFactoryConfigurationError | TransformerException | IOException e) {
			log.error(e.getLocalizedMessage());
		}
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

		if (toPdf) {
			try {
				return generatePdf(byteArrays);
			} catch (DocumentException | IOException e) {
				log.error(e.getLocalizedMessage());
			}
		}
		if (outputStream.size() == 0) {
			try {
				IOUtils.write(byteArrays, outputStream);
			} catch (IOException e1) {
				log.error(e1.getLocalizedMessage());
			}
		}
		return outputStream;
	}

	@Override
	public OutputStream convert(InputStream source) {

		Document document = null;
		try {
			document = toDocument(source);
		} catch (IOException | ParserConfigurationException | FactoryConfigurationError e) {
			log.error(e.getLocalizedMessage());
		}

		byte[] byteArrays = null;
		try {
			byteArrays = writeDocument(document);
		} catch (TransformerFactoryConfigurationError | TransformerException | IOException e) {
			log.error(e.getLocalizedMessage());
		}

		try {
			return generatePdf(byteArrays);
		} catch (DocumentException | IOException e) {
			log.error(e.getLocalizedMessage());
		}
		return null;
	}

	private OutputStream generatePdf(byte[] byteArrays) throws com.lowagie.text.DocumentException, IOException {
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			ITextRenderer renderer = new ITextRenderer();
			renderer.setDocumentFromString(new String(byteArrays));
			ITextFontResolver fontResolver = renderer.getFontResolver();

			ClassPathResource resource = new ClassPathResource("fonts/SIMSUN.TTC");

			fontResolver.addFont(resource.getPath(), BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
			renderer.getSharedContext().setBaseURL("file:/D:/test");
			renderer.layout();
			renderer.createPDF(out);
			return out;
		} catch (Exception e) {
			log.error(e.getLocalizedMessage());
		}
		return null;
	}

	public byte[] writeDocument(Document document) throws TransformerFactoryConfigurationError, TransformerException, IOException {
		byte[] byteArrays = null;

		try (ByteArrayOutputStream out = new ByteArrayOutputStream();
				OutputStreamWriter osw = new OutputStreamWriter(out);
				Writer writer = new BufferedWriter(osw);) {

			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(writer);

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer serializer = tf.newTransformer();

			serializer.setOutputProperty("encoding", "UTF-8");
			serializer.setOutputProperty("indent", "yes");
			serializer.setOutputProperty("method", "html");
			serializer.transform(domSource, streamResult);
			byteArrays = out.toByteArray();
		}
		return byteArrays;
	}

	public Document toDocument(InputStream source)
			throws IOException, ParserConfigurationException, FactoryConfigurationError {
		HWPFDocumentCore wordDocument = WordToHtmlUtils.loadDoc(source);
		WordToHtmlConverter wordToHtmlConverter = new WordToHtmlConverter(
				DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument());
		wordToHtmlConverter.processDocument(wordDocument);
		Document document = wordToHtmlConverter.getDocument();
		return document;
	}
}
