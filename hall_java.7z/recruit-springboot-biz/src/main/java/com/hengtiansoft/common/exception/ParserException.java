package com.hengtiansoft.common.exception;

public class ParserException extends Exception {

	private static final long serialVersionUID = 5236994110237290584L;

	public ParserException(Exception e) {
		super(e);
	}
	
	public ParserException() {
	}
	
	public ParserException(String e) {
		super(e);
	}

}
