package com.hengtiansoft.common.exception;

public class ResumeExistException extends Exception{
	
	public ResumeExistException(String string) {
		super(string);
	}

	public ResumeExistException(Exception e) {
		super(e);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -7522355143255339974L;

}
