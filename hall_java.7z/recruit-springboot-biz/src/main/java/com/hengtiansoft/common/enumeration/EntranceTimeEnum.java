package com.hengtiansoft.common.enumeration;

import com.hengtiansoft.bean.tableModel.QrCodeRecord;

import java.util.HashMap;
import java.util.Map;

public enum EntranceTimeEnum {

    TAG_FOR_MORNING(-1,""),BEFORE_NINE_THIRTY(0,"9:00-9:30"),BEFORE_TEN(1,"9:30-10:00"), BEFORE_TEN_THIRTY(2, "10:00-10:30")
    , BEFORE_ELEVEN(3,"10:30-11:00"),BEFORE_ELEVEN_THIRTY(4,"11:00-11:30"), BEFORE_TWELVE(5, "11:30-12:00")
    , BEFORE_TWELVE_THIRTY(6,"12:00-12:30"), BEFORE_THIRTEEN(7,"12:30-13:00"), BEFORE_THIRTEEN_THIRTY(8, "13:00-13:30")
    , BEFORE_FOURTEEN(9,"13:30-14:00"), BEFORE_FOURTEEN_THIRTY(10, "14:00-14:30"), BEFORE_FIFTEEN(11, "14:30-15:00")
    , BEFORE_FIFTEEN_THIRTY(12, "15:00-15:30"),BEFORE_SIXTEEN(13,"15:30-16:00"), BEFORE_SIXTEEN_THIRTY(14, "16:00-16:30")
    , BEFORE_SEVENTEEN(15, "16:30-17:00"), BEFORE_SEVENTEEN_THIRTY(16, "17:00-17:30"), BEFORE_EIGHTEEN(17, "17:30-18:00"),
    TAG_FOR_AFTERNOON(19,"");


    private Integer code;
    private String desc;

    EntranceTimeEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    private static final Map<Integer, EntranceTimeEnum> map;
    static {
        map = new HashMap<>();
        for (EntranceTimeEnum entranceTimeEnum : EntranceTimeEnum.values()) {
            map.put(entranceTimeEnum.code, entranceTimeEnum);
        }
    }

    public static EntranceTimeEnum verifyTime(QrCodeRecord record) {
        int hour = Integer.parseInt(record.getCreateTs().substring(11,13));
        int min = Integer.parseInt(record.getCreateTs().substring(14, 16));

        int temp = hour * 2 + (min > 30 ? 1 : 0) - 18;
        return map.get(temp);
    }

}
