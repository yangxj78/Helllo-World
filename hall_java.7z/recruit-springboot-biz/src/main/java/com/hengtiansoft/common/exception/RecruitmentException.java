package com.hengtiansoft.common.exception;

/**
 * 招聘会相关异常
 * Created by linwu on 7/20/2018.
 */
public class RecruitmentException extends BaseException{


    public RecruitmentException() {
        super();
    }


    public RecruitmentException(String s) {
        super(s);
    }

    public RecruitmentException(DisplayableError error, String s) {
        super(error, s);
    }

}
