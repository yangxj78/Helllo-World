package com.hengtiansoft.common.utils;

import org.apache.commons.io.IOUtils;
import org.jsoup.Jsoup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;

public class Html2MHTUtils {

    private static final Logger log = LoggerFactory.getLogger(Html2MHTUtils.class);

    public static String mht2html(InputStream inputStream) {
        return getMimeMessageContent(ExtendIOUtils.toString(inputStream),false);
    }

    public static String mht2htmlEncoded(String s) {
        return getMimeMessageContent(s,true);
    }

    public static String getName(String strName, int ID) {
        char separator = '/';
        if (strName.lastIndexOf(separator) >= 0)
            return format(strName.substring(strName.lastIndexOf(separator) + 1));
        return "temp" + ID;
    }

    private static String getEncoding(MimeBodyPart bp) {
        String[] header = null;
        try {
            header = bp.getHeader("Content-Type");
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return Arrays.asList(header).stream().map((key) -> {
            int pos = key.indexOf("charset=");
            key = pos == -1 ? "gbk" : key.substring(pos + 8, key.length());
            if (key.toLowerCase().compareTo("gb2312") == 0) {
                key = "gbk";
            }
            return key;
        }).findFirst().get();
    }

    private static String format(String strName) {
        if (strName == null)
            return null;
        strName = strName.replaceAll("     ", " ");
        String strText = "\\/:*?\"<>|^___FCKpd___0quot;";
        for (int i = 0; i < strName.length(); ++i) {
            String ch = String.valueOf(strName.charAt(i));
            if (strText.indexOf(ch) != -1) {
                strName = strName.replace(strName.charAt(i), '-');
            }
        }
        return strName;
    }

    public static String getTitle(String mhtFilename) {
        String content = getMimeMessageContent(mhtFilename,false);
        int begin = content.indexOf("<title>");
        int end = content.indexOf("</title>");
        if (begin != -1 && end != -1 && end > begin) {
            return content.substring(begin + 7, end).trim();
        }
        return null;
    }

    private static String getMimeMessageContent(String mhtFilename,boolean encoded) {
        try {
            byte[] bytes = mhtFilename.getBytes();
            ByteArrayInputStream stream = new ByteArrayInputStream(bytes);
            Session mailSession = Session.getInstance(System.getProperties(), null);
            MimeMessage msg = new MimeMessage(mailSession, stream);
            Object content = msg.getContent();
            if (content instanceof Multipart) {
                MimeMultipart mp = (MimeMultipart) content;
                MimeBodyPart bp1 = (MimeBodyPart) mp.getBodyPart(0);
                String strText="";
                if(encoded){
                    strText = getHtmlText(bp1);
                }else {
                    String strEncodng = getEncoding(bp1);
                    strText = getHtmlTextByEncoding(bp1, strEncodng);
                }
                if (strText != null)
                    strText = strText.toLowerCase();
                return strText;
            }
            String strContent = (String) content;
            return Jsoup.parse(strContent).outerHtml();
        } catch (FileNotFoundException e) {
            log.error("file not found" + e.getMessage());
        } catch (MessagingException e) {
            log.error("message exception" + e.getMessage());
        } catch (IOException e) {
            log.error("io exception :" + e.getMessage());
        }
        return null;
    }

    private static String getHtmlText(MimeBodyPart bp) {

        byte[] buffer = new byte[1024];
        int length;
        String str = "";
        try (InputStream textStream = bp.getInputStream();
             ByteArrayOutputStream result = new ByteArrayOutputStream()) {
            while ((length = textStream.read(buffer)) != -1) {
                result.write(buffer, 0, length);
            }

            str = result.toString();
        } catch (IOException | MessagingException e) {
            e.printStackTrace();
        }
        return str;
    }
    private static String getHtmlTextByEncoding(MimeBodyPart bp, String strEncoding) {
        String content = null;
        try {
            InputStream textStream = bp.getInputStream();
            content = IOUtils.toString(textStream, strEncoding.replace("\"", ""));
            IOUtils.closeQuietly(textStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    public static void saveFile(String strText, String savePath) {
        try {
            Files.write(Paths.get(savePath), strText.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
