package com.hengtiansoft.common.service.impl;

import com.hengtiansoft.bean.tableModel.Recruitment;
import com.hengtiansoft.common.service.CommonService;

/**
 * Created by linwu on 7/20/2018.
 */
public class CommonServiceImpl implements CommonService{


}
