package com.hengtiansoft.common.enumeration;

import lombok.Getter;
import lombok.Setter;

public enum SexEnum {
	MAN("man","男"),
	WOMAN("woman","女");
	
	@Getter @Setter private String desc;
	@Getter @Setter private String name;
	
	SexEnum(String name, String desc){
		this.desc = desc;
	}
}
