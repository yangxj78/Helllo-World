package com.hengtiansoft.common.enumeration;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public enum EducationalEnum {
    DOCTOR(65,"博士研究生")
    ,MASTER(66,"硕士研究生")
    ,UNDERGRADUATE_COLLEGE(67,"大学本科")
    , COLLEGE(68, "大学专科")
    , SECONDARY_SPECIALIST(69, "中等专科")
    ,VOCATIONAL_HIGH_SCHOOL(70, "职业高中")
    ,TECHNICAL_SCHOOL(71, "技工学校")
    ,ORDINARY_HIGH_SCHOOL(72, "普通高中")
    ,JUNIOR_MIDDLE_SCHOOL(73, "初中")
    ,PRIMARY_SCHOOL(74, "小学")
    ,OTHER(75, "其他")
    ;

    private Integer code;
    private String desc;
    private static final Map<Integer, EducationalEnum> map;

    static {
        map = new HashMap<>();
        for (EducationalEnum educationalEnum : EducationalEnum.values()) {
            map.put(educationalEnum.code, educationalEnum);
        }
    }

    EducationalEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Integer verifyEducation(String str) {
        if (StringUtils.isEmpty(str)) {
            return OTHER.getCode();
        }
        if (str.contains("博士")){
            return DOCTOR.getCode();
        } else if (str.contains("硕士")||str.contains("研究生")) {
            return MASTER.getCode();
        } else if (str.contains("本科")) {
            return UNDERGRADUATE_COLLEGE.getCode();
        } else if (!str.contains("大专以下")&&(str.contains("大专")||str.contains("大学专科"))) {
            return COLLEGE.getCode();
        } else if (str.contains("中等专科")) {
            return SECONDARY_SPECIALIST.getCode();
        } else if (str.contains("职业高中")) {
            return VOCATIONAL_HIGH_SCHOOL.getCode();
        } else if (str.contains("技工学校")) {
            return TECHNICAL_SCHOOL.getCode();
        } else if (str.contains("高中")) {
            return ORDINARY_HIGH_SCHOOL.getCode();
        } else if (str.contains("初中")) {
            return JUNIOR_MIDDLE_SCHOOL.getCode();
        } else if (str.contains("小学")) {
            return PRIMARY_SCHOOL.getCode();
        } else {
            return OTHER.getCode();
        }
    }

    public static String getEduDesc(int code) {
        switch (code) {
            case 65: return "博士研究生";
            case 66: return "硕士研究生";
            case 67: return "大学本科";
            case 68: return "大学专科";
            case 69: return "中等专科";
            case 70: return "职业高中";
            case 71: return "技工学校";
            case 72: return "普通高中";
            case 73: return "初中";
            case 74: return "小学";
            default: return "其他";
        }
    }

    public static Map<Integer, EducationalEnum> getMap() {
        return map;
    }
}
