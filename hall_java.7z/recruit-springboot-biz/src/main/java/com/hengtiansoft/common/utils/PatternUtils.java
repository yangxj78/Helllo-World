package com.hengtiansoft.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternUtils {

	public static String getReguText(String regu, String target) {
		Pattern yearsPattern = Pattern.compile(regu);
		Matcher yearsMatch = yearsPattern.matcher(target);
		if (yearsMatch.find() && yearsMatch.groupCount() > 0) {
			return yearsMatch.group(1);
		}
		return null;
	}
}
