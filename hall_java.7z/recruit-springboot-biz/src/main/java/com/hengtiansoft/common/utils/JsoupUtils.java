package com.hengtiansoft.common.utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.Arrays;
import java.util.ListIterator;

public class JsoupUtils {

	public static String parseRegularByDocument(Document document, String regu) {
		String elementStr = document.select(":matchesOwn(" + regu + ")").text();
		return PatternUtils.getReguText(regu, elementStr);
	}

	public static String parseContainTextByDocument(Document document, String regu) {
		Elements elements = document.select(":containsOwn(" + regu + ")");
		return elements.text();
	}

	public static String parseParentContainTextByDocument(Document document, String regu) {
		Elements elements = document.select(":containsOwn(" + regu + ")");
		if (elements != null && elements.parents() != null && elements.parents().size() > 0) {
			Element parentElement = elements.parents().get(0);
			return parentElement.text().replace(regu, "");
		}
		return null;
	}

	public static Elements parseParentsElementByDocument(Document document, String regu) {
		Elements elements = document.select(":containsOwn(" + regu + ")");
		if (elements != null && elements.parents() != null) {
			return elements.parents();
		}
		return null;
	}

	public static String getAllStringByTagSpan(String content) {
		return getTagByName(content, "span");
	}

	public static String getAllStringByTagTd(String content) throws InterruptedException {
		return getTagByName(content, "td");
	}

	public static Element getTagByFilter(String content, String tag, String filterTag, String... filterValue) {
		Document document = Jsoup.parse(content);
		Elements tagElements = document.getElementsByTag(tag);

		return doGetElementByFilterCondition(tagElements, filterTag, filterValue);
	}

	private static Element doGetElementByFilterCondition(Elements e, String filterTag, String... filterValues) {
		ListIterator<Element> listIterator = e.listIterator();

		while (listIterator.hasNext()) {
			Element filterElement = listIterator.next();

			if (getMatchedString(filterElement, filterValues) != null) {
				return filterElement;
			}
			doGetElementByFilterCondition(listIterator.next(), filterTag, filterValues);
		}
		return null;
	}

	private static Element doGetElementByFilterCondition(Element e, String filterTag, String... filterValues) {
		Elements filterElements = e.getElementsByTag(filterTag);

		ListIterator<Element> filterIterator = filterElements.listIterator();

		while (filterIterator.hasNext()) {
			Element filterElement = filterIterator.next();

			if (getMatchedString(filterElement, filterValues) != null) {
				return filterElement;
			}
			doGetElementByFilterCondition(e, filterTag, filterValues);
		}
		return null;
	}

	private static Element getMatchedString(Element filterElement, String... filterValues) {
		for (String str : Arrays.asList(filterValues)) {
			if (filterElement.text() != null && filterElement.text().contains(str)) {
				return filterElement;
			}
		}
		return null;
	}

	private static String getTagByName(String content, String tagName) {
		StringBuffer sb = new StringBuffer();
		Document document = Jsoup.parse(content);
		document.getElementsByTag(tagName).stream().forEach((e) -> {
			sb.append(e.text());
			sb.append(">");
		});
		return sb.toString();
	}

	public static String parseParentContainHTMLByDocument(Document document, String string) {
		Elements elements = document.select(":matchesOwn(" + string + ")");
		if (elements != null && elements.parents() != null && elements.parents().size() > 0) {
			Element parentElement = elements.parents().get(0);
			if (parentElement != null && parentElement.parents() != null && parentElement.parents().size() > 0) {
				Element parElement = parentElement.parents().get(0);
				return parElement.select("table :eq(0)").outerHtml();
			}

		}
		return null;
	}
}
