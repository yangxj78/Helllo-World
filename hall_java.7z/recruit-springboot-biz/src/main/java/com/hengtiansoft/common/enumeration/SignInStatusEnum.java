package com.hengtiansoft.common.enumeration;

import java.util.HashMap;
import java.util.Map;

/**
 * 招聘会场次枚举类
 * Created by linwu on 7/18/2018.
 */
public enum SignInStatusEnum {

    NULL(0, "未签到"), SIGN_IN(1, "已签到"), SIGN_OUT(2, "已签退");

    private Integer code;

    private String desc;

    private static final Map<Integer, SignInStatusEnum> map;

    static {
        map = new HashMap<>();
        for (SignInStatusEnum signInStatusEnum : SignInStatusEnum.values()) {
            map.put(signInStatusEnum.code, signInStatusEnum);
        }
    }

    SignInStatusEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }


    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }


    public static Map<Integer, SignInStatusEnum> getMap() {
        return map;
    }


}
