package com.hengtiansoft.common.converters;

import com.hengtiansoft.bean.ipeopleModel.ConentType;
import com.hengtiansoft.common.constant.MagicNumConstant;
import com.hengtiansoft.common.enumeration.NplClassEnum;
import com.hengtiansoft.common.exception.CustomException;
import lombok.Data;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.ansj.domain.Result;
import org.ansj.domain.Term;
import org.ansj.library.DicLibrary;
import org.ansj.recognition.impl.StopRecognition;
import org.ansj.splitWord.analysis.DicAnalysis;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Slf4j
@Service
public class NplMatcher {

    private static String[] filterChar = {"：", ":", " ", "|", "　　", "&nbsp;" };

    private String CLASS_URL ="http://10.6.11.229:5555/getClassification";

    private static ExecutorService exec = Executors.newCachedThreadPool();
    static {
        for (int i = 0; i < MagicNumConstant.TWENTY; i++) {
            DicLibrary.insert(DicLibrary.DEFAULT, i + "年工作经验", "userDefine", MagicNumConstant.ONE_THOUSAND);
        }
    }

    class NplClassEnumUrl {
        @Getter
        private NplClassEnum nplClassEnum;
        @Getter
        private String classUrl;

        public NplClassEnumUrl(NplClassEnum nplClassEnum) throws CustomException {
            this.nplClassEnum = nplClassEnum;
            if (NplClassEnum.FULL == nplClassEnum) {
                this.classUrl = CLASS_URL;
            } else {
                throw new CustomException("npl classEnum is not for classUrl NplClassEnum:" + nplClassEnum.getName());
            }
        }
    }

    public Map<String, String> processChildClassTxt(ConentType contentType, NplClassEnum nplClassEnum) throws Exception {
        NplClassEnumUrl nplClassEnumUrl = new NplClassEnumUrl(nplClassEnum);
        Map<String, String> classContentMap = new HashMap<String, String>();
        String content = contentType.getContent();
        String[] contentLines = content.split("\n");
        if (contentLines != null) {
            for (String originLine : contentLines) {
                if (StringUtils.isNotBlank(originLine)) {
                    parseClass(classContentMap, originLine, nplClassEnumUrl);
                }
            }
        }
        return classContentMap;
    }

    public Map<String, String> processTxt(ConentType contentType) throws Exception {
        NplClassEnumUrl nplClassEnumUrl = new NplClassEnumUrl(NplClassEnum.FULL);
        Map<String, String> classContentMap = new HashMap<String, String>();
        String content = "";
        if ("docx".equals(contentType.getType())) {
            content = contentType.getContent();
        } else {
            content = contentType.getContent();
            if ("mht".equals(contentType.getType()) || "htm".equals(contentType.getType())
                    || "html".equals(contentType.getType())) {
                content = filtercontent(contentType.getContent());
            } else {
                content = filterContent(content);
            }
        }
        if (content != null) {
            String[] contentLines = null;
            String os = System.getProperty("os.name");
            if (os.toLowerCase().startsWith("win")) {
                contentLines = content.split("\r");
                if (contentLines.length == 1) {
                    contentLines = content.split("\n");
                }
            } else {
                contentLines = content.split("\n");
                if (contentLines != null && contentLines.length == 1 && content.contains("\r")) {
                    contentLines = content.split("\r");
                }
            }
            if (contentLines != null) {
                List<ClassifyEntity> contentLineList = new ArrayList<ClassifyEntity>();
                for (int i = 0; i < contentLines.length; i++) {
                    contentLineList.add(new ClassifyEntity(contentLines[i], null));
                }
                final CountDownLatch latch = new CountDownLatch(contentLineList.size());
                for (ClassifyEntity classifyEntity : contentLineList) {
                    exec.submit(new ClassifyCallable(latch, classifyEntity, nplClassEnumUrl));
                }
                latch.await();
                for (ClassifyEntity classifyEntity : contentLineList) {
                    String[] classArray = nplClassEnumUrl.getNplClassEnum().getClassArray();
                    if (classifyEntity.getClassLine() != null) {
                        for (String classStr : classArray) {
                            appendFinalClassContentMap(classStr, classifyEntity.getClassLine(),
                                    classifyEntity.getOriginLine() + "\n", classContentMap);
                        }
                    }
                }
            }
        }
        return classContentMap;
    }

    @Data
    class ClassifyEntity {
        private String originLine;
        private String classLine;

        public ClassifyEntity(String originLine, String classLine) {
            this.originLine = originLine;
            this.classLine = classLine;
        }
    }

    class ClassifyCallable implements Callable<String> {
        private ClassifyEntity classifyEntity;
        private NplClassEnumUrl nplClassEnumUrl;
        private CountDownLatch latch;

        public ClassifyCallable(CountDownLatch latch, ClassifyEntity classifyEntity, NplClassEnumUrl nplClassEnumUrl) {
            this.classifyEntity = classifyEntity;
            this.nplClassEnumUrl = nplClassEnumUrl;
            this.latch = latch;
        }

        @Override
        public String call() throws Exception {
            parseClass(classifyEntity, nplClassEnumUrl);
            latch.countDown();
            return "done";
        }
    }

    private void parseClass(ClassifyEntity classifyEntity, NplClassEnumUrl nplClassEnumUrl) throws Exception {
        StopRecognition filter = getStopWord();
        String segLine = lineProcess(classifyEntity.getOriginLine(), filter, true);
        String classLine = generalClass(segLine, nplClassEnumUrl.getClassUrl());// 得到具体分类
        classifyEntity.setClassLine(classLine);
    }

    private void parseClass(Map<String, String> classContentMap, String originLine, NplClassEnumUrl nplClassEnumUrl)
            throws Exception {
        StopRecognition filter = getStopWord();
        String segLine = lineProcess(originLine, filter, true);
        String classLine = generalClass(segLine, nplClassEnumUrl.getClassUrl());// 得到具体分类
        String[] classArray = nplClassEnumUrl.getNplClassEnum().getClassArray();
        if (classLine != null) {
            for (String classStr : classArray) {
                appendFinalClassContentMap(classStr, classLine, originLine + "\n", classContentMap);
            }
        }
    }

    /**
     * Description: TODO
     *
     * @param content
     * @return
     */
    public String filterContent(String content) {
        String newContent = "";
        if (content != null) {
            for (int i = 0; i < filterChar.length; i++) {
                if (i == 0) {
                    newContent = content.replaceAll(filterChar[i], "");
                } else {
                    newContent = newContent.replaceAll(filterChar[i], "");
                }
            }
        }
        newContent = newContent.trim();
        return newContent;
    }

    /**
     * Description: TODO
     *
     * @param content
     * @return
     */
    public String filtercontent(String content) {
        return content.replaceAll("\\s*", "").replaceAll("<xml>.*?</xml>", "").replaceAll("<style>.*?</style>", "")
                .replaceAll("<.*?>", "");
    }

    private void appendFinalClassContentMap(String classStr, String classLine, String originLine,
            Map<String, String> lineMap) {
        if (classLine != null) {
            if (classLine.indexOf(classStr) > -1) {
                if (lineMap.get(classStr) != null) {
                    lineMap.put(classStr, (lineMap.get(classStr) + "\n" + originLine));
                } else {
                    lineMap.put(classStr, originLine);
                }
            }
        }
    }

    public String generalClass(String lineContent, String classUrl) throws Exception {
        String line, resultStr = "";
        HttpURLConnection conn = null;
        try {
            String newUrl = classUrl + "?t=" + URLEncoder.encode(lineContent, "UTF-8");
            URL restURL = new URL(newUrl);
            conn = (HttpURLConnection) restURL.openConnection();
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            // 设置访问提交模式，表单提交
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setUseCaches(false); // 不允许缓存
            conn.setRequestMethod("GET");
            conn.setAllowUserInteraction(false);
            conn.setConnectTimeout(1000000);// 连接超时 单位毫秒
            conn.setReadTimeout(20000000);// 读取超时 单位毫秒
            conn.setDoInput(true);
            int resultCode = conn.getResponseCode();
            if (HttpURLConnection.HTTP_OK == resultCode) {
                BufferedReader bReader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while (null != (line = bReader.readLine())) {
                    resultStr += line;
                }
                bReader.close();
            }
        } catch (IOException e) {
            log.error("npl net work error:" + e.getLocalizedMessage());
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
        return resultStr;
    }

    private String lineProcess(String info, StopRecognition filter, boolean needFilter) {
        if (info == null) {
            info = "";
        }
        Result result = DicAnalysis.parse(info);
        Result resultNew = result;
        if (needFilter) {
            resultNew = result.recognition(filter);
        }
        List<Term> listTerm = resultNew.getTerms();
        StringBuilder sb = new StringBuilder("");
        for (Term term : listTerm) {
            sb.append(term.getName() + " ");
        }
        return sb.toString();
    }

    private StopRecognition getStopWord() {
        StopRecognition filter = new StopRecognition();
        filter.insertStopWords("，");
        filter.insertStopWords("。");
        filter.insertStopWords("：");
        filter.insertStopWords("、");
        filter.insertStopWords("；");
        filter.insertStopWords(".");
        filter.insertStopWords(". ");
        return filter;
    }

    public static void main(String[] args) {
        String originLine = "垂直制G表符asGcii码G换行";
        char a = '7';// \v,垂直制表符ascii码换行
        char[] oriChars = originLine.toCharArray();
        List<String> tableRowList = new ArrayList<String>();
        int idx = 0;
        for (int i = 0; i < oriChars.length - 1; i++) {
            if (oriChars[i] == a && oriChars[i] > 0) {
                String subLine = originLine.substring(idx, i);
                tableRowList.add(subLine);
                idx = i + 1;
            }
        }
        if (idx > 0) {
            String subLine = originLine.substring(idx, oriChars.length);
            tableRowList.add(subLine);
        }
    }
}
