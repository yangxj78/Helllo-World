package com.hengtiansoft.common.enumeration;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum WorkYearsEnum {

    GRADUATE(2, "应届毕业生")
    , LESS_THAN_TWO_YEAR(3, "2年以下")
    , LESS_THAN_FIVE_YEAR(4, "3-5年")
    , LESS_THAN_EIGHT_YEAR(5, "5-8年")
    , MORE_THAN_EIGHT_YEAR(6, "8年以上"),
    ;


    private Integer code;
    private String desc;

    WorkYearsEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    private static final Map<Integer, WorkYearsEnum> map;
    static {
        map = new HashMap<>();
        for (WorkYearsEnum workYearsEnum : WorkYearsEnum.values()) {
            map.put(workYearsEnum.code, workYearsEnum);
        }
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static Integer verifyWorkYears(String str) {
        if (StringUtils.isEmpty(str)) {
            return LESS_THAN_TWO_YEAR.getCode();
        }
        str = StringUtils.deleteWhitespace(str);
        if (str.contains("应届") || str.contains("毕业生")) {
            return GRADUATE.getCode();
        }
        String regex = "^[0-9]*";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            if (StringUtils.isEmpty(matcher.group())) {
                return LESS_THAN_TWO_YEAR.getCode();
            }
            int year = Integer.parseInt(matcher.group());
            if (year <= 2) {
                return LESS_THAN_TWO_YEAR.getCode();
            } else if (year <= 5) {
                return LESS_THAN_FIVE_YEAR.getCode();
            } else if (year < 8) {
                return LESS_THAN_EIGHT_YEAR.getCode();
            } else {
                return MORE_THAN_EIGHT_YEAR.getCode();
            }
        }
        return LESS_THAN_TWO_YEAR.getCode();
    }

    public static String getDescByCode(Integer code){
        if(map.get(code) != null){
            return map.get(code).desc;
        }
        return "无该工作年限字典数据"+code;
    }

}
