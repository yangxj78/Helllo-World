package com.hengtiansoft.common.exception;

public class ConvertResumeException extends Exception {

	public ConvertResumeException(String localizedMessage) {
		super(localizedMessage);
	}

	public ConvertResumeException(Exception e) {
		super(e);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 9197277851161969461L;

}
