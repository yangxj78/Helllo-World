package com.hengtiansoft.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.artofsolving.jodconverter.OfficeDocumentConverter;
import org.artofsolving.jodconverter.office.DefaultOfficeManagerConfiguration;
import org.artofsolving.jodconverter.office.OfficeManager;

import java.io.*;
import java.util.regex.Pattern;

@Slf4j
public class libreOfficeWordToPdf {
    public static void main(String[] args) throws Exception {
        String wordpath = "D:\\aaa\\test\\word";
        String pdfpath = "D:\\aaa\\test\\pdf\\";
        String textpath = "D:\\aaa\\test\\text\\";

        File file = new File(wordpath);

        File fa[] = file.listFiles();
        for (File f : fa) {

            String string = f.getName();

            try {
                String name = string.substring(0, string.lastIndexOf(".")) + ".pdf";
                String textName = string.substring(0, string.lastIndexOf(".")) + ".txt";

                String padf = pdfpath + name;
                word2PDF(f.getPath(), padf);
                InputStream inputStream = new FileInputStream(new File(padf));
                String text = ReadPDFUtil.paserPDFFileByIText(inputStream);
                IOUtils.copy(new ByteArrayInputStream(text.getBytes()), new FileOutputStream(textpath + textName));

            } catch (Exception e) {

            }

        }
    }

    public static String getOfficeHome() {
        String osName = System.getProperty("os.name");
        if (Pattern.matches("Linux.*", osName)) {
            return "/opt/libreoffice5.3";
        } else if (Pattern.matches("Windows.*", osName)) {
            return "C:/Program Files/LibreOffice 5";
        } else if (Pattern.matches("Mac.*", osName)) {
            return "/Application/OpenOffice.org.app/Contents";
        }
        return null;
    }

    public static boolean word2PDF(String docxPath, String pdfPath) {
        OfficeManager officeManager = null;

        try {

            File inputFile = new File(docxPath);
            String libreOfficePath = getOfficeHome();
            log.debug("libreOfficePath:" + libreOfficePath);
            // 此类在jodconverter中3版本中存在，在2.2.2版本中不存在
            DefaultOfficeManagerConfiguration configuration = new DefaultOfficeManagerConfiguration();
            // libreOffice的安装目录
            configuration.setOfficeHome(new File(libreOfficePath));
            // 端口号
            configuration.setPortNumber(8100);
            // 设置任务队列超时为24小时
            officeManager = configuration.buildOfficeManager();
            officeManager.start();
            OfficeDocumentConverter converter = new OfficeDocumentConverter(officeManager);
            File outputFile = new File(pdfPath);
            converter.convert(inputFile, outputFile);
            // 转换结束
            return true;
        } catch (Exception e) {
            log.debug("libreOfficeWordToPdfError" + e.getMessage());
        } finally {
            if (officeManager != null) {
                officeManager.stop();
            }
        }
        return false;
    }
}
